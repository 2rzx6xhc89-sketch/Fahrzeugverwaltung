# Einsatzverwaltung mit Atemschutzüberwachung auf dem Raspberry Pi einrichten

Stand: Version 5.205.0 (23.10.2026) · Die Bedienung steht in `docs/BEDIENUNG.md`, Betrieb und Notfall (Update, Sicherung zurückspielen, Pi tauschen) in `docs/BETRIEBSHANDBUCH.md`.

Diese Anleitung richtet die App so ein, dass sie dauerhaft auf einem Raspberry Pi läuft.
Alle Geräte im selben WLAN (Gerätehaus, Leitstelle) sehen dann dieselben Live-Daten –
Änderungen erscheinen bei allen praktisch sofort. Für Besatzungen auf ihrem eigenen
Handy, unterwegs, gibt es zusätzlich einen eigenen, streng eingeschränkten Melde-Link –
eine eigene Fahrzeug-App pro Fahrzeug (FMS-Status, Stärke, Standort alle 2 Minuten), die sich
gefahrlos auch von außerhalb des WLANs freigeben lässt (Schritt 8) – ganz ohne VPN-App.

**Was du brauchst:**
- Einen Raspberry Pi (Modell 3B+ oder neuer reicht locker) mit Raspberry Pi OS
- Eine Fritz!Box, an der der Pi per Kabel oder WLAN hängt
- Die Dateien aus diesem Projekt: `server.js`, `einsatz.js`, `package.json` und die Ordner `public/`
  (App Einsatzverwaltung), `asue/` (App Atemschutzüberwachung) und `melde/` (Fahrzeug-App)

**Inhalt:** Schnellinstallation · 1. Node.js auf dem Pi installieren · 2. Projekt auf den Pi übertragen · 3. Abhängigkeiten installieren · 4. Server testweise starten · 5. Server dauerhaft laufen lassen (Autostart) · 6. Feste IP-Adresse für den Pi in der Fritz!Box vergeben · 7. Von den Geräten im Gerätehaus/Fahrzeugen zugreifen · 8. Fahrzeug-App – der Meldeserver (Port 8081) · 9. Daten sichern (Backup) · 10. App aktualisieren · Kurz zur Bedienung · 11. App Atemschutzüberwachung (ASÜ) auf dem Pi · 12. Umstieg von der bisherigen „Fahrzeugverwaltung“ · 13. ASÜ über Mobilfunk und mit mehreren Geräten · 14. what3words in der Lagekarte · 15. Automatische Sicherung auf USB-Stick oder Netzlaufwerk · 16. Übungsgenerator auch unterwegs (GitHub Pages, ab Version 3.16) · 17. Alarmmonitor im Gerätehaus · 18. Gefahrstoffdatenbank, Übungsleitstelle und Startansicht der Karte · 19. Atemschutz-Datenbank für die Gerätewarte · Fehlersuche · Anhang: Hinweise zu einzelnen Versionen

---

## Schnellinstallation (empfohlen)

Das Installationsskript erledigt die Schritte 1 bis 5 und die Übernahme einer alten
„Fahrzeugverwaltung“ automatisch. ZIP auf den Pi kopieren (z. B. `scp einsatzverwaltung-pi.zip pi@<IP>:~`), dann am Pi:

```bash
cd ~
unzip -o einsatzverwaltung-pi.zip
cd ~/einsatzverwaltung
bash install.sh
```

Als normaler Benutzer starten, nicht mit `sudo` – das Skript fragt selbst nach dem Passwort,
wo es nötig ist. Danach weiter mit Schritt 6 (feste IP) und Schritt 8 (https für die Fahrzeug-App).
Die Schritte 1–5 unten beschreiben dasselbe von Hand, falls etwas schiefgeht.

---

## 1. Node.js auf dem Pi installieren

Am Pi anmelden (per Bildschirm/Tastatur oder per SSH von einem anderen Rechner) und im Terminal:

```bash
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs
```

Prüfen, ob es geklappt hat:

```bash
node -v
npm -v
```

Beides sollte eine Versionsnummer anzeigen (z. B. `v20.x.x`).

---

## 2. Projekt auf den Pi übertragen

Auf dem Pi ein Verzeichnis anlegen:

```bash
mkdir -p ~/einsatzverwaltung
cd ~/einsatzverwaltung
```

Jetzt die Dateien/Ordner (`server.js`, `einsatz.js`, `package.json`, `public/`, `asue/`, `melde/`) in genau dieses Verzeichnis kopieren. Wie du das machst, ist egal – z. B.:

- **USB-Stick:** Dateien auf einen Stick kopieren, am Pi einstecken, ins Verzeichnis kopieren.
- **Per SCP von deinem PC/Mac aus** (Terminal auf deinem Rechner, nicht auf dem Pi):
  ```bash
  scp -r server.js einsatz.js package.json public asue melde pi@<IP-des-Pi>:~/einsatzverwaltung/
  ```
- **Per USB/Netzlaufwerk**, wie es bei euch sonst üblich ist.

Am Ende sollte die Struktur so aussehen:

```
~/einsatzverwaltung/
  server.js
  einsatz.js            ← Einsätze, Status, Tagebuch, Archiv
  package.json
  public/               ← App Einsatzverwaltung (Port 8080)
    index.html
  asue/                 ← App Atemschutzüberwachung (Port 8082)
  melde/                ← Fahrzeug-App (Port 8081)
    index.html
    benutzer.js         ← Zugänge der Feuerwehren
    wappen/
```

---

## 3. Abhängigkeiten installieren

Im Projektverzeichnis auf dem Pi:

```bash
cd ~/einsatzverwaltung
npm install
```

Das lädt `express` und `ws` herunter (braucht Internetzugang, nur einmalig).

---

## 4. Server testweise starten

```bash
node server.js
```

Im Terminal sollte erscheinen:

```
Einsatzverwaltung läuft auf Port 8080 (http)
Lokal auf diesem Gerät:  http://localhost:8080
Im Netzwerk erreichbar unter http://<IP-Adresse-des-Rechners>:8080
Isolierter Meldeserver läuft auf Port 8081 (nur FMS-Status + Stärke, pro Fahrzeug per Token).
```

Die eigene IP-Adresse des Pi herausfinden:

```bash
hostname -I
```

Das gibt z. B. `192.168.178.50` aus. Jetzt auf einem **anderen** Gerät im selben WLAN
(Handy, Laptop) im Browser öffnen:

```
http://192.168.178.50:8080
```

Wenn die App lädt und oben „Verbunden“ anzeigt, funktioniert alles. Mit `Strg + C`
im Terminal beenden, um zu Schritt 5 überzugehen.

---

## 5. Server dauerhaft laufen lassen (Autostart)

Damit der Server auch nach einem Neustart des Pi automatisch wieder läuft, richten wir
ihn als **systemd-Dienst** ein.

Datei anlegen:

```bash
sudo nano /etc/systemd/system/einsatzverwaltung.service
```

Folgenden Inhalt einfügen (den Pfad in `WorkingDirectory` ggf. anpassen, falls dein
Benutzername nicht `pi` ist – mit `whoami` prüfen):

```ini
[Unit]
Description=Einsatzverwaltung Server
After=network.target

[Service]
Type=simple
WorkingDirectory=/home/pi/einsatzverwaltung
ExecStart=/usr/bin/node server.js
Restart=on-failure
RestartSec=5
User=pi
Environment=PORT=8080
# Environment=MELDE_PORT=8081   # optional, Standard ist ohnehin PORT+1
# Environment=BACKUP_RETENTION_DAYS=60   # optional, Standard ist 30 Tage

[Install]
WantedBy=multi-user.target
```

Speichern (`Strg+O`, dann `Enter`) und schließen (`Strg+X`).

Dienst aktivieren und starten:

```bash
sudo systemctl daemon-reload
sudo systemctl enable einsatzverwaltung
sudo systemctl start einsatzverwaltung
```

Status prüfen:

```bash
sudo systemctl status einsatzverwaltung
```

Sollte „active (running)" zeigen. Ab jetzt startet der Server automatisch bei jedem
Neustart des Pi mit.

**Nützliche Befehle:**

```bash
sudo systemctl restart einsatzverwaltung   # neu starten (z. B. nach einem Update)
sudo systemctl stop einsatzverwaltung      # anhalten
journalctl -u einsatzverwaltung -f         # Live-Log ansehen (zum Fehlersuchen)
```

---

## 6. Feste IP-Adresse für den Pi in der Fritz!Box vergeben

Damit sich die Adresse des Pi nicht ändert (sonst müsstet ihr die URL immer wieder neu
suchen), in der Fritz!Box:

1. `http://fritz.box` im Browser öffnen, anmelden.
2. **Heimnetz → Netzwerk → Netzwerkverbindungen** öffnen.
3. Den Raspberry Pi in der Liste suchen (Name z. B. „raspberrypi").
4. Bearbeiten-Stift anklicken → Haken bei **„Diesem Netzwerkgerät immer die gleiche
   IPv4-Adresse zuweisen"** setzen → Speichern.

Danach bleibt die Adresse (z. B. `192.168.178.50`) dauerhaft gleich.

---

## 7. Von den Geräten im Gerätehaus/Fahrzeugen zugreifen

Auf jedem Gerät im selben WLAN im Browser aufrufen:

```
http://192.168.178.50:8080
```

(mit eurer tatsächlichen Pi-IP-Adresse aus Schritt 6). Am besten als Lesezeichen/App-Icon
auf den Startbildschirmen speichern, damit niemand die Adresse eintippen muss.

**Als App installieren:** Die Seite lässt sich auch als richtige App installieren (eigenes
Icon, kein Browser-Rahmen) — im Browser-Menü auf „Zum Startbildschirm hinzufügen"
(iPhone/iPad: Teilen-Symbol → „Zum Home-Bildschirm") bzw. „App installieren"
(Android/Chrome, erscheint oft automatisch als Vorschlag).

**Atemschutzüberwachung:** Das ist eine eigene App auf eigenem Port:
`http://192.168.178.50:8082`. Sie wird auf den Tablets getrennt als App angelegt (eigenes
Symbol „Atemschutz“) und hat ihre eigene Anmeldung. Details siehe Schritt 11.

---

## 8. Fahrzeug-App – der Meldeserver (Port 8081)

Auf Port **8081** läuft ein eigener, streng begrenzter Server für alles, was **von außen**
erreichbar sein soll. Er startet automatisch mit `node server.js`:

```
Meldeserver (Fahrzeug-App) läuft auf Port 8081 (http).
Nur diesen Port nach außen freigeben, NICHT Port 8080.
```

Er bietet nur eines an:

**Fahrzeug-App** – eine eigene App je Fahrzeug (Handy der Besatzung oder Tablet im
   Fahrzeug): „Im Einsatz“ / „Verfügbar“ (FMS-Status kommt über PowerAlarm), Stärke (Führer/
   Mannschaft/AGT) und **alle 2 Minuten der Standort**. Die Besatzung sieht nur die
   Einsatznummer und das Stichwort, keine Adresse und keine anderen Fahrzeuge. Welches
   Fahrzeug gemeint ist, steckt in einem langen, zufälligen Code in der Adresse.

Die Einsatzverwaltung (8080) und die Atemschutzüberwachung (8082) bleiben im eigenen Netz.

### Warum HTTPS nötig ist

Handys geben den **Standort nur an Seiten mit https://** heraus. Für Status und Stärke im
Gerätehaus-WLAN reicht `http://`, für den Standort braucht Port 8081 eine https-Adresse, die
auch über Mobilfunk erreichbar ist. Zwei Wege:

**A) Tailscale Funnel (empfohlen, ohne Einstellungen an der Fritz!Box)**

1. Auf dem Pi Tailscale installieren und anmelden (kostenloses Konto):
   ```bash
   curl -fsSL https://tailscale.com/install.sh | sh
   sudo tailscale up
   ```
2. Port 8081 öffentlich per https freigeben (beim ersten Mal den angezeigten Link öffnen und
   Funnel für den Pi erlauben):
   ```bash
   sudo tailscale funnel --bg 8081
   tailscale funnel status
   ```
   Angezeigt wird eine Adresse wie `https://einsatz.tailXXXX.ts.net`. Sie leitet **nur** auf
   Port 8081 weiter; die Handys der Besatzungen brauchen kein Tailscale.
3. In der Einsatzverwaltung: **Verwaltung → Einstellungen → Fahrzeug-App → Externe Adresse** = `https://einsatz.tailXXXX.ts.net`.

**B) Eigene Domain / DynDNS mit Zertifikat**

Portfreigabe in der Fritz!Box (**Internet → Freigaben → Portfreigaben**) nur für Port 8081 auf
die feste Pi-Adresse, dazu ein Zertifikat für den Namen (z. B. Let's Encrypt mit certbot) und
in der systemd-Datei:

```ini
Environment=MELDE_TLS_CERT=/pfad/zum/fullchain.pem
Environment=MELDE_TLS_KEY=/pfad/zum/privkey.pem
```

Externe Adresse dann z. B. `https://feuerwehr.example.de:8081`. Eine MyFRITZ!-Freigabe allein
liefert für den Pi **kein** gültiges https-Zertifikat.

**Wichtig:** Niemals Port 8080 oder 8082 nach außen freigeben.

### Fahrzeug-App einrichten

1. In der Einsatzverwaltung ein Fahrzeug antippen → **„Stärke …“ → „Fahrzeug-App für dieses
   Fahrzeug“** → „Link kopieren“ (oder „Öffnen“ direkt auf dem Fahrzeug-Tablet).
2. Link an die Besatzung schicken. Auf dem Handy öffnen und als App anlegen
   (iPhone: Teilen → „Zum Home-Bildschirm“, Android: Menü → „App installieren“).
   Das Symbol heißt wie das Fahrzeug, z. B. „14-46-1“.
3. Beim ersten Öffnen die **Standortfreigabe erlauben**.
4. **Benachrichtigungen (ab 3.65):** In der App unter „Benachrichtigungen“ → **„🔔 Benachrichtigungen
   einschalten“** und erlauben. Dann kommen Nachrichten der Einsatzleitung, neue Aufträge und
   das Umsetzen in einen anderen Einsatz auch bei **gesperrtem Handy bzw. geschlossener App** an.
   „Test senden“ prüft es sofort. Voraussetzungen: Die App ist über die **https-Adresse** geöffnet
   (Tailscale Funnel oder eigene Domain, siehe oben), auf **iPhone/iPad** nur als App vom
   Home-Bildschirm (ab iOS 16.4), und der Pi hat Internet (er schickt die Nachricht verschlüsselt
   über den Push-Dienst von Google, Apple bzw. Mozilla). Einstellen lässt sich das unter
   Verwaltung → Einstellungen → Fahrzeug-App → **„Benachrichtigungen (Push)“** (`an` / `kurz` = ohne
   Text auf dem Sperrbildschirm / `aus`). Der Alarm selbst kommt weiter über Melder bzw. PowerAlarm.
5. **Standort bei gesperrtem Handy (ab 3.66):** In der App unter **Standort → „Standort bei gesperrtem
   Handy“ → Einrichten**: kostenlose Begleit-App **Traccar Client** (Android/iPhone) installieren, die angezeigte
   Server-URL (`https://…/api/hintergrund/<Code>`) eintragen, Intervall 60 s, Standort „Immer erlauben“,
   Dienst einschalten. Der Pi nimmt diese Standorte nur 3 Stunden ab Alarm bzw. „Im Einsatz“ an und verwirft
   alles andere (Einstellung „Standort im Hintergrund: Stunden“). Geht nur über die https-Adresse.

Der Standort wird gesendet, solange die App **geöffnet und der Bildschirm an** ist (die App
hält ihn dafür an), und nur bei Status 1, 3, 4 oder alarmiert – bei Status 2 und 6 pausiert er,
außer „auch bei Status 2 und 6“ ist eingeschaltet. Im Hintergrund oder bei gesperrtem Handy
dürfen Web-Apps keinen Standort senden – dafür die Begleit-App (Punkt 5). Für eine lückenlose Ortung ein Tablet fest im
Fahrzeug mit Ladekabel und geöffneter App verwenden.

---

## 9. Daten sichern (Backup)

**Läuft jetzt automatisch mit** — der Server legt täglich (beim ersten Start des Tages,
danach stündlich geprüft) selbstständig eine Kopie an:

```
~/einsatzverwaltung/backups/data-2026-09-24.json
~/einsatzverwaltung/backups/data-2026-09-25.json
...
```

Ältere Backups als **30 Tage** werden automatisch gelöscht. Die Anzahl der aufbewahrten
Tage lässt sich über die Umgebungsvariable `BACKUP_RETENTION_DAYS` anpassen (z. B. in der
systemd-Datei aus Schritt 5: `Environment=BACKUP_RETENTION_DAYS=60`).

**Falls ihr mal auf ein Backup zurückgreifen müsst:**

```bash
sudo systemctl stop einsatzverwaltung
cp ~/einsatzverwaltung/backups/data-2026-09-24.json ~/einsatzverwaltung/data.json
sudo systemctl start einsatzverwaltung
```

**Ab Version 3.15 zusätzlich:** stündlich eine Kopie in `backups/stuendlich/` (48 Stunden) und
automatisch auf einen **USB-Stick oder ein Netzlaufwerk** – siehe Schritt 15. Der Stand steht unter
Verwaltung → Einstellungen → „Datensicherung“; dort gibt es auch „Jetzt sichern“ und „Sicherung herunterladen“.

---

## 10. App aktualisieren

Neue Version als ZIP auf den Pi kopieren und:

```bash
rm -rf ~/update && mkdir ~/update
unzip -o ~/einsatzverwaltung-pi.zip -d ~/update
bash ~/update/einsatzverwaltung/install.sh
```

Das Skript sichert vorher `data.json`, behält `asue/benutzer.js` (eure Zugänge), `backups/`,
`tiles/`, `objekte/` und eigene Einstellungen in der Dienstdatei und startet den Dienst neu.

**Aktualisieren über die Oberfläche (ab 3.43):** Verwaltung → Einstellungen → Sicherung & System → „Programm aktualisieren“ (Admin) – ZIP auswählen, der Pi prüft das Paket, sichert und startet neu. Das ist der übliche Weg; der Befehl oben ist für den Notfall.

Besondere Hinweise zu einzelnen Versionen stehen im **Anhang: Hinweise zu einzelnen Versionen** am Ende (neueste zuerst). Steht dort nichts Besonderes, genügt das normale Einspielen.

---

## Kurz zur Bedienung

Die ausführliche Bedienung steht in `docs/BEDIENUNG.md` (gegliedert in Grundlagen, Im Einsatz, Fahrzeuge/Apps, Übungen, Verwaltung). Das Wichtigste:

- **Einsatz eröffnen:** Reiter „Einsatz“ → „+ Neuer Einsatz“ (Stichwort, Meldebild, Adresse mit Adresssuche, Einsatzleiter …) – oder automatisch aus der Alarmmail. Mehrere Einsätze können gleichzeitig laufen.
- **Reiter im Einsatz:** Übersicht · Tagebuch · Aufträge (nur Sonderlage) · Fahrzeuge · Abschnitte · Lagekarte · Nachrichten (mit Fotos) · Atemschutz · Gefahrstoff · VU · Checklisten · Nachbereitung · Zeitstrahl. Die Leiste bleibt beim Scrollen stehen.
- **Fahrzeugstatus:** kommt über PowerAlarm bzw. die Leitstelle; von Hand über den Status-Knopf am Fahrzeug. Bei A/3/4 wird das Fahrzeug dem Einsatz zugeordnet (bei mehreren Einsätzen wird gefragt).
- **Einsatztagebuch:** nach FwDV 100 mit fortlaufender Nummer; Einträge sind nicht änderbar, Korrekturen werden als neuer Eintrag erfasst. Statuswechsel, Stärke, Anforderungen, Lagemeldungen und ASÜ-Meldungen landen automatisch darin.
- **Lagekarte:** Reiter im Einsatz. ⌂ zeigt 1 km um das Gerätehaus (einstellbar). Der Pi lädt Kacheln aus dem Internet und speichert jede angesehene Kachel im Ordner `tiles/` – danach auch offline verfügbar. Tipp: das Gemeindegebiet einmal mit Internet in mehreren Zoomstufen durchblättern.
- **Gefahrstoffdatenbank:** alle UN-Nummern des ADR mit ERG-Leitfaden und Absperrabständen, auf Deutsch und ohne Internet.
- **Großschadenslage (Unwetter):** Haken im Einsatz setzen → Aufträge erfassen, Fahrzeuge disponieren, eigenes Tagebuch je Auftrag.
- **Übungen:** Übungsgenerator, Demo-Einsätze und die **Übungsleitstelle** (`/uebleitstelle/`), mit der eine Person Leitstelle und Fahrzeuge spielt.
- **Einsatz beenden:** archiviert alles (Reiter „Archiv“: Bericht, Druck/PDF, CSV).

---

## 11. App Atemschutzüberwachung (ASÜ) auf dem Pi

**Aufruf:** `http://<Pi-IP>:8082` – auf dem Tablet/Handy als eigene App anlegen
(„Zum Home-Bildschirm“ bzw. „App installieren“). Anmeldung wie bisher mit dem Zugang der eigenen
Feuerwehr (Datei `asue/benutzer.js`). Einsatzverwaltung (Port 8080) und Atemschutzüberwachung
(Port 8082) sind zwei getrennte Apps: eigene Symbole, eigene Anmeldung, kein Umschalter –
sie teilen sich nur den Datenbestand auf dem Pi. Anderen Port wählen: `Environment=ASUE_PORT=…`.

**Was automatisch passiert, wenn die ASÜ vom Pi geladen wird (nichts einzutragen):**

- **Truppstatus an die Einsatzverwaltung:** bereit / im Einsatz / waren im Einsatz, jeweils
  als Anzahl Trupps und Personen. Bei jeder Änderung, alle 5 Minuten als Lebenszeichen und
  einmal beim „Einsatzende“. Namen, Gerätenummern und Drücke werden **nicht** übertragen.
  In der Einsatzverwaltung erscheint das unter **Einsatz → Atemschutzüberwachung · Truppstatus**
  (live, je Feuerwehr) sowie im Einsatztagebuch und im Einsatzbericht. Meldet sich eine ASÜ
  länger als 7 Minuten nicht, steht dort „keine Meldung seit … – Verbindung der ASÜ prüfen“.
- **Gemeinsame Datenbank:** Sobald in der ASÜ der erste Trupp angelegt ist, wird der Einsatz
  automatisch auf dem Pi in derselben `data.json` mitgesichert (inkl. täglichem Backup).
  Diese Trupp-Daten sind für die Einsatzverwaltung **nicht** sichtbar – der Server gibt sie
  nur an die ASÜ-Geräte heraus. Weitere Geräte (z. B. ein Handy für die Trupp-Erfassung)
  treten unter **Einsatzdaten → Mehrere Geräte** mit dem Einsatz-Code bei.
- Beispieldaten (nach der ersten Anmeldung) werden nie gemeldet.
- **Einsatz Ende** in der Einsatzverwaltung leert die ASÜ-Anzeige dort. Läuft die ASÜ noch,
  erscheint ihr Stand bei der nächsten Änderung bzw. spätestens nach 5 Minuten wieder.

**Einstellungen (optional, in der systemd-Datei aus Schritt 5):**

```ini
Environment=ASUE_KEY=langer-geheimer-schluessel   # Wehr-Schlüssel, dann muss er in jeder ASÜ unter
                                                  # Einsatzdaten → Mehrere Geräte eingetragen sein
Environment=ASUE_AUFBEWAHRUNG_TAGE=90             # ASÜ-Einsätze auf dem Pi nach 90 Tagen löschen
```

Ohne `ASUE_KEY` ist die Schnittstelle im eigenen WLAN offen – das reicht, solange die Ports
8080 und 8082 nicht ins Internet freigegeben sind (siehe Schritt 8).

**HTTPS – was ohne geht und was nicht:** Über `http://<Pi-IP>:8082` funktionieren
Anmeldung, Überwachung, Truppstatus, Protokoll-PDF und Kamera-**Fotos** für die Texterkennung.
Nur mit HTTPS (gültiges Zertifikat) funktionieren zusätzlich: Offline-Betrieb/Installation als
App mit eigenem Icon und das **Live-Scannen** von QR-Codes mit dem Kamerabild. Wer das braucht:

1. Ein gültiges Zertifikat für den Pi besorgen – am einfachsten mit **Tailscale**
   (`sudo tailscale cert <name>.ts.net`, Geräte brauchen die Tailscale-App; damit ist der Pi
   im Einsatz auch über Mobilfunk erreichbar) oder mit einer eigenen Domain und Let's Encrypt.
2. In der systemd-Datei eintragen und neu starten:
   ```ini
   Environment=TLS_CERT=/pfad/zum/fullchain.pem
   Environment=TLS_KEY=/pfad/zum/privkey.pem
   ```
   Danach laufen beide Apps mit HTTPS: `https://<name>:8080` und `https://<name>:8082`.

**Im Einsatz unterwegs:** Die ASÜ arbeitet auch ohne Verbindung zum Pi normal weiter (Daten
bleiben auf dem Tablet). Damit Truppstatus und Abgleich auch über **Mobilfunk** ankommen,
siehe Schritt 13.

**Zugänge ändern:** ab Version 3.76 in der Einsatzverwaltung unter **Verwaltung → ASÜ-Zugänge**
(Kennwort neu setzen, Zugang anlegen/ändern/löschen – ohne Terminal). Weiterhin möglich: als `admin` in
der ASÜ anmelden → Einstellungen → „Passwort ändern / Zugang anlegen“ und den erzeugten Eintrag in
`asue/benutzer.js` auf dem Pi ersetzen.

---

## 12. Umstieg von der bisherigen „Fahrzeugverwaltung“

Die Daten bleiben erhalten. Beim ersten Start übernimmt der Server die alten Daten automatisch:
Status Frei/Alarmiert/Im Einsatz wird zu FMS 2/A/3, Mannschaft/PA-Träger zur Stärke, und ein gerade
laufender Einsatz (alarmierte Fahrzeuge, Abschnitte, Lagekarte) wird als Einsatz „Übernommen aus der
bisherigen Fahrzeugverwaltung“ angelegt. Vorher trotzdem `data.json` sichern.

```bash
sudo systemctl stop fahrzeugverwaltung
sudo systemctl disable fahrzeugverwaltung
mv ~/fahrzeugverwaltung ~/einsatzverwaltung
# neue Dateien (server.js, einsatz.js, package.json, public/, asue/, melde/) nach ~/einsatzverwaltung kopieren, data.json und backups/ bleiben liegen
cd ~/einsatzverwaltung && npm install
sudo mv /etc/systemd/system/fahrzeugverwaltung.service /etc/systemd/system/einsatzverwaltung.service
sudo sed -i 's#/fahrzeugverwaltung#/einsatzverwaltung#; s#Fahrzeugverwaltung Server#Einsatzverwaltung Server#' /etc/systemd/system/einsatzverwaltung.service
sudo systemctl daemon-reload
sudo systemctl enable --now einsatzverwaltung
```

Auf den Tablets/Handys die Seite einmal neu laden. Wer die App als Icon auf dem
Startbildschirm hat, legt es am besten neu an (neuer Name „Einsatz“ und neues Symbol).
Die ASÜ bisher von GitHub: dort sind die Einsatzdaten im Browser des Geräts gespeichert.
Laufende Einsätze vorher mit „Einsatzende“ abschließen, danach die ASÜ vom Pi verwenden
(`http://<Pi-IP>:8082`) und neu als App anlegen.

---

## 13. ASÜ über Mobilfunk und mit mehreren Geräten (ab Version 3.4)

### Was die ASÜ ab 3.4 macht

- **Ein Gerät führt die Überwachung.** Wer einen Einsatz anlegt bzw. freigibt, führt ihn.
  Nur dieses Gerät kann Zeiten, Drücke, Notfall, Trupps und Einsatzdaten ändern, meldet den
  Truppstatus an die Einsatzverwaltung und bekommt die Druckabfragen.
- **Alle anderen Geräte zeigen nur an** (Hinweis „Nur Anzeige“, Knöpfe ausgegraut). Sie sehen
  alle Trupps live und können **Trupps vorschlagen** („+ Trupp vorschlagen“ oder per
  Trupp-QR-Code). Das führende Gerät bekommt einen Hinweis und **bestätigt** oder **lehnt ab**.
  Erst nach der Bestätigung ist der Trupp in der Überwachung.
- **Führung wechseln:** unter *Einsatzdaten → Mehrere Geräte*
  - **Führung übergeben** – nur am führenden Gerät, Zielgerät aus der Liste wählen.
  - **Führung übernehmen (Admin-Passwort)** – wenn das führende Gerät ausgefallen ist.
    Es gilt der Admin-Zugang aus `asue/benutzer.js` auf dem Pi. Nach 5 Fehlversuchen ist das
    Gerät 10 Minuten gesperrt. Jede Übernahme steht im Protokoll der Einsatzverwaltung.
- Der Pi setzt das verbindlich durch: Änderungen von nicht führenden Geräten lehnt er ab.
- Jedes Gerät bekommt unter *Einsatzdaten → Mehrere Geräte → Name dieses Geräts* einen Namen
  (z. B. „Tablet ELW“, „Handy AGT-Sammelplatz“), damit Vorschläge und Übergabe eindeutig sind.

### Pi von außen erreichbar machen (einmalig)

Die Schnittstelle der ASÜ darf **nur mit Wehr-Schlüssel** ins Internet. Port 8080 (Einsatzverwaltung)
und 22 (SSH) bleiben immer intern.

1. **Wehr-Schlüssel setzen** (langer Zufallswert, z. B. mit `openssl rand -hex 16` erzeugen):
   ```bash
   sudo nano /etc/systemd/system/einsatzverwaltung.service
   ```
   Zeile ändern in `Environment=ASUE_KEY=<euer-schluessel>` (Raute am Anfang entfernen).
   Wird die ASÜ von GitHub geladen, zusätzlich:
   `Environment=ASUE_ORIGIN=https://NAME.github.io`
   (ab 3.78 einfacher: Verwaltung → ASÜ-Zugänge → „Paket für GitHub erzeugen“ trägt die Herkunft selbst ein
   und erzeugt das fertige Paket; Wehr-Schlüssel unter Einstellungen → Schnittstellen.)
   ```bash
   sudo systemctl daemon-reload && sudo systemctl restart einsatzverwaltung
   ```
2. **Port 8082 per Tailscale Funnel auf Port 8443 veröffentlichen** (Port 443 nutzt bereits
   die Fahrzeug-App):
   ```bash
   sudo tailscale funnel --bg --https=8443 https+insecure://localhost:8082
   tailscale funnel status
   ```
   Ohne Zertifikat auf dem Pi (kein `TLS_CERT`) stattdessen `http://localhost:8082`.
   Die Adresse lautet dann `https://einsatz.tailXXXX.ts.net:8443`.
3. Test vom Handy **im Mobilfunk** (WLAN aus): `https://einsatz.tailXXXX.ts.net:8443/api/health`
   muss `{"ok":true,"name":"Einsatzverwaltung","schluessel":true,…}` zeigen.

### In jeder ASÜ eintragen (einmalig je Gerät)

*Einsatzdaten → Mehrere Geräte:*

- **Server-Adresse(n):** beide Adressen, durch Leerzeichen getrennt, z. B.
  `http://<Pi-IP>:8082/api https://einsatz.tailXXXX.ts.net:8443/api`
  (erste Adresse: der Pi im Gerätehaus-WLAN, z. B. `http://192.168.178.50:8082/api`; mit Zertifikat auf
  dem Pi `https://…`; zweite Adresse: Tailscale Funnel für unterwegs)
  Die App prüft alle und nimmt die erste erreichbare: im Gerätehaus-WLAN die interne, unterwegs
  die Tailscale-Adresse. Bricht die Verbindung ab, sucht sie nach spätestens 15 Sekunden neu.
- **Wehr-Schlüssel:** derselbe wie `ASUE_KEY`.
- **Name dieses Geräts.**

Der Beitritts-QR-Code enthält beide Adressen: Ein neues Gerät scannt ihn und ist sofort
verbunden (der Wehr-Schlüssel muss dort einmal eingetragen sein).

### Ablauf im Einsatz

1. Tablet am Überwachungsplatz: Trupp anlegen → der Einsatz wird automatisch auf dem Pi
   gesichert, das Tablet **führt**. Den Einsatz-Code bzw. Beitritts-QR zeigt *Einsatzdaten*.
2. Weitere Geräte treten mit dem Code/QR bei und zeigen an. Neue Trupps dort vorschlagen;
   das Tablet bestätigt sie.
3. Tablet fällt aus: an einem anderen Gerät *Führung übernehmen* mit Admin-Passwort.
4. *Einsatzende* am führenden Gerät: Die anderen Geräte zeigen „Einsatz wurde am führenden
   Gerät beendet“ und können mit *Einsatzende* bzw. *Trennen* aufräumen.

---

## 14. what3words in der Lagekarte (optional, ab Version 3.5)

Leitstellen und Anrufer geben Einsatzorte oft als what3words-Adresse durch (z. B. `///tisch.lampe.fenster`).
Mit einem API-Schlüssel rechnet der Pi diese in Koordinaten um – in allen Adresssuchen der Einsatzverwaltung –
und zeigt im Fenster „Koordinate“ die what3words-Adresse eines Punkts an.

1. **Schlüssel besorgen:** Konto unter <https://accounts.what3words.com> anlegen. Der kostenlose Tarif reicht
   **nicht** für die Umrechnung in Koordinaten. what3words bietet Einsatzorganisationen kostenlose Tarife an –
   dort als Feuerwehr anfragen, sonst ist ein kostenpflichtiger Tarif nötig.
2. **Auf dem Pi eintragen:**
   ```bash
   sudo nano /etc/systemd/system/einsatzverwaltung.service
   ```
   Zeile `Environment=W3W_KEY=<euer-schluessel>` im Block `[Service]` ergänzen (ohne Raute, ohne Leerzeichen),
   speichern, dann:
   ```bash
   sudo systemctl daemon-reload && sudo systemctl restart einsatzverwaltung
   ```
3. **Test:** In der Lagekarte `///tisch.lampe.fenster` suchen. Kommt „Der API-Tarif erlaubt keine Umrechnung“,
   fehlt der passende Tarif.

Braucht Internet am Pi. Ohne Schlüssel bleibt alles wie bisher.

---

## 15. Automatische Sicherung auf USB-Stick oder Netzlaufwerk (ab Version 3.15)

Fällt die SD-Karte des Pi aus, sind `data.json` **und** die Backups darauf weg. Deshalb sichert der Pi ab 3.15
automatisch auf einen zweiten Datenträger: beim Start, stündlich (wenn sich etwas geändert hat) und nach jedem
beendeten Einsatz. Auf dem Datenträger entsteht der Ordner `einsatzverwaltung-sicherung/` mit
`data-JJJJ-MM-TT.json` (eine Datei je Tag, 90 Tage), den Objekt-Plänen (`objekte/`) und `asue/benutzer.js`.

Geschrieben wird nur, wenn dort wirklich ein Datenträger eingehängt ist – steckt der Stick nicht, meldet die
Einsatzverwaltung „Stick nicht erkannt“ und schreibt nichts auf die SD-Karte.

**USB-Stick (empfohlen: fest am Pi stecken lassen)**

1. Stick am PC mit **FAT32** oder **exFAT** formatieren und ihm den Namen **FWBACKUP** geben.
2. Stick in den Pi stecken, dann **einmalig** (als der Benutzer, unter dem die Einsatzverwaltung läuft):
   ```bash
   sudo bash ~/einsatzverwaltung/docs/stick-einrichten.sh
   ```
   Das Skript (ab 3.65) legt `/mnt/fwbackup` an, trägt den Stick in `/etc/fstab` ein (eine alte Zeile für
   FWBACKUP wird ersetzt, vorher wird `/etc/fstab` gesichert) und schaltet das **automatische Einhängen** ein.
   Am Ende steht „Stick erkannt“ und die Größe des Sticks.
3. In der Einsatzverwaltung: Verwaltung → Einstellungen → **Sicherung & System** → **„Jetzt sichern“**. Dort muss
   „🟢 Stick erkannt (FWBACKUP)“ und „/mnt/fwbackup: gesichert …“ stehen.

**Abziehen und wieder einstecken (ab 3.65 ohne Terminal):** Der Pi hängt den Stick nur zum Sichern ein und
nach einer Minute ohne Zugriff selbst wieder aus. Steht in der Verwaltung „kann gefahrlos abgezogen werden“,
den Stick einfach abziehen. Wird ein Stick eingesteckt, erkennt die Einsatzverwaltung ihn innerhalb von
15 Sekunden und **sichert sofort**. So lassen sich auch **zwei Sticks im Wechsel** verwenden (beide mit dem
Namen FWBACKUP), einer davon außer Haus.

Anzeige unter Verwaltung → Einstellungen → Sicherung & System:

| Anzeige | Bedeutung |
|---|---|
| 🟢 Stick erkannt · kann gefahrlos abgezogen werden | Stick steckt, ist gerade nicht eingehängt – alles in Ordnung |
| 🟢 Stick erkannt · eingehängt | Sicherung läuft oder lief gerade; nach 1 Minute wieder „abziehbar“ |
| 🔴 Stick nicht erkannt | Kein Stick mit dem Namen FWBACKUP – einstecken, die Sicherung startet von selbst |
| 🟠 Stick erkannt, aber nicht eingehängt | Alte Einrichtung (vor 3.65) – einmal `stick-einrichten.sh` ausführen (Schritt 2) |

Wer den Stick vor 3.65 von Hand eingerichtet hat, führt Schritt 2 einmal aus – danach entfällt
`sudo mount /mnt/fwbackup`. Der Stick muss FAT32 oder exFAT haben (für ext4 passen die Optionen nicht).

Bei Raspberry Pi OS **mit Desktop** werden Sticks automatisch unter `/media/…` eingehängt – diese erkennt die
Einsatzverwaltung von selbst, dann entfällt Schritt 2.

**Netzlaufwerk / zweiter Rechner (NAS, Windows-Freigabe)** – statt oder zusätzlich zum Stick:
```bash
sudo apt install -y cifs-utils
sudo mkdir -p /mnt/fwbackup
printf 'username=NUTZER\npassword=PASSWORT\n' | sudo tee /root/.fwbackup-cred >/dev/null && sudo chmod 600 /root/.fwbackup-cred
echo "//NAS-ADRESSE/FREIGABE /mnt/fwbackup cifs credentials=/root/.fwbackup-cred,uid=$(id -u),gid=$(id -g),nofail,_netdev 0 0" | sudo tee -a /etc/fstab
sudo systemctl daemon-reload && sudo mount /mnt/fwbackup
```
Anderer Ordner oder mehrere Ziele: in der Dienstdatei `Environment=BACKUP_ZIEL=/mnt/fwbackup /mnt/nas` (mit Leerzeichen getrennt).

**Zurückspielen** (z. B. auf einer neuen SD-Karte nach der Installation):
```bash
sudo systemctl stop einsatzverwaltung
cp /mnt/fwbackup/einsatzverwaltung-sicherung/data-2026-09-27.json ~/einsatzverwaltung/data.json
cp -r /mnt/fwbackup/einsatzverwaltung-sicherung/objekte ~/einsatzverwaltung/
cp /mnt/fwbackup/einsatzverwaltung-sicherung/asue/benutzer.js ~/einsatzverwaltung/asue/
sudo systemctl start einsatzverwaltung
```
Die Dienstdatei mit Wehr-Schlüssel und API-Schlüsseln wird aus Sicherheitsgründen **nicht** mitgesichert –
diese Schlüssel getrennt und sicher aufbewahren. Die Sicherung enthält Namen (Atemschutz) und Einsatzdaten:
Stick bzw. Laufwerk entsprechend verwahren.

---

## 16. Übungsgenerator auch unterwegs (GitHub Pages, ab Version 3.16)

Der Übungsgenerator läuft auf dem Pi unter `http://<Pi>:8080/uebung/` – nur dort kann er Einsätze verschicken.
Zum **Vorbereiten von unterwegs** liegt er zusätzlich im Paket `asue-fuer-github.zip` im Ordner `uebung/`:
den Ordner einfach mit in das GitHub-Repository der ASÜ hochladen. Dann ist er unter
`https://NAME.github.io/REPO/uebung/` erreichbar (vorbereiten, speichern, exportieren – ohne Verbindung zum Pi).

Im WLAN der Wehr dann „Im Netzwerk übernehmen“ antippen (vorher unter „Einstellungen“ die Adresse der
Einsatzverwaltung eintragen, z. B. `http://192.168.178.50:8080`) – das Szenario erscheint in der App auf dem Pi
und kann dort verschickt werden. Alternativ: „Exportieren“ und auf dem Pi-Gerät „Importieren“.

---

## 17. Alarmmonitor im Gerätehaus (ab Version 3.69)

Ein Bildschirm in der Fahrzeughalle zeigt im Ruhezustand Uhr, Hinweise, Unwetterwarnungen und Fahrzeugstatus –
bei Alarm Stichwort, Einsatzort mit Karte, Kräfte laut Stichwortliste, alarmierte Fahrzeuge, Hydranten,
Rettungspunkt, „Wer kommt?“ und einen QR-Code für die Navigation aufs Handy.

**Einrichten in der Einsatzverwaltung:** Verwaltung → **Alarmmonitor** → „+ Monitor anlegen“: Name, Ortswehr
(der Monitor zeigt nur Alarme, an denen ein Fahrzeug dieser Ortswehr beteiligt ist; leer = alle), Koordinate des
Gerätehauses, Gong, Infotext. Danach erscheint der **Link** (QR-Code). Mit **„Probealarm“** zeigt der Monitor
60 Sekunden lang einen Testalarm.

**Welcher Link?** Im Netz des Pi geht `http://<Pi>:8080/monitor/<Code>`. Für Gerätehäuser in anderen Orten
den Link über die **externe Adresse** des Meldeservers nehmen (`https://….ts.net/monitor/<Code>`, Tailscale
Funnel aus Schritt 8) – er erscheint, sobald die externe Adresse eingetragen ist.

**Hardware:** Fernseher oder Monitor mit HDMI und ein **Raspberry Pi** (ab Pi 4, Raspberry Pi OS *mit Desktop*),
alternativ ein Mini-PC oder ein Fire-TV-Stick mit einem Browser im Vollbild (z. B. „Fully Kiosk Browser“).

**Raspberry Pi als Monitor-Rechner (Autostart im Vollbild):**
```bash
mkdir -p ~/.config/labwc
echo 'chromium-browser --kiosk --noerrdialogs --disable-infobars --autoplay-policy=no-user-gesture-required "https://DEINE-ADRESSE/monitor/CODE" &' >> ~/.config/labwc/autostart
sudo reboot
```
(Bei älterem Raspberry Pi OS mit X11 statt `~/.config/labwc/autostart` die Datei `~/.config/lxsession/LXDE-pi/autostart`
mit der Zeile `@chromium-browser --kiosk … "URL"` verwenden.) Bildschirmschoner abschalten:
`sudo raspi-config` → Display Options → Screen Blanking → **No**. `--autoplay-policy=…` erlaubt den Gong ohne Klick;
in anderen Browsern einmal auf den Bildschirm klicken (unten rechts steht „Ton bereit“).

Der Monitor holt alle 3 Sekunden den Stand, zeigt bei Verbindungsverlust „Keine Verbindung zum Pi seit …“ und lädt
sich nach einem Programm-Update selbst neu. Der Link ist geheim; „Neuer Link“ bzw. „Sperren“ unter Verwaltung →
Alarmmonitor, falls er weitergegeben wurde.

---

## 18. Gefahrstoffdatenbank, Übungsleitstelle und Startansicht der Karte (ab Version 3.96)

Hier ist nichts zu installieren – alles kommt mit dem normalen Update.

- **Gefahrstoffdatenbank:** Die Daten liegen in `public/gefahrstoffe.json` (ADR 2025 und ERG 2024, gut 1 MB) und werden mit dem Programm aktualisiert. Sie funktionieren ohne Internet. Nur die Links zu GESTIS, ERI-Cards und CAMEO sowie „Aktuellen Wind abrufen“ brauchen Internet am jeweiligen Gerät.
- **Startansicht der Lagekarte (⌂):** Vorgabe 1 km um 52.05477, 9.23712. Ändern unter Verwaltung → Einstellungen (Mittelpunkt als „Breite, Länge“ und Umkreis in Metern).
- **Übungsleitstelle:** im Gerätehaus-Netz unter `http://<Pi-IP>:8080/uebleitstelle/` (ab 3.99 auch mit Sonderlage, Automatik und den Szenarien des Übungsgenerators) – Anmeldung mit Benutzer und PIN der Einsatzverwaltung (Einsatzleitung oder Admin). Sie läuft nur im eigenen Netz; Port 8080 bitte **nicht** nach außen freigeben. Übungsfahrzeuge sind vollständig von den echten Fahrzeugen getrennt: es geht nichts an die echten Fahrzeug-Apps, an Push-Meldungen, den Alarmmonitor oder nach außen.
- Nach dem Update auf jedem Tablet die Einsatzverwaltung einmal neu laden, damit die neue Version aus dem Zwischenspeicher kommt.

---

## 19. Atemschutz-Datenbank für die Gerätewarte (ab Version 4.0)

1. **Zugänge anlegen:** Verwaltung → **Atemschutz-DB** → „+ Gerätewart anlegen“ – je Atemschutzgerätewart ein Zugang mit seiner Ortswehr und E-Mail-Adresse. Den ausgedruckten Zettel mit dem Startkennwort übergeben.
2. **E-Mail-Versand** muss eingerichtet sein (Verwaltung → Einstellungen → Schnittstellen → E-Mail), sonst kommen keine Erinnerungen.
3. **Zugriff von außen:** Die Gerätewarte arbeiten in der ASÜ – im Feuerwehrhaus oder über die Internetadresse der ASÜ (Tailscale Funnel Port 8443, siehe Schritt 13). Es muss nichts zusätzlich freigegeben werden; Port 8080 bleibt intern.
4. **Wehr-Schlüssel setzen** (falls noch nicht geschehen), wenn die ASÜ von außen erreichbar ist – sonst ist die Liste „einsatzbereit ja/nein“ ohne Schlüssel abrufbar. In der ASÜ lässt er sich jetzt per QR-Code eintragen (Verwaltung → ASÜ-Zugänge → „🔑 Wehr-Schlüssel als QR“).
5. **ASÜ über GitHub:** Paket unter Verwaltung → ASÜ-Zugänge neu erzeugen und hochladen (enthält jetzt auch `sammeln.html`).

Die Daten liegen in `data.json` auf dem Pi und sind damit in der (verschlüsselten) Datensicherung enthalten. Gesundheitsdaten werden nicht gespeichert – von der Eignungsuntersuchung nur Datum und „gültig bis“.

## 20. Feuerwehrhäuser prüfen (ab Version 4.1)

1. Verwaltung → **Feuerwehrhäuser** öffnen. Jede Zeile mit rotem „prüfen“ über „Bearbeiten“ kontrollieren (Koordinate aus der Karte übernehmen) und „geprüft“ setzen.
2. Nachbarwehren mit „🛰 Aus OpenStreetMap ergänzen“ holen (der Pi braucht dafür Internet) oder einzeln anlegen.
3. Mit „Anfahrtszeiten testen“ an zwei, drei bekannten Adressen prüfen, ob die Schätzung passt; sonst Tempo, Umwegfaktor oder die Ausrückzeit der Wehr anpassen.

## 21. Selbsttest einrichten (ab Version 4.2)

1. Verwaltung → Einstellungen → Schnittstellen → E-Mail: bei **System-Empfänger** mindestens eine Adresse eintragen (z. B. die des Admins).
2. Verwaltung → **Zustand des Pi → Selbsttest**: Uhrzeit prüfen (Vorgabe 06:45), „Prüfen und Mail senden“ drücken – die Mail muss ankommen.
3. Kommt die tägliche Mail einmal nicht, ist der Pi aus, ohne Netz oder der Mailversand gestört.

## 22. Gerätedatenbank einrichten (ab Version 4.7)

1. Verwaltung → **Gerätewarte** → „Ausrüstungsliste übernehmen und Datenbank aktivieren“ (einmalig, PIN-Bestätigung). Danach pflegen die Gerätewarte die Ausrüstung; ein Excel-Import der Fahrzeuge ändert sie nicht mehr.
2. Verwaltung → Gerätewarte: „+ Gerätewart anlegen“ (Gerätedatenbank) bzw. „+ Atemschutzgerätewart anlegen“ (Atemschutz-Datenbank) – Ortswehren und E-Mail-Adresse eintragen, Zettel mit Startkennwort und Link übergeben.
3. Die Gerätewarte ergänzen Inventar-Nummern, Prüfart, Intervall und nächste Prüfung und drucken die QR-Etiketten.

## 23. Datenbank-Apps und Benachrichtigungen für Gerätewarte (ab Version 5.5)

1. Die Gerätedatenbank (`/geraete`) und die Atemschutz-Datenbank (`/atemschutz`) lassen sich auf Handy, Tablet und PC als **eigene App** installieren (Android/Chrome/Edge: „📲 Als App installieren“, iPhone/iPad: in Safari „Teilen → Zum Home-Bildschirm“). Sie werden über die **https-Adresse der ASÜ** geöffnet (Tailscale Funnel, Port 8443, Schritt 13).
2. **Benachrichtigungen** nutzen denselben Schlüssel wie die Fahrzeug-App (`push-vapid.json`, entsteht beim ersten Start). Der Pi braucht dafür Internet. In der App „🔔 Benachrichtigungen“ → „Auf diesem Gerät einschalten“ → „Test senden“.
3. **Angemeldet bleiben (30 Tage):** Haken bei der Anmeldung, nur auf dienstlichen bzw. eigenen Geräten. Verlorene Geräte meldet der Admin unter Verwaltung → Sicherheit → „Angemeldete Geräte“ ab.

## 24. Superadmin (ab Version 5.4)

1. Verwaltung → Benutzer: einen Admin bearbeiten, Haken **„Superadmin“**, Kennwort mit mindestens 12 Zeichen (Buchstaben und Ziffern) vergeben. Der Benutzername muss kleingeschrieben sein.
2. Mit diesem Kennwort kommt man in Einsatzverwaltung, ASÜ (als Admin) sowie Geräte- und Atemschutz-Datenbank (alle Ortswehren). Wechsel alle 4 Monate; jede Anmeldung steht im Sicherheitsprotokoll.
3. Damit die ASÜ von GitHub den Superadmin auch offline kennt: ASÜ neu veröffentlichen (Schritt 26).

## 25. Datenschutz einrichten (ab Version 5.7)

1. Verwaltung → Einstellungen → **Datenschutz**: verantwortliche Stelle und Datenschutzbeauftragte/n eintragen (Zeilen mit „ | “ trennen). Die Datenschutzhinweise erscheinen dann in allen Apps unter `/datenschutz`.
2. **Löschfristen** mit dem Datenschutzbeauftragten festlegen und eintragen (GPS-Spuren, Fotos, Nachrichten, ganze Einsätze, ausgeschiedene Atemschutzgeräteträger). Vorgabe ist überall „0 = nie“.
3. **Schriften:** Der Pi lädt die Schriften beim ersten Aufruf einmal selbst (braucht Internet) und legt sie im Ordner `schrift/` ab. Die Geräte verbinden sich danach nicht mehr mit Google. Kontrolle: Verwaltung → Sicherheit, Punkt „Schriften liegen auf dem Pi“.
4. Das **Verzeichnis der Verarbeitungstätigkeiten** (Entwurf) mit dem Datenschutzbeauftragten durchgehen und die offenen Punkte abarbeiten.

## 26. ASÜ automatisch auf GitHub veröffentlichen (ab Version 5.8)

Bisher musste nach jedem Update ein ZIP erzeugt und von Hand auf GitHub hochgeladen werden. Jetzt kann der Pi das selbst:

1. Auf github.com mit dem Konto der Feuerwehr anmelden → Profilbild → **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**.
2. Name z. B. „Einsatzverwaltung“, Ablauf z. B. 1 Jahr, **Repository access: Only select repositories** → das ASÜ-Repository (z. B. `asue`). Unter **Permissions → Repository permissions → Contents: Read and write**. „Generate token“ und den Schlüssel (beginnt mit `github_pat_`) kopieren.
3. Einsatzverwaltung → Verwaltung → **ASÜ-Zugänge** → Abschnitt „Direkt auf GitHub veröffentlichen“: Repository als `konto/name`, Branch `main`, Schlüssel einfügen, Haken **„Nach jedem Update automatisch veröffentlichen“**, Speichern (PIN).
4. „⬆ Jetzt auf GitHub veröffentlichen“ – nach 1–2 Minuten ist die Seite aktuell. Ab jetzt veröffentlicht der Pi etwa 90 Sekunden nach jedem Update von selbst; klappt es nicht, kommt eine Mail an die System-Empfänger und der Sicherheits-Check zeigt es an.
5. Der Schlüssel liegt nur auf dem Pi und wird nie an Geräte geschickt. Läuft er ab, einfach einen neuen eintragen.

## 27. Notfallmappe und Ersatz-Pi (ab Version 5.8)

1. Verwaltung → Einstellungen → Betrieb: **„Ansprechpartner bei Ausfall des Pi“** eintragen.
2. Verwaltung → **Berichte & Notfall → Notfallmappe öffnen** → drucken. Je ein Exemplar in den ELW und ins Feuerwehrhaus. Nach Änderungen an Fahrzeugen neu drucken.
3. Ersatz-Pi bzw. Ersatz-Speicherkarte vorbereiten und den Ablauf „Pi tauschen“ aus `docs/BETRIEBSHANDBUCH.md` einmal im Jahr üben.

## 28. Hydrantenprüfung einrichten (ab Version 5.9)

1. Verwaltung → Einstellungen → Gruppe **Hydrantenprüfung**: Prüfintervall in Monaten (Vorgabe 12), Umkreis der Löschwasser-Abdeckung (Vorgabe 300 m) und **„Mängel melden an“** – die E-Mail-Adresse des Wasserversorgers oder der Gemeinde (mehrere mit Komma). Leer = nur die System-Empfänger.
2. Die Hydranten kommen aus OpenStreetMap (werden vom Pi geladen, Internet nötig). Fehlende Hydranten melden die Besatzungen direkt in der Fahrzeug-App (auf die Karte tippen → „Hydranten hier melden und prüfen“).
3. Prüfen tun die Besatzungen mit der **Fahrzeug-App** (Karte → Hydrant antippen); die Übersicht steht unter **Verwaltung → Hydranten**. Mehr in `docs/BEDIENUNG.md` und der Kurzanleitung Fahrzeugbesatzung.

## 29. Fahrtenbuch und Fahrzeugfristen (ab Version 5.10)

1. Verwaltung → Einstellungen → Gruppe **Fahrzeug-App**: **„Fahrtenbuch: vorgegebene Ziele“** (Vorgabe „Feuerwehrtechnische Zentrale | Ortsgebiet | Aerzen“, mit „ | “ trennen) und **„Fahrtenbuch: Erinnerung bei Status 2“** (an/aus). Die Erinnerung braucht Benachrichtigungen in der Fahrzeug-App (Einstellung `MELDE_PUSH`, Schritt 8).
2. Die Besatzung trägt nach jeder Fahrt in der Fahrzeug-App nur den km-Stand ein; Abfahrt und Ankunft kommen aus dem FMS-Status, die Einsatznummer aus dem laufenden Einsatz.
3. Die Gerätewarte tragen in der Gerätedatenbank beim Fahrzeug unter **„🚗 Fahrtenbuch & Fristen“** HU, SP, UVV, Wartung und Pumpenprüfung ein. Erinnerungen 28 Tage vorher per Mail und Push; die Fristen erscheinen auch auf dem Alarmmonitor und im Kalender-Abo.
4. Das Fahrtenbuch enthält keine Kosten – nur km, Liter, Betriebsstunden, Zweck, Ziel und Fahrer.

## 30. PowerAlarm-Anbindung (ab Version 5.12)

1. In PowerAlarm (www.poweralarm.de): **Administration → Verwaltung → „API-Keys für Schnittstellen“** → neuen Key für die JSON-Schnittstelle anlegen, Beschreibung „Einsatzverwaltung“, Rechte **Gruppen/Kontakte lesen: ja** und **Alarm auslösen: ja**. Key kopieren (er wird nur dort angezeigt; nie ungültige Keys verwenden – PowerAlarm sperrt dann).
2. Einsatzverwaltung → Verwaltung → Einstellungen → **Alarmierung & E-Mail → PowerAlarm-Anbindung → Zugangsdaten**: Key eintragen, Speichern (PIN). Dort auch: „Alarme aus PowerAlarm einlesen“ (aus/hinweis/einsatz), „Fahrzeugstatus an PowerAlarm senden“ (an/aus), „Vorgewählte Gruppe“.
3. Verwaltung → Einstellungen → Alarmierung → **PowerAlarm-Anbindung** → **„Verbindung prüfen“** – die Gruppen aus PowerAlarm erscheinen. Einmal **„Probealarm senden“** an eine Testgruppe.
4. Für „Status senden“: Verwaltung → Fahrzeuge → je Fahrzeug die **PowerAlarm-Kennung** (BOS-Kennung 8-stellig, OPTA oder ISSI) eintragen – dieselbe wie in PowerAlarm unter Administration → Fahrzeuge.
5. Der Pi braucht Internet zu `www.poweralarm.de` (Port 443). Den Fahrzeugstatus **empfangen** tut weiterhin „Fahrzeugstatus von außen“ (HTTP-Kontakt in PowerAlarm) – dafür ist kein Key nötig.

## Fehlersuche

| Problem | Prüfen |
|---|---|
| Seite lädt nicht | Läuft der Dienst? `sudo systemctl status einsatzverwaltung` |
| „Getrennt“ in der App | Ist der Pi im selben Netzwerk erreichbar? `ping 192.168.178.50` |
| Nach Neustart des Pi nichts erreichbar | `sudo systemctl enable einsatzverwaltung` ausgeführt? |
| Änderungen anderer Geräte kommen nicht an | Alle Geräte auf **derselben** Adresse (`http://<Pi-IP>:8080`), nicht `localhost`? |
| `npm install` schlägt fehl | Hat der Pi Internetzugang? (Nur für die Installation nötig, danach nicht mehr) |
| Fahrzeug-App zeigt „Nicht gefunden" | Link über „Fahrzeug-App für dieses Fahrzeug“ erzeugt (nicht abgetippt)? Läuft der Meldeserver (Port 8081)? |
| Fahrzeug-App: „Standort nicht verfügbar“ | Adresse beginnt nicht mit https:// – externe Adresse einrichten (Schritt 8). Standortfreigabe am Handy erlaubt? |
| ASÜ-Zahlen erscheinen nicht in der Einsatzverwaltung | ASÜ vom Pi geöffnet (Port 8082), nicht von GitHub? Unter ASÜ → Einstellungen „Übergabe an Einsatzverwaltung“: Zeile „Zuletzt erfolgreich gesendet“? Beispieldaten werden nie gesendet. |
| ASÜ meldet „Wehr-Schlüssel falsch“ | `ASUE_KEY` gesetzt? Dann denselben Schlüssel in der ASÜ unter Einsatzdaten → Mehrere Geräte eintragen. |
| ASÜ zeigt „Nur Anzeige“, soll aber führen | Am führenden Gerät *Führung übergeben* oder hier *Führung übernehmen (Admin-Passwort)*. |
| ASÜ über Mobilfunk „Server nicht erreichbar“ | `tailscale funnel status` zeigt Port 8443? Beide Adressen eingetragen? `ASUE_ORIGIN` gesetzt, wenn die ASÜ von GitHub kommt? |
| Benachrichtigungen kommen nicht an | App über die **https**-Adresse geöffnet? iPhone: als App vom Home-Bildschirm? In der App „Test senden“. Hat der Pi Internet? Im Handy: Benachrichtigungen für die App/den Browser erlaubt, kein „Nicht stören“/Stromsparmodus, der Hintergrundaktivität verbietet? |
| ASÜ auf GitHub veröffentlichen schlägt fehl | Meldung im Abschnitt „Direkt auf GitHub veröffentlichen“ lesen: „Schlüssel ungültig“ → neuen Schlüssel erzeugen; „keine Berechtigung“ → beim Schlüssel „Contents: Read and write“ und das richtige Repository wählen; „nicht gefunden“ → Schreibweise `konto/name` und Branch prüfen. Hat der Pi Internet? |
| Apps zeigen eine andere Schrift | Der Pi hat die Schriften noch nicht geladen (kein Internet). Sie werden automatisch nachgeladen, sobald er online ist. |
| Fahrzeug-App von unterwegs nicht erreichbar | Zuerst **Verwaltung → Zustand des Pi → „Verbindung von außen“** – zeigt die Ursache und hat Knöpfe zum Reparieren. Sonst: Tailscale Funnel aktiv (`tailscale funnel status`) bzw. Portfreigabe für Port **8081** eingerichtet (siehe Schritt 8)? |

---

## Anhang: Hinweise zu einzelnen Versionen

Neueste Version zuerst. Was in einer Version neu ist, beschreibt `docs/BEDIENUNG.md` (Anhang „Versionshistorie“).

**Version 5.72** (Gerätedatenbank am PC: ein Knopf „Prüfen“ mit Auswahl): über „Programm aktualisieren“ einspielen.

**Version 5.71** (Gerätedatenbank: „aus Foto“ entfernt, am PC alle Funktionen in einer Reihe ohne „Mehr“): über „Programm aktualisieren“ einspielen.

**Version 5.70** (Gerätedatenbank: Mehr in der unteren Leiste, Menüs schließen beim Tippen daneben, Druckansicht im Fenster, Begriffe/Vorlagen/Listen in einem Fenster, Wochenüberblick in der Übersicht): über „Programm aktualisieren“ einspielen.

**Version 5.69** (PowerAlarm-Fahrzeuge: nur aktueller Status und A; nach Einsatzende zurück auf den gelesenen Status; feste Reiterleisten in der Verwaltung): über „Programm aktualisieren“ einspielen.

**Version 5.68** (Gerätedatenbank: + Gerät, Scannen, Prüfen als feste Leiste unten auf Handy/Tablet): über „Programm aktualisieren“ einspielen.

**Version 5.67** (Überschrift aller Fenster bleibt beim Scrollen stehen): über „Programm aktualisieren“ einspielen.

**Version 5.66** (Ablaufplan übersichtlicher: Besetzungsleiste, Ein Platz/Alle Plätze, Hilfsmittel rechts): über „Programm aktualisieren“ einspielen.

**Version 5.65** (Objekt-Eingabe überarbeitet: Abschnitte, Art als Kacheln, Merkmale als Schaltflächen): über „Programm aktualisieren“ einspielen.

**Version 5.64** (Objekte: Symbole auch auf der Karte, Merkmale, Filter; Ansprechpartner: Kategorien, Stichworte, Ort, 24 h, Filter): über „Programm aktualisieren“ einspielen.

**Version 5.63** (Fahrzeugkarten: Status-Hinweis in der Mitte; Korrektur der Gestaltung aus 5.62): über „Programm aktualisieren“ einspielen.

**Version 5.62** (Aussehen und Bedienung: einheitliche Knöpfe, Nachtmodus, Statusfarben, Rückgängig, Wischen, direkt zum eigenen Platz, Ladeanzeige, Symbole): über „Programm aktualisieren“ einspielen.

**Version 5.61** (ELW-Info: Offline-Hinweis, Aufträge, Atemschutz, Großanzeige; Platz übergeben; Zähler/Ton bei Meine Feuerwehren; Fahrzeug-App-Sperren am Pi; Einstellungen zwischen Fahrzeugen übernehmen): über „Programm aktualisieren“ einspielen.

**Version 5.60** (neues App-Icon für die Einsatzverwaltung auf dem Home-Bildschirm): über „Programm aktualisieren“ einspielen.

**Version 5.59** (eigenes App-Icon für die Gerätedatenbank): über „Programm aktualisieren“ einspielen.

**Version 5.58** (ELW-Info-App unter /elw – nur Ansicht, fürs Tablet im ELW über VPN): über „Programm aktualisieren“ einspielen.

**Version 5.57** (Platz-Name automatisch, neue Ansicht „Meine Feuerwehren“ mit Aufträgen, Fahrzeugen und Nachrichten): über „Programm aktualisieren“ einspielen.

**Version 5.56** (neuer Editor für die Ablaufpläne, Reiter Fahrzeug-App in der Gerätedatenbank mit Schaltern): über „Programm aktualisieren“ einspielen.

**Version 5.55** (Ablaufplan: Erklärungen für den ganzen Plan und je Platz): über „Programm aktualisieren“ einspielen.

**Version 5.54** (Gerätewart stellt je Fahrzeug ein, welche Checklisten und Meldungen in der Fahrzeug-App kommen): über „Programm aktualisieren“ einspielen.

**Version 5.53** (Ablaufpläne Team ELW/ÖEL mit Plätzen, „Mein Platz“, Bearbeiten und „Meine Feuerwehren“): über „Programm aktualisieren“ einspielen.

**Version 5.52** (PowerAlarm-Status: nur Klarnamen von Personen überspringen, OrtsBM/GemBM werden ausgewertet): über „Programm aktualisieren“ einspielen.

**Version 5.51** (PowerAlarm-Status: nur Fahrzeuge, keine Personen/Funktionen): über „Programm aktualisieren“ einspielen.

**Version 5.50** (Gerätedatenbank: „Mehr“ wird beim Aufklappen zu „Weniger“): über „Programm aktualisieren“ einspielen.

**Version 5.49** („Alarmiert“ bleibt bis Status 3; automatisches Beenden zählt nur ausgerückte Fahrzeuge): über „Programm aktualisieren“ einspielen.

**Version 5.48** (PowerAlarm-Fahrzeuge über Bezeichnung/OPTA erkennen): über „Programm aktualisieren“ einspielen; der Pi verbindet sich danach neu und übernimmt alle Status.

**Version 5.47** (Fahrzeugstatus über den PowerAlarm-Websocket mit PA-Monitor-Key): über „Programm aktualisieren“ einspielen, danach in Einstellungen → PowerAlarm den PA-Monitor API-Key eintragen. Ausgehende Verbindung zu www.poweralarm.de Port 8001 muss im Netz erlaubt sein.

**Version 5.46** (Statusmeldungen „Status Änderung X => Y“ per E-Mail/PowerAlarm setzen den Fahrzeugstatus statt Alarm): über „Programm aktualisieren“ einspielen.

**Version 5.45** (Handy-Ansicht der Datenbank: Bereiche als Menü oben links): über „Programm aktualisieren“ einspielen.

**Version 5.44** (Feuerwehrhäuser eindeutig je Gemeinde/Stadt): über „Programm aktualisieren“ einspielen, danach Verwaltung → Feuerwehrhäuser → „🔄 Mit Fahrzeugliste abgleichen“.

**Version 5.43** (Alarmmonitor ohne Kräfte laut Stichwort / weitere Kräfte): über „Programm aktualisieren“ einspielen; der Monitor lädt sich selbst neu.

**Version 5.42** (Feuerwehrhäuser mit Fahrzeugliste abgleichen, Leitung der Gerätewarte je Ortswehr): über „Programm aktualisieren“ einspielen. Danach unter Verwaltung → Feuerwehrhäuser „🔄 Mit Fahrzeugliste abgleichen“.

**Version 5.41** (Gerätewarte pflegen ihre E-Mail-Adresse selbst): über „Programm aktualisieren“ einspielen.

**Version 5.40** (Gerätedatenbank: Vorlaufzeit der Erinnerungen je Zugang für App und E-Mail in Wochen): über „Programm aktualisieren“ einspielen.

**Version 5.39** (Fahrzeug-App: 📍 Standort und 🔔 Benachrichtigungen oben als Zeichen, Nachrichten-Spalten getauscht): über „Programm aktualisieren“ einspielen.

**Version 5.38** (Fahrzeug-App: Nachrichten auf dem Tablet zweispaltig): über „Programm aktualisieren“ einspielen.

**Version 5.37** (Fahrzeug-App mit Tablet-Ansicht, Verbrauchsmaterial nicht mehr auf der Startseite): über „Programm aktualisieren“ einspielen.

**Version 5.36** (Verbrauchsliste der Fahrzeug-App nur aus dem Verbrauchsmaterial der Gerätedatenbank): über „Programm aktualisieren“ einspielen; danach je Fahrzeug das Verbrauchsmaterial eintragen.

**Version 5.35** (Beleuchtung ohne „ja“, Schläuche/AGT/Beleuchtung beim Schaden melden, Schaummittel beim Verbrauchsmaterial): über „Programm aktualisieren“ einspielen.

**Version 5.34** (Fahrzeug-App: Schaden melden ohne vorgefertigte Texte, Freitext direkt unter „Was ist betroffen?“): über „Programm aktualisieren“ einspielen.

**Version 5.33** (Fach-Nr. je Gerät, Beladeplan mit Sortierung und Spaltenauswahl, Baujahr/Hersteller nur noch in der Gerätedatenbank): über „Programm aktualisieren“ einspielen.

**Version 5.32** (Fahrzeugdaten mit Beladung, Fristen und QR-Code zusammengefasst, Fahrtenbuch mit Filtern, gleich hohe Eingabefelder): über „Programm aktualisieren“ einspielen.

**Version 5.31** (Gerätedatenbank: einfacheres Gerätefenster, aufgeräumte Handy-Ansicht, Fahrzeugdaten mit QR-Code, Verbrauchsmaterial je Fahrzeug für die Fahrzeug-App, Stromaggregat automatisch als Gerät, Lagerplatz, Live-Aktualisierung, Feedback): über „Programm aktualisieren“ einspielen. Danach Hersteller/Baujahr und Verbrauchsmaterial je Fahrzeug eintragen.

**Version 5.30** (beim Anlegen von Geräten und Ausrüstung werden alle vorhandenen Bezeichnungen angezeigt): über „Programm aktualisieren“ einspielen.

**Version 5.29** (Stromaggregat in kVA und Beleuchtung intern/extern in der Fahrzeug-Beladung und Ausrüstungssuche): über „Programm aktualisieren“ einspielen, danach die Werte je Fahrzeug eintragen (mit Gerätedatenbank durch den Gerätewart).

**Version 5.28** (Aufträge erkunden: neue Spalte „🔍 Erkunden“, Meldungen des Erkunders bleiben am Auftrag, danach zurück unter „Neu“ mit Vermerk „erkundet“): über „Programm aktualisieren“ einspielen, keine Einstellungen nötig.

**Version 5.27** (Nachbesprechung, BMA-Fehlalarme, Ortswehr-Übersicht, Ablöseplanung, Unwetter-Liste, Navigation und gesprochene Lagemeldung in der Fahrzeug-App, AGT-Tauglichkeit in Atemschutz-Karte und Besatzung, Rollen Gemeinde- und Ortsbrandmeister, Datenschutz-Schwärzung): über „Programm aktualisieren“ einspielen. Danach unter Verwaltung → Benutzer die Zugänge der Orts- und Gemeindebrandmeister anlegen und unter Einstellungen → Betrieb die Datenschutz-Frist festlegen (z. B. 24 Monate, Absprache mit dem Datenschutzbeauftragten der Gemeinde).

**Version 5.26** (Umzugshinweis auf der alten GitHub-Seite der ASÜ): über „Programm aktualisieren“ einspielen, dann Verwaltung → ASÜ-Zugänge → „Hinweis auf die alte Seite veröffentlichen“ bzw. das ZIP im bisherigen Repository hochladen.

**Version 5.25** (ASÜ direkt vom Pi – GitHub wird für die Ortswehren nicht mehr gebraucht; GitHub nur noch für die eigenständige ASÜ für andere Feuerwehren): über „Programm aktualisieren“ einspielen. Danach unter Verwaltung → ASÜ-Zugänge die Internetadresse des Pi prüfen und die Tablets auf die Adresse des Pi umstellen (siehe Bedienungsanleitung „Neu in 5.25“). Die bisherige automatische Veröffentlichung auf GitHub ist abgeschaltet; für die eigenständige ASÜ ein neues Repository anlegen. Schritt 26 gilt ab jetzt nur noch für die eigenständige Ausgabe; `ASUE_ORIGIN` wird nicht mehr gebraucht.

**Version 5.24** (einheitliche Begriffe für Geräte in allen Ortswehren; Ausrüstung: Wasser, Schaummittel, Schläuche und AGT einmal mit Summe und Menge je Fahrzeug): über „Programm aktualisieren“ einspielen, ASÜ auf GitHub neu veröffentlichen. Danach in der Gerätedatenbank unter ⋯ Mehr → „Einheitliche Begriffe“ die abweichenden Bezeichnungen umstellen.

**Version 5.23** (Gerätedatenbank: Monatsliste per Mail, Prüfen am Fahrzeug nach Geräteraum, Haltbarkeit, Prüfnachweis, Reparaturstufen, QR-Code fürs Fahrzeug, Gerätevorlagen, „Wo ist …?“, Jahresbericht): über „Programm aktualisieren“ einspielen, ASÜ auf GitHub neu veröffentlichen.

**Version 5.22** (Ampel der Gerätedatenbank in der Fahrzeug-App): über „Programm aktualisieren“ einspielen.

**Version 5.21** (einfachere Bedienung: Meine Ansicht je Benutzer, Ausgaben-Menü im Einsatz, Einsatz-Karten mit Text, Verwaltung in 5 Gruppen, einheitliche Druckansicht; Gerätedatenbank mit „Heute zu tun“, Reitern im Gerätedialog, einklappbaren Fahrzeugen, Filter- und Mehr-Menü, Dubletten-Warnung; großer Einsatz-Bildschirm in der Fahrzeug-App): über „Programm aktualisieren“ einspielen, ASÜ auf GitHub neu veröffentlichen.

**Version 5.20** (Gerätedatenbank: Stapelprüfung, weitere Prüflisten, Mängel mit Foto und Frist, Beladeplan, Fehlteile, Ampel, Lager, Lebenslauf, Aussonderung, Offline; Baujahr; Übersicht Gemeindebrandmeister): über „Programm aktualisieren“ einspielen, ASÜ auf GitHub neu veröffentlichen. Für den Gemeindebrandmeister einen Gerätewart-Zugang mit allen Ortswehren anlegen.

**Version 5.19** (Kalender der Gerätedatenbank je Ortswehr mit Abo für Apple/Google): über „Programm aktualisieren“ einspielen, ASÜ auf GitHub neu veröffentlichen.

**Version 5.18.2** (Beladung mit Anzahl wird in der Gerätedatenbank gepflegt): über „Programm aktualisieren“ einspielen, ASÜ auf GitHub neu veröffentlichen.

**Version 5.18.1** (Einsatzbericht erst nach Ablauf der 3-Stunden-Frist für Schadensmeldungen): über „Programm aktualisieren“ einspielen.

**Version 5.18** (Beladung mit Anzahl, Standard-/Zusatzausstattung, Einsatzbericht an die Ortsbrandmeister, Auto-Schließen, Schadensmeldung bis 3 h): über „Programm aktualisieren“ einspielen, danach unter Verwaltung → Einstellungen → Alarmierung & E-Mail die Adressen der Ortsbrandmeister eintragen und die Beladung der Fahrzeuge prüfen. ASÜ auf GitHub neu veröffentlichen.

**Version 5.17.3** (Darstellungsfehler auf PC, Tablet und Handy behoben, bebilderte Anleitung): über „Programm aktualisieren“ einspielen. ASÜ auf GitHub neu veröffentlichen.

**Version 5.17.2** (Einstellungs-Leiste bleibt beim Scrollen stehen, untere Leiste am Handy fest): über „Programm aktualisieren“ einspielen.

**Version 5.17.1** (Fahrzeug-App: Benachrichtigungen immer für alles, keine Auswahl mehr): über „Programm aktualisieren“ einspielen.

**Version 5.17** (Benachrichtigungen auch in Fahrzeug-App und bei den System-Mails der Einsatzverwaltung auswählbar): über „Programm aktualisieren“ einspielen.

**Version 5.16** (Benachrichtigungen je Zugang auswählbar – App und E-Mail getrennt): über „Programm aktualisieren“ einspielen. ASÜ auf GitHub neu veröffentlichen.

**Version 5.15** (Gerätetausch in der ASÜ: scannen, FTZ oder Elemente, Tauschgerät mit QR): über „Programm aktualisieren“ einspielen. ASÜ auf GitHub neu veröffentlichen.

**Version 5.14** (ein Einsatz je PowerAlarm-Alarm, PowerAlarm + E-Mail zusammengeführt, Fahrzeuge in der Nachalarmierung): über „Programm aktualisieren“ einspielen.

**Version 5.13** (Checklisten als Excel, Alarmmonitor mit Ortsfeuerwehren, Hydranten nur eigene Gemeinde): über „Programm aktualisieren“ einspielen. Für den Hydranten-Filter muss unter Einstellungen die Stadt/Gemeinde eingetragen sein.

**Version 5.12** (PowerAlarm-Anbindung): über „Programm aktualisieren“ einspielen, danach Schritt 30.

**Version 5.11** (Excel-Import und -Export der Datenbanken je Ortswehr): über „Programm aktualisieren“ einspielen. ASÜ auf GitHub neu veröffentlichen (Datenbank-Apps).

**Version 5.10.4** (Gesamttest, Fehlerbehebung): über „Programm aktualisieren“ einspielen. Anleitungen und Demo auf Stand 5.10.4.

**Version 5.10 – 5.10.3** (Fahrtenbuch, Fahrzeugfristen, Hydrantenfotos, Löschwasser-Abdeckung): über „Programm aktualisieren“ einspielen, danach Schritt 29. ASÜ auf GitHub neu veröffentlichen (Gerätedatenbank).

**Version 5.9** (Hydrantenprüfung über die Fahrzeug-App): über „Programm aktualisieren“ einspielen, danach Schritt 28.

**Version 5.8** (Jahresbericht, Notfallmappe, ASÜ automatisch auf GitHub, Betriebshandbuch): über „Programm aktualisieren“ einspielen, danach Schritte 26 und 27.

**Version 5.7** (Trupp-Stärke nach FwDV 7, Prüfarten, Datenschutzhinweise, Schriften vom Pi): über „Programm aktualisieren“ einspielen, danach Schritt 25. ASÜ auf GitHub neu veröffentlichen.

**Version 5.6** (Angemeldet bleiben, Sicherheitsübersicht, Prüfprotokoll, Wochenüberblick, Jahresauswertung Atemschutz, persönlicher Link, Löschfrist für Geräteträger): über „Programm aktualisieren“ einspielen.

**Version 5.5** (Datenbanken als App mit Benachrichtigungen): über „Programm aktualisieren“ einspielen, danach Schritt 23.

**Version 5.4** (Superadmin): über „Programm aktualisieren“ einspielen, danach Schritt 24.

**Version 5.3** (Gerätetausch und Prüfung aus der ASÜ für jede Feuerwehr): über „Programm aktualisieren“ einspielen, ASÜ auf GitHub neu hochladen.

**Version 5.2** (Gerätewart und Atemschutzgerätewart getrennt anlegen): über „Programm aktualisieren“ einspielen.

**Version 5.1** (Kennwort der Gerätewarte alle 4 Monate, Erinnerung per Mail): über „Programm aktualisieren“ einspielen. Von außen erreichbar sind die Datenbanken über die Internetadresse der ASÜ (Tailscale Funnel Port 8443, Schritt 13) unter `/geraete` und `/atemschutz` – Port 8080 bleibt intern.

**Version 5.0** (eigene Seiten für Geräte- und Atemschutz-Datenbank, Nachweis und Prüffristen umgezogen): über „Programm aktualisieren“ einspielen. Beim ersten Start werden Prüffristen und Geräte außer Dienst aus der Alarmmonitor-Verwaltung in die Gerätedatenbank übernommen (siehe Systemprotokoll). Danach den Gerätewarten die Links aus Verwaltung → Gerätewarte geben. ASÜ über GitHub: Paket neu hochladen (die eigenen Seiten gibt es nur direkt auf dem Pi).

**Version 4.9** (Verbrauch nachfüllen, Fahrzeug-Check, Beladungsprüfung, Ausleihen): über „Programm aktualisieren“ einspielen; die Fahrzeug-Apps laden die neue Version selbst, ASÜ-Seite neu laden bzw. GitHub-Paket neu hochladen. Optional die Listen für Verbrauch und Fahrzeug-Check je Ortswehr in der Gerätedatenbank anpassen.

**Version 4.8** (Schäden aus der Fahrzeug-App melden): über „Programm aktualisieren“ einspielen; die Fahrzeug-Apps laden die neue Version von selbst, ASÜ-Seite neu laden bzw. GitHub-Paket neu hochladen. Damit Meldungen ankommen, bei den Gerätewart-Zugängen den Bereich Geräte und eine E-Mail-Adresse eintragen.

**Version 4.7** (Gerätedatenbank für Gerätewarte, ersetzt die Ausrüstungsliste): über „Programm aktualisieren“ einspielen, danach Schritt 22. ASÜ-Seite neu laden bzw. GitHub-Paket neu hochladen. Bestehende Zugänge der Atemschutzgerätewarte behalten den Bereich Atemschutz.

**Version 4.6** (Alarmmonitor: außer Dienst, Nachtmodus): über „Programm aktualisieren“ einspielen; den Nachtmodus je Monitor unter „Bearbeiten“ einschalten.

**Version 4.5** (Alarmmonitor: Karte mit Status-1-Fahrzeugen, Kalender, Prüffristen und Kalender-Abo): über „Programm aktualisieren“ einspielen; die Monitore laden die neue Seite von selbst. Danach je Monitor unter „Bearbeiten“ die Kalender-Adressen eintragen und unter „Prüffristen“ die eigenen Fristen anlegen. Für das Abo in Google/Apple muss der Meldeserver von außen erreichbar sein (Schritt 13).

**Version 4.4** (zwei Prüftermine je Atemschutzgerät mit Mail eine Woche vorher): über „Programm aktualisieren“ einspielen; ASÜ-Seite neu laden bzw. GitHub-Paket neu hochladen. Ein bisher eingetragenes „Prüfung fällig“ wird als Prüftermin 1 übernommen. Bei jedem Gerätewart-Zugang eine E-Mail-Adresse eintragen.

**Version 4.3** (Gerätepflege, Gerätetausch und Formblatt in der Atemschutz-Datenbank): über „Programm aktualisieren“ einspielen. Die ASÜ-Geräte müssen die neue Version laden (Seite einmal neu öffnen); wer die ASÜ über GitHub verteilt, das GitHub-Paket neu erzeugen und hochladen. Flasche, LA, Maske und Drücke stehen erst für Einsätze und Übungen ab dieser Version im Nachweis.

**Version 4.2** (Einsatzbereitschaft der Atemschutzgeräteträger auf einen Blick, täglicher Selbsttest): über „Programm aktualisieren“ einspielen, danach Schritt 21. Wer die ASÜ über GitHub verteilt, das GitHub-Paket neu erzeugen und hochladen.

**Version 4.1.1** (ASÜ: Nach- und Vorname beim Einlesen getrennt): über „Programm aktualisieren“ einspielen. Wer die ASÜ über GitHub verteilt, das GitHub-Paket neu erzeugen und hochladen.

**Version 4.1** (Feuerwehrhäuser und Anfahrtszeiten für Übungsgenerator und Übungsleitstelle): über „Programm aktualisieren“ einspielen, danach Schritt 20.

**Version 4.0.1** (Atemschutz-Datenbank nur für die Ortswehren der Gemeinde): über „Programm aktualisieren“ einspielen.

**Version 4.0** (Atemschutz-Datenbank für die Gerätewarte mit QR-Codes, Nachweisen nach FwDV 7 und Mail-Erinnerungen, Sammel-App, Geräte-Abgleich der ASÜ neu): über „Programm aktualisieren“ einspielen, danach Schritt 19. Wer die ASÜ über GitHub verteilt, das GitHub-Paket neu erzeugen und hochladen (neue Datei `sammeln.html`).

**Version 3.99** (Übungsleitstelle mit Sonderlage, Aufträgen, Automatik für die Übungsfahrzeuge und eingebundenem Übungsgenerator – Drehbücher spielt der Pi selbst ab): über „Programm aktualisieren“ einspielen. Wer den Übungsgenerator auch bei GitHub Pages nutzt, dort `uebung/index.html` ersetzen.

**Version 3.98** (Übungsleitstelle: eine Person spielt Fahrzeuge und Leitstelle mit virtuellen Übungsfahrzeugen – echte Fahrzeuge und Fahrzeug-Apps bleiben unberührt): über „Programm aktualisieren“ einspielen.

**Version 3.97** (Gefahrstoffdatenbank aus ADR 2025 und ERG 2024, komplett deutsch, Gefahrnummer und Leitfaden für alle Stoffe, Einsatz-Reiter „Gefahrstoff“, Eintragen aus der Datenbank, ⌂ der Lagekarte auf 1 km ums Gerätehaus): über „Programm aktualisieren“ einspielen.

**Version 3.96** (Gefahrstoff-Datenbank: Suche nach Nummer und Name, rund 2.350 UN-Nummern, Einsatzblatt mit übersetzten ERG-2024-Leitfäden, Absperrabständen und Stoffwerten, Übernahme in den Einsatz, Absperrbereich mit Wind auf der Lagekarte): über „Programm aktualisieren“ einspielen.

**Version 3.95** (Vollbild der Lagekarte ohne Reiterleiste): über „Programm aktualisieren“ einspielen.

**Version 3.94** (Reiterleiste über der Lagekarte mit Zahlen wie überall, Hauptreiter „Lagekarte“ entfallen): über „Programm aktualisieren“ einspielen.

**Version 3.93** (Tagebuch-Eingabe bleibt oben stehen, Diktierknopf neben dem Inhalt, Lagekarte aus dem Einsatz ohne Wechsel der Grundansicht, Zurück nur im Vollbild, Reiter Aufträge nur bei Sonderlage): über „Programm aktualisieren“ einspielen.

**Version 3.92** (Posterdruck: Anzahl Blätter wählbar, Anordnung, Vorschau; Funkskizze zeigt Unterabschnitte; Lagekarte/Einsatztaktik-Knöpfe aus der Übersicht entfernt): über „Programm aktualisieren“ einspielen.

**Version 3.91** (kompakterer Kopfbereich, Reiterleisten bleiben beim Scrollen stehen, neue Reiter-Reihenfolge im Einsatz, Nachrichten und Fotos mit Unterreitern, Symbolleiste bei wenig Platz): über „Programm aktualisieren“ einspielen.

**Version 3.90** (Unterabschnitte sichtbar mit dem Hauptabschnitt verbunden, Bereitstellungsraum als schmale aufklappbare Leiste rechts im Reiter Abschnitte): über „Programm aktualisieren“ einspielen.

**Version 3.89** (Lagekarte-Suche springt bei Koordinate/what3words direkt, Unterabschnitte, keine ASÜ-Meldungen mehr zum fehlenden Wehr-Schlüssel, Diktieren im Tagebuch und in der Fahrzeug-App, Tagebuch Von/An mit freier Eingabe, Filter und ⇄-Tausch): über „Programm aktualisieren“ einspielen.

**Version 3.88** (Funkrufname ÖEL 14-09-10, eigene Timer, Lagekarte: Symbole skalieren mit dem Zoom, Leitungen verlängern, ohne Saugleitung, Lagekarte als Reiter im Einsatz, Fahrzeugdetails → Lagekarte, Fahrzeug-App: Standort auch bei „Verfügbar“, Hydranten auf der Karte, Nachrichten im Auftragstagebuch, ELW-App-Karte hängt nicht mehr, Alarmmonitor mit Ortsfahrzeugen und weiteren Kräften, Mail-Anhänge in der App): über „Programm aktualisieren“ einspielen.

**Version 3.87** (ELW-Besatzungs-App: Einsatzstelle als Flamme, ELW als Fahrzeug): über „Programm aktualisieren“ einspielen.

**Version 3.86** (Fahrzeug-App je Fahrzeug nur auf einem Endgerät – Freigabe/Gerätewechsel über die Einsatzverwaltung, mehrere Geräte in den Fahrzeugdaten erlaubbar). Hinweis: Nach dem Einspielen wird das erste Gerät gebunden, das die App eines Fahrzeugs benutzt. Läuft eine App bisher auf mehreren Handys, dort „Mehrere Endgeräte erlauben“ setzen oder das richtige Gerät freigeben. Über „Programm aktualisieren“ einspielen.

**Version 3.85** (Fahrzeug-App: Standorte der anderen Fahrzeuge desselben Einsatzes auf der Karte, mit „FZ“ abwählbar): über „Programm aktualisieren“ einspielen.

**Version 3.84** (Fahrzeug-App: Reiter Stärke und Standort entfallen – Stärke im Reiter Einsatz, Standort und Benachrichtigungen dort aufklappbar): über „Programm aktualisieren“ einspielen.

**Version 3.83** (Fahrzeug-App: Nachrichten an andere Fahrzeuge im Einsatz, in der Einsatzverwaltung gekennzeichnet und ohne Meldung; ASÜ fragt beim Einsatzbeginn, ob sie sich dem Einsatz anschließt – eigenständig nicht sichtbar, Zeiten trotzdem im Atemschutz-Nachweis): über „Programm aktualisieren“ einspielen.

**Version 3.82** (Fahrzeug hinzufügen: vorhandene Fahrzeuge direkt aus der Liste wählen – erste Zeile filtert, mehrere auf einmal; Fahrzeuge über die Fahrzeugansicht entlassen oder ganz aus dem Einsatz entfernen): über „Programm aktualisieren“ einspielen.

**Version 3.81** (Fahrzeug-App: Eingabe oben, offene Nachrichten, darunter Verlauf nach Zeit; Links und Koordinaten überall anklickbar): über „Programm aktualisieren“ einspielen.

**Version 3.80** (Crash Recovery System bei VU mit Rettungsblatt an die Fahrzeuge, Führungsstelle ELW/ÖEL, Aufträge in der Einsatzuhr, Aufträge auch in den Nachrichten der Fahrzeug-App, Status 2 löscht „Im Einsatz/Verfügbar“, Fahrzeuge aus dem Einsatz entfernen, letzte GPS-Zeit, Mail-Anhänge öffnen, Abmelden beim Schließen, automatische Einsätze nach 1 h ohne Bearbeitung beenden): über „Programm aktualisieren“ einspielen.

**Version 3.79** (Kommunikation mit den Fahrzeugen: Förderstrecke mit Kartenbild und ///what3words je Pumpe an die Fahrzeuge senden, Links/what3words/Koordinaten in Nachrichten anklickbar und springen in die Karte, BR-Link in der Nachricht, Bildschirmfoto/Ausschnitt/Kartenausschnitt als Bild, alle empfangenen Nachrichten in der Fahrzeug-App, Karte im Vollbild, gemeldete Aufträge nicht mehr selbst übernehmbar): über „Programm aktualisieren“ einspielen.

**Version 3.78** (ASÜ über GitHub an die Ortswehren verteilen: Paket aus Verwaltung → ASÜ-Zugänge, Anmeldung über den Pi, Gerät merkt sich den Zugang und den Wehr-Schlüssel, Kennwörter bleiben bei neuen Versionen gleich): über „Programm aktualisieren“ einspielen.

**Version 3.77** (ASÜ-Zugänge mit Startcode: Die Feuerwehr legt ihr Kennwort bei der ersten Anmeldung in der ASÜ selbst fest; „Eigenes Kennwort ändern“ in der ASÜ): über „Programm aktualisieren“ einspielen. Die ASÜ-Tablets laden die neue Version beim nächsten Öffnen.

**Version 3.76** (Verwaltung → ASÜ-Zugänge: Kennwörter der Ortswehren neu setzen – einzeln oder mehrere, Vorschlag oder eigenes, einmalig anzeigen/drucken –, Zugänge anlegen, ändern, löschen; schreibt direkt `asue/benutzer.js`): über „Programm aktualisieren“ einspielen.

**Version 3.75** (Verwaltung → Zustand des Pi → „Verbindung von außen“: Prüfung von Programm, Internet, Tailscale, Funnel, Adresse und dem echten Weg von außen; Knöpfe „Funnel neu einrichten“, „Tailscale neu starten“, „Programm neu starten“, „Pi neu starten“; Überwachung alle 10 Minuten mit ⛔-Hinweis und Mail): über „Programm aktualisieren“ einspielen. Damit die Reparatur-Knöpfe auf einem bestehenden Pi funktionieren, einmalig den Befehl eingeben, den die Seite beim ersten Versuch anzeigt (Bedienungsanleitung „Neu in 3.75“).

**Version 3.74** (Pendelverkehr: Kreisverkehr über zwei Wegstrecken mit eigenem Rückweg, Zeitverlust durch Begegnungen auf engen Wegen im Gegenverkehr, Vergleich beider Betriebsarten): über „Programm aktualisieren“ einspielen.

**Version 3.73** (Lagekarte: Pendelverkehr als Strecke einzeichnen und berechnen – Liefermenge, Umlaufzeiten, fehlende Fahrzeuge, Pufferbehälter): über „Programm aktualisieren“ einspielen.

**Version 3.72** (Einsatz → Atemschutz zeigt nur noch die Überwachungen, die dem Einsatz zugewiesen sind): über „Programm aktualisieren“ einspielen.

**Version 3.71** (Priorität vergibt nur noch die Einsatzverwaltung bei der Disposition – keine Vorgabe mehr aus Fahrzeug-App, E-Mail und Formular; „⚡ PRIOLAGE“ der Leitstelle wird rot blinkend gekennzeichnet und steht immer oben): über „Programm aktualisieren“ einspielen.

**Version 3.70** (Fahrzeug-App: neuer Reiter „Melden“ in der Sonderlage – Aufträge mit Foto und Standort an die Einsatzverwaltung schicken): über „Programm aktualisieren“ einspielen. Die Fahrzeug-Apps laden die neue Version beim nächsten Öffnen.

**Version 3.69** (Alarmmonitor für das Gerätehaus – Einrichtung siehe Schritt 17): über „Programm aktualisieren“ einspielen.

**Version 3.68** (Checklisten und Jahresauswertung nach den landeseinheitlichen Stichworten, neue Checklisten BMA, Wald-/Vegetationsbrand und Gewässer; Alarm-Mails mit Stichworten wie „H1 VU Y“ werden vollständig gelesen): über „Programm aktualisieren“ einspielen. Eigene, schon angepasste Checklisten bleiben unverändert – die neuen Listen bei Bedarf unter Einstellungen → Einsatz ergänzen.

**Version 3.67** (Einsatzübersicht mit Stichwort, Kräften/Fahrzeugen/Mitteln und Meldebildern nach der Stichwortliste der KRL Weserbergland ab 31.07.2026; Rettungspunkte Forst auch in der Karte der Fahrzeug-App, mit ✚ ausblendbar): über „Programm aktualisieren“ einspielen.

**Version 3.66** (eigene App-Symbole; Feedback-Knopf 💬 mit Versand an joern-preuss@web.de; Excel mit einer Spalte je Ausrüstung, JSON-Export entfällt; Archiv und Verwaltung für Betrachter ausgeblendet; Rettungspunkte Forst in der Lagekarte; Standort im Hintergrund über Traccar Client/OwnTracks, 3 Stunden): über „Programm aktualisieren“ einspielen. Für das Feedback muss der E-Mail-Versand eingerichtet sein (Schritt „E-Mail“ in den Einstellungen). Rettungspunkte: optional die KWF-Datei einlesen (Verwaltung → Einstellungen → Lagekarte). Neue App-Symbole: auf iPhone/iPad die Apps einmal vom Home-Bildschirm entfernen und neu hinzufügen.

**Version 3.65** (Sicherungsstick ohne Terminal: automatisches Einhängen, Anzeige „Stick erkannt / nicht erkannt“, Sicherung sofort nach dem Einstecken; Benachrichtigungen in der Fahrzeug-App auch bei gesperrtem Handy): über „Programm aktualisieren“ einspielen. Danach einmalig am Pi `sudo bash ~/einsatzverwaltung/docs/stick-einrichten.sh` (Schritt 15) und in den Fahrzeug-Apps „🔔 Benachrichtigungen einschalten“ (Schritt 8). Die Fahrzeug-Apps laden die neue Version beim nächsten Öffnen.

**Version 3.64** (Tastaturkürzel-Übersicht korrigiert, Anleitungen aktualisiert): über „Programm aktualisieren“ einspielen.

**Version 3.63** (Such- und Filterzeile im Reiter Ausrüstung einheitlich, Auswahlfelder auf iPad/iPhone flach; neue Demo-Version): über „Programm aktualisieren“ einspielen.

**Version 3.62** (hängende ASÜ-Hinweise „keine Meldung seit …“ lassen sich entfernen; der Pi räumt veraltete ASÜ-Meldungen automatisch auf): über „Programm aktualisieren“ einspielen.

**Version 3.61** (neues Kartensymbol Dekon-Platz in Lagekarte und Einsatztaktik; Anzeige „Mitsenden“ auf der E-Mail-Seite repariert): über „Programm aktualisieren“ einspielen.

**Version 3.60** (Stärkemeldung von der Übersicht in den Reiter Fahrzeuge verlegt; Fahrzeug über die Fahrzeugansicht unter Fahrzeuge oder Abschnitte in einen anderen Einsatz verschieben, nur aus dem geöffneten Einsatz heraus; „nur dieser Einsatz“ standardmäßig an): über „Programm aktualisieren“ einspielen.

**Version 3.59** (Sonderlage: Auftragsübersicht mit Priorität, Kategorie und Ort neben der verkleinerten Einsatzuhr; Ausrüstung: Suchfeld, andere Ortswehren mit Treffern werden hervorgehoben): über „Programm aktualisieren“ einspielen.

**Version 3.58** (Fahrzeug-App in der Großschadenslage: Auftragskarte, „Im Einsatz“ setzt den Auftrag auf in Arbeit, „Verfügbar (Auftrag erledigt)“ schließt ihn mit Ergebnis ab und gibt das Fahrzeug für den nächsten Auftrag frei): über „Programm aktualisieren“ einspielen.

**Version 3.57** (Fahrzeug-App ohne FMS-Status und Sprechwunsch; neu „Im Einsatz“ und „Verfügbar“ – steuert das Senden des Standorts und erscheint in der Einsatzverwaltung am Fahrzeug; Status über PowerAlarm): über „Programm aktualisieren“ einspielen. Die Fahrzeug-Apps laden beim nächsten Öffnen neu.

**Version 3.56** (Waldbrandeinsatzkarte Niedersachsen wie FeWIS: Link, Kurzanleitung, Zugangsdaten nur für Einsatzleitung und Admins, Einsatzort zum Kopieren): über „Programm aktualisieren“ einspielen, danach als Admin unter Einstellungen → Einsatz die Zugangsdaten eintragen.

**Version 3.55** (FeWIS: Link, Kurzanleitung und Zugangsdaten – Zugangsdaten nur für Einsatzleitung und Admins; Angaben für die Meldung kopieren; Tagebucheintrag): über „Programm aktualisieren“ einspielen, danach als Admin unter Einstellungen → Einsatz → FeWIS Adresse, Zugang und Anleitung eintragen.

**Version 3.54.1** (nur Anleitung: Beispieladresse mit DuckDNS entfernt; für den Zugriff von außen gilt Tailscale Funnel): über „Programm aktualisieren“ einspielen.

**Version 3.54** (Bereitstellungsräume im Reiter Abschnitte wie ein Abschnitt, mit Link/QR und Versand an Fahrzeuge; „＋ Fahrzeug hinzufügen“ im Bereich Fahrzeuge, neue Fahrzeuge mit Gemeinde und Kennzeichen dauerhaft in der Fahrzeugliste): über „Programm aktualisieren“ einspielen.

**Version 3.53** (Atemschutzüberwachung: Personen einzeln erfassen, zu Trupps zusammenstellen und dabei den Truppführer festlegen; Truppführer wechseln; Trupp auflösen): über „Programm aktualisieren“ einspielen. Die ASÜ-App lädt beim nächsten Öffnen neu.

**Version 3.52** (Stärke ohne Unterführer, Status 2 setzt die Stärke zurück und verlässt bei mehreren Einsätzen den Einsatz, Fahrzeuge in einen anderen Einsatz umsetzen, Ort bei Objekten, Werkfeuerwehren Aerzener Maschinenfabrik und Lenze in der Ausrüstung, E-Mails gelesen für alle Benutzer, Suche nach Ausrüstung): über „Programm aktualisieren“ einspielen. Fahrzeug-App, Besatzungs-App und Sammelseite laden beim nächsten Öffnen neu.

**Version 3.51** (Wasserförderung über lange Wegstrecke: Geländehöhen offline auf dem Pi, Höhen auch von Hand mit Zwischenpunkten, 1 oder 2 B-Leitungen, Überdruck-Warnung bei Gefälle, Pumpentabelle mit Fahrzeugzuweisung, Höhenprofil mit Druckverlauf, Nachrechnen beim Verschieben einer Pumpe, Förderstrecke in Einsatzbericht und Einsatzmappe): über „Programm aktualisieren“ einspielen. Der Pi lädt danach einmalig die Geländehöhen (ca. 25 MB je Kachel, für Aerzen zwei Kacheln) – braucht dafür Internet; Stand unter Verwaltung → Einstellungen → Lagekarte → „Wasserförderung über lange Wegstrecke“.

**Version 3.50** (Bereitstellungsräume: mehrere je Einsatz, je Raum ein Handy-Link für Ankunft, Abfahrt und Stärke; Link per QR-Code oder direkt an die Fahrzeug-App schicken): über „Programm aktualisieren“ einspielen.

**Version 3.49** (Fahrzeuge nachmelden – auch solche, die noch nicht in der Fahrzeugliste stehen – in der Einsatzverwaltung „＋ Fahrzeug“, in der Besatzungs-App und beim Einlesen der Sammelseite; Markierung „🆕 nachgemeldet“ in der Fahrzeugverwaltung): über „Programm aktualisieren“ einspielen.

**Version 3.48** (Stärken sammeln in der ELW-Besatzungs-App: Fahrzeugliste weiter per QR-Code aus „📱 Per Handy sammeln“, Rückmeldung sofort online mit „An Einsatzverwaltung senden“, weitere Fahrzeuge per Suche ergänzen): über „Programm aktualisieren“ einspielen. Auf den Handys der Besatzung lädt die App beim nächsten Öffnen neu.

**Version 3.47.1** (Rückmeldungen der ELW-Besatzung nur noch informativ, kein Eintrag im Einsatztagebuch): über „Programm aktualisieren“ einspielen.

**Version 3.47** (ELW-Besatzung: App „Wer kommt?“ mit persönlichem Link je Person, Ankunftszeit, Standort des ELW auf der Karte; neuer Reiter **Besatzung** in der Einsatzverwaltung): über „Programm aktualisieren“ einspielen; danach im Reiter Besatzung die Personen anlegen und die QR-Codes verteilen. Für den ELW-Standort in der Fahrzeug-App des ELW den Standort einschalten.

**Version 3.46** (Fahrzeug-App: Reiter **Karte** mit what3words – Punkt antippen, eigener Standort, Einsatzort, Suche nach ///drei.wörtern, an die Einsatzleitung senden, Navigation): über „Programm aktualisieren“ einspielen; die Fahrzeug-App auf den Handys einmal neu laden.

**Version 3.45** (Alarmmail: Kräfte **GBM-AE**, **WF Aerzener Maschinenfabrik** und **Drohnenstaffel** werden alarmiert; Kürzel auch mit Funkrufnamen; Leitstellen-Mail mit **„Auftrag“** = Großschadenslage → Auftrag, Lage wird bei Bedarf angelegt): über „Programm aktualisieren“ einspielen.

**Version 3.44** (Verwaltung → Fahrzeuge: Suche und Filter nach Gemeinde, Ortswehr, Typ, Sondereinheit, Sortierung): über Einstellungen → Sicherung & System → „Programm aktualisieren“ einspielen.

**Version 3.43** (Überwachung des Mail-Alarms mit roter Leiste auf allen Geräten; Gefahrstoffe aus der Alarmmail automatisch am Einsatz mit Gefahrenkreis-Vorschlag; **Programm-Update per Knopfdruck** unter Einstellungen → Sicherung & System): einmalig noch wie oben mit install.sh einspielen – ab dann geht jedes Update über „Programm aktualisieren“.

**Version 3.42** (neuer Reiter **E-Mail**: Mails schreiben mit Inhalten zum Anhaken – Einsatzdaten, Lagemeldungen, Fahrzeuge/Stärke, Tagebuch, Aufträge, Bericht-PDF, Fotos –, Eingang mit Ergebnis und Gesendet; **Einstellungen** in Bereiche mit Suche geordnet): wie oben einspielen und auf allen Geräten neu laden.

**Version 3.41.4** (Testalarme per E-Mail von `joern-preuss@web.de`, Betreff mit **TESTALARM**, Vorlagen in `docs/Vorlage_Testalarm_per_Mail.txt`; Testeinsätze laufen als Übung): wie oben einspielen.

**Version 3.41.3** (zweites Postfach **`elw@feuerwehr-aerzen.de`** nur für den Empfang von Einsätzen, versendet nichts): einspielen, dann unter Schnittstellen → „E-Mail: zweites Postfach (nur Empfang)“ das Passwort eintragen.

**Version 3.41.2** (Alarmmail der Leitstelle Weserbergland `els@krl-wb.de` wird zum Einsatz: Stichwort, Einsatzort mit Objekt, Koordinate, Alarmzeit; alarmierte Einsatzmittel und die Fahrzeuge der alarmierten Ortsfeuerwehren gehen auf Status A): wie oben einspielen; Kürzel der Ortsfeuerwehren unter Einstellungen → E-Mail prüfen.

**Version 3.41.1** (E-Mail-Konto **Strato** `elw@gemeindefeuerwehr-aerzen.de` vorbelegt): einspielen, dann als Admin unter Verwaltung → Einstellungen → Schnittstellen → E-Mail nur noch das **Passwort** eintragen und im Block „E-Mail“ eine Test-Mail senden.

**Version 3.41** (**E-Mail**: Konto unter Verwaltung → Einstellungen → Schnittstellen → „E-Mail“ eintragen; Einsatzbericht als PDF, Lagemeldungen, freie Nachrichten und Systemmeldungen verschicken; Mails freigegebener Absender – Leitstelle oder eigene Erkunder – werden automatisch zu Einsatz, Tagebuch-Eintrag oder in der Großschadenslage zum Auftrag): wie oben einspielen und auf allen Geräten neu laden. install.sh installiert dafür Chromium (für den Bericht als PDF; ohne geht er als HTML-Datei mit). Neue Datei `mail.js` – install.sh kopiert sie mit.

**Version 3.40** (Atemschutzüberwachung: Trupp als **CSA** anlegen – höchstens 20 Minuten mit Warnung und Alarm; Sicherheitstrupp-Warnung direkt in der Überwachung bestätigen): wie oben einspielen, **ASÜ auf allen Tablets neu laden**.

**Version 3.39** (Fahrzeug-App mit Reitern Einsatz · Nachrichten · Stärke · Standort; Meldungen auf der offenen Seite bei Alarm, Nachricht, Objektdaten, Statusänderung): wie oben einspielen; die Fahrzeug-Apps holen sich die neue Fassung beim nächsten Öffnen.

**Version 3.38** (Lagekarte: Farben der Gefahrenkreise je Ring änderbar): wie oben einspielen und auf allen Geräten neu laden.

**Version 3.37** (Fahrzeug-App: **Objektdaten** für das erste alarmierte Fahrzeug der zuständigen Ortsfeuerwehr, das die Einsatzleitung vor Ort übernimmt; beim Objekt neues Feld „Zuständige Ortsfeuerwehr“): wie oben einspielen, Einsatzverwaltung und Fahrzeug-Apps neu laden. **Tipp:** bei den Objekten die zuständige Ortsfeuerwehr eintragen, wenn die Adresse keinen Ortsteil enthält.

**Version 3.36** (Stärkemeldung: **„📱 Per Handy sammeln“** – Fahrzeugliste per QR-Code aufs Handy, Stärken dort offline erfassen, Ergebnis per QR-Code, Foto oder Code zurück in die Einsatzverwaltung): wie oben einspielen und auf allen Geräten neu laden.

**Version 3.35** (Grundlage für die **Demo-Version** auf dem USB-Stick; Schnellfilter heißt wie die eigene Gemeinde; neue Einstellung `EV_HOST` für die Listen-Adresse): wie oben einspielen und auf allen Geräten neu laden. Die Demo selbst kommt als eigene Datei `Einsatzverwaltung-Demo.zip` und wird **nicht** auf dem Pi installiert.

**Version 3.34** (Einstellungen: „Symbole ins Tagebuch“ als Auswahlliste mit Suche und „alle/keine“; Lagekarte: auch die Untergruppen der Seitenleiste aufklappbar): wie oben einspielen und auf allen Geräten neu laden.

**Version 3.33** (Lagekarte: „📷 Ausschnitt / Poster“ – Bereich aufziehen, als Bild an Fahrzeuge senden, als PNG speichern oder als Poster bis A0 drucken, auch auf A4/A3-Blätter verteilt): wie oben einspielen und auf allen Geräten neu laden.

**Version 3.32** (Lagekarte: alle Werkzeuge, Marker, Fahrzeuge und Anzeigen links in aufklappbaren Bereichen; Leiste einklappbar für eine größere Karte): wie oben einspielen und auf allen Geräten neu laden.

**Version 3.31** (Atemschutzüberwachung zeigt, von welcher Feuerwehr die Überwachung ist – in der ASÜ-App und in der Einsatzverwaltung): wie oben einspielen, Einsatzverwaltung **und ASÜ auf allen Tablets** neu laden.

**Version 3.30** (Demo- und Übungseinsätze aus realen Einsätzen: im Archiv „🎭 Demo daraus erstellen“ – Personen, Rufnummern, Kennzeichen und Zeiten werden fiktiv; Abspielen als fertiger Demo-Einsatz im Archiv oder als Live-Übung): wie oben einspielen und auf allen Geräten neu laden. Neue Datei `demo.js` wird von install.sh mitkopiert.

**Version 3.29** (Sicherheit und Datenschutz: verschlüsselte Datensicherung, PIN-Abfrage vor kritischen Aktionen, Sicherheitshinweise für Admins, Löschfristen): wie oben einspielen und auf allen Geräten neu laden. Danach als Admin unter Verwaltung → **Sicherheit** den Sicherheits-Check durchgehen. Empfohlen: unter Einstellungen → „Schnittstellen, Adressen und Schlüssel“ → Betrieb ein **Sicherungs-Passwort** (mind. 12 Zeichen) eintragen und getrennt vom Stick aufbewahren; Löschfristen mit dem Datenschutzbeauftragten abstimmen und unter „Datenschutz“ eintragen (Vorgabe: nie löschen). Entschlüsseln einer Sicherung: `node sicherung-entschluesseln.js <Sicherungsordner> <Zielordner>`.

**Version 3.28** (Zugänge der Fahrzeug-App erneuern und sperren, Übersicht unter Verwaltung → Fahrzeug-App; die Schlüssel der Links liegen nur noch auf dem Pi): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden. Die bisherigen Links der Fahrzeuge gelten weiter.

**Version 3.27.1** (kleine Korrekturen: Beschriftung der Gefahrenkreise überdeckt nicht mehr das Symbol in der Mitte, GPS-Kennung verdeckt nicht mehr den Status am Fahrzeugzeichen, VU-Vorlage etwas weiter aufgezogen, verständlichere Einträge im Änderungsprotokoll, ASÜ-Hinweis und Übergabe-Checkliste): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden.

**Version 3.27** (Nachtmodus, Dichte, Einsatz-Zeitstrahl, Lagebesprechung, Übergabe der Einsatzleitung, Einsatzmappe, Plausibilitätsprüfung und Ablösung, Expositionsnachweis, Änderungsprotokoll): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden. Neuer Ordner `protokoll/` im Programmordner (wird bei Updates nicht gelöscht).

**Version 3.26** (Suche mit Strg+F, Tastaturkürzel, Mehrfachauswahl, Rückgängig, wartende Änderungen, Tagebuch-Textbausteine und Vorschläge, Hinweis-Zentrale): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden (auch die Fahrzeug-Tablets, damit die neue Verbindungsüberwachung aktiv ist).

**Version 3.25** (Arbeitsplätze für mehrere Bildschirme, „auf der Karte zeigen“ im anderen Fenster, Töne nur in einem Fenster, Anzeige-Modus mit Status-Tableau und Einsatz-Uhren): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden. Am ELW-/Gerätehaus-PC im Browser für die Adresse der Einsatzverwaltung „Pop-ups immer erlauben“ einstellen, damit ein Arbeitsplatz alle Fenster auf einmal öffnen kann.

**Version 3.24** (mehrere Bildschirme: Reiter und Einsatz-Bereiche über ⧉ in eigenen Fenstern): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden. Beim ersten Öffnen eines Fensters ggf. im Browser „Pop-ups erlauben“.

**Version 3.23** (alle Schnittstellen, Adressen und Schlüssel unter Verwaltung → Einstellungen → „Schnittstellen, Adressen und Schlüssel“ änderbar): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden. Werte aus der Dienstdatei (`Environment=…`) gelten weiter, bis in der App ein anderer Wert eingetragen wird; App-Werte stehen in `einstellungen.json` im Programmordner (nicht in der Datensicherung – nach einer Neuinstallation neu eintragen). Schlüssel werden in der App nie angezeigt.

**Version 3.22** (Wetter automatisch ins Tagebuch, Fotodokumentation mit Ort und Karte, Funkskizze, Pressetext-Entwurf, Jahresauswertung im Archiv, Fahrzeugstatus von außen z. B. aus PowerAlarm): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden. Für Wetter braucht der Pi Internet. PowerAlarm: Verwaltung → Einstellungen → „Fahrzeugstatus von außen“ einschalten und die angezeigte Adresse (Port 8081) in PowerAlarm als HTTP-Kontakt eintragen – Port 8081 ist ohnehin für die Fahrzeug-App freigegeben, eine weitere Portfreigabe ist nicht nötig.

**Version 3.21** (Lagekarte/Einsatztaktik: Fahrzeuge als taktische Zeichen mit Häkchen für die Darstellung, Einheitenzeichen, Pfeile/Linien/Text, Drehleiter-Aufstellfläche, Lagestände mit Vergleich und Bericht, Sperren, Vorlagen, wichtige Symbole automatisch ins Tagebuch): wie oben einspielen und die Einsatzverwaltung auf allen Geräten neu laden.

**Version 3.20** (Nachrichten und Fotos auch vom Fahrzeug an den ELW, Verlauf „Einsatz → Nachrichten“, Häkchen „Bericht“ für Nachrichten mit Bildern, Filter nach Absender/Empfänger im Einsatzbericht): wie oben einspielen, danach die Einsatzverwaltung auf allen Geräten und die Fahrzeug-App in den Fahrzeugen einmal neu laden. Bilder aus dem Bericht liegen dauerhaft im neuen Ordner `berichtbilder/` und werden mitgesichert.

**Version 3.19.1** (Ansprechpartner werden im Reiter „Objekte“ → „Ansprechpartner“ gepflegt; im Einsatz nur noch suchen und hinzufügen): wie oben einspielen. Die vorhandenen Ansprechpartner bleiben erhalten.

**Version 3.19** (Lagekarte: Rückgängig/Wiederherstellen, mehrere Bearbeiter ohne Überschreiben mit Anzeige „wer ist in der Karte“, Drucken/PDF mit Maßstab, Nordpfeil und Legende, Schlauchzahl und Wasserförderung mit Verstärkerpumpen, Flächen messen, Suchraster für die Personensuche, Zeitraffer der Lage): wie oben einspielen und die Einsatzverwaltung auf allen Geräten einmal neu laden. Alle Geräte sollten die neue Version haben, damit gleichzeitiges Arbeiten nichts überschreibt.

**Version 3.18** (Ansprechpartner-Datenbank mit Zuordnung zum Einsatz, CSV-Import/-Export): wie oben einspielen.

**Version 3.17** (Anmeldung auf dem Server mit Rollen, Zustand des Pi, Nachbereitung je Fahrzeug mit Gerätewart-Liste, Atemschutz-Nachweis je Person, Auswertung im Übungsgenerator): wie oben einspielen. **Wichtig:** Alle Geräte müssen sich danach einmal neu anmelden – mit denselben Benutzern und PINs wie bisher. Bei der ersten Anmeldung stellt der Pi die PIN auf ein sicheres Verfahren um. Admin-PIN 1234 bitte ändern. ASÜ und Fahrzeug-App sind nicht betroffen. Bei GitHub Pages den Ordner `uebung/` aus `asue-fuer-github.zip` aktualisieren.

**Version 3.16** (ASÜ: Einsatz-Code und andere Felder werden beim Tippen nicht mehr gelöscht; Übungsgenerator; Bilder in Nachrichten an die Fahrzeug-App): wie oben einspielen **und** die ASÜ bei GitHub Pages mit `asue-fuer-github.zip` aktualisieren (enthält jetzt auch den Ordner `uebung/`).

**Version 3.15** (Einsatz-Uhren für Notstromaggregat und Lagemeldung, Nachrichten an die Fahrzeug-App, automatische Datensicherung auf USB-Stick/Netzlaufwerk, Ausrüstungsfilter in der Fahrzeugliste des Einsatzes): wie oben einspielen, dann Schritt 15 einrichten. Die Fahrzeug-App lädt die neue Version beim nächsten Öffnen.

**Version 3.14** (Karte „VU“ mit Unfallfahrzeugen, Hochvolt-Hinweisen und Rettungsdatenblatt-Links; Checklisten nach Stichwort; Einsatzbericht als PDF mit Lagekarte und Atemschutz; Unwetterwarnungen für den Landkreis; Niederschlagsradar und Warnkarte des DWD auf der Lagekarte): wie oben einspielen. Für Warnungen braucht der Pi Internet; Radar und Rettungsdatenblätter lädt das jeweilige Gerät direkt.

**Version 3.13** (Abschnitte mit freien Fahrzeugen, Farben und Bereichen auf der Lagekarte; Reiter „Objekte“; Gefahrstoff-Links GESTIS/ERI-Cards korrigiert): wie oben einspielen.

**Version 3.12** (zweite Karte „Einsatztaktik“ mit Feuerwehr-Symbolen und Leitungen, Ausbreitungskegel mit Wind-Abruf, Satellitenbild online, GPS-Fahrzeuge von Hand verschiebbar): wie oben einspielen, danach die Einsatzverwaltung im Browser einmal neu laden.

**Version 3.11** (Auftragsübersicht mit Spalte „In Arbeit“ direkt in der Karte „Aufträge“, Abschnitte nebeneinander, Nachträge im Tagebuch, Stärke direkt in der Fahrzeugliste): wie oben einspielen.

**Version 3.10** (Reiter „Einheiten“ und „Ausrüstung“, Tagebuch mit „Meldung“, Abschnitte mit Auftrag und Ziehen, Fahrzeugsuche mit Ausrüstung, Adresssuche zuerst in 31855 Aerzen, Fahrzeug-App mit QR-Code zum Drucken): wie oben einspielen.

**Version 3.9** (neue Einsatzansicht: Kräfte in der Kopfzeile, Einsatzwahl neben den Reitern, Karten Übersicht/Einsatztagebuch/Abschnitte/Atemschutz/Aufträge/Fahrzeuge; ASÜ-Daten und „Zuschauen“ in der Einsatzverwaltung): wie oben einspielen **und** die ASÜ-Dateien bei GitHub ersetzen.

**Version 3.8** (Reiter „Gefahrstoffe“: Warntafel entschlüsseln, Stoffdaten über GESTIS, ERI-Cards und CAMEO Chemicals): wie oben einspielen.

**Version 3.7** (eigener Reiter „Lagekarte“, auch ohne Einsatz nutzbar; ausgeblendete Wasserentnahmestellen verschwinden jetzt zuverlässig): wie oben einspielen.

**Version 3.6** (Lagekarte.info-Link sowie KML- und GeoJSON-Export entfernt – gearbeitet wird nur noch in der eigenen Lagekarte; Kreise, Gefahrenkreise, Linien und Messstrecken lassen sich verschieben): wie oben einspielen. Ein früher erzeugter Lagekarten-Link funktioniert danach nicht mehr.

**Version 3.5** (what3words in allen Adresssuchen und im Koordinatenfenster, siehe Schritt 14): wie oben einspielen.

**Version 3.4.1** (ASÜ: Nachname und Vorname getrennt, Nachfrage „Ist der Trupp draußen?“ 10 Minuten nach „Rückzug angetreten“, einstellbar unter Einstellungen): wie oben einspielen und die ASÜ-Dateien auch bei GitHub ersetzen.

**Version 3.4** (ASÜ: ein führendes Gerät, Trupp-Vorschläge, Übergabe/Übernahme, mehrere Server-Adressen):
wie oben einspielen **und** die neuen ASÜ-Dateien auch bei GitHub hochladen, falls die ASÜ von dort geladen wird.
Laufende gemeinsame ASÜ-Einsätze: Führend wird das Gerät, das den Einsatz freigegeben hat. Danach Schritt 13.

**Version 3.3** (Auftragsübersicht mit Bereitstellungsraum, Wasserentnahmestellen, Gefahrenkreise): ebenfalls
einfach wie oben einspielen. Die Wasserentnahmestellen lädt der Pi etwa 5 Sekunden nach dem Start einmalig aus
OpenStreetMap (braucht dafür Internet) und speichert sie in `wasser.json`.

**Update auf Version 3.2** (scrollbare Karte, Aufträge bei Großschadenslagen, Objektpläne): einfach wie oben
einspielen. Vorhandene Lagekarten laufender Einsätze stellt der Server beim ersten Start automatisch auf
Geokoordinaten um. Danach auf jedem Tablet die Einsatzverwaltung einmal neu laden.


**Version 5.73:** Gerätedatenbank am PC – Bereich-Buttons und Geräteanzahl in der oberen Reiterleiste.

**Version 5.74:** Reiter „Datenbank“ in der Gerätedatenbank entfernt.

**Version 5.75:** Kopfzeile der Übersicht ohne Zusatztext.

**Version 5.76:** Feedback und Benutzermenü der Gerätedatenbank oben rechts in der Reiterleiste.

**Version 5.77:** PowerAlarm-Fahrzeuge – in der Detailansicht nur noch der Knopf „A“.

**Version 5.78:** Darstellung Gerätedatenbank auf Android korrigiert.

**Version 5.79:** Leitung je Ortswehr in der Verwaltung einstellbar.

**Version 5.80:** Pressluftatmer mit zugeordnetem Lungenautomat und Flasche.

**Version 5.81:** Atemschutzgerät = Gerät + Lungenautomat + Flasche; Prüftermine einmal für alle Geräte.

**Version 5.82:** QR-Scan in der ASÜ prüft Tauglichkeit; Geräte-QR mit LA und Flasche.

**Version 5.83:** QR live scannen, 4-stellige Nummer für Personen und Geräte, Tauglichkeit immer sichtbar.

**Version 5.84:** schnellerer Abgleich mit der Atemschutz-DB, aufgeräumte Handyansicht der ASÜ.

**Version 5.85:** Hinweis, wenn eine Person im Einsatz erneut unter Atemschutz geht.

**Version 5.86:** Trupp/Person in der ASÜ direkt löschen; Handy-Darstellung Geräteerfassung.

**Version 5.87:** Einrichtungslink für den Wehr-Schlüssel, Kamera startet mit QR live.

**Version 5.88:** DB-Reiter aus der ASÜ entfernt, Person einem Trupp zuweisen, sicherere Tauglichkeitsanzeige.

**Version 5.89:** ASÜ-Führung: Übergabe mit Annahme, Übernahme nur mit Zugang des führenden Geräts.

**Version 5.91:** Wehr-Leiste am führenden Gerät ausgeblendet.

**Version 5.91:** Einsatzende nur am führenden Gerät.

**Version 5.91:** Einsatz beenden nur am führenden Gerät; Gerätenachweis im Einsatznachweis.

**Version 5.92:** Träger-App „Mein Atemschutz“ (/traeger) mit Zugang je Geräteträger, Terminen, Erinnerungen und Online-Schulung.

**Version 5.93:** Import-Bereich für die jährliche Online-Schulung.

**Version 5.94:** Übungen/Einsätze von Hand im Einsatznachweis eintragen.

**Version 5.95:** Darstellung der Datenbank-Seiten auf dem Handy korrigiert.

**Version 5.96:** Bereiche entkoppelt (eigene Programmdatei Gerätedatenbank, getrennte Zugänge, Reiter Verwaltung nur für den Admin).

**Version 5.97:** Neue App Berichtswesen (/berichte) für Orts- und Gemeindebrandmeister.

**Version 5.98:** OBM-Adressen aus dem Berichtswesen.

**Version 5.99:** ASÜ und Gerätedatenbank im Programm getrennt, alte OBM-Adressen entfallen.

**Version 5.108:** Übungsleitstelle nur für den Starter, Mehrfachauswahl, Priorität Hoch/Mittel/Niedrig, Platzauswahl je Führungsstelle.

**Version 5.109:** Priolage-Zähler in der Spalte Neu korrigiert, Rufzeichen-Suche bei Anforderungen.

**Version 5.110:** Kategorie Feuer, Board-Spalte „In Dispo“, Erkunden nur bei Bedarf, Tagebuch Von/An-Tausch.

**Version 5.111:** Anforderung zeigt alle freien Fahrzeuge (nicht im Einsatz) zur Auswahl.

**Version 5.112:** Anforderung: Dropdown mit freien Fahrzeugen und Funktionen beim Tippen.

**Version 5.113:** Anforderung zeigt alle Fahrzeuge (im Einsatz markiert).

**Version 5.114:** Ort in der Überschrift des Auftragsfensters.

**Version 5.115:** ÖEL beim Einsatz anlegen setzt immer Sonderlage (Großschadenslage).

**Version 5.116:** Ort in allen Auftragsansichten in der Überschrift.

**Version 5.117:** Einheitliche Überschrift aller Auftragsfenster.

**Version 5.118:** Objekte als Liste nach Kategorien.

**Version 5.119:** Einsatz-Uhren als Kachelzeile (Dauer, Lagemeldung, Stärke, Atemschutz), Aufträge wie im Reiter Aufträge.

**Version 5.120:** 5.119 in der Einsatz-Übersicht zurückgenommen; stattdessen Anzeige „Einsatz-Uhren“ (Fenster und Bildschirme) mit Kachelzeile und Aufträgen wie im Reiter Aufträge.

**Version 5.121:** Anzeige Einsatz-Uhren: Aufträge in Spalten wie das Board; Board-Karte ohne doppelten Ort.

**Version 5.122:** Einsatz-Uhren: bei Sonderlage alarmierte Wehren statt Atemschutz.

**Version 5.123:** Einsatz-Uhren: Kopf (Stichwort/Nummer) nur bei mehreren Einsätzen.

**Version 5.124:** Alarmmonitor in der Sonderlage: Auftrag statt Einsatzort, bei mehreren Fahrzeugen große Karte.

**Version 5.125:** Übungsleitstelle: getrenntes Scrollen, alle Fahrzeuge verfügbar, nur benutzte angezeigt, Sonderlage nach Aufträgen gruppiert.

**Version 5.126:** Berichtswesen: Fahrzeuge, Hydranten, Ausrüstung als Berichte; Reiter Karte mit Abdeckung (Radius) und Einsätzen.

**Version 5.127:** Berichtswesen: Diagramme, Vorschau ablaufende Nachweise, Karte nach Anfahrtszeit, Hydranten nach Zustand, E-Mail-Abo, Jahresbericht.

**Version 5.128:** Berichtswesen: Karte drucken, Vorjahresvergleich, Hitliste je Ortsteil, Atemschutz-Belastung je Person, Kennzahlen, Namen kürzen/ausblenden.

**Version 5.129:** Darstellungsprüfung aller Apps (Handy/Tablet/PC) – Umbrüche, Überläufe, Fehler im Ablaufplan behoben.

**Version 5.205:** Reiterleiste im Einsatz springt nicht mehr, wenn Zahlen dazukommen (fester Platz für die Zahl).
**Version 5.204:** Aufträge: bei „Sonstiges“ ist eine Beschreibung Pflicht und wird statt „Sonstiges“ angezeigt; ///what3words in der Auftragsübersicht.
**Version 5.203:** E-Mail-Alarm: auch Mails, die anderswo schon als gelesen markiert wurden, werden verarbeitet (UIDs je Postfach, letzte 2 Tage).
**Version 5.202.1:** PowerAlarm: Führungs-/Datengruppen (auch mit Schreibfehlern, auch bei Hand-Zuordnung) alarmieren nicht die ganze Ortswehr; Funkrufname in Gruppennamen ohne führende Null.
**Version 5.202:** PowerAlarm/Leitstelle: alarmierte Ortswehren der eigenen Gemeinde werden mit ihren Einsatzfahrzeugen alarmiert, auch ohne Kürzel-Liste; Führungsgruppen (OrtsBM, GBM) nicht die ganze Wehr.
**Version 5.201:** Fahrzeug-App: Nach Einsatzende verschwinden nicht bestätigte Nachrichten, Einblendungen und Benachrichtigungen dieses Einsatzes.
**Version 5.200.2:** Knopf „Neuen Hydranten melden“ aus 5.200.1 wieder entfernt (Melden wie bisher per Antippen der Karte).
**Version 5.200:** Hydranten: OpenStreetMap verbinden (OAuth) und geprüfte neue Hydranten mit einem Tipp direkt in OSM eintragen (mit Doppel-Prüfung).
**Version 5.199:** Berichtswesen: Filter in Karte, Fristen und Anforderungen speichern und per Antippen wieder aufrufen (je Zugang).
**Version 5.198.4:** Etikettenbögen: Vier-Punkt-Ausrichtung (oberste/unterste Reihe, linke/rechte Spalte).
**Version 5.198.3:** Etikettenbögen werden ohne Leerseite zwischen den Bögen gedruckt.
**Version 5.198.2:** Vorgedruckte Etiketten auch für Fahrzeuge, Funkgeräte, Akkus und Lagerartikel.
**Version 5.198.1:** Etikett-Menü: jederzeit neu scannen, Code eintippen, einzeln sofort drucken (Bogen + Position wählbar) oder lösen.
**Version 5.198:** Vorgedruckte QR-Etiketten: Blanko-Bögen Avery L7872 (Geräte) und L6146 (Atemschutzgeräte, Träger) drucken und per Scan oder Code zuweisen; Übersetzung in allen Scannern, altes Etikett wird beim Ersetzen gesperrt.
**Version 5.197:** Fälschungssicheres Einsatztagebuch: Prüfsummen-Kette (SHA-256) je Eintrag, Anzeige „Tagebuch unverändert“, Siegel beim Einsatzende, Prüfsumme im Ausdruck.
**Version 5.196:** ASÜ: Ruhezeit nach dem Atemschutzeinsatz (FwDV 7) – Anzeige je Geräteträger, Warnung bei erneutem Einsatz vor Ablauf, Richtwert einstellbar (Vorgabe 30 min).
**Version 5.195:** Träger-App: Übungsstrecke (Datum der Übung) und G 26 (gültig bis) trägt jeder Träger selbst ein – Status und Datenbank sofort aktuell, in der Datenbank als „vom Träger eingetragen“ markiert.
**Version 5.194:** In allen Apps „▦ Nur QR-Code drucken“ (Größe 2,5–15 cm, 1× oder ganze Seite); Etikettendruck wahlweise mit Beschriftung oder nur Code.
**Version 5.193.4:** Träger-App: Terminfelder Übungsstrecke/G 26 auf dem Handy untereinander, keine Überlappung mehr.
**Version 5.193.3:** Fehler behoben: Sicherheitsabfragen (z. B. „Zugang löschen?“) erschienen in Datenbank-App und ASÜ nicht – Aktionen wurden nicht ausgeführt.
**Version 5.193.2:** Fahrzeug-App: rote Punkte in der unteren Leiste nur noch, wenn es dort etwas gibt.
**Version 5.193.1:** Fehler behoben: Gemeindebrandmeister-Kennzeichen (und Superadmin, E-Mail) gingen nach jedem Update in der Benutzerverwaltung verloren.
**Version 5.193:** Neu gemeldete Hydranten mit Art/DN melden, in Verwaltung und Wassermeister-App übernehmen, zusammenführen oder als Fehlmeldung entfernen; Knopf „In OpenStreetMap eintragen“; automatischer Abgleich mit OSM.
**Version 5.192.1:** Knopf „Alle offenen Mängel jetzt an den Wassermeister senden“.
**Version 5.192:** Hydrantenprüfung: Mängel gesammelt sonntags abends per Mail an den Wassermeister (je Hydrant Hinweis, Fotos, Karte); App für den Wassermeister per Link zum Abhaken „behoben“.
**Version 5.191:** Fahrzeug-App: alle Eingaben (Status, Stärke, Nachrichten, Meldungen, Fahrtenbuch …) werden ohne Netz gespeichert und später in der richtigen Reihenfolge gesendet.
**Version 5.190:** Fahrzeug-App: Hydrantenprüfung ohne Netz – Prüfungen werden auf dem Handy gespeichert und automatisch nachgesendet; Hydranten und besuchte Kartenkacheln auch im Funkloch.
**Version 5.189.1:** Automatisches Abmelden nur für Admin, Einsatzleitung und Ortsbrandmeister; Betrachter bleiben angemeldet.
**Version 5.189:** Einsatzverwaltung meldet Geräte nach 30 Minuten ohne Bedienung automatisch ab (Hinweis eine Minute vorher, einstellbar, 0 = aus).
**Version 5.188:** Gerätedatenbank und Atemschutz-Datenbank sind eine App (`/datenbank`) mit einer Anmeldung; Gerätewart sieht und bearbeitet die Atemschutzgeräte, Atemschutzgerätewart hat das Lager. Alte Links leiten weiter.
**Version 5.187.2:** Regenradar: Verlauf und Vorhersage mit der richtigen DWD-Messzeit (REFERENCE_TIME) – keine leeren Bilder mehr.
**Version 5.187.1:** Regenradar repariert – gültige Zeitpunkte vom DWD über den Pi, sonst einfaches Radar wie bisher.
**Version 5.187:** Radar mit 2-h-Vorhersage und Zeitschieber; Reiter in Berichtswesen und Datenbanken wie in ASÜ/Einsatzverwaltung.
**Version 5.186:** Eigene Dialoge statt Browser-Fenster, Rückgängig in Fahrzeug-App/ASÜ/Gerätedatenbank, feste Statusleiste, Wappen, einheitliche Suche, Leerzustände, Designvorschau entfernt.
**Version 5.185:** Durchgängige Symbole auch in der Einsatzverwaltung, „Aa“-Knopf ausgeblendet, besserer Kontrast, Mindestschrift 12 px.
**Version 5.184:** Einheitliches Erscheinungsbild aller Apps, eigene Symbole, Berichtswesen-Navigation, GDB-Startkacheln, ASÜ-Truppübersicht, kompakter Handy-Kopf.
**Version 5.183:** Anforderungen aus Vorjahren übernehmen/erneut stellen; Anzeige „Schon angefordert in …“.
**Version 5.182.1:** Berichtswesen: Auswahl im Monats-/Jahresbericht als gruppierte Zeilen.
**Version 5.182:** Einsatz-Uhren: kein Notstrom-Timer bei ÖEL; Lagemeldung um eigene Zeit verschiebbar.
**Version 5.181.2:** Prüflauf; Darstellungsfehler auf Handy/Tablet behoben (Aufträge, Formulare, Ansprechpartner, Tabellen, Anmeldung ASÜ/Gerätedatenbank).
**Version 5.181.1:** Schwebender Darstellungs-Knopf ◐ aus allen Apps entfernt.
**Version 5.181:** Fahrzeugverwaltung: vorgegebene Stärke (Soll) je Fahrzeug, in der Stärkemeldung übernehmbar.
**Version 5.180.1:** Aufträge in der Auftragsansicht per Drag & Drop in andere Spalten ziehen (Status).
**Version 5.180:** Einsatzstelle beim Anlegen von Einsätzen/Aufträgen auf der Karte suchen.
**Version 5.179:** Gefahrstoffdatenbank: Drucken-Knopf.

**Version 5.178:** Auftragstagebuch mit Vorauswahl der Fahrzeuge des Auftrags.

**Version 5.177.1:** Auftragskarten: bei Priolage nur „PRIOLAGE“, kein „vor Ort“-Schild.

**Version 5.177:** Auftragskarten zeigen die Adresse statt der Beschreibung.

**Version 5.176:** Lagekarte im Vollbild in voller Höhe mit schwebender Leiste.

**Version 5.175:** Aufträge kompakt (umschaltbar).

**Version 5.174:** Fenster und Rückfragen im Vollbild der Lagekarte sichtbar.

**Version 5.173:** Fahrzeug-App ohne schwebenden Darstellungs-Knopf.

**Version 5.172:** Fahrzeug-App ohne Textvorschläge.

**Version 5.171:** E-Mail → Gesendet zeigt nur Mails aus der Einsatzverwaltung (Systemmails einblendbar).

**Version 5.170.1:** Kurzanleitungen für alle Apps.

**Version 5.170:** Speicherbelegung unter „Zustand des Pi“.

**Version 5.169:** Benachrichtigungen (Mail/Fahrzeug-App) selbst einstellbar für Orts- und Gemeindebrandmeister, Erinnerung an wartende Anforderungen, Haushaltsjahr, Lager-Bewegungsprotokoll, Kurzanleitungen aktualisiert.

**Version 5.168:** Anforderungen ändern, drucken, Excel; Mails bei Bewertung; Gemeindelager mit Mindestbestand-Mail und Anfordern; bessere Zuordnung anonymer Personen; Fahrzeug/Funktion überall gleich.

**Version 5.167:** Namen in Berichtswesen und Atemschutz-Datenbank: Ortsbrandmeister ja, Gemeindebrandmeister nur anonym (nur lesen).

**Version 5.166:** Berichtswesen zeigt keine Namen mehr (Personen anonym als „Person n“).

**Version 5.165:** Anforderungen: Schritt „Eingetroffen“ mit Mail an den Ortsbrandmeister.

**Version 5.164:** Lager „Gemeinde“ in der Gerätedatenbank mit öffentlichen Artikeln (für Ortswehren nur lesend).

**Version 5.163:** Filter „Fahrzeuge“ in Kräfte & Mittel: ohne Fahrzeugtyp = Funktion.

**Version 5.162:** Anforderungen mit optionalem Link.

**Version 5.161:** Filter „Fahrzeuge“ in Kräfte & Mittel blendet Funktionen aus.

**Version 5.160:** Königsförde und Selxen sind überall eine Ortsfeuerwehr „Königsförde/Selxen“ (zwei Feuerwehrhäuser bleiben).

**Version 5.159:** Einstellungen mit Statuspunkten, „Was fehlt noch?“, Verbindungstests, Anbindungs-Übersicht, Erweitert-Schalter, Einrichtungs-Assistent, Export/Import, „Mitglied ausgeschieden“.

**Version 5.158:** Verwaltung aufgeräumt – neue Gruppen, Zugangsdaten beim jeweiligen Thema, Einstellungs-Blöcke zuklappbar und beschrieben.

**Version 5.157:** Anforderungen als filterbare Tabelle mit ein-/ausblendbaren Spalten für den Gemeindebrandmeister.

**Version 5.156:** Anforderungsliste im Berichtswesen (OBM fordern an, GBM bewertet, Bestellung und Ausgabe mit Zeitstempel).

**Version 5.155:** Priorität der Aufträge einheitlich „sofort / dringend / kann warten“.

**Version 5.154:** Gemeindebrandmeister als Häkchen; Rechte in der Einsatzverwaltung über die Rolle, Vorgabe Betrachter.

**Version 5.153:** Gemeindebrandmeister zentral in der Einsatzverwaltung: ein Benutzer/Kennwort für EV, Datenbanken und Berichtswesen, Zugangsblatt mit allen Links.

**Version 5.152:** Zugangsblatt als PDF (Name, Benutzer, Einmal-Kennwort, Link, QR) beim Anlegen von Zugängen in den Datenbanken und im Berichtswesen.

**Version 5.151.4:** Standort eines Fahrzeugs wird nach 24 Stunden ohne neue Meldung entfernt.

**Version 5.151.3:** Anfrage eines zweiten Geräts der Fahrzeug-App ablehnbar.

**Version 5.151.2:** Datendatei geschützt: Speichern nacheinander, automatische Wiederherstellung aus der Sicherung statt leerem Start, keine leeren Sicherungen.

**Version 5.151.1:** Zweite Meldung zum selben Einsatz ergänzt Fahrzeuge, Kräfte, Meldenden, Objekt, Stichwort und Meldebild.

**Version 5.151:** Kein doppelter Einsatz mehr, wenn Leitstellen-Mail und PowerAlarm zum selben Alarm kommen.

**Version 5.150:** FeuerON: Atemschutz-Nachweise als CSV für den Personen-Import; Ausfüllhilfe „Für FeuerON“ im Einsatzbericht.

**Version 5.149:** Einheitliches Aussehen aller Apps (Farben, Schrift, Kopf, Anmeldeseite); Hell/Dunkel/Nacht in allen Apps.

**Version 5.148:** Übersicht-Blöcke und Einsatzkopf einklappbar; Tagebuch-Eingabe einklappbar; leere Abschnitte klein; entlassene Fahrzeuge als einklappbare Zeile; Menü „⋯“ im Kopf.

**Version 5.147:** Fahrzeuge aus Kräfte & Mittel in Einsatz/Abschnitt ziehen; neuer Alarm öffnet sich direkt; „Alarmierte Fahrzeuge übernehmen ✓“; Abschluss-Assistent überspringt Schritte ohne offene Punkte; Tastenkürzel an den Knöpfen.

**Version 5.146:** Kräfte & Mittel behält die letzte Auswahl; Wasserstelle direkt als Nachricht an Fahrzeuge.

**Version 5.145:** Inhalt des Einsatzberichts wählbar, Einsatzort auf der Karte/per what3words, Objekt übernimmt Straße, „Anfordern“ in Kräfte & Mittel.

**Version 5.144:** Funkskizze bearbeitbar (verschieben, weitere Funkbereiche), Reiter Einsatz zuerst, Kräfte & Mittel merkt die Ansicht, what3words für Hydranten/Wasserstellen, Tagebuch-Filter und schwächere automatische Einträge, Nachrichten kopieren/weiterleiten, Abschnitte einklappbar, Lagebesprechung mit Anforderungen.

**Version 5.143:** Kräfte & Mittel kompakter (Filter in einer Zeile, Ortswehren als Chips, flachere Matrix).

**Version 5.142:** Einheiten und Ausrüstung zusammengefasst zu „Kräfte & Mittel“ (Liste, Nach Ortswehr, Ausrüstungs-Matrix, eine Suche für Fahrzeuge und Ausrüstung).

**Version 5.141:** Beim Einsatz eröffnen „Übung“ wählbar – wie eine Übung aus dem Übungsgenerator.

**Version 5.140:** Aufbau „Leitstand“ zum Umschalten (Instrumentenleiste, Fahrzeugspalte, Erinnerungsband) – alle Seiten bleiben.

**Version 5.139:** Tagebuch erkennt frei geschriebene und diktierte Meldungen (Fahrzeug, Status, Anforderung), automatische Erinnerungen (Sprechwunsch, Anfahrt, Anforderung, Ablösung).

**Version 5.138:** Lagetisch als neue Anzeige für Wandbildschirme (Karte, „Jetzt wichtig“, Fahrzeuge, Zeitstrahl).

**Version 5.137:** Designvorschau „Signal Klar“ zum Ausprobieren (Knopf „Aa“ unten links oder Alt+D) mit den Stufen Büro, Einsatz und Außen – nur Aussehen, Funktionen unverändert.

**Version 5.136:** Hilfe in allen Apps (ⓘ, F1) mit Sprung zum passenden Abschnitt, „Was ist neu“ nach Updates, QR-Codes und Etiketten für Funkgeräte und Akkus.

**Version 5.135.2:** Hinweis „ASÜ-Schnittstelle: falscher Schlüssel“ entfernt.

**Version 5.135.1:** Digitalfunk: „Heute zu tun“ und Suche oben, Reiter und Knöpfe in einer Zeile.

**Version 5.135:** Funkbeauftragter per Häkchen in der Verwaltung der Gerätewarte; Beauftragte benennt der Funkbeauftragte per Häkchen.

**Version 5.134:** Digitalfunk: Funkbeauftragter und Beauftragte pflegen, Ortsgerätewarte sehen und melden Schäden (Mail an den Funkbeauftragten), Excel-Export/-Import, Ortswehr und Fahrzeug aus der OPTA.

**Version 5.133:** Berichtswesen: Fristen je Person (Ampel) und individuell einstellbarer Monatsbericht per Mail; Einsatz: Verpflegung; Digitalfunk: nach Fahrzeug gruppiert, Mail bei neuem Soll-Stand.

**Version 5.132:** Digitalfunk in der Gerätedatenbank (Funkgeräte mit ISSI/OPTA/Programmierstand, Sicherheitskarten, Akkus mit Kapazitätstests), Rufgruppe an die Fahrzeuge senden (auch an später hinzukommende), Tagebuch-Schnellwahl mit wählbaren Fahrzeugen und Rufgruppen.

**Version 5.131.4:** Objektliste: höchstens 3 Zeilen je Objekt, Objekte deutlich getrennt.

**Version 5.131.3:** Berichtswesen zeigt nur Fahrzeuge, keine Funktionen.

**Version 5.131.2:** Automatisch abmelden, wenn der Browser länger als 30 s geschlossen war (Ausnahme „angemeldet bleiben“ für feste Anzeigen); Atemschutz-Datenbank: Klick auf die Person öffnet sie, Knopf „Bearbeiten“ entfällt.

**Version 5.131.1:** Links der Apps in Atemschutz-/Gerätedatenbank zeigen auf die ASÜ-Internetadresse (vorher Fahrzeug-App-Adresse, Link funktionierte von außen nicht).

**Version 5.131:** Einsatz-Abschluss-Assistent (überspringbar), Atemschutzgeräteträger automatisch im Expositionsnachweis mit Abfrage (Hygiene, Kontakt), Offline-Puffer für Tablets, Rückgängig-Verlauf, signierte Updates, Browser-Bibliotheken lokal, PIN mindestens 6 Zeichen, Wiederherstellungsprobe der Sicherung, erweiterte Selbstüberwachung des Pi.

**Version 5.130:** Sicherheitsprüfung und CRA: Standard-PIN muss geändert werden, Sicherheits-Header, ASÜ von außen nur mit Schlüssel, Anmeldeprotokoll nicht mehr an alle Geräte, Excel-Import auf dem Server, SHA-256 beim Update, SECURITY.md, SBOM, docs/CRA.md.

**Version 5.107:** QR-Code der ELW-App unter Ausgaben.

**Version 5.106:** Übungsleitstelle: Fahrzeuge aus dem Einsatz nehmen, Ortswehr, Filter, 2. Bildschirm.

**Version 5.105:** Bericht Inbetriebnahmen, Gerätenachweis und Protokoll mit Ortswehr/Druck passt, Berichtswesen im Datenbank-Layout.

**Version 5.104:** Reiter der Atemschutz-Datenbank zusammengefasst.

**Version 5.103:** Ortswehr des Trägers in der ASÜ, Summenleiste auf jeder Seite der Atemschutz-Datenbank.

**Version 5.102:** Admin-Recht je Bereich, Kalender in der Atemschutz-Datenbank, Leitung je Bereich, Träger-App nur über die Internetadresse.

**Version 5.101:** Inbetriebnahme der Atemschutzgeräte nach dem Tausch (ASÜ, Träger-App, Atemschutz-Datenbank).

**Version 5.100:** ASÜ-Zugänge, Gerätewarte und Online-Schulung aus der Einsatzverwaltung in die Verwaltung der Datenbank-Apps verlegt.
