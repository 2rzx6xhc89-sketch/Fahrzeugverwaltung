# Sicherheit – Einsatzverwaltung

## Schwachstellen melden
Bitte Sicherheitslücken **nicht öffentlich** melden, sondern per E-Mail an **joern-preuss@web.de** (Betreff „Sicherheit Einsatzverwaltung“). Bitte angeben: betroffene Version (Verwaltung → System), betroffene App, Schritte zum Nachstellen.

- Eingangsbestätigung: innerhalb von 3 Werktagen
- Erste Bewertung: innerhalb von 10 Werktagen
- Behebung: kritische Lücken so schnell wie möglich als Update-Paket, sonst mit der nächsten Version
- Wer meldet, wird auf Wunsch in den Versionshinweisen genannt.

## Unterstützte Versionen
Sicherheitsupdates gibt es für die **jeweils aktuelle Version**. Updates werden als Paket `einsatzverwaltung-X.Y.zip` bereitgestellt und unter Verwaltung → System → Update eingespielt. Vor dem Einspielen prüft der Pi das Paket (Inhalt, Probestart) und zeigt die **SHA-256-Prüfsumme** an – sie muss mit der Angabe zur Freigabe übereinstimmen.

## Sicherheitsfunktionen (Kurzüberblick)
- Anmeldung mit PIN/Kennwort (PBKDF2), Sperre nach Fehlversuchen, Sitzungs-Cookie `HttpOnly; SameSite=Strict` (mit TLS `Secure`)
- Standard-PIN 1234 muss beim ersten Anmelden geändert werden
- Rollen und Rechte je App, Zugänge je Ortswehr, Superadmin mit starkem Kennwort
- Sicherheitshinweise an Admins (Fehlversuche, neue Geräte, falscher Wehr-Schlüssel), Anmeldeprotokoll
- ASÜ-Schnittstelle von außen nur mit Wehr-Schlüssel; Port 8080 nie aus dem Internet erreichbar
- Sicherheits-Header (nosniff, Frame-Schutz, Referrer-Policy, Permissions-Policy, HSTS bei HTTPS)
- Sicherungen verschlüsselt (AES-256-GCM), Löschfristen für personenbezogene Daten
- Stückliste der Software (SBOM): `docs/sbom.cdx.json`
