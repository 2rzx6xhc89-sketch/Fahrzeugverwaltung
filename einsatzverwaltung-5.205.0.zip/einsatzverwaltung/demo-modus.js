/*
 * Demo-Version der Einsatzverwaltung (Start mit EV_DEMO=1, z. B. vom USB-Stick).
 * - Alle Internetdienste (Adresssuche, Wetter, Warnungen, Wasserentnahmestellen, what3words,
 *   Höhenprofil, Radar, Satellitenbild) werden durch fiktive Ersatzdienste auf demselben Rechner ersetzt.
 * - Die Karte zeigt nur den fiktiven Ort aus dem Ordner demo-daten/ (keine Kacheln aus dem Internet).
 * - Der Server ruft keine fremden Adressen auf (Schutz gegen versehentliche Abrufe).
 * Im normalen Betrieb (ohne EV_DEMO) hat diese Datei keine Wirkung.
 */
const fs = require('fs');
const path = require('path');

const AKTIV = process.env.EV_DEMO === '1';
const DIR = path.join(__dirname, 'demo-daten');
const lies = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8')); } catch (e) { return d; } };
const KARTE = AKTIV ? lies('demo-karte.json', null) : null;
const ADR = AKTIV ? lies('adressen.json', { ort: 'Musterhausen', plz: '12345', adressen: [] }) : null;
const PORT = Number(process.env.PORT) || 8080;
const BASIS = `http://127.0.0.1:${PORT}/demo-dienste`;

/* Feste Werte im Demo-Betrieb (überschreiben Einstellungen und Umgebungsvariablen) */
const WERTE = {
  NINA_URL: `${BASIS}/nina`,
  WETTER_URL: `${BASIS}/wetter`,
  NOMINATIM_URL: `${BASIS}/nominatim/search`,
  OVERPASS_URL: `${BASIS}/overpass`,
  W3W_URL: `${BASIS}/w3w`,
  W3W_KEY: 'demo',
  OSM_TILE_URL: `${BASIS}/keine/{z}/{x}/{y}.png`,
  GEOCODE_ORT: `${ADR ? ADR.plz : ''} ${ADR ? ADR.ort : ''}`.trim(),
  WASSER_RADIUS_KM: '2',
  BACKUP_ZIEL: 'aus',
  // ab 5.7/5.8: Datenschutzhinweise und Notfallmappe mit erfundenen Angaben
  DS_VERANTWORTLICHER: 'Gemeinde Musterstadt | Der Bürgermeister | Rathausplatz 1, 12345 Musterstadt | info@musterstadt.example',
  DS_DSB: 'Datenschutzbeauftragte der Gemeinde Musterstadt | datenschutz@musterstadt.example',
  NOTFALL_KONTAKT: 'Admin Einsatzverwaltung (Demo): 0000 1234567 | Gemeindebrandmeister (Demo): 0000 7654321',
  ASUE_KEY: '',
  ASUE_ORIGIN: '',
  TLS_CERT: '', TLS_KEY: '', MELDE_TLS_CERT: '', MELDE_TLS_KEY: '',
  // im Browser: relative Adressen, damit es auch vom Handy im selben WLAN geht
  C_WIND_URL: '/demo-dienste/wetter',
  C_DWD_WMS: '/demo-dienste/wms',
  C_SAT_URL: '/demo-dienste/luftbild/{z}/{x}/{y}.jpg',
  C_HOEHE_URL: '/demo-dienste/hoehe',
  // E-Mail: in der Demo nie echte Postfächer (Versand/Abruf aus, erfundene Adressen)
  MAIL_SMTP_HOST: '', MAIL_IMAP_HOST: '', MAIL2_IMAP_HOST: '', MAIL_PASSWORT: '', MAIL2_PASSWORT: '', MAIL_ABRUF_SEK: '0',
  MAIL_BENUTZER: 'elw@musterhausen.example', MAIL2_BENUTZER: 'alarm@musterhausen.example', MAIL_ABSENDER: 'Feuerwehr Musterhausen – ELW <elw@musterhausen.example>',
};
function wert(id) { return AKTIV && Object.prototype.hasOwnProperty.call(WERTE, id) ? WERTE[id] : undefined; }

/* Der Server darf im Demo-Betrieb nur sich selbst aufrufen */
if (AKTIV && typeof globalThis.fetch === 'function') {
  const echt = globalThis.fetch;
  globalThis.fetch = (url, opt) => {
    let host = '';
    try { host = new URL(typeof url === 'string' ? url : url.url || String(url)).hostname; } catch (e) { host = ''; }
    if (!['127.0.0.1', 'localhost', '::1', '[::1]'].includes(host)) return Promise.reject(new Error('Demo-Version: kein Internetzugriff'));
    return echt(url, opt);
  };
}

const norm = (s) => String(s || '').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').replace(/str\.?(\s|$)/g, 'strasse$1').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
const anzeige = (a) => `${a.name ? `${a.name}, ` : ''}${a.strasse}${a.nr ? ` ${a.nr}` : ''}, ${ADR.plz} ${ADR.ort}`;
function suche(q) {
  const n = norm(q).replace(new RegExp(`\\b(${norm(ADR.plz)}|${norm(ADR.ort)}|deutschland)\\b`, 'g'), '').trim();
  if (!n) return [];
  const nrM = /(\d+\s*[a-z]?)\s*$/.exec(n); const nr = nrM ? nrM[1].replace(/\s/g, '') : '';
  const text = nrM ? n.slice(0, nrM.index).trim() : n;
  const treffer = [];
  ADR.adressen.forEach((a) => {
    const s = norm(a.strasse), nm = norm(a.name);
    let p = 0;
    if (text && (s === text || s.startsWith(text))) p = 3; else if (text && s.includes(text)) p = 2; else if (text && nm && nm.includes(text)) p = 2.5;
    if (!p) return;
    if (nr) { if (a.nr.toLowerCase() === nr) p += 3; else if (a.nr) return; else p += 0.5; } else if (!a.nr) p += 1; else if (a.name && nm.includes(text)) p += 1;
    treffer.push({ p, a });
  });
  return treffer.sort((x, y) => y.p - x.p).slice(0, 5).map(({ a }) => ({ display_name: anzeige(a), lat: String(a.lat), lon: String(a.lon) }));
}
function naechste(lat, lon) {
  let best = null, bd = Infinity;
  ADR.adressen.forEach((a) => { if (!a.nr) return; const d = (a.lat - lat) ** 2 + ((a.lon - lon) * 0.62) ** 2; if (d < bd) { bd = d; best = a; } });
  return best && Math.sqrt(bd) * 111320 < 250 ? best : null;
}

/* what3words-Ersatz: feste, erfundene Wortkombinationen für 3-m-Felder im Demo-Gebiet */
const WOERTER = ['apfel', 'birne', 'kirsche', 'pflaume', 'traube', 'melone', 'zitrone', 'nuss', 'beere', 'quitte',
  'eiche', 'buche', 'linde', 'ahorn', 'birke', 'tanne', 'fichte', 'weide', 'pappel', 'erle',
  'amsel', 'drossel', 'meise', 'fink', 'specht', 'eule', 'falke', 'storch', 'reiher', 'schwalbe',
  'tisch', 'stuhl', 'lampe', 'fenster', 'tür', 'treppe', 'dach', 'keller', 'garten', 'zaun',
  'wolke', 'regen', 'sonne', 'wind', 'nebel', 'schnee', 'blitz', 'donner', 'tau', 'frost',
  'kanne', 'tasse', 'teller', 'löffel', 'gabel', 'messer', 'schale', 'krug', 'glas', 'topf',
  'brücke', 'mühle', 'turm', 'brunnen', 'scheune', 'hof', 'weg', 'pfad', 'feld', 'wiese',
  'rot', 'blau', 'grün', 'gelb', 'leise', 'laut', 'warm', 'kühl', 'hell', 'dunkel',
  'buch', 'heft', 'stift', 'karte', 'brief', 'bild', 'uhr', 'glocke', 'kerze', 'spiegel',
  'hase', 'igel', 'fuchs', 'dachs', 'reh', 'biber', 'otter', 'maus', 'wiesel', 'luchs'];
const N3 = 1000000, MUL = 7919;
function invers(a, m) { let [r0, r1, s0, s1] = [a, m, 1, 0]; while (r1) { const q = Math.floor(r0 / r1); [r0, r1] = [r1, r0 - q * r1]; [s0, s1] = [s1, s0 - q * s1]; } return ((s0 % m) + m) % m; }
const MUL_INV = invers(MUL, N3);
const W3W_SCHRITT = 3 / 111320;
function feld(lat, lon) {
  const m = KARTE.mitte, cosl = Math.cos((m.lat * Math.PI) / 180);
  const r = Math.floor((lat - m.lat) / W3W_SCHRITT) + 500, c = Math.floor(((lon - m.lon) * cosl) / W3W_SCHRITT) + 500;
  if (r < 0 || r >= 1000 || c < 0 || c >= 1000) return null;
  return { r, c, i: (r * 1000 + c) % N3 };
}
function worteAus(lat, lon) {
  const f = feld(lat, lon); if (!f) return null;
  const k = Number((BigInt(f.i) * BigInt(MUL)) % BigInt(N3));
  return `${WOERTER[k % 100]}.${WOERTER[Math.floor(k / 100) % 100]}.${WOERTER[Math.floor(k / 10000)]}`;
}
function koordAus(worte) {
  const t = String(worte).toLowerCase().split('.'); if (t.length !== 3) return null;
  const ix = t.map((w) => WOERTER.indexOf(w)); if (ix.some((x) => x < 0)) return null;
  const k = ix[0] + ix[1] * 100 + ix[2] * 10000;
  const i = Number((BigInt(k) * BigInt(MUL_INV)) % BigInt(N3));
  const r = Math.floor(i / 1000), c = i % 1000;
  const m = KARTE.mitte, cosl = Math.cos((m.lat * Math.PI) / 180);
  return { lat: m.lat + (r - 500 + 0.5) * W3W_SCHRITT, lng: m.lon + ((c - 500 + 0.5) * W3W_SCHRITT) / cosl };
}

/* Wetter: ruhiger Herbsttag, Werte ändern sich langsam im Laufe des Tages */
function wetterJetzt() {
  const t = Date.now() / 3600000, h = new Date().getHours();
  const temp = 11 + 5 * Math.sin(((h - 9) / 24) * 2 * Math.PI) + Math.sin(t / 5);
  return {
    time: new Date().toISOString().slice(0, 16), temperature_2m: +temp.toFixed(1), relative_humidity_2m: Math.round(72 + 10 * Math.sin(t / 7)),
    precipitation: 0, weather_code: Math.sin(t / 9) > 0.3 ? 3 : 2, wind_speed_10m: +(14 + 6 * Math.sin(t / 3)).toFixed(1),
    wind_direction_10m: Math.round(240 + 25 * Math.sin(t / 4)), wind_gusts_10m: +(28 + 8 * Math.sin(t / 3)).toFixed(1),
  };
}
const TRANSPARENT = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');

function einrichten(app, express) {
  if (!AKTIV) return;
  const r = express.Router();
  r.get('/nominatim/search', (req, res) => res.json(suche(req.query.q)));
  r.get('/nominatim/reverse', (req, res) => {
    const a = naechste(Number(req.query.lat), Number(req.query.lon));
    if (!a) return res.json({ address: { village: ADR.ort, postcode: ADR.plz }, display_name: `${ADR.plz} ${ADR.ort}` });
    res.json({ address: { road: a.strasse, house_number: a.nr, postcode: ADR.plz, village: ADR.ort }, display_name: anzeige(a) });
  });
  r.post('/overpass', (req, res) => {
    const w = lies('../wasser.json', null) || lies('wasser.json', { pts: [] });
    const TYP = { H: 'fire_hydrant', B: 'water_tank', S: 'suction_point', T: 'fire_water_pond', Q: 'water_source' };
    res.json({ elements: (w.pts || []).map(([lat, lon, typ, info], i) => ({ type: 'node', id: i + 1, lat, lon, tags: { emergency: TYP[typ] || 'fire_hydrant', ...(info.a ? { 'fire_hydrant:type': info.a } : {}), ...(info.d ? { 'fire_hydrant:diameter': info.d } : {}), ...(info.v ? { water_volume: info.v } : {}), ...(info.n ? { name: info.n } : {}) } })) });
  });
  r.get('/wetter', (req, res) => res.json({ current: wetterJetzt() }));
  r.get('/nina/dashboard/:ars', (req, res) => res.json([{ id: 'demo.warnung.1', payload: { data: { headline: 'Übungswarnung (Demo): Starke Böen', provider: 'DWD', severity: 'Minor', msgType: 'Alert' } }, sent: new Date(Date.now() - 3600000).toISOString() }]));
  r.get('/nina/warnings/:id', (req, res) => res.json({ sender: 'DWD', sent: new Date(Date.now() - 3600000).toISOString(), info: [{ language: 'de-DE', headline: 'Übungswarnung (Demo): Starke Böen', event: 'STARKE BÖEN', severity: 'Minor', description: 'Dies ist eine erfundene Warnung der Demo-Version. Es treten Windböen um 55 km/h aus Südwest auf.', instruction: 'Keine echte Warnung – nur zur Vorführung.', onset: new Date(Date.now() - 3600000).toISOString(), expires: new Date(Date.now() + 6 * 3600000).toISOString() }] }));
  r.get('/w3w/convert-to-coordinates', (req, res) => {
    const k = koordAus(req.query.words);
    if (!k) return res.status(400).json({ error: { code: 'BadWords', message: 'Unbekannte Demo-Adresse' } });
    res.json({ words: String(req.query.words).toLowerCase(), coordinates: k, nearestPlace: `${ADR.ort} (Demo)` });
  });
  r.get('/w3w/convert-to-3wa', (req, res) => {
    const [lat, lon] = String(req.query.coordinates || '').split(',').map(Number);
    const w = Number.isFinite(lat) && Number.isFinite(lon) ? worteAus(lat, lon) : null;
    if (!w) return res.status(400).json({ error: { code: 'BadCoordinates', message: 'Außerhalb des Demo-Gebiets' } });
    res.json({ words: w, nearestPlace: `${ADR.ort} (Demo)`, coordinates: { lat, lng: lon } });
  });
  r.get('/w3w/autosuggest', (req, res) => res.json({ suggestions: [] }));
  r.get('/hoehe', (req, res) => {
    const la = String(req.query.latitude || '').split(',').map(Number), lo = String(req.query.longitude || '').split(',').map(Number);
    const m = KARTE.mitte;
    res.json({ elevation: la.map((lat, i) => { const y = (lat - m.lat) * 111320, x = (lo[i] - m.lon) * 68500; const tal = Math.max(0, 14 - Math.abs(y + 480) / 25); return +(118 + y / 60 + 6 * Math.sin(x / 350) + 4 * Math.cos(y / 260) - tal).toFixed(1); }) });
  });
  r.get('/wms', (req, res) => { res.set('Content-Type', 'image/png'); res.end(TRANSPARENT); });
  r.get('/luftbild/:z/:x/:y.jpg', (req, res) => {
    const f = path.join(DIR, 'luftbild', String(Number(req.params.z)), String(Number(req.params.x)), `${Number(req.params.y)}.jpg`);
    res.set('Cache-Control', 'public, max-age=604800');
    if (fs.existsSync(f)) { res.set('Content-Type', 'image/jpeg'); return fs.createReadStream(f).pipe(res); }
    res.set('Content-Type', 'image/png'); fs.createReadStream(path.join(DIR, 'leer.png')).on('error', () => res.end(TRANSPARENT)).pipe(res);
  });
  app.use('/demo-dienste', r);

  // Startseite mit Demo-Kennung (Kartengrenzen, Hinweisband)
  const extra = lies('demo-info.json', {});
  const info = { name: (KARTE && KARTE.name) || 'Musterhausen', karte: KARTE, zugaenge: Array.isArray(extra.zugaenge) ? extra.zugaenge : [] };
  const seite = (datei) => (req, res, next) => {
    fs.readFile(datei, 'utf8', (e, html) => {
      if (e) return next();
      res.set('Cache-Control', 'no-cache');
      res.set('Content-Type', 'text/html; charset=utf-8'); res.send(html.replace('<head>', `<head><script>window.EV_DEMO=${JSON.stringify(info)};</script>`));
    });
  };
  const start = seite(path.join(__dirname, 'public', 'index.html'));
  app.get('/', start);
  app.get('/index.html', start);
}

/* Kachel außerhalb des Demo-Gebiets */
function leereKachel(res) {
  res.set('Content-Type', 'image/png');
  fs.createReadStream(path.join(DIR, 'leer.png')).on('error', () => res.end(TRANSPARENT)).pipe(res);
}

module.exports = { AKTIV, KARTE, wert, einrichten, leereKachel, _intern: { suche, worteAus, koordAus, naechste } };
