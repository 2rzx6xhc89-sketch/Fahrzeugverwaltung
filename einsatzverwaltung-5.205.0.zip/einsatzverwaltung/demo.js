/* Demo- und Übungseinsätze aus realen Einsätzen (ab 3.30)
   ---------------------------------------------------------------------------------------------
   Aus einem archivierten Einsatz entsteht ein „Drehbuch“: personenbezogene Daten werden durch
   fiktive ersetzt (Namen, Telefon, E-Mail, Kennzeichen, Hausnummern, Benutzer), Fotos und Bilder
   entfallen, Zeiten werden auf einen neutralen Tag verschoben und lange Pausen auf Wunsch gekürzt,
   der Ort bleibt, verliert die Hausnummer oder wird verlegt. Das Drehbuch enthält keinen Verweis auf
   den Originaleinsatz. Alles läuft nur auf dem Pi.

   Die Funktionen hier sind rein (ohne Speicherzugriff); server.js ruft sie auf. */
'use strict';

const TAG = 24 * 3600 * 1000;
const SYSTEM_NAMEN = /^(System|Fahrzeug-App|ASÜ|Schnittstelle|PowerAlarm|Löschfrist|automatisch|Einsatzende|Drehbuch|Demo|Übungsleitung.*|ELW|Leitstelle|Einsatzleitung)$/;
const MIN = 60 * 1000;

/* ---------- Wortlisten ---------- */
const TITEL = ['Herr', 'Herrn', 'Frau', 'Hr.', 'Fr.', 'Dr.', 'Familie', 'Fam.', 'Prof.'];
const DIENSTGRADE = ['GemBM', 'StvGemBM', 'Stv.GemBM', 'OrtsBM', 'StvOrtsBM', 'Stv.OrtsBM', 'KBM', 'KrBM', 'StKBM', 'ABM', 'StBM', 'GBM', 'BM', 'OBM', 'HBM', 'EHBM', 'HLM', 'OLM', 'LM', 'OFM', 'FM', 'FMA', 'FwA', 'ZF', 'ZugF', 'GF', 'GrF', 'TF', 'EL', 'AL', 'AbL', 'ASL', 'BR', 'OBR', 'BD', 'BOR', 'BAR', 'Kam.', 'Kamerad', 'Kameradin', 'Notarzt', 'Notärztin', 'NA', 'RS', 'RA', 'NFS', 'POK', 'PHK', 'PK', 'KHK', 'Bürgermeister', 'Bürgermeisterin', 'Ortsbrandmeister', 'Gemeindebrandmeister', 'Kreisbrandmeister', 'Zugführer', 'Gruppenführer', 'Einsatzleiter', 'Abschnittsleiter', 'stv.', 'Stv.'];
// Wörter, die in Personenfeldern stehen, aber keine Namen sind
const KEINE_NAMEN = new Set(['ELW', 'Leitstelle', 'Einsatzleitung', 'Einsatzleiter', 'Anwohner', 'Anwohnerin', 'Anrufer', 'Anruferin', 'Mitteiler', 'Mitteilerin', 'Nachbar', 'Nachbarin', 'Bewohner', 'Bewohnerin', 'Eigentümer', 'Eigentümerin', 'Landwirt', 'Landwirtin', 'Passant', 'Passantin', 'Zeuge', 'Zeugin', 'Fahrer', 'Fahrerin', 'Hausmeister', 'Betreiber', 'Polizei', 'Rettungsdienst', 'Notarzt', 'RTW', 'NEF', 'KTW', 'RTH', 'Übungsleitung', 'System', 'Fahrzeug-App', 'ASÜ', 'Schnittstelle', 'Drehbuch', 'Tel', 'Tel.', 'Telefon', 'Handy', 'Mobil', 'Energieversorger', 'Wasserversorger', 'Bauhof', 'Gemeinde', 'Straßenmeisterei', 'Autobahnmeisterei', 'Kreis', 'Landkreis', 'Stadt', 'Feuerwehr', 'Ortsfeuerwehr', 'Wache', 'Gerätehaus', 'Abschnitt', 'Bereitstellung', 'Bereitstellungsraum', 'Atemschutz', 'Sicherheitstrupp', 'Angriffstrupp', 'Wassertrupp', 'Trupp', 'Gruppe', 'Staffel', 'Zug', 'Verband', 'Führungsgruppe', 'Führungsstaffel', 'Unbekannt', 'Unbekannte', 'Meldender', 'Meldende', 'Wasserversorgung', 'Brandbekämpfung', 'Menschenrettung', 'Technische', 'Hilfe', 'Nord', 'Süd', 'Ost', 'West', 'Mitte', 'Kreisstraße', 'Bundesstraße', 'Autobahn', 'Rettungsleitstelle', 'Kooperative', 'Regionalleitstelle', 'Pressesprecher', 'Presse', 'Seelsorge', 'Notfallseelsorge', 'THW', 'DLRG', 'DRK', 'ASB', 'JUH', 'MHD', 'Nicht', 'zugeteilt', 'Eingang', 'Ausgang', 'Vermerk', 'admin', 'Admin']);
['Wetterdienst', 'Warndienst', 'DWD', 'NINA', 'Unwetter', 'Wetter', 'Radar', 'Hydrant', 'Einsatzstelle', 'Schadensstelle', 'Lage', 'Lagemeldung', 'Rückmeldung', 'Nachforderung', 'Anforderung', 'Sammelplatz', 'Sammelstelle', 'Patientenablage', 'Rettung', 'Ablösung', 'Brandwache', 'Nachlöscharbeiten', 'Bereitschaft', 'Führung', 'Stab', 'TEL', 'ÖEL', 'KatS'].forEach((w) => KEINE_NAMEN.add(w));
const KEIN_NAME_ENDE = /(dienst|stelle|leitung|versorgung|gruppe|trupp|wache|amt|behörde|verwaltung|zentrale|meisterei|wehr|bereich|abschnitt|raum|platz|ablage|führer|leiter|meldung|wagen|fahrzeug)$/i;
// Nachnamen, die zugleich gewöhnliche Wörter sind: nur mit Titel, Dienstgrad oder Vorname ersetzen
const WOERTER = new Set(['Brand', 'Wolf', 'Fuchs', 'Koch', 'Bauer', 'Richter', 'Winter', 'Sommer', 'Berg', 'Stein', 'Feld', 'Wald', 'Graben', 'Schnee', 'Keller', 'Becker', 'Fischer', 'Jäger', 'Kaiser', 'König', 'Vogel', 'Hahn', 'Lang', 'Klein', 'Groß', 'Kurz', 'Frank', 'Frei', 'Fels', 'Busch', 'Bach', 'Brunnen', 'Mühle', 'Hof', 'Horn', 'Kopf', 'Arm', 'Fuß', 'Hand', 'Herz', 'Blume', 'Rose', 'Weiß', 'Schwarz', 'Roth', 'Braun', 'Grün', 'Schulz', 'Glas', 'Holz', 'Eisen', 'Licht', 'Nebel', 'Regen', 'Sturm', 'Wind', 'Feuer', 'Wasser', 'Rauch', 'Bär', 'Löwe', 'Adler', 'Falke', 'Strauß', 'Storch', 'Kraft', 'Hoffmann', 'Engel', 'Morgen', 'Abend', 'Heide', 'Linde', 'Eiche', 'Wiese', 'Moor', 'Ufer', 'Rain', 'Lamm', 'Kuh', 'Stier', 'Ochs', 'Stahl', 'Kupfer', 'Zinn', 'Blei', 'Gold', 'Silber', 'Ring', 'Burg', 'Turm', 'Tor', 'Wand', 'Dach', 'Haus', 'Scheune', 'Stall', 'Garten', 'Weg', 'Pfad', 'Platz', 'Markt', 'Schmied', 'Müller', 'Meyer', 'Meier', 'Schneider', 'Weber', 'Wagner', 'Schäfer', 'Schröder', 'Krüger', 'Zimmermann', 'Hartmann', 'Lange', 'Werner', 'Walter', 'Peters', 'Möller']);
// Diese Wörter gelten zwar als Wort, sind aber fast nur Nachnamen – dürfen frei ersetzt werden
['Schulz', 'Hoffmann', 'Müller', 'Meyer', 'Meier', 'Schneider', 'Weber', 'Wagner', 'Schäfer', 'Schröder', 'Krüger', 'Zimmermann', 'Hartmann', 'Werner', 'Walter', 'Peters', 'Möller', 'Becker', 'Fischer'].forEach((w) => WOERTER.delete(w));

const NACHNAMEN = ['Albers', 'Brinkmann', 'Dammann', 'Ebeling', 'Fenske', 'Gerdes', 'Harms', 'Ilse', 'Jansen', 'Kuhlmann', 'Lüders', 'Martens', 'Nolte', 'Oltmanns', 'Petersen', 'Quast', 'Rademacher', 'Sievers', 'Thiele', 'Uhlig', 'Vollmer', 'Wendt', 'Ziegler', 'Bartels', 'Claasen', 'Diekmann', 'Ehlers', 'Freese', 'Grote', 'Heitmann', 'Imholz', 'Janßen', 'Kröger', 'Lorenzen', 'Mahnke', 'Niemeyer', 'Ohlsen', 'Plate', 'Reinecke', 'Schütte', 'Tiedemann', 'Ulrichs', 'Voß', 'Wiechmann', 'Behrens', 'Carstens', 'Dreyer', 'Evers', 'Frerichs', 'Gödeke', 'Hinrichs', 'Iwersen', 'Jürgens', 'Kasten', 'Lampe', 'Mertens', 'Nagel', 'Onken', 'Pape', 'Ritter', 'Sander', 'Timm', 'Utermöhlen', 'Vieth', 'Warnecke'];
const VORNAMEN_M = ['Jens', 'Lars', 'Sven', 'Timo', 'Ole', 'Nils', 'Heiko', 'Dirk', 'Malte', 'Björn', 'Kai', 'Frank', 'Torsten', 'Holger', 'Jan', 'Uwe', 'Marco', 'Stefan', 'Arne', 'Hauke'];
const VORNAMEN_W = ['Anke', 'Birte', 'Katrin', 'Silke', 'Meike', 'Nina', 'Tanja', 'Imke', 'Frauke', 'Heike', 'Jana', 'Kerstin', 'Wiebke', 'Maren', 'Sabine', 'Insa', 'Levke', 'Gesa', 'Julia', 'Petra'];
const WEIBLICH = /(a|e|ine|in|ey|y)$/i;
const MAENNLICH_TROTZ = new Set(['Uwe', 'Ole', 'Hauke', 'Arne', 'Heinrich', 'Rene', 'René', 'Jonte', 'Timo', 'Sascha', 'Andrea', 'Luca', 'Nikita', 'Mika', 'Joshua', 'Elias', 'Jona', 'Noah', 'Henry', 'Harry', 'Andy', 'Rudy', 'Tony', 'Danny', 'Jimmy', 'Freddy', 'Remy', 'Timmy', 'Kenny', 'Bobby', 'Willy', 'Charly', 'Jonny', 'Gary']);

/* ---------- Hilfen ---------- */
const escRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const GROSS = /^[A-ZÄÖÜ][a-zäöüßéèáàç'-]+$/;
const istEpoche = (v) => typeof v === 'number' && v > 9.4e11 && v < 4.2e12;
const ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})$/;
const pad = (n) => String(n).padStart(2, '0');
function hash(s) { let h = 2166136261; for (const c of String(s)) { h ^= c.codePointAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
function tief(o, fn, pfad = []) {   // alle Werte besuchen; fn(wert, schluessel, eltern, pfad) → neuer Wert oder undefined
  if (Array.isArray(o)) { for (let i = 0; i < o.length; i += 1) { const n = fn(o[i], i, o, pfad); if (n !== undefined) o[i] = n; if (o[i] && typeof o[i] === 'object') tief(o[i], fn, pfad.concat(i)); } return o; }
  if (o && typeof o === 'object') { Object.keys(o).forEach((k) => { const n = fn(o[k], k, o, pfad); if (n !== undefined) o[k] = n; if (o[k] && typeof o[k] === 'object') tief(o[k], fn, pfad.concat(k)); }); }
  return o;
}
const TEXT_FREI = new Set(['id', 'type', 'art', 'st', 'stil', 'richtung', 'auto', 'funkrufname', 'fahrzeugtyp', 'ortswehr', 'stadt', 'farbe', 'kanal', 'was', 'status', 'code', 'schema', 'liste', 'kat', 'prio', 'modell', 'antrieb', 'lage', 'rettung', 'hersteller', 'version', 'vid', 'abschnitt', 'kontaktId', 'nid', 'eid', 'evId', 'quelle', 'ortQuelle', 'icon', 'symbol', 'geraetNr', 'rufgruppe', 'funktion']);

/* ---------- Personen finden ---------- */
function namensTeile(wert) {   // „ZF Wagner“, „Hinrich Brandes“, „Wagner, Tim“, „EL, ZF Wagner, GF Hoffmann“ → [{titel, vor, nach, roh}]
  const out = [];
  const s = String(wert || '').replace(/\([^)]*\)/g, ' ').replace(/\b(Tel\.?|Telefon|Handy|Mobil)\b.*$/i, ' ');
  // „Nachname, Vorname“ (genau zwei Wörter mit Komma) erkennen
  const km = /^\s*([A-ZÄÖÜ][\wäöüß'-]+),\s*([A-ZÄÖÜ][\wäöüß'-]+)\s*$/.exec(s);
  if (km && !KEINE_NAMEN.has(km[1]) && !KEINE_NAMEN.has(km[2]) && !DIENSTGRADE.includes(km[1]) && !DIENSTGRADE.includes(km[2])) return [{ titel: '', vor: km[2], nach: km[1], roh: s.trim() }];
  s.split(/[,;/+&]|\s+und\s+|\s+u\.\s+/).forEach((teil) => {
    let w = teil.trim().split(/\s+/).filter(Boolean);
    const titel = [];
    while (w.length && (TITEL.includes(w[0]) || DIENSTGRADE.includes(w[0]))) titel.push(w.shift());
    w = w.filter((x) => GROSS.test(x) && !KEINE_NAMEN.has(x) && !KEIN_NAME_ENDE.test(x) && !DIENSTGRADE.includes(x) && !TITEL.includes(x));
    if (!w.length || w.length > 3) return;
    if (!titel.length && w.length === 1 && WOERTER.has(w[0])) return;   // einzelnes normales Wort ohne Titel: kein Name
    out.push({ titel: titel.join(' '), vor: w.length > 1 ? w.slice(0, -1).join(' ') : '', nach: w[w.length - 1], roh: teil.trim() });
  });
  return out;
}
const PERSONENFELDER = ['einsatzleiter', 'meldender', 'leiter', 'teilnehmer', 'name', 'nachname', 'vorname', 'truppfuehrer', 'fuehrer', 'bearbeiter', 'ansprechpartner'];
const PERSON_IN_TEXT = new RegExp(`(?:^|[^\\p{L}])(?:${TITEL.concat(DIENSTGRADE).map(escRe).join('|')})\\s+((?:[A-ZÄÖÜ][a-zäöüßéè'-]+\\s+)?[A-ZÄÖÜ][a-zäöüßéè'-]+)`, 'gu');

function personenSammeln(rec, ctx) {
  const personen = new Map();   // schlüssel nachname → {nach, vor:Set, titel:Set, quellen:Set, n}
  const add = (p, quelle) => {
    if (!p || !p.nach || p.nach.length < 2) return;
    if ((ctx.funkrufnamen || []).includes(p.nach) || (ctx.orte || []).includes(p.nach)) return;
    const k = p.nach.toLowerCase();
    const x = personen.get(k) || { nach: p.nach, vor: new Set(), titel: new Set(), quellen: new Set(), n: 0 };
    if (p.vor) x.vor.add(p.vor);
    if (p.titel) x.titel.add(p.titel);
    x.quellen.add(quelle); x.n += 1;
    personen.set(k, x);
  };
  const e = rec.einsatz || {};
  [['einsatzleiter', 'Einsatzleiter'], ['meldender', 'Meldender']].forEach(([f, q]) => namensTeile(e[f]).forEach((p) => add(p, q)));
  (e.abschnitte || []).forEach((a) => namensTeile(a.leiter).forEach((p) => add(p, 'Abschnittsleiter')));
  (e.elWechsel || []).forEach((w) => [w.von, w.an].forEach((v) => namensTeile(v).forEach((p) => add(p, 'Übergabe'))));
  (e.besprechungen || []).forEach((b) => namensTeile(b.teilnehmer).forEach((p) => add(p, 'Lagebesprechung')));
  (e.kontakte || []).forEach((k) => namensTeile(k.name).forEach((p) => add(p, 'Ansprechpartner')));
  (e.vu || []).forEach((v) => namensTeile(v.fahrer || v.halter || '').forEach((p) => add(p, 'Verkehrsunfall')));
  const auf = rec.auftraege && Array.isArray(rec.auftraege.liste) ? rec.auftraege.liste : [];
  auf.forEach((a) => namensTeile(a.meldender).forEach((p) => add(p, 'Auftrag')));
  (rec.asueDetail || []).forEach((d) => (d.trupps || []).forEach((t) => (t.mitglieder || []).forEach((m) => {
    const nach = String(m.nachname || '').trim(), vor = String(m.vorname || '').trim();
    if (nach) add({ nach, vor, titel: '' }, 'Atemschutz');
    else namensTeile(m.name).forEach((p) => add(p, 'Atemschutz'));
  })));
  // von/an im Tagebuch und in Nachrichten (ohne Funkrufnamen und bekannte Stellen)
  const vonAn = (v, q) => { const s = String(v || ''); if (!s || (ctx.funkrufnamen || []).includes(s) || (ctx.benutzer || []).includes(s)) return; namensTeile(s).forEach((p) => add(p, q)); };
  (rec.tagebuch || []).forEach((t) => { vonAn(t.von, 'Tagebuch'); vonAn(t.an, 'Tagebuch'); });
  (e.nachrichten || []).forEach((m) => { vonAn(m.von, 'Nachrichten'); vonAn(m.an, 'Nachrichten'); });
  (e.lage || []).forEach((m) => { vonAn(m.von, 'Lagemeldung'); vonAn(m.an, 'Lagemeldung'); });
  // Freitext: „Herr Brandes“, „ZF Wagner“ …
  tief(JSON.parse(JSON.stringify(rec)), (v, k) => {
    if (typeof v !== 'string' || TEXT_FREI.has(k) || v.length < 5) return;
    for (const m of v.matchAll(PERSON_IN_TEXT)) {
      const w = m[1].split(/\s+/); const nach = w.pop();
      if (KEINE_NAMEN.has(nach) || KEIN_NAME_ENDE.test(nach) || DIENSTGRADE.includes(nach)) continue;
      const titel = (m[0].trim().split(/\s+/)[0] || '').replace(/^[^\p{L}]+/u, '');
      add({ nach, vor: w.join(' '), titel }, 'Text');
    }
  });
  // Vornamen, die als eigene Personen erfasst wurden, aber zu einem Nachnamen gehören, zusammenführen
  personen.forEach((x, k) => { if (!x.vor.size && [...personen.values()].some((y) => y !== x && y.vor.has(x.nach))) personen.delete(k); });
  return [...personen.values()];
}

function fiktivVorschlag(personen, belegt) {
  const frei = NACHNAMEN.filter((n) => !belegt.has(n.toLowerCase()));
  const benutzt = new Set();
  return personen.map((p) => {
    let i = hash(p.nach) % frei.length; let tries = 0;
    while (benutzt.has(frei[i]) && tries < frei.length) { i = (i + 1) % frei.length; tries += 1; }
    const nach = frei[i]; benutzt.add(nach);
    const vor = [...p.vor].map((v) => {
      const weib = WEIBLICH.test(v) && !MAENNLICH_TROTZ.has(v);
      const l = weib ? VORNAMEN_W : VORNAMEN_M;
      return [v, l[hash(v) % l.length]];
    });
    return { original: p.nach, ersatz: nach, vornamen: vor, quellen: [...p.quellen], titel: [...p.titel], anzahl: p.n, nurKontext: WOERTER.has(p.nach) };
  });
}

/* ---------- Ersetzen ---------- */
function ersetzerBauen(ersetzungen) {
   // ersetzungen: [{von, zu, kontext:bool}] – längere zuerst; Namen mit Genitiv-s
  const liste = ersetzungen.filter((x) => x && x.von && x.von.length >= 2 && x.von !== x.zu).sort((a, b) => b.von.length - a.von.length);
  const kontext = `(?:${TITEL.concat(DIENSTGRADE).map(escRe).join('|')})\\s+`;
  const regeln = liste.map((x) => {
    const kern = escRe(x.von).replace(/\s+/g, '\\s+');
    const re = x.kontext
      ? new RegExp(`(${kontext}(?:[A-ZÄÖÜ][a-zäöüß-]+\\s+)?)${kern}(?=s?(?![\\p{L}\\d]))`, 'gu')
      : new RegExp(`(?<![\\p{L}\\d])${kern}(?=s?(?![\\p{L}\\d]))`, 'gu');
    return { re, zu: x.zu, kontext: !!x.kontext };
  });
  return (s) => {
    let t = s; let n = 0;
    regeln.forEach((r) => { t = t.replace(r.re, (...m) => { n += 1; return r.kontext ? m[1] + r.zu : r.zu; }); });
    return { text: t, n };
  };
}
const TEL = /((?:Tel(?:efon)?\.?|Handy|Mobil(?:nummer)?|Rufnummer|Nr\.|erreichbar(?: unter)?|unter)[:\s]*)((?:\+49|0049|0)[\d\s/()-]{5,}\d)|(?<![\d])(01[5-7]\d[\s/-]?\d{6,8})(?!\d)/gi;
const MAIL = /[\w.+-]+@[\w-]+\.[\w.-]+/g;
const KENNZ = /(?<![\p{L}\d])([A-ZÄÖÜ]{1,3})-([A-Z]{1,2})\s?(\d{1,4})([EH])?(?![\p{L}\d])/gu;
const STRASSE = '(?:[A-ZÄÖÜ][\\p{L}.-]*(?:straße|strasse|str\\.|weg|allee|platz|ring|gasse|damm|chaussee|pfad|stieg|kamp|hof|berg|ufer|markt|wall|graben|brink|anger|feld|twete|horst|winkel|redder|siedlung)|(?:Am|An der|An den|Auf dem|Auf der|Im|In der|Zum|Zur|Hinter dem|Unter den)\\s+[A-ZÄÖÜ][\\p{L}-]+)';
const HAUSNR = new RegExp(`(${STRASSE})\\s+(\\d{1,4}\\s?[a-zA-Z]?(?:\\s?[-–/]\\s?\\d{1,4}[a-zA-Z]?)?)(?![\\p{L}\\d])`, 'gu');
const MGRS = /\b\d{2}[C-HJ-NP-X]\s?[A-HJ-NP-Z]{2}\s?\d{3,5}\s?\d{3,5}\b/g;
const DEZ = /(?<![\d.])(-?\d{1,2}\.\d{4,})\s*[,;]\s*(-?\d{1,3}\.\d{4,})(?![\d.])/g;

/* ---------- Zeit ---------- */
function zeitAbbildung(rec, opt) {
   // Stützstellen aus allen Ereigniszeiten; lange Lücken auf opt.maxPauseMin kürzen
  const e = rec.einsatz || {};
  const a0 = Number(e.alarmzeit) || Number((rec.tagebuch || [])[0] && rec.tagebuch[0].t) || Date.now();
  const ende0 = Number(e.ende) || a0;
  const k = new Set([a0, ende0]);
  (rec.tagebuch || []).forEach((t) => { if (istEpoche(t.t)) k.add(t.t); });
  Object.values(e.fahrzeuge || {}).forEach((f) => (f.zeiten || []).forEach((z) => { if (istEpoche(z.t)) k.add(z.t); }));
  (e.nachrichten || []).forEach((m) => { if (istEpoche(m.t)) k.add(m.t); });
  const stuetz = [...k].filter((t) => t >= a0 - 6 * 3600 * 1000 && t <= ende0 + 2 * TAG).sort((x, y) => x - y);
  const P = Math.max(0, Number(opt.maxPauseMin) || 0) * MIN;
  const g = [0]; // komprimierte Zeit relativ zum ersten Punkt
  for (let i = 1; i < stuetz.length; i += 1) { const d = stuetz[i] - stuetz[i - 1]; g.push(g[i - 1] + (P && d > P ? P : d)); }
  const i0 = stuetz.indexOf(a0) >= 0 ? stuetz.indexOf(a0) : 0;
  const gA = g[i0] || 0;
  function rel(t) {   // → ms nach Alarm (gekürzt)
    if (!stuetz.length) return t - a0;
    if (t <= stuetz[0]) return (g[0] - gA) - (stuetz[0] - t);
    const n = stuetz.length - 1;
    if (t >= stuetz[n]) return (g[n] - gA) + (t - stuetz[n]);
    let lo = 0, hi = n; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (stuetz[m] <= t) lo = m; else hi = m; }
    const d = stuetz[hi] - stuetz[lo]; const f = d ? (t - stuetz[lo]) / d : 0;
    return (g[lo] - gA) + f * (g[hi] - g[lo]);
  }
  return { a0, ende0, rel, dauerAlt: ende0 - a0, dauerNeu: rel(ende0) };
}
function zeitenAnwenden(rec, abbild, ziel) {   // ziel(relMs) → neue Epoche; wandelt Zahlen, ISO-Texte und Uhrzeiten/Datumsangaben in Texten
  const { a0, ende0, rel } = abbild;
  const lo = a0 - 400 * TAG, hi = ende0 + 400 * TAG;
  const neu = (t) => ziel(rel(Math.min(Math.max(t, a0 - 2 * TAG), ende0 + 30 * TAG)));
  const dA = new Date(a0);
  const textZeit = (s) => {
    let t = s.replace(/(?<![\d.:,])([01]?\d|2[0-3])(?::([0-5]\d)(?![\d:])|\.([0-5]\d)(?=\s?Uhr))/g, (m, h, mi1, mi2) => {
      const mi = mi1 != null ? mi1 : mi2;
      const c = new Date(dA.getFullYear(), dA.getMonth(), dA.getDate(), +h, +mi).getTime();
      let tt = c; if (tt < a0 - 3 * 3600 * 1000) tt += TAG;
      if (tt < a0 - 3 * 3600 * 1000 || tt > ende0 + 6 * 3600 * 1000) return m;
      const n = new Date(neu(tt)); const sep = m.includes(':') ? ':' : '.';
      return `${pad(n.getHours())}${sep}${pad(n.getMinutes())}`;
    });
    t = t.replace(/(?<![\d.])(\d{1,2})\.(\d{1,2})\.(\d{4}|\d{2})?(?![\d])/g, (m, d, mo, y) => {
      const jahr = y ? (y.length === 2 ? 2000 + +y : +y) : dA.getFullYear();
      const tt = new Date(jahr, +mo - 1, +d, dA.getHours(), dA.getMinutes()).getTime();
      if (!(+mo >= 1 && +mo <= 12) || Math.abs(tt - a0) > 3 * TAG) return m;
      const n = new Date(neu(tt));
      return `${pad(n.getDate())}.${pad(n.getMonth() + 1)}.${y ? (y.length === 2 ? String(n.getFullYear()).slice(2) : n.getFullYear()) : ''}`;
    });
    return t;
  };
  tief(rec, (v, k) => {
    if (istEpoche(v) && v > lo && v < hi) return neu(v);
    if (typeof v === 'string') {
      if (ISO.test(v)) { const t = Date.parse(v); if (Number.isFinite(t)) return new Date(neu(t)).toISOString(); }
      if (/^\d{4}-\d{2}-\d{2}$/.test(v)) { const t = new Date(`${v}T12:00:00`).getTime(); if (Math.abs(t - a0) < 3 * TAG) { const n = new Date(neu(t)); return `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`; } return undefined; }
      if (!TEXT_FREI.has(k) && /\d/.test(v)) return textZeit(v);
    }
    return undefined;
  });
}

/* ---------- Ort ---------- */
function adresseTeile(a) {
  const s = String(a || '');
  const m = new RegExp(STRASSE, 'u').exec(s);
  return { voll: s.trim(), strasse: m ? m[0] : '', ohneNr: s.replace(HAUSNR, '$1').trim() };
}
function koordVerschieben(rec, von, nach) {
  const cos0 = Math.cos(von.lat * Math.PI / 180), cos1 = Math.cos(nach.lat * Math.PI / 180);
  const f = (lat, lon) => [+(nach.lat + (lat - von.lat)).toFixed(6), +(nach.lon + (lon - von.lon) * cos0 / cos1).toFixed(6)];
  const nah = (lat, lon) => Math.abs(lat - von.lat) < 0.6 && Math.abs(lon - von.lon) < 0.9;
  tief(rec, (v) => {
    if (!v || typeof v !== 'object') return undefined;
    if (Array.isArray(v)) {
      if (v.length === 2 && typeof v[0] === 'number' && typeof v[1] === 'number' && nah(v[0], v[1])) { const [a, b] = f(v[0], v[1]); v[0] = a; v[1] = b; }
      else if (v.length >= 3 && istEpoche(v[0]) && typeof v[1] === 'number' && typeof v[2] === 'number' && nah(v[1], v[2])) { const [a, b] = f(v[1], v[2]); v[1] = a; v[2] = b; }
      return undefined;
    }
    [['lat', 'lon'], ['brLat', 'brLon']].forEach(([a, b]) => { if (typeof v[a] === 'number' && typeof v[b] === 'number' && nah(v[a], v[b])) { const [x, y] = f(v[a], v[b]); v[a] = x; v[b] = y; } });
    return undefined;
  });
  return f;
}

/* ---------- Hauptfunktion: Drehbuch aus Archiv ---------- */
const BASIS_TAG = [2000, 0, 3];   // Montag, 3. Januar 2000 – neutraler Bezugstag im Drehbuch
function drehbuchErstellen(rec0, opt, ctx) {
   // opt: {ersetzungen:[{von,zu,kontext}], ort:{art:'behalten'|'ohneNr'|'verlegen', adresse, lat, lon}, maxPauseMin, name}
  const rec = JSON.parse(JSON.stringify(rec0));
  const e = rec.einsatz || (rec.einsatz = {});
  const statistik = { namen: 0, telefon: 0, email: 0, kennzeichen: 0, hausnummern: 0, bilder: 0, benutzer: 0 };
  // 1) Bilder und Dateien entfernen
  tief(rec, (v, k, eltern) => {
    if (k === 'fotos' && Array.isArray(v)) { statistik.bilder += v.length; return []; }
    if (k === 'bilder' && Array.isArray(v)) { statistik.bilder += v.length; return []; }
    if (k === 'bild' && v) { statistik.bilder += 1; return null; }
    if (k === 'kontaktId' || k === 'objektId') return null;
    if (k === 'telefon' || k === 'telefon2') { if (v) statistik.telefon += 1; return v ? `01234 ${String(560000 + (hash(v) % 9999)).padStart(6, '0')}` : v; }
    if (k === 'email') { if (v) statistik.email += 1; return v ? `kontakt${hash(v) % 900 + 100}@beispiel.invalid` : v; }
    if (k === 'kennzeichen' && v) { statistik.kennzeichen += 1; return `XX-DE ${hash(v) % 900 + 100}`; }
    return undefined;
  });
  delete rec.objekt;
  // 2) Benutzer → „Bediener 1 …“
  const bn = new Map();
  const bediener = (u) => { if (!bn.has(u)) bn.set(u, `Bediener ${bn.size + 1}`); return bn.get(u); };
  const benutzer = new Set(ctx.benutzer || []);
  const funk = new Set(ctx.funkrufnamen || []);
  tief(JSON.parse(JSON.stringify(rec)), (v, k) => {   // auch frühere, inzwischen gelöschte Benutzer: alles in „user“-Feldern
    if (k === 'user' && typeof v === 'string' && v && !funk.has(v) && !SYSTEM_NAMEN.test(v)) benutzer.add(v);
  });
  tief(rec, (v, k) => {
    if (typeof v !== 'string' || !benutzer.has(v)) return undefined;
    if (['user', 'von', 'an', 'bearbeiter'].includes(k)) { statistik.benutzer += 1; return bediener(v); }
    return undefined;
  });
  // 3) Namen und frei eingetragene Ersetzungen
  const ers = (opt.ersetzungen || []).map((x) => ({ von: String(x.von || '').trim(), zu: String(x.zu || '').trim(), kontext: !!x.kontext })).filter((x) => x.von && x.zu);
  bn.forEach((neu, alt) => { if (alt.length >= 4 && !KEINE_NAMEN.has(alt)) ers.push({ von: alt, zu: neu, kontext: false }); });
  const ersetze = ersetzerBauen(ers);
  // Ort
  const ort = opt.ort || { art: 'ohneNr' };
  const alt = adresseTeile(e.adresse);
  let verlegt = null;
  if (ort.art === 'verlegen' && Number.isFinite(+ort.lat) && Number.isFinite(+ort.lon) && Number.isFinite(e.lat) && Number.isFinite(e.lon)) {
    koordVerschieben(rec, { lat: e.lat, lon: e.lon }, { lat: +ort.lat, lon: +ort.lon });
    const neuA = adresseTeile(ort.adresse || '');
    verlegt = { alt, neu: neuA };
  }
  const nr0 = String(e.nummer || '');
  tief(rec, (v, k) => {
    if (typeof v !== 'string' || TEXT_FREI.has(k) || !v) return undefined;
    let t = v;
    const r = ersetze(t); t = r.text; statistik.namen += r.n;
    t = t.replace(MAIL, (m) => { statistik.email += 1; return `kontakt${hash(m) % 900 + 100}@beispiel.invalid`; });
    t = t.replace(TEL, (m, vor, num, mobil) => { statistik.telefon += 1; const x = `01234 ${String(560000 + (hash(num || mobil) % 9999)).padStart(6, '0')}`; return vor ? vor + x : x; });
    t = t.replace(KENNZ, (m) => { if (/^(DMO|TMO|KFZ|THL|ABC|GSL|TH|VU|BMA|LNA|OrgL)$/.test(m.split('-')[0])) return m; statistik.kennzeichen += 1; return `XX-DE ${hash(m) % 900 + 100}`; });
    if (verlegt) {
      if (alt.voll) t = t.split(alt.voll).join(verlegt.neu.voll || alt.ohneNr);
      if (alt.strasse && verlegt.neu.strasse) t = t.replace(new RegExp(`${escRe(alt.strasse)}(?:\\s+\\d{1,4}\\s?[a-z]?)?`, 'gu'), verlegt.neu.strasse);
      t = t.replace(MGRS, '(Koordinate siehe Karte)');
      t = t.replace(DEZ, '(Koordinate siehe Karte)');
    }
    if (ort.art !== 'behalten') t = t.replace(HAUSNR, (m, s) => { statistik.hausnummern += 1; return s; });
    if (nr0) t = t.split(nr0).join('{{NR}}');
    return t === v ? undefined : t;
  });
  if (verlegt && verlegt.neu.voll) e.adresse = verlegt.neu.voll;
  // 4) Zeiten auf den Bezugstag legen (Tageszeit des Alarms bleibt erhalten), Pausen kürzen
  const abbild = zeitAbbildung(rec, opt);
  const da = new Date(abbild.a0);
  const basis = new Date(BASIS_TAG[0], BASIS_TAG[1], BASIS_TAG[2], da.getHours(), da.getMinutes()).getTime();
  zeitenAnwenden(rec, abbild, (r) => Math.round(basis + r));
  // 5) Kennzeichnen, Verweise auf den Originaleinsatz entfernen
  const id0 = String(e.id || '');
  if (id0.length >= 6) tief(rec, (v) => (typeof v === 'string' && v.includes(id0) ? v.split(id0).join('demo') : undefined));
  e.nummer = '{{NR}}';
  e.id = 'demo';
  delete e.beendet; delete e.eroeffnet;
  e.notiz = [e.notiz, 'Demo-Einsatz nach einem realen Einsatz – alle Personen, Rufnummern und Zeiten sind fiktiv.'].filter(Boolean).join(' · ');
  return {
    rec, statistik,
    dauerAlt: abbild.dauerAlt, dauerNeu: abbild.dauerNeu,
    kopf: { stichwort: e.stichwort || '', meldebild: e.meldebild || '', adresse: e.adresse || '', gsl: !!e.gsl, fahrzeuge: Object.keys(e.fahrzeuge || {}).length, tagebuch: (rec.tagebuch || []).length },
  };
}

/* ---------- Drehbuch einsetzen ---------- */
function drehbuchZeiten(rec, startMs, tempo) {   // Kopie mit echten Zeiten: Alarm = startMs, Abstände / tempo
  const r = JSON.parse(JSON.stringify(rec));
  const a0 = r.einsatz.alarmzeit;
  const ende0 = r.einsatz.ende || a0;
  const abb = { a0, ende0, rel: (t) => t - a0 };
  const tp = Math.max(0.25, Math.min(20, Number(tempo) || 1));
  zeitenAnwenden(r, abb, (rel) => Math.round(startMs + rel / tp));
  return r;
}
function idEinsetzen(rec, id) {   // Platzhalter 'demo' in Verweisen (evId, eid) auf die neue Einsatz-ID setzen
  tief(rec, (v, k) => (v === 'demo' && (k === 'evId' || k === 'eid' || k === 'einsatzId') ? id : undefined));
  return rec;
}
function nummerEinsetzen(rec, nummer) {
  tief(rec, (v) => (typeof v === 'string' && v.includes('{{NR}}') ? v.split('{{NR}}').join(nummer) : undefined));
  return rec;
}

/* Ereignisse für eine Live-Übung: nur, was von außen kommt (Status, Stärke, Eingänge, Nachrichten, ASÜ, Positionen, Aufträge).
   Entscheidungen der Einsatzleitung (Abschnitte, Lagemeldungen, Karte …) treffen die Übenden selbst. */
function liveEreignisse(rec) {
  const e = rec.einsatz || {};
  const fz = rec.fahrzeuge || {};
  const name = (vid) => (fz[vid] && fz[vid].funkrufname) || '';
  const ev = [];
  Object.entries(e.fahrzeuge || {}).forEach(([vid, f]) => (f.zeiten || []).forEach((z) => { if (z && z.st && istEpoche(z.t)) ev.push({ t: z.t, art: 'status', fz: name(vid), st: String(z.st) }); }));
  const vonFz = new Set(Object.values(fz).map((x) => x.funkrufname));
  (rec.tagebuch || []).forEach((t) => {
    if (!istEpoche(t.t)) return;
    const text = String(t.text || '');
    if (t.auto === 'status') {
      // F/UF/M/G (bis 3.51) oder F/M/G (ab 3.52)
      const m = /^Stärkemeldung (\d+)\/(\d+)\/(\d+)(?:\/(\d+))?, davon (\d+) AGT/.exec(text);
      if (m && vonFz.has(t.von)) ev.push({ t: t.t, art: 'staerke', fz: t.von, f: +m[1], uf: 0, m: m[4] != null ? +m[2] + +m[3] : +m[2], agt: +m[5] });
      return;
    }
    if (t.auto === 'asue') { ev.push({ t: t.t, art: 'tb', richtung: 'Eingang', von: t.von, an: t.an || 'ELW', text }); return; }
    if (t.auto || t.richtung !== 'Eingang') return;
    const nm = /^Nachricht \(Fahrzeug-App\): (.*?)(?: \[(?:mit Bild|mit \d+ Bildern)\])?$/s.exec(text);
    if (nm && vonFz.has(t.von)) { if (nm[1] && nm[1] !== '(nur Bild)') ev.push({ t: t.t, art: 'nachricht', fz: t.von, text: nm[1] }); return; }
    ev.push({ t: t.t, art: 'tb', richtung: 'Eingang', von: t.von || '', an: t.an || 'ELW', text });
  });
  Object.entries(rec.spuren || {}).forEach(([vid, l]) => {
    let letzte = 0;
    (Array.isArray(l) ? l : []).forEach((p) => { if (Array.isArray(p) && istEpoche(p[0]) && p[0] - letzte >= 30 * 1000) { letzte = p[0]; ev.push({ t: p[0], art: 'pos', fz: name(vid), lat: p[1], lon: p[2] }); } });
  });
  const auf = rec.auftraege && Array.isArray(rec.auftraege.liste) ? rec.auftraege.liste : [];
  auf.forEach((a) => { if (istEpoche(a.eingang)) ev.push({ t: a.eingang, art: 'auftrag', kat: a.kat, priolage: !!a.priolage, adresse: a.adresse, lat: a.lat, lon: a.lon, text: a.text, meldender: a.meldender, telefon: a.telefon }); });
  return ev.filter((x) => x.art !== 'status' || x.fz).sort((a, b) => a.t - b.t);
}

/* Liste aus der Oberfläche → Ersetzungsregeln (voller Name, Nachname, Vorname) */
function ersetzungenAus(personen, extra) {
  const out = [];
  (Array.isArray(personen) ? personen : []).forEach((p) => {
    if (!p || p.aktiv === false) return;
    const von = String(p.original || '').trim(), zu = String(p.ersatz || '').trim();
    if (!von || !zu) return;
    const kontext = !!p.nurKontext;
    (Array.isArray(p.vornamen) ? p.vornamen : []).forEach((vv) => {
      const [va, vn] = Array.isArray(vv) ? vv : [];
      if (!va) return;
      out.push({ von: `${va} ${von}`, zu: `${vn || va} ${zu}`, kontext: false });
      out.push({ von: `${von}, ${va}`, zu: `${zu}, ${vn || va}`, kontext: false });
      if (vn && !WOERTER.has(va) && !KEINE_NAMEN.has(va)) out.push({ von: va, zu: vn, kontext: false });
    });
    out.push({ von, zu, kontext });
  });
  (Array.isArray(extra) ? extra : []).forEach((x) => { const von = String((x && x.von) || '').trim(), zu = String((x && x.zu) || '').trim(); if (von.length >= 2) out.push({ von, zu: zu || '…', kontext: false }); });
  return out;
}

module.exports = { ersetzungenAus, idEinsetzen, personenSammeln, fiktivVorschlag, drehbuchErstellen, drehbuchZeiten, nummerEinsetzen, liveEreignisse, zeitAbbildung, adresseTeile, WOERTER, KEINE_NAMEN, _intern: { namensTeile, ersetzerBauen, TEL, KENNZ, HAUSNR } };
