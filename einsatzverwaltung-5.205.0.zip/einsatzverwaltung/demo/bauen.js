/*
 * Baut die Demo-Version für den USB-Stick aus dem aktuellen Programmstand.
 *   node demo/bauen.js <ausgabeOrdner> <kachelOrdner> <wappenOrdner>
 * Die Kacheln erzeugt demo/karte/zeichnen.js, die Wappen demo/wappen.py.
 * Der Startdatenstand (Beispiel-Einsätze) entsteht danach mit demo/startdaten.js.
 *
 * Wichtig: Nichts Echtes kommt auf den Stick – keine Fahrzeugliste mit Namen und Kennzeichen,
 * keine ASÜ-Zugänge, keine Wappen, keine Einstellungen, keine Daten des Pi.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const QUELLE = path.resolve(__dirname, '..');
const AUS = path.resolve(process.argv[2]);
const KACHELN = path.resolve(process.argv[3]);
const WAPPEN = path.resolve(process.argv[4]);
const P = path.join(AUS, 'programm');
const PORT = 8180;

const kopie = (a, b) => { fs.mkdirSync(path.dirname(b), { recursive: true }); fs.cpSync(a, b, { recursive: true }); };
const lies = (f) => fs.readFileSync(f, 'utf8');
const schreib = (f, t, mode) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, t, mode ? { mode } : undefined); };
function ersetze(text, alt, neu, datei) {
  if (!text.includes(alt)) throw new Error(`Nicht gefunden in ${datei}: ${String(alt).slice(0, 80)}`);
  return text.split(alt).join(neu);
}

fs.rmSync(AUS, { recursive: true, force: true });
fs.mkdirSync(P, { recursive: true });

/* 1) Programm */
['server.js', 'einsatz.js', 'mail.js', 'demo.js', 'demo-modus.js', 'sicherung-entschluesseln.js', 'package.json'].forEach((f) => kopie(path.join(QUELLE, f), path.join(P, f)));
kopie(path.join(QUELLE, 'public'), path.join(P, 'public'));
kopie(path.join(QUELLE, 'melde'), path.join(P, 'melde'));
kopie(path.join(QUELLE, 'asue'), path.join(P, 'asue'));
{ // Anleitung ohne echte Postfächer, Leitstellen- und Testadressen
  let md = lies(path.join(QUELLE, 'docs', 'BEDIENUNG.md'));
  md = md.split('\n').filter((z) => !z.startsWith('**Vorbelegt (ab 3.41.1)')).join('\n');
  [[/joern-preuss@web\.de/g, 'test@musterhausen.example'], [/elw@gemeindefeuerwehr-aerzen\.de/g, 'elw@musterhausen.example'], [/elw@feuerwehr-aerzen\.de/g, 'alarm@musterhausen.example'],
    [/ \(Strato, `imap\.strato\.de` Port 993 SSL\)/g, ''], [/Kooperativen Regionalleitstelle Weserbergland/g, 'Leitstelle'], [/els@krl-wb\.de/g, 'alarm@leitstelle-musterkreis.example'],
    [/Hallenbad Aerzen Aerzen Aerzen Hopfenweg 16/g, 'Hallenbad Musterhausen Musterstadt Musterhausen Bahnhofstraße 5'], [/Hopfenweg 16, Aerzen/g, 'Bahnhofstraße 5, Musterhausen'], [/Hallenbad Aerzen/g, 'Hallenbad Musterhausen'],
    [/„FL HM 14-46-10“ = 14-46-10/g, '„FL MK 1-46-1“ = 1-46-1'], [/Aer = Aerzen, GrB = Groß Berkel, Reh = Reher/g, 'Mus = Musterhausen, Bsp = Beispieldorf, Lin = Lindenau'],
    [/\*\*GBM-AE = 14-01-1, 14-02-1, 14-02-2\*\*, \*\*WF Aerzener Maschinenfabrik = Aerzener Maschinenfabrik GmbH\*\*, \*\*Drohnenstaffel = 89-59-1\*\* /g, ''],
    [/die Werkfeuerwehren \*\*Aerzener Maschinenfabrik\*\* und \*\*Lenze\*\* mit eigenen Kacheln; „Gemeinde Aerzen“/g, 'die Werkfeuerwehren (z. B. **WF Musterwerk**) mit eigenen Kacheln; „Gemeinde Musterstadt“'], [/„Kettensäge Grießem“/g, '„Kettensäge Lindenau“'],
    [/Strato-Postfach/g, 'Postfach'], [/\(Strato\)/g, ''], [/31855 Aerzen/g, '12345 Musterhausen'],
    [/\(Vorgabe 52\.05477, 9\.23712\)/g, '(in der Demo: Ortsmitte Musterhausen)'], [/ \(52\.05477, 9\.23712\)/g, '']].forEach(([a, b]) => { md = md.replace(a, b); });
  md = md.replace(/Flecken Aerzen/g, 'Gemeinde Musterstadt').replace(/Gemeinde Aerzen/g, 'Gemeinde Musterstadt').replace(/„Aerzen“/g, '„Musterstadt“').replace(/Aerzen ist geprüft/g, 'Musterhausen ist geprüft').replace(/Die 13 Ortswehren des/g, 'Die Ortswehren der');
  md = md.replace(/Hameln-Pyrmont/g, 'Musterkreis').replace(/Hameln/g, 'Musterstadt').replace(/Groß Berkel/g, 'Beispieldorf').replace(/Dehmke/g, 'Lindenau').replace(/Rohrsen/g, 'Neudorf').replace(/Bad Münder/g, 'Bergheim').replace(/aerzen/g, 'musterhausen').replace(/Aerzen/g, 'Musterhausen');   // ab 5.146: Beispiele ohne echte Orte
  schreib(path.join(AUS, 'Anleitung', 'Bedienungsanleitung.md'), md);
  // ab 5.8: Kurzbeschreibung dazu (enthält keine echten Daten)
  fs.copyFileSync(path.join(QUELLE, 'docs', 'KURZBESCHREIBUNG.md'), path.join(AUS, 'Anleitung', 'Kurzbeschreibung.md'));
  // ab 5.10.4: Kurzanleitungen (ohne echte Daten; Ortsname ersetzt)
  [['KURZANLEITUNG_Fahrzeugbesatzung.md', 'Kurzanleitung Fahrzeugbesatzung.md'], ['KURZANLEITUNG_Geraetewart.md', 'Kurzanleitung Geraetewart.md'], ['KURZANLEITUNG_Atemschutzgeraetewart.md', 'Kurzanleitung Atemschutzgeraetewart.md'], ['KURZANLEITUNG_Geraetetraeger.md', 'Kurzanleitung Geraetetraeger.md']].forEach(([a, b]) => schreib(path.join(AUS, 'Anleitung', b), lies(path.join(QUELLE, 'docs', a)).replace(/Aerzen/g, 'Musterstadt')));
}
const pkg = JSON.parse(lies(path.join(P, 'package.json')));
pkg.name = 'einsatzverwaltung-demo'; pkg.description = 'Einsatzverwaltung – Demo-Version mit erfundenen Daten'; pkg.scripts = { start: 'node server.js' };
schreib(path.join(P, 'package.json'), JSON.stringify(pkg, null, 2) + '\n');

/* 2) Echte Daten entfernen bzw. durch erfundene ersetzen */
schreib(path.join(P, 'mail.js'), ersetze(lies(path.join(P, 'mail.js')), 'Hallenbad Aerzen Aerzen Aerzen Hopfenweg 16', 'Hallenbad Musterhausen Musterstadt Musterhausen Bahnhofstraße 5', 'mail.js'));
const FZ = require('./fahrzeuge');
const MITTE = JSON.parse(lies(path.join(__dirname, 'karte', 'daten', 'demo-karte.json'))).mitte;
const HEIMAT = `{lat:${MITTE.lat}, lon:${MITTE.lon}, name:'Musterhausen'}`;
let idx = lies(path.join(P, 'public', 'index.html'));
idx = idx.split('\n').map((z) => (z.startsWith('const BASE_VEHICLES = [') ? `const BASE_VEHICLES = ${JSON.stringify(FZ)};` : z)).join('\n');
idx = ersetze(idx, "const HEIMAT_STD = {lat:52.0497, lon:9.2660, name:'Aerzen'};", `const HEIMAT_STD = ${HEIMAT};`, 'index.html');
idx = ersetze(idx, "city:'Aerzen'", "city:'Musterstadt'", 'index.html');
idx = idx.replace(/placeholder="Aerzen"/g, 'placeholder="Musterhausen"').replace(/ELW Aerzen/g, 'ELW Musterhausen').replace(/Schulstraße 3, Aerzen/g, 'Schulstraße 3, Musterhausen').replace(/Grundschule Aerzen/g, 'Grundschule Musterhausen');
// ab 3.97: Startansicht ⌂ der Lagekarte auf die Demo-Karte
idx = ersetze(idx, 'const KARTEN_HOME_STD = {lat:52.05477, lon:9.23712, radius:1000};', `const KARTEN_HOME_STD = {lat:${MITTE.lat}, lon:${MITTE.lon}, radius:1000};`, 'index.html');
idx = idx.replace(/placeholder="52\.05477, 9\.23712"/g, `placeholder="${MITTE.lat}, ${MITTE.lon}"`).replace('(Vorgabe: 52.05477, 9.23712 mit 1 km)', '(Vorgabe: Ortsmitte Musterhausen mit 1 km)').replace('(Vorgabe: Gerätehaus Aerzen, 1 km)', '(Demo: Ortsmitte Musterhausen, 1 km)');
idx = ersetze(idx, "(ff.oel || '14-09-10') : (ff.elw || '14-11-10')", "(ff.oel || '77-09-10') : (ff.elw || '77-11-10')", 'index.html');
// Werkfeuerwehren im Reiter Ausrüstung (ab 3.52): erfundenes Werk statt echter Firmen
idx = idx.replace(/const AUSR_WERKFEUERWEHREN = \[[^\n]*\];/, "const AUSR_WERKFEUERWEHREN = [{ort:'Musterwerk GmbH', kurz:'WF Musterwerk'}];");
idx = idx.replace(/placeholder="z\. B\. Grupenhagen, Am Anger"/g, 'placeholder="z. B. Lindenau, Am Anger"');
idx = idx.replace(/„GrB = Groß Berkel“/g, '„Bsp = Beispieldorf“').replace(/placeholder="Aer = Aerzen"/g, 'placeholder="Mus = Musterhausen"').replace(/Leitstelle Hameln/g, 'Leitstelle Musterkreis');
schreib(path.join(P, 'public', 'index.html'), idx);
let ueb = lies(path.join(P, 'public', 'uebung', 'index.html'));
ueb = ersetze(ueb, "const HEIMAT_STD = {lat:52.0497, lon:9.2660, name:'Aerzen'};", `const HEIMAT_STD = ${HEIMAT};`, 'uebung');
ueb = ersetze(ueb, "', 31855 Aerzen'", "', 12345 Musterhausen'", 'uebung');
schreib(path.join(P, 'public', 'uebung', 'index.html'), ueb);
// ab 3.98: Übungsleitstelle – Kartenmitte der Demo
schreib(path.join(P, 'public', 'uebleitstelle', 'index.html'), ersetze(lies(path.join(P, 'public', 'uebleitstelle', 'index.html')), 'const K = {lat:52.05477, lon:9.23712, z:14};', `const K = {lat:${MITTE.lat}, lon:${MITTE.lon}, z:15};`, 'uebleitstelle'));
// Server: Ersatzwerte für den Heimatort (nur Vorgabe, der Datenstand setzt den Heimatort ohnehin)
let srv = lies(path.join(P, 'server.js'));
srv = srv.replace(/\{ lat: 52\.0497, lon: 9\.266, name: 'Aerzen' \}/g, `{ lat: ${MITTE.lat}, lon: ${MITTE.lon}, name: 'Musterhausen' }`).replace(/\{ lat: 52\.0497, lon: 9\.266, heimat: true \}/g, `{ lat: ${MITTE.lat}, lon: ${MITTE.lon}, heimat: true }`).replace(/\{ lat: 52\.0497, lon: 9\.2660, name: 'Aerzen' \}/g, `{ lat: ${MITTE.lat}, lon: ${MITTE.lon}, name: 'Musterhausen' }`);
// E-Mail-Vorgaben der echten Wehr (Adressen, Leitstelle, Testabsender, Ortswehr-Kürzel) durch erfundene ersetzen
[["'smtp.strato.de'", "''"], ["'imap.strato.de'", "''"], ['elw@gemeindefeuerwehr-aerzen.de', 'elw@musterhausen.example'], ['elw@feuerwehr-aerzen.de', 'alarm@musterhausen.example'],
  ['Feuerwehr Aerzen – ELW', 'Feuerwehr Musterhausen – ELW'], ['els@krl-wb.de', 'alarm@leitstelle-musterkreis.example'], ["'Leitstelle Hameln'", "'Leitstelle Musterkreis'"],
  ['joern-preuss@web.de', 'test@musterhausen.example'], ['Testalarm Jörn Preuß', 'Testalarm'], ["'31855 Aerzen'", "'12345 Musterhausen'"],
  ['Strato: smtp.strato.de; sonst z. B. ', 'z. B. '], ['Strato: imap.strato.de; sonst z. B. ', 'z. B. '], ['Vorgaben für Aerzen: Alarmmail der Kooperativen Regionalleitstelle Weserbergland;', 'Vorgaben (Demo):'], ["hilfe: 'Bei Strato die vollständige E-Mail-Adresse.'", "hilfe: 'Meist die vollständige E-Mail-Adresse.'"],
].forEach(([a, b]) => { srv = ersetze(srv, a, b, 'server.js'); });
// ab 3.97/3.98: Startansicht ⌂ und Startpunkt der Übungsfahrzeuge
srv = ersetze(srv, 'lat: 52.05477, lon: 9.23712', `lat: ${MITTE.lat}, lon: ${MITTE.lon}`, 'server.js');
// ab 4.1: echte Feuerwehrhäuser raus (Demo bekommt erfundene über die Startdaten)
{ const n = srv.replace(/const STANDORTE_AERZEN = \[[\s\S]*?\n\];/, 'const STANDORTE_AERZEN = [];'); if (n === srv) throw new Error('STANDORTE_AERZEN nicht gefunden'); srv = n; }
// Besatzungs-App: ELW der Demo
srv = ersetze(srv, "typ: 'text', vorgabe: '14-11-10', hilfe: 'Funkrufname des Fahrzeugs (ELW)", "typ: 'text', vorgabe: '77-11-10', hilfe: 'Funkrufname des Fahrzeugs (ELW)", 'server.js');
srv = ersetze(srv, "String(A.CREW_FZ || '14-11-10')", "String(A.CREW_FZ || '77-11-10')", 'server.js');
// Kürzel der Ortsfeuerwehren in „Alarmierte Kräfte“ (ab 3.52 mehrzeilig, mit Werkfeuerwehr und Drohnenstaffel)
{ const re = /const MAIL_KRAEFTE_VORGABE = \[[\s\S]*?\];/; if (!re.test(srv)) throw new Error('MAIL_KRAEFTE_VORGABE nicht gefunden');
  srv = srv.replace(re, "const MAIL_KRAEFTE_VORGABE = [{ kuerzel: 'Mus', ortswehr: 'Musterhausen' }, { kuerzel: 'Bsp', ortswehr: 'Beispieldorf' }, { kuerzel: 'Lin', ortswehr: 'Lindenau' }];"); }
srv = ersetze(srv, 'Feuerwehrtechnische Zentrale | Ortsgebiet | Aerzen', 'Feuerwehrtechnische Zentrale | Ortsgebiet | Musterstadt', 'server.js');   // ab 5.10.1: Ziele im Fahrtenbuch
schreib(path.join(P, 'server.js'), srv);
let einsatz = lies(path.join(P, 'einsatz.js'));
einsatz = einsatz.replace('const HEIMAT = { lat: 52.0497, lon: 9.2660 }; // Aerzen', `const HEIMAT = { lat: ${MITTE.lat}, lon: ${MITTE.lon} }; // Musterhausen (Demo)`);
einsatz = einsatz.replace("|| 'Aerzen')", "|| 'Musterstadt')");
schreib(path.join(P, 'einsatz.js'), einsatz);

// Wappen
fs.copyFileSync(path.join(WAPPEN, 'musterstadt.png'), path.join(P, 'public', 'icons', 'wappen.png'));
fs.rmSync(path.join(P, 'asue', 'wappen'), { recursive: true, force: true });
fs.mkdirSync(path.join(P, 'asue', 'wappen'));
const WEHREN = [['musterhausen', 'Musterhausen'], ['beispieldorf', 'Beispieldorf'], ['lindenau', 'Lindenau'], ['neudorf', 'Neudorf']];
['musterstadt', ...WEHREN.map((w) => w[0])].forEach((w) => fs.copyFileSync(path.join(WAPPEN, `${w}.png`), path.join(P, 'asue', 'wappen', `${w}.png`)));
let asue = lies(path.join(P, 'asue', 'index.html'));
const png64 = fs.readFileSync(path.join(WAPPEN, 'musterstadt.png')).toString('base64');
const jpg64 = fs.readFileSync(path.join(WAPPEN, 'musterstadt.jpg')).toString('base64');
asue = asue.replace(/(<img class="wappen" data-fallback="" src="data:image\/png;base64,)[A-Za-z0-9+/=]+(")/, `$1${png64}$2`);
asue = asue.replace(/const WAPPEN_JPG = '[A-Za-z0-9+/=]+';/, `const WAPPEN_JPG = '${jpg64}';`);
asue = asue.replace(/b\.gemeinde==='aerzen'/g, "b.gemeinde==='musterstadt'").replace(/eingebautes Aerzen-Wappen/g, 'eingebautes Demo-Wappen');
schreib(path.join(P, 'asue', 'index.html'), asue);
// ab 5.146: auch die übrigen Datenbank-Seiten tragen ein eingebautes Wappen – durch das Demo-Wappen ersetzen
['datenbank.html', 'berichte.html', 'traeger.html', 'sammeln.html'].forEach((f) => { const d = path.join(P, 'asue', f); if (!fs.existsSync(d)) return; let t = lies(d);
  t = t.replace(/(<img class="wappen"[^>]*src="data:image\/png;base64,)[A-Za-z0-9+/=]+(")/g, `$1${png64}$2`).replace(/const WAPPEN_JPG = '[A-Za-z0-9+/=]+';/g, `const WAPPEN_JPG = '${jpg64}';`).replace(/gemeinde==='aerzen'/g, "gemeinde==='musterstadt'");
  schreib(d, t); });
let sw = lies(path.join(P, 'asue', 'sw.js'));
sw = sw.replace(/const SHELL = \[[^\]]*\];/, `const SHELL = ['./', './index.html', './sammeln.html', './benutzer.js', './manifest.webmanifest', './icon-192.png', './icon-512.png', ${['musterstadt', ...WEHREN.map((w) => w[0])].map((w) => `'./wappen/${w}.png'`).join(', ')}];`).replace(/const CACHE = '([^']+)'/, "const CACHE = '$1-demo'");
schreib(path.join(P, 'asue', 'sw.js'), sw);
// ASÜ-Zugänge: nur erfundene Wehren, Passwort für alle „demo1234“ (Admin: „admin1234“)
const hash = (pw) => { const salt = crypto.randomBytes(16).toString('hex'); return { salt, hash: crypto.pbkdf2Sync(pw, Buffer.from(salt, 'hex'), 150000, 32, 'sha256').toString('hex') }; };
const ben = {
  version: 1, iterationen: 150000,
  gemeinden: { musterstadt: { name: 'Gemeinde Musterstadt', wappen: 'wappen/musterstadt.png' } },
  benutzer: [
    ...WEHREN.map(([u, n]) => ({ user: u, name: `Ortsfeuerwehr ${n}`, ort: n, gemeinde: 'musterstadt', rolle: 'wehr', wappen: `wappen/${u}.png`, ...hash('demo1234') })),
    { user: 'admin', name: 'Administrator', ort: 'Gemeinde Musterstadt', gemeinde: 'musterstadt', rolle: 'admin', wappen: 'wappen/musterstadt.png', ...hash('admin1234') },
  ],
};
schreib(path.join(P, 'asue', 'benutzer.js'), `/* Benutzer der ASÜ-App (DEMO-VERSION, erfundene Zugänge). Passwort: demo1234, Admin: admin1234 */\nwindow.ASUE_BENUTZER = ${JSON.stringify(ben, null, 1)};\n`);

/* 3) Karte und Ersatzdienste */
const DD = path.join(P, 'demo-daten');
fs.mkdirSync(DD, { recursive: true });
['demo-karte.json', 'adressen.json'].forEach((f) => fs.copyFileSync(path.join(__dirname, 'karte', 'daten', f), path.join(DD, f)));
fs.copyFileSync(path.join(KACHELN, 'leer.png'), path.join(DD, 'leer.png'));
kopie(path.join(KACHELN, 'tiles'), path.join(P, 'tiles'));
kopie(path.join(KACHELN, 'luftbild'), path.join(DD, 'luftbild'));
fs.mkdirSync(path.join(P, 'startdaten'), { recursive: true });
const wj = JSON.parse(lies(path.join(__dirname, 'karte', 'daten', 'wasser.json'))); wj.stand = Date.now();   // sonst „älter als 30 Tage“ beim ersten Start
schreib(path.join(P, 'startdaten', 'wasser.json'), JSON.stringify(wj));
schreib(path.join(DD, 'demo-info.json'), JSON.stringify({ zugaenge: [{ name: 'Admin', pin: '123456' }, { name: 'Einsatzleitung', pin: '222222' }, { name: 'Betrachter', pin: '333333' }] }, null, 1));

/* 4) Start- und Hilfsskripte */
const V = path.join(__dirname, 'stick');
const vorlage = (f) => lies(path.join(V, f)).replace(/@PORT@/g, String(PORT)).replace(/@MPORT@/g, String(PORT + 1)).replace(/@APORT@/g, String(PORT + 2)).replace(/@VERSION@/g, pkg.version);
const winBat = (t) => t.replace(/\r?\n/g, '\r\n');
schreib(path.join(AUS, 'Start Windows.bat'), winBat(vorlage('start.bat').replace(/@NETZ@/g, '0')));
schreib(path.join(AUS, 'Start Windows - mit Handy im WLAN.bat'), winBat(vorlage('start.bat').replace(/@NETZ@/g, '1')));
schreib(path.join(AUS, 'Stick vorbereiten (einmalig) Windows.bat'), winBat(vorlage('vorbereiten.bat')));
schreib(path.join(AUS, 'Demo zuruecksetzen Windows.bat'), winBat(vorlage('zuruecksetzen.bat')));
schreib(path.join(P, 'werkzeuge', 'vorbereiten.ps1'), '\ufeff' + winBat(vorlage('vorbereiten.ps1')));   // BOM: Windows PowerShell 5 liest sonst ANSI
schreib(path.join(AUS, 'Mac und Linux', 'Start Mac.command'), vorlage('start.sh').replace(/@NETZ@/g, '0'), 0o755);
schreib(path.join(AUS, 'Mac und Linux', 'Start Linux.sh'), vorlage('start.sh').replace(/@NETZ@/g, '0'), 0o755);
schreib(path.join(AUS, 'Mac und Linux', 'Start mit Handy im WLAN.sh'), vorlage('start.sh').replace(/@NETZ@/g, '1'), 0o755);
schreib(path.join(AUS, 'Mac und Linux', 'Stick vorbereiten (einmalig).sh'), vorlage('vorbereiten.sh'), 0o755);
schreib(path.join(AUS, 'Mac und Linux', 'Demo zuruecksetzen.sh'), vorlage('zuruecksetzen.sh'), 0o755);
schreib(path.join(AUS, 'LIESMICH.html'), vorlage('LIESMICH.html'));
fs.mkdirSync(path.join(AUS, 'node'), { recursive: true });
schreib(path.join(AUS, 'node', 'HIER KOMMT NODE.JS HIN.txt'), winBat('Dieser Ordner wird mit „Stick vorbereiten (einmalig)“ gefüllt (Node.js für Windows, auf Wunsch auch für Mac und Linux).\nAlternativ ein auf dem Rechner installiertes Node.js ab Version 18 – dann wird dieser Ordner nicht gebraucht.\n'));
console.log('Demo-Paket gebaut:', AUS);
