/*
 * Ergänzt den Startdatenstand der Demo um erfundene E-Mails (Seite „E-Mail“: Eingang und Gesendet).
 *   node demo/beispielmails.js <programm/startdaten/data.json>
 * Alle Adressen enden auf .example, alle Namen sind erfunden.
 */
const fs = require('fs');
const f = process.argv[2];
const d = JSON.parse(fs.readFileSync(f, 'utf8'));
const arch = (d['arch.index'] || []).slice().sort((a, b) => a.alarmzeit - b.alarmzeit);
const nach = (nr) => arch.find((x) => x.nummer === nr) || arch[0] || {};
let n = 0; const id = () => `demo${(++n).toString(36).padStart(4, '0')}`;
const LS = { name: 'Leitstelle Musterkreis', adresse: 'alarm@leitstelle-musterkreis.example' };
const e1 = nach('2026-001'), e2 = nach('2026-002'), e3 = nach('2026-003');
d['mail.eingang'] = [
  { id: id(), t: (e1.alarmzeit || Date.now()) + 26 * 60000, von: { name: 'Trupp Erkundung', adresse: 'erkundung@musterhausen.example' }, an: ['elw@musterhausen.example'], betreff: 'Lage Rückseite Scheune',
    text: 'Rückseite der Scheune frei zugänglich, Feuer greift nicht auf das Wohnhaus über.\nZufahrt für die Drehleiter über den Feldweg möglich.', postfach: 'elw@musterhausen.example', art: 'erkunder',
    ergebnis: `Tagebuch Einsatz ${e1.nummer}`, einsatz: e1.nummer, eid: e1.id, anhaenge: [], bilder: [] },
  { id: id(), t: (e3.alarmzeit || Date.now()) - 20000, von: LS, an: ['alarm@musterhausen.example'], betreff: 'MK202600314',
    text: 'ALARMMAIL Leitstelle Musterkreis\n\nEinsatznummer: MK202600314\n\nTH1: Ölspur\n\nca. 300 m auf der Fahrbahn\n\nEINSATZORT:\nMusterstadt Musterhausen Hauptstraße 40\n\nAlarmierte Kräfte: Mus\n\nAlarmierte Einsatzmittel: FL MK 77-11-40, FL MK 77-11-56',
    postfach: 'alarm@musterhausen.example', art: 'leitstelle', ergebnis: `Einsatz angelegt ${e3.nummer} · 2 Fahrzeug(e) alarmiert`, einsatz: e3.nummer, eid: e3.id, anhaenge: [], bilder: [] },
  { id: id(), t: (e3.alarmzeit || Date.now()) + 3 * 3600000, von: { name: 'Gewinnspiel-Team', adresse: 'info@werbung.example' }, an: ['elw@musterhausen.example'], betreff: 'Sie haben gewonnen!',
    text: 'Herzlichen Glückwunsch …', postfach: 'elw@musterhausen.example', art: null, ergebnis: 'ignoriert – Absender nicht freigegeben', einsatz: null, eid: null, anhaenge: [], bilder: [] },
];
d['mail.ausgang'] = [
  { id: id(), t: (e1.alarmzeit || Date.now()) + 40 * 60000, an: ['leitstelle@leitstelle-musterkreis.example'], betreff: `Lagemeldung ${e1.nummer} B3 – Brand landwirtschaftliches Anwesen`,
    text: 'Scheune in Vollbrand, Riegelstellung zum Wohnhaus aufgebaut, keine Personen in Gefahr.\n\n—\n(automatisch aus der Einsatzverwaltung)', anhaenge: [], grund: 'Lagemeldung', user: 'automatisch', einsatzId: e1.id, ok: true, abgelehnt: [] },
  { id: id(), t: (e2.alarmzeit || Date.now()) + 2 * 3600000, an: ['wehrfuehrung@musterhausen.example'], betreff: `Einsatzbericht ${e2.nummer} – TH VU`,
    text: `Guten Tag,\n\nanbei der Einsatzbericht zum Einsatz ${e2.nummer}.\n\nDiese E-Mail wurde nach Einsatzende automatisch verschickt.`, anhaenge: [{ name: `Einsatzbericht ${e2.nummer}.pdf`, groesse: 412000 }], grund: 'Einsatzbericht', user: 'admin', einsatzId: e2.id, ok: true, abgelehnt: [] },
];
fs.writeFileSync(f, JSON.stringify(d));
console.log('Beispiel-Mails:', d['mail.eingang'].length, 'Eingang,', d['mail.ausgang'].length, 'Gesendet');
