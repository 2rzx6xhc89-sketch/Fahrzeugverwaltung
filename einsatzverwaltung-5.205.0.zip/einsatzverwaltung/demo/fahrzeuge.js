/* Erfundene Fahrzeuge und Funktionen für die Demo-Version (Gemeinde „Musterstadt“).
   Funkrufnamen, Kennzeichen (Kennung „XY“ gibt es nicht) und Namen sind frei erfunden. */
const fz = (id, funkrufname, ortswehr, fahrzeugtyp, stadt, o = {}) => ({
  id, funkrufname, ortswehr, fahrzeugtyp, filterType: o.filterType != null ? o.filterType : fahrzeugtyp, name: o.name || '', stadt,
  kennzeichen: o.kz || '', sondereinheit: o.se || '', equipmentCategory: '', ausruestung: o.aus || [], einsatz: false,
  personnelDefault: { mannschaft: o.m || 0, paTraeger: o.pa || 0 }, funktion: o.funktion || '',
});
const G = 'Musterstadt';
module.exports = [
  fz('d01', '77-01-1', 'Musterhausen', '', G, { filterType: '', name: 'Klaus Beispiel', funktion: 'GemBM', kz: 'XY-FW 101' }),
  fz('d02', '77-02-1', 'Beispieldorf', '', G, { filterType: '', name: 'Anna Muster', funktion: 'Stellv. GemBM' }),
  // Ortsfeuerwehr Musterhausen (Stützpunkt)
  fz('d10', '77-11-10', 'Musterhausen', 'ELW 1', G, { kz: 'XY-FW 1110', m: 4, aus: ['Durchsage', 'Notfallrucksack', 'Strom/Beleuchtung (kVA): 6kVA'] }),
  fz('d11', '77-11-40', 'Musterhausen', 'HLF 20', G, { kz: 'XY-FW 1140', m: 9, pa: 4, aus: ['AGT- Geräte: 4', 'Wasser (Liter): 2000', 'Schaum (1 %) (Liter): 120', 'Hilfeleistungs satz', 'Rettungszylinder', 'WBK', 'Lichtmast', 'Tauchpumpe', 'Kettensäge', 'AED', 'Hebekissen', 'Türöffnung', 'Strom/Beleuchtung (kVA): 14KVA'] }),
  fz('d12', '77-11-24', 'Musterhausen', 'TLF 3000', G, { kz: 'XY-FW 1124', m: 3, pa: 2, aus: ['AGT- Geräte: 2', 'Wasser (Liter): 3000', 'Schaum (1 %) (Liter): 120', 'WBK'] }),
  fz('d13', '77-11-30', 'Musterhausen', 'DLAK 23/12', G, { kz: 'XY-FW 1130', m: 3, aus: ['Rettungs- plattform LKW', 'Schleifkorbtrage', 'Strom/Beleuchtung (kVA): 5kVA'] }),
  fz('d14', '77-11-19', 'Musterhausen', 'MTW', G, { kz: 'XY-FW 1119', m: 9 }),
  fz('d15', '77-11-56', 'Musterhausen', 'GW-L2', G, { kz: 'XY-FW 1156', m: 3, aus: ['Faltbehälter: 5000', 'MZ: MZ16', 'Strom/Beleuchtung (kVA): 9kVA'] }),
  // weitere Ortsfeuerwehren
  fz('d20', '77-21-44', 'Beispieldorf', 'LF 10', G, { kz: 'XY-FW 2144', m: 9, pa: 4, aus: ['AGT- Geräte: 4', 'Wasser (Liter): 1000', 'Tauchpumpe', 'Kettensäge', 'Notfallrucksack'] }),
  fz('d21', '77-21-19', 'Beispieldorf', 'MTW', G, { kz: 'XY-FW 2119', m: 9 }),
  fz('d30', '77-31-47', 'Lindenau', 'TSF-W', G, { kz: 'XY-FW 3147', m: 6, pa: 2, aus: ['AGT- Geräte: 2', 'Wasser (Liter): 750'] }),
  fz('d40', '77-41-42', 'Neudorf', 'MLF', G, { kz: 'XY-FW 4142', m: 6, pa: 2, aus: ['AGT- Geräte: 2', 'Wasser (Liter): 1000', 'Kettensäge'] }),
  // Nachbarstadt
  fz('d50', '78-11-30', 'Beispielstadt', 'DLK 23/12', 'Beispielstadt', { kz: 'XY-BS 1130', m: 3 }),
  fz('d51', '78-11-52', 'Beispielstadt', 'RW', 'Beispielstadt', { kz: 'XY-BS 1152', m: 3, aus: ['Hilfeleistungs satz', 'Rettungszylinder', 'Hebekissen', 'Be- und Entlüftungsgerät', 'Strom/Beleuchtung (kVA): 14KVA'] }),
  // Kreisfeuerwehr
  fz('d90', '99-01-1', 'Kreisfeuerwehr', 'KdoW', 'Kreisfeuerwehr Musterkreis', { filterType: '', name: 'Peter Beispielmann', funktion: 'KBM' }),
  fz('d91', '99-12-1', 'Kreisfeuerwehr', 'ELW 2', 'Kreisfeuerwehr Musterkreis', { kz: 'XY-LK 912', m: 6, se: 'Kreisfeuerwehrbereitschaft' }),
  fz('d92', '99-73-1', 'Kreisfeuerwehr', 'GW-G', 'Kreisfeuerwehr Musterkreis', { kz: 'XY-LK 973', m: 6, pa: 4, se: 'ABC-Zug', aus: ['Ex-Warngerät', 'Multimessgerät', 'CSA: 5'] }),
  fz('d93', '99-17-1', 'Kreisfeuerwehr', 'GW-Messtechnik', 'Kreisfeuerwehr Musterkreis', { kz: 'XY-LK 917', m: 3, se: 'Messzug', aus: ['Multimessgerät', 'Ex-Warngerät'] }),
  fz('d94', '99-68-1', 'Kreisfeuerwehr', 'GW-L', 'Kreisfeuerwehr Musterkreis', { kz: 'XY-LK 968', m: 3, se: 'Versorgungsgruppe' }),
  // Rettungsdienst
  fz('d97', '1-83-1', 'Rettungswache Musterhausen', 'RTW', 'Rettungsdienst', { kz: 'XY-RD 831', m: 2 }),
  fz('d98', '1-82-1', 'Rettungswache Musterhausen', 'NEF', 'Rettungsdienst', { kz: 'XY-RD 821', m: 2 }),
];
