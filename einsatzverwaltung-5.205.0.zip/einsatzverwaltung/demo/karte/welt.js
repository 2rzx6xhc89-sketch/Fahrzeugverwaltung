/*
 * Fiktiver Ort „Musterhausen“ für die Demo-Version der Einsatzverwaltung.
 * Alle Straßen, Gebäude, Adressen und Wasserentnahmestellen sind frei erfunden.
 * Koordinaten in Metern (x = Ost, y = Nord) um den Mittelpunkt MITTE.
 * Ausgabe: welt.json (Geometrie für die Kacheln), adressen.json, wasser.json
 */
const fs = require('fs');
const path = require('path');

const MITTE = { lat: 52.0, lon: 9.2 };
const BEREICH = { x0: -1500, x1: 1500, y0: -1200, y1: 1200 };      // gezeichnete Fläche
const KERN = { x0: -950, x1: 950, y0: -750, y1: 750 };               // darin darf der Kartenmittelpunkt liegen
const ORT = 'Musterhausen', PLZ = '12345';

let seed = 20261001;
const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
const zw = (a, b) => a + rnd() * (b - a);

function geo(x, y) {
  return { lat: +(MITTE.lat + y / 111320).toFixed(7), lon: +(MITTE.lon + x / (111320 * Math.cos(MITTE.lat * Math.PI / 180))).toFixed(7) };
}

/* ---------- Straßen ---------- */
// art: haupt (Kreisstraße), str (Ortsstraße), wohn (Wohnweg), weg (Feld-/Waldweg)
const STRASSEN = [
  { name: 'Hauptstraße', art: 'haupt', pts: [[-1500, -90], [-1000, -70], [-600, -40], [-300, -35], [0, 0], [300, 20], [500, 30], [800, 55], [1100, 90], [1500, 130]], haeuser: [[-560, 460]] },
  { name: 'Bahnhofstraße', art: 'str', pts: [[0, 0], [10, 150], [30, 300], [45, 470], [55, 520]], haeuser: [[0, 1]] },
  { name: 'Schulstraße', art: 'str', pts: [[0, 0], [-15, -150], [-20, -300], [-40, -470], [-60, -650]], haeuser: [[0, 1]] },
  { name: 'Kirchstraße', art: 'str', pts: [[-300, -35], [-295, 100], [-280, 250], [-120, 290], [30, 300]], haeuser: [[0, 1]] },
  { name: 'Lindenweg', art: 'str', pts: [[-600, -40], [-615, -200], [-620, -350], [-500, -400], [-300, -410], [-35, -400]], haeuser: [[0, 1]] },
  { name: 'Gartenstraße', art: 'wohn', pts: [[-300, -35], [-305, -130], [-320, -220], [-170, -225], [-18, -220]], haeuser: [[0, 1]] },
  { name: 'Rosenweg', art: 'wohn', pts: [[-600, -40], [-620, 100], [-640, 250], [-460, 255], [-280, 250]], haeuser: [[0, 1]] },
  { name: 'Eichenring', art: 'wohn', ring: true, pts: kreis(-480, 420, 115, 14), haeuser: [[0, 1]] },
  { name: 'Am Anger', art: 'wohn', pts: [[-470, 255], [-475, 305]], haeuser: [] },
  { name: 'Mühlenweg', art: 'str', pts: [[300, 20], [310, -100], [330, -250], [380, -380], [450, -500], [470, -560]], haeuser: [[0, 1]] },
  { name: 'Birkenweg', art: 'wohn', pts: [[-15, -150], [150, -155], [312, -160]], haeuser: [[0, 1]] },
  { name: 'Am Sportplatz', art: 'str', pts: [[330, -250], [500, -255], [700, -265]], haeuser: [[0, 0.45]] },
  { name: 'Industriestraße', art: 'str', pts: [[500, 30], [540, 180], [560, 350], [750, 370], [950, 380]], haeuser: [] },
  { name: 'Waldstraße', art: 'str', pts: [[1100, 90], [1110, 300], [1130, 500], [1150, 700], [1180, 1000], [1200, 1200]], haeuser: [[0, 0.3]] },
  { name: 'Feldweg', art: 'weg', pts: [[-60, -650], [-80, -900], [-100, -1200]], haeuser: [] },
  { name: 'Am Mühlenbach', art: 'weg', pts: [[470, -560], [650, -600], [820, -610]], haeuser: [] },
  { name: 'Biogasweg', art: 'weg', pts: [[820, -610], [900, -700]], haeuser: [] },
  { name: 'Waldweg', art: 'weg', pts: [[45, 470], [-200, 650], [-600, 800], [-1000, 900]], haeuser: [] },
  { name: 'Am Bahnhof', art: 'wohn', pts: [[45, 470], [200, 470], [300, 460]], haeuser: [] },
];
function kreis(cx, cy, r, n) { const p = []; for (let i = 0; i <= n; i++) { const a = (i / n) * Math.PI * 2; p.push([+(cx + r * Math.cos(a)).toFixed(1), +(cy + r * Math.sin(a)).toFixed(1)]); } return p; }
const BREITE = { haupt: 9, str: 7, wohn: 5.5, weg: 3.5 };

/* ---------- Flächen ---------- */
const FLAECHEN = [
  { art: 'acker', pts: [[-1500, -1200], [1500, -1200], [1500, 1200], [-1500, 1200]] },
  { art: 'wald', name: 'Musterwald', pts: [[300, 640], [800, 600], [1500, 560], [1500, 1200], [150, 1200], [180, 900]] },
  { art: 'wald', name: 'Eichholz', pts: [[-1500, -700], [-900, -800], [-800, -1200], [-1500, -1200]] },
  { art: 'wald', pts: [[-1500, 700], [-1100, 950], [-900, 1200], [-1500, 1200]] },
  { art: 'wiese', pts: [[-1500, -620], [-600, -620], [0, -580], [700, -650], [1500, -560], [1500, -330], [700, -360], [450, -440], [0, -380], [-700, -460], [-1500, -400]] },
  { art: 'wohngebiet', pts: [[-720, -480], [-720, 520], [-300, 560], [100, 520], [420, 440], [420, -330], [300, -430], [0, -460], [-400, -470]] },
  { art: 'gewerbe', pts: [[440, 70], [460, 400], [1000, 430], [1000, 120], [700, 80]] },
  { art: 'friedhof', name: 'Friedhof', pts: [[-260, 120], [-150, 120], [-150, 220], [-260, 220]] },
  { art: 'sport', name: 'Sportplatz', pts: [[400, -290], [640, -290], [640, -430], [400, -430]] },
  { art: 'hof', pts: [[400, -480], [540, -480], [540, -600], [400, -600]] },
  { art: 'gewerbe', name: 'Biogasanlage', pts: [[860, -690], [1000, -690], [1000, -820], [860, -820]] },
  { art: 'gewerbe', name: 'Kläranlage', pts: [[1150, -480], [1300, -480], [1300, -600], [1150, -600]] },
  { art: 'acker2', pts: [[-1500, 400], [-750, 400], [-750, 650], [-1500, 650]] },
  { art: 'acker2', pts: [[600, -900], [1500, -900], [1500, -1200], [600, -1200]] },
  { art: 'acker2', pts: [[-600, 650], [-150, 600], [-100, 900], [-650, 1000]] },
  { art: 'wiese', pts: [[1050, 150], [1500, 180], [1500, 520], [1050, 520]] },
];
const WASSER = {
  bach: { name: 'Mühlenbach', breite: 8, pts: [[-1500, -480], [-1100, -540], [-600, -520], [-250, -500], [0, -480], [250, -470], [450, -540], [700, -520], [1000, -440], [1500, -420]] },
  teiche: [{ name: 'Löschteich', cx: -230, cy: -560, r: 28 }, { name: 'Klärbecken', cx: 1225, cy: -540, r: 32 }],
};
const BAHN = { name: 'Bahnstrecke', pts: [[-1500, 620], [-700, 580], [0, 545], [700, 520], [1500, 480]] };

/* ---------- Besondere Gebäude ---------- */
// x,y Mitte · b,t Breite/Tiefe · w Drehung (Grad) · adr Hausnummer an Straße
const BESONDERE = [
  { name: 'Feuerwehrhaus', strasse: 'Hauptstraße', nr: '30', x: 175, y: -45, b: 34, t: 22, w: 4, art: 'fw' },
  { name: 'Kirche St. Martin', strasse: 'Kirchstraße', nr: '2', x: -205, y: 60, b: 36, t: 17, w: 2, art: 'kirche' },
  { name: 'Grundschule Musterhausen', strasse: 'Schulstraße', nr: '12', x: -110, y: -300, b: 60, t: 18, w: 0, art: 'oeff' },
  { name: 'Sporthalle', strasse: 'Schulstraße', nr: '14', x: -105, y: -350, b: 40, t: 26, w: 0, art: 'oeff' },
  { name: 'Seniorenheim Haus Sonnenblick', strasse: 'Kirchstraße', nr: '20', x: -170, y: 230, b: 55, t: 16, w: 10, art: 'oeff' },
  { name: 'Rathaus', strasse: 'Hauptstraße', nr: '12', x: -110, y: -5, b: 26, t: 16, w: 3, art: 'oeff' },
  { name: 'Supermarkt', strasse: 'Hauptstraße', nr: '45', x: 400, y: 85, b: 50, t: 35, w: 3, art: 'gew' },
  { name: 'Tankstelle', strasse: 'Hauptstraße', nr: '60', x: 720, y: 15, b: 20, t: 12, w: 5, art: 'gew' },
  { name: 'Musterwerk GmbH – Halle 1', strasse: 'Industriestraße', nr: '5', x: 640, y: 210, b: 120, t: 60, w: 3, art: 'gew' },
  { name: 'Musterwerk GmbH – Halle 2', strasse: 'Industriestraße', nr: '5', x: 650, y: 300, b: 80, t: 40, w: 3, art: 'gew' },
  { name: 'Holzbau Beispiel KG', strasse: 'Industriestraße', nr: '12', x: 850, y: 300, b: 70, t: 45, w: 3, art: 'gew' },
  { name: 'Spedition Muster', strasse: 'Industriestraße', nr: '9', x: 870, y: 190, b: 90, t: 40, w: 5, art: 'gew' },
  { name: 'Bahnhof', strasse: 'Bahnhofstraße', nr: '20', x: 90, y: 515, b: 30, t: 12, w: -3, art: 'oeff' },
  { name: 'Mühlenhof – Wohnhaus', strasse: 'Mühlenweg', nr: '7', x: 425, y: -515, b: 16, t: 12, w: 20, art: 'haus' },
  { name: 'Mühlenhof – Scheune', strasse: 'Mühlenweg', nr: '7', x: 490, y: -545, b: 36, t: 18, w: 20, art: 'scheune' },
  { name: 'Mühlenhof – Stall', strasse: 'Mühlenweg', nr: '7', x: 470, y: -590, b: 40, t: 14, w: 20, art: 'scheune' },
  { name: 'Biogasanlage', strasse: 'Biogasweg', nr: '1', x: 930, y: -755, b: 26, t: 26, w: 0, art: 'tank' },
  { name: 'Sportheim', strasse: 'Am Sportplatz', nr: '10', x: 520, y: -282, b: 22, t: 10, w: 0, art: 'oeff' },
  { name: 'Kläranlage', strasse: 'Am Mühlenbach', nr: '30', x: 1270, y: -520, b: 14, t: 10, w: 0, art: 'gew' },
  { name: 'Kindergarten Pusteblume', strasse: 'Rosenweg', nr: '2', x: -570, y: 60, b: 28, t: 14, w: 85, art: 'oeff' },
];

/* ---------- Hilfsfunktionen ---------- */
function abstandSeg(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy;
  let t = l ? ((px - ax) * dx + (py - ay) * dy) / l : 0; t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}
function abstandLinie(px, py, pts) { let m = Infinity; for (let i = 1; i < pts.length; i++) m = Math.min(m, abstandSeg(px, py, ...pts[i - 1], ...pts[i])); return m; }
function laenge(pts) { let s = 0; for (let i = 1; i < pts.length; i++) s += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); return s; }
function punktBei(pts, d) {
  for (let i = 1; i < pts.length; i++) {
    const [ax, ay] = pts[i - 1], [bx, by] = pts[i]; const l = Math.hypot(bx - ax, by - ay);
    if (d <= l || i === pts.length - 1) { const t = l ? Math.min(1, d / l) : 0; return { x: ax + (bx - ax) * t, y: ay + (by - ay) * t, rx: (bx - ax) / (l || 1), ry: (by - ay) / (l || 1) }; }
    d -= l;
  }
}
function inPoly(x, y, pts) { let c = false; for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) { const [xi, yi] = pts[i], [xj, yj] = pts[j]; if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c; } return c; }
function rechteck(x, y, b, t, wGrad) {
  const w = (wGrad * Math.PI) / 180, c = Math.cos(w), s = Math.sin(w);
  return [[-b / 2, -t / 2], [b / 2, -t / 2], [b / 2, t / 2], [-b / 2, t / 2]].map(([u, v]) => [+(x + u * c - v * s).toFixed(1), +(y + u * s + v * c).toFixed(1)]);
}

/* ---------- Gebäude entlang der Straßen ---------- */
const gebaeude = [];   // {pts, art, strasse, nr, x, y, name?}
BESONDERE.forEach((g) => gebaeude.push({ pts: rechteck(g.x, g.y, g.b, g.t, g.w), art: g.art, strasse: g.strasse, nr: g.nr, x: g.x, y: g.y, name: g.name }));
const frei = (x, y, r) => {
  for (const s of STRASSEN) if (abstandLinie(x, y, s.pts) < BREITE[s.art] / 2 + r) return false;
  if (abstandLinie(x, y, WASSER.bach.pts) < 14 + r) return false;
  if (abstandLinie(x, y, BAHN.pts) < 18 + r) return false;
  for (const g of gebaeude) if (Math.hypot(g.x - x, g.y - y) < r + Math.max(8, Math.hypot(...(g.pts[0].map((v, i) => v - [g.x, g.y][i]))))) return false;
  for (const f of FLAECHEN) if (['friedhof', 'sport', 'hof'].includes(f.art) && inPoly(x, y, f.pts)) return false;
  return true;
};
const wohngebiet = FLAECHEN.find((f) => f.art === 'wohngebiet').pts;
const gewerbe = FLAECHEN.filter((f) => f.art === 'gewerbe').map((f) => f.pts);
STRASSEN.forEach((s) => {
  if (!s.haeuser.length) return;
  const L = laenge(s.pts);
  let nrL = 1, nrR = 2;
  const belegt = new Set(BESONDERE.filter((g) => g.strasse === s.name).map((g) => Number(g.nr)));
  const frei2 = (n) => { while (belegt.has(n)) n += 2; return n; };
  [-1, 1].forEach((seite) => {
    let d = 12;
    while (d < L - 8) {
      const p = punktBei(s.pts, d);
      const anteil = d / L;
      const ok = s.haeuser.some(([a, b]) => anteil >= a && anteil <= b);
      const nx = -p.ry * seite, ny = p.rx * seite;   // seite -1 = rechts
      const off = BREITE[s.art] / 2 + zw(11, 15);
      const x = p.x + nx * off, y = p.y + ny * off;
      const b = zw(11, 16), t = zw(9, 13);
      const imOrt = inPoly(x, y, wohngebiet) || s.name === 'Waldstraße' || s.name === 'Hauptstraße';
      if (ok && imOrt && !gewerbe.some((g) => inPoly(x, y, g)) && frei(x, y, 7.5)) {
        const w = (Math.atan2(p.ry, p.rx) * 180) / Math.PI;
        if (seite < 0) nrR = frei2(nrR); else nrL = frei2(nrL);
        const nr = seite < 0 ? nrR : nrL;
        gebaeude.push({ pts: rechteck(x, y, b, t, w), art: 'haus', strasse: s.name, nr: String(nr), x: +x.toFixed(1), y: +y.toFixed(1) });
        if (seite < 0) nrR += 2; else nrL += 2;
        // Nebengebäude (Garage) gelegentlich
        if (rnd() < 0.35) {
          const gx = x + nx * 9 + p.rx * 8, gy = y + ny * 9 + p.ry * 8;
          if (frei(gx, gy, 3.5)) gebaeude.push({ pts: rechteck(gx, gy, 6, 5, w), art: 'neben', x: +gx.toFixed(1), y: +gy.toFixed(1) });
        }
        d += b + zw(10, 16);
      } else {
        d += 8;
      }
    }
  });
});

/* ---------- Adressen ---------- */
const adressen = [];
const schonDa = new Set();
gebaeude.forEach((g) => {
  if (!g.strasse || !g.nr) return;
  const k = `${g.strasse} ${g.nr}`;
  if (schonDa.has(k) && !g.name) return;
  schonDa.add(k);
  adressen.push({ strasse: g.strasse, nr: g.nr, name: g.name || '', ...geo(g.x, g.y) });
});
STRASSEN.forEach((s) => { const p = punktBei(s.pts, laenge(s.pts) / 2); adressen.push({ strasse: s.name, nr: '', name: '', ...geo(p.x, p.y) }); });

/* ---------- Wasserentnahmestellen ---------- */
const wasser = [];
const hydrantTyp = () => (rnd() < 0.75 ? 'underground' : 'pillar');
STRASSEN.filter((s) => s.art !== 'weg').forEach((s) => {
  const L = laenge(s.pts);
  for (let d = 40; d < L; d += zw(85, 120)) {
    const p = punktBei(s.pts, d);
    if (Math.abs(p.x) > 1200 || Math.abs(p.y) > 900) continue;
    if (!inPoly(p.x, p.y, wohngebiet) && !gewerbe.some((g) => inPoly(p.x, p.y, g)) && s.name !== 'Hauptstraße') continue;
    const x = p.x - p.ry * (BREITE[s.art] / 2 + 1.5), y = p.y + p.rx * (BREITE[s.art] / 2 + 1.5);
    if (wasser.some((w) => Math.hypot(w.x - x, w.y - y) < 60)) continue;
    const dm = s.art === 'haupt' || gewerbe.some((g) => inPoly(p.x, p.y, g)) ? (rnd() < 0.5 ? '150' : '100') : (rnd() < 0.6 ? '80' : '100');
    wasser.push({ x, y, typ: 'H', info: { a: hydrantTyp(), d: dm } });
  }
});
wasser.push({ x: -230, y: -560, typ: 'T', info: { n: 'Löschteich Lindenweg', v: '400' } });
wasser.push({ x: -45, y: -470, typ: 'S', info: { n: 'Saugstelle Mühlenbach (Brücke Schulstraße)' } });
wasser.push({ x: 455, y: -520, typ: 'S', info: { n: 'Saugstelle Mühlenhof' } });
wasser.push({ x: 760, y: 140, typ: 'B', info: { n: 'Löschwasserbehälter Musterwerk', v: '200' } });
wasser.push({ x: -150, y: -330, typ: 'B', info: { n: 'Zisterne Grundschule', v: '100' } });
const wasserPts = wasser.map((w) => { const g = geo(w.x, w.y); return [g.lat, g.lon, w.typ, w.info]; });

/* ---------- Ausgabe ---------- */
const out = path.join(__dirname, 'daten');
fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'welt.json'), JSON.stringify({ MITTE, BEREICH, KERN, ORT, STRASSEN: STRASSEN.map((s) => ({ ...s, breite: BREITE[s.art] })), FLAECHEN, WASSER, BAHN, gebaeude }));
fs.writeFileSync(path.join(out, 'adressen.json'), JSON.stringify({ ort: ORT, plz: PLZ, adressen }, null, 0));
const ecke = (x, y) => geo(x, y);
const kern0 = ecke(KERN.x0, KERN.y0), kern1 = ecke(KERN.x1, KERN.y1);
fs.writeFileSync(path.join(out, 'demo-karte.json'), JSON.stringify({
  name: ORT, mitte: MITTE,
  kern: { s: kern0.lat, w: kern0.lon, n: kern1.lat, o: kern1.lon },
  zMin: 15, zMax: 19,
}, null, 1));
fs.writeFileSync(path.join(out, 'wasser.json'), JSON.stringify({ stand: Date.parse('2026-01-01T00:00:00Z'), quelle: 'Demo (fiktiv)', mitte: { ...MITTE, name: ORT }, radiusKm: 2, anzahl: wasserPts.length, pts: wasserPts }));
// Hilfe für den Datenstand-Generator: Punkte in Metern abrufen
fs.writeFileSync(path.join(out, 'orte.json'), JSON.stringify(Object.fromEntries(BESONDERE.map((g) => [g.name, { ...geo(g.x, g.y), strasse: g.strasse, nr: g.nr }])), null, 1));
console.log(`Gebäude: ${gebaeude.length}, Adressen: ${adressen.length}, Wasserentnahmestellen: ${wasserPts.length}`);
module.exports = { geo };
