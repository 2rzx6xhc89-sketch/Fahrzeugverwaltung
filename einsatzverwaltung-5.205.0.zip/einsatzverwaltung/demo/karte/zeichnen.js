/*
 * Zeichnet die fiktive Demo-Karte (welt.json) als Kartenkacheln.
 * Stile: „karte“ (Straßenkarte) und „luftbild“ (gezeichnetes Luftbild, kein echtes Foto).
 * Aufruf: node zeichnen.js <ausgabeOrdner>   (braucht Playwright/Chromium und python3 mit Pillow)
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const pw = require(process.env.PLAYWRIGHT || '/opt/node22/lib/node_modules/playwright');

const W = JSON.parse(fs.readFileSync(path.join(__dirname, 'daten', 'welt.json'), 'utf8'));
const AUS = path.resolve(process.argv[2] || path.join(__dirname, 'kacheln'));
const ZOOMS = (process.env.ZOOMS || '13,14,15,16,17,18,19').split(',').map(Number);
const STILE = (process.env.STILE || 'karte,luftbild').split(',');
const TILE = 256, CHUNK = 2048;

const { lat: LAT0, lon: LON0 } = W.MITTE;
const wx = (lon, z) => ((lon + 180) / 360) * TILE * 2 ** z;
const wy = (lat, z) => { const r = (lat * Math.PI) / 180; return ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * TILE * 2 ** z; };
const geo = (x, y) => ({ lat: LAT0 + y / 111320, lon: LON0 + x / (111320 * Math.cos((LAT0 * Math.PI) / 180)) });
const mpp = (z) => (156543.03392 * Math.cos((LAT0 * Math.PI) / 180)) / 2 ** z;
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');

let seed = 77;
const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };

function inPoly(x, y, pts) { let c = false; for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) { const [xi, yi] = pts[i], [xj, yj] = pts[j]; if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c; } return c; }
function abstandSeg(px, py, ax, ay, bx, by) { const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; let t = l ? ((px - ax) * dx + (py - ay) * dy) / l : 0; t = Math.max(0, Math.min(1, t)); return Math.hypot(px - (ax + t * dx), py - (ay + t * dy)); }
function abstandLinie(px, py, pts) { let m = Infinity; for (let i = 1; i < pts.length; i++) m = Math.min(m, abstandSeg(px, py, ...pts[i - 1], ...pts[i])); return m; }

/* Feldstücke und Bäume (einmal, für alle Zoomstufen gleich) */
const wohn = W.FLAECHEN.find((f) => f.art === 'wohngebiet').pts;
const sperr = W.FLAECHEN.filter((f) => ['wald', 'wohngebiet', 'gewerbe', 'friedhof', 'sport', 'hof'].includes(f.art)).map((f) => f.pts);
const FELD_FARBEN = ['#8C9A5B', '#A3A56A', '#B9AD7A', '#7F8F4E', '#C4B58A', '#96A35F', '#A99A6B', '#6F8447', '#B5A374'];
const felder = [];
for (let gx = W.BEREICH.x0; gx < W.BEREICH.x1; gx += 180) for (let gy = W.BEREICH.y0; gy < W.BEREICH.y1; gy += 140) {
  const pts = [[gx, gy], [gx + 180, gy], [gx + 180, gy + 140], [gx, gy + 140]].map(([x, y]) => [x + (rnd() - 0.5) * 30, y + (rnd() - 0.5) * 30]);
  felder.push({ pts, farbe: FELD_FARBEN[Math.floor(rnd() * FELD_FARBEN.length)], w: Math.floor(rnd() * 4) * 45 });
}
const baeume = [];
for (let i = 0; i < 9000 && baeume.length < 2600; i++) {
  const x = W.BEREICH.x0 + rnd() * (W.BEREICH.x1 - W.BEREICH.x0), y = W.BEREICH.y0 + rnd() * (W.BEREICH.y1 - W.BEREICH.y0);
  const imOrt = inPoly(x, y, wohn) || W.FLAECHEN.some((f) => f.art === 'friedhof' && inPoly(x, y, f.pts));
  const amBach = abstandLinie(x, y, W.WASSER.bach.pts) < 25 && abstandLinie(x, y, W.WASSER.bach.pts) > 7;
  if (!imOrt && !amBach) continue;
  if (W.STRASSEN.some((s) => abstandLinie(x, y, s.pts) < s.breite / 2 + 3)) continue;
  if (W.gebaeude.some((g) => Math.hypot(g.x - x, g.y - y) < 10)) continue;
  baeume.push([x, y, 2.5 + rnd() * 3.5]);
}
const DACH = ['#9C4A3A', '#8A3B30', '#6E6A66', '#A65C45', '#5A5552', '#7B4235', '#B0624A'];
W.gebaeude.forEach((g, i) => { g.dach = g.art === 'gew' || g.art === 'tank' ? '#B4B8BA' : g.art === 'scheune' ? '#7A6A5C' : DACH[(i * 7 + 3) % DACH.length]; });

function svgFuer(stil, z) {
  const m = mpp(z);
  // Ursprung je Zoomstufe abziehen: SVG rechnet mit 32-Bit-Gleitkomma, Weltpixel (~1e7) wären zu ungenau
  const k0 = kachelBereich(z), OX = k0.tx0 * TILE, OY = k0.ty0 * TILE;
  const P = (x, y) => { const g = geo(x, y); return [wx(g.lon, z) - OX, wy(g.lat, z) - OY]; };
  const d = (pts, zu) => pts.map(([x, y], i) => { const [a, b] = P(x, y); return `${i ? 'L' : 'M'}${a.toFixed(1)} ${b.toFixed(1)}`; }).join('') + (zu ? 'Z' : '');
  const px = (meter, min) => Math.max(min, meter / m);
  const o = [];
  const karte = stil === 'karte';
  // Flächen
  const F = karte
    ? { acker: '#EEF0D5', acker2: '#F3EAD0', wiese: '#D4EDB8', wald: '#ADD19E', wohngebiet: '#E3E0DC', gewerbe: '#EBDBE8', friedhof: '#AACBAF', sport: '#9FDCC0', hof: '#F2DFC4' }
    : { acker: 'none', acker2: 'none', wiese: '#7E9C55', wald: '#34502C', wohngebiet: '#6E8A4D', gewerbe: '#8E8E86', friedhof: '#4F6E3F', sport: '#5E9A48', hof: '#8D8270' };
  if (!karte) felder.forEach((f) => o.push(`<path d="${d(f.pts, true)}" fill="${f.farbe}"/>`));
  else o.push(`<path d="${d(W.FLAECHEN[0].pts, true)}" fill="${F.acker}"/>`);
  W.FLAECHEN.slice(1).forEach((f) => { if (F[f.art] !== 'none') o.push(`<path d="${d(f.pts, true)}" fill="${F[f.art]}"${karte && f.art === 'wald' && z >= 15 ? ' class="wald"' : ''}/>`); });
  if (karte && z >= 15) W.FLAECHEN.filter((f) => f.art === 'wald').forEach((f) => o.push(`<path d="${d(f.pts, true)}" fill="url(#baum)"/>`));
  if (karte && z >= 16) { const sp = W.FLAECHEN.find((f) => f.art === 'sport'); const [a, b] = P(430, -310), [c, e] = P(610, -410); o.push(`<rect x="${a}" y="${b}" width="${c - a}" height="${e - b}" fill="#88CFA7" stroke="#fff" stroke-width="${px(1, 1)}"/>`); void sp; }
  // Wasser
  const bachFarbe = karte ? '#AAD3DF' : '#3E5A57';
  o.push(`<path d="${d(W.WASSER.bach.pts)}" fill="none" stroke="${bachFarbe}" stroke-width="${px(W.WASSER.bach.breite, 1.5)}" stroke-linecap="round" stroke-linejoin="round"/>`);
  W.WASSER.teiche.forEach((t) => { const [a, b] = P(t.cx, t.cy); o.push(`<circle cx="${a}" cy="${b}" r="${px(t.r, 1)}" fill="${bachFarbe}"/>`); });
  // Bäume im Luftbild
  if (!karte && z >= 15) baeume.forEach(([x, y, r]) => { const [a, b] = P(x, y); o.push(`<circle cx="${a.toFixed(1)}" cy="${b.toFixed(1)}" r="${px(r, 0.8).toFixed(1)}" fill="#2E4A26" opacity=".85"/>`); });
  // Straßen
  const reihen = ['weg', 'wohn', 'str', 'haupt'];
  const fuellung = karte ? { weg: '#A0723C', wohn: '#FFFFFF', str: '#FFFFFF', haupt: '#F9E2A0' } : { weg: '#A3957A', wohn: '#7A7A75', str: '#6E6E69', haupt: '#64645F' };
  const rand = karte ? { wohn: '#BDBDBD', str: '#ABABAB', haupt: '#C79E3A' } : { wohn: '#5D5D58', str: '#55554F', haupt: '#4D4D48' };
  const minB = { weg: 1, wohn: z >= 15 ? 2 : 1, str: z >= 14 ? 2.5 : 1.5, haupt: z >= 14 ? 3.5 : 2.5 };
  if (z >= 14 || !karte) reihen.filter((a) => a !== 'weg').forEach((art) => W.STRASSEN.filter((s) => s.art === art).forEach((s) => o.push(`<path d="${d(s.pts)}" fill="none" stroke="${rand[art]}" stroke-width="${(px(s.breite, minB[art]) + (z >= 16 ? 2 : 1.4)).toFixed(1)}" stroke-linecap="round" stroke-linejoin="round"/>`)));
  reihen.forEach((art) => W.STRASSEN.filter((s) => s.art === art).forEach((s) => o.push(`<path d="${d(s.pts)}" fill="none" stroke="${fuellung[art]}" stroke-width="${px(s.breite, minB[art]).toFixed(1)}" stroke-linecap="round" stroke-linejoin="round"${art === 'weg' && karte ? ` stroke-dasharray="${z >= 16 ? '6 3' : '3 2'}"` : ''}/>`)));
  // Bahn
  o.push(`<path d="${d(W.BAHN.pts)}" fill="none" stroke="${karte ? '#8C8C8C' : '#5E5650'}" stroke-width="${px(4, 2.5)}"/>`);
  if (karte) o.push(`<path d="${d(W.BAHN.pts)}" fill="none" stroke="#fff" stroke-width="${px(2, 1.2)}" stroke-dasharray="${z >= 16 ? '10 10' : '6 6'}"/>`);
  // Gebäude
  if (z >= 15) W.gebaeude.forEach((g) => {
    const fill = karte ? ({ fw: '#E9A49E', kirche: '#C7BBAE', oeff: '#D8C6B4', gew: '#D2C4CF', scheune: '#D6C9B5', tank: '#C9C2C9' }[g.art] || '#D9D0C9') : g.dach;
    if (g.art === 'tank') { const [a, b] = P(g.x, g.y); o.push(`<circle cx="${a}" cy="${b}" r="${px(12, 1.5)}" fill="${karte ? fill : '#3F4A3A'}" stroke="${karte ? '#A79CA6' : '#2A3127'}" stroke-width="${z >= 17 ? 1 : 0.5}"/>`); return; }
    o.push(`<path d="${d(g.pts, true)}" fill="${fill}" stroke="${karte ? '#B9AA9E' : 'rgba(0,0,0,.35)'}" stroke-width="${z >= 17 ? 1 : 0.5}"/>`);
    if (!karte && z >= 17 && g.art !== 'gew') { const [a, b] = P(...g.pts[0]), [c, e] = P(...g.pts[2]); void c; void e; const [m1, m2] = P(...g.pts[1]), [m3, m4] = P(...g.pts[3]); o.push(`<path d="M${(a + m1) / 2} ${(b + m2) / 2}L${(m3 + c) / 2} ${(m4 + e) / 2}" stroke="rgba(255,255,255,.18)" stroke-width="${z >= 18 ? 1.5 : 1}"/>`); }
  });
  // Rauschen für das Luftbild
  if (!karte) o.push(`<rect id="rausch" x="0" y="0" width="1" height="1" filter="url(#n${z})" opacity=".22" style="mix-blend-mode:multiply"/>`);
  // Beschriftung
  const lbl = [];
  if (karte) {
    const halo = 'paint-order="stroke" stroke="#fff" stroke-width="3" stroke-linejoin="round"';
    if (z <= 15) { const [a, b] = P(-150, 120); lbl.push(`<text x="${a}" y="${b}" font-size="${z === 13 ? 13 : z === 14 ? 16 : 20}" font-weight="bold" fill="#333" text-anchor="middle" ${halo}>Musterhausen</text>`); }
    if (z >= 14 && z <= 17) W.FLAECHEN.filter((f) => f.art === 'wald' && f.name).forEach((f) => { const cx = f.pts.reduce((s, p) => s + p[0], 0) / f.pts.length, cy = f.pts.reduce((s, p) => s + p[1], 0) / f.pts.length; const [a, b] = P(cx, cy); lbl.push(`<text x="${a}" y="${b}" font-size="${z >= 16 ? 13 : 11}" font-style="italic" fill="#2F6B2A" text-anchor="middle" ${halo}>${esc(f.name)}</text>`); });
    if (z >= 16) {
      const fs = z >= 18 ? 13 : z === 17 ? 12 : 11;
      W.STRASSEN.forEach((s, i) => {
        if (s.ring) { const [a, b] = P(s.pts[0][0] - 115, s.pts[0][1]); lbl.push(`<text x="${a}" y="${b}" font-size="${fs}" fill="#333" text-anchor="middle" ${halo}>${esc(s.name)}</text>`); return; }
        // längsten Abschnitt nehmen, Text immer von links nach rechts
        let best = null, bl = 0;
        for (let k = 1; k < s.pts.length; k++) { const l = Math.hypot(s.pts[k][0] - s.pts[k - 1][0], s.pts[k][1] - s.pts[k - 1][1]); if (l > bl) { bl = l; best = [s.pts[k - 1], s.pts[k]]; } }
        if (bl / m < s.name.length * fs * 0.62 + 20) return;
        let [p1, p2] = best; const [a1] = P(...p1), [a2] = P(...p2); if (a2 < a1) [p1, p2] = [p2, p1];
        const wiederholen = z >= 18 ? Math.max(1, Math.floor(bl / m / (s.name.length * fs * 0.62 * 4))) : 1;
        lbl.push(`<path id="s${i}_${z}" d="${d([p1, p2])}" fill="none"/>`);
        for (let r = 0; r < wiederholen; r++) lbl.push(`<text font-size="${fs}" fill="#333" dy="${fs * 0.35}" ${halo}><textPath href="#s${i}_${z}" startOffset="${((r + 0.5) / wiederholen) * 100}%" text-anchor="middle">${esc(s.name)}</textPath></text>`);
      });
      const [b1, b2] = [W.WASSER.bach.pts[5], W.WASSER.bach.pts[6]];
      lbl.push(`<path id="bach_${z}" d="${d([b1, b2])}" fill="none"/><text font-size="${fs}" font-style="italic" fill="#3A6EA5" dy="-${fs * 0.6}" ${halo}><textPath href="#bach_${z}" startOffset="50%" text-anchor="middle">Mühlenbach</textPath></text>`);
    }
    if (z >= 17) W.gebaeude.filter((g) => g.name).forEach((g) => {
      if (/–/.test(g.name) && !/Scheune|Halle 1/.test(g.name)) return;
      const [a, b] = P(g.x, g.y);
      const name = g.name.replace(/ – .*/, '');
      lbl.push(`<text x="${a}" y="${b + 4}" font-size="${z >= 18 ? 12 : 10}" font-style="italic" fill="${g.art === 'fw' ? '#B3121F' : '#6B4D36'}" text-anchor="middle" font-weight="${g.art === 'fw' ? 'bold' : 'normal'}" ${halo}>${esc(name)}</text>`);
    });
    if (z >= 17) W.FLAECHEN.filter((f) => ['friedhof', 'sport'].includes(f.art) && f.name).forEach((f) => { const cx = f.pts.reduce((a, p) => a + p[0], 0) / f.pts.length, cy = f.pts.reduce((a, p) => a + p[1], 0) / f.pts.length; const [a, b] = P(cx, cy); lbl.push(`<text x="${a}" y="${b}" font-size="${z >= 18 ? 12 : 10}" font-style="italic" fill="#2F6B2A" text-anchor="middle" ${halo}>${f.art === 'friedhof' ? '✝ ' : ''}${esc(f.name)}</text>`); });
    if (z >= 18) W.gebaeude.filter((g) => g.art === 'haus' && g.nr && !g.name).forEach((g) => { const [a, b] = P(g.x, g.y); lbl.push(`<text x="${a}" y="${b + 3}" font-size="${z >= 19 ? 10 : 8.5}" fill="#7A6F66" text-anchor="middle">${esc(g.nr)}</text>`); });
  }
  const freq = Math.min(1.5, mpp(z) / 3).toFixed(4);
  const defs = `<defs>
    <pattern id="baum" patternUnits="userSpaceOnUse" width="24" height="24"><circle cx="6" cy="6" r="2.2" fill="#8DBF7C"/><circle cx="18" cy="17" r="2.2" fill="#8DBF7C"/></pattern>
    <filter id="n${z}" filterUnits="userSpaceOnUse" x="-1e7" y="-1e7" width="3e7" height="3e7" color-interpolation-filters="sRGB"><feTurbulence type="fractalNoise" baseFrequency="${freq}" numOctaves="3" seed="4"/><feColorMatrix type="saturate" values="0"/></filter>
  </defs>`;
  return `${defs}<g>${o.join('')}</g><g font-family="DejaVu Sans, Arial, sans-serif">${lbl.join('')}</g>`;
}

function kachelBereich(z) {
  const B = z >= 19 ? { x0: -1150, x1: 1150, y0: -900, y1: 900 } : W.BEREICH;
  const a = geo(B.x0, B.y1), b = geo(B.x1, B.y0);
  return { tx0: Math.floor(wx(a.lon, z) / TILE), tx1: Math.floor(wx(b.lon, z) / TILE), ty0: Math.floor(wy(a.lat, z) / TILE), ty1: Math.floor(wy(b.lat, z) / TILE) };
}

(async () => {
  const tmp = path.join(AUS, '_teile');
  fs.mkdirSync(tmp, { recursive: true });
  const b = await pw.chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: CHUNK, height: CHUNK } });
  const liste = [];
  for (const stil of STILE) for (const z of ZOOMS) {
    const k = kachelBereich(z);
    const bg = stil === 'karte' ? '#EEF0D5' : '#9A9F68';
    await p.setContent(`<!doctype html><html><body style="margin:0;background:${bg}"><svg id="s" xmlns="http://www.w3.org/2000/svg" width="${CHUNK}" height="${CHUNK}" style="display:block">${svgFuer(stil, z)}</svg></body></html>`);
    for (let cx = k.tx0 * TILE; cx <= k.tx1 * TILE; cx += CHUNK) for (let cy = k.ty0 * TILE; cy <= k.ty1 * TILE; cy += CHUNK) {
      const vx = cx - k.tx0 * TILE, vy = cy - k.ty0 * TILE;
      await p.evaluate(([x, y, n]) => { const s = document.getElementById('s'); s.setAttribute('viewBox', `${x} ${y} ${n} ${n}`); const r = document.getElementById('rausch'); if (r) { r.setAttribute('x', x); r.setAttribute('y', y); r.setAttribute('width', n); r.setAttribute('height', n); } }, [vx, vy, CHUNK]);
      const f = path.join(tmp, `${stil}_${z}_${cx / TILE}_${cy / TILE}.png`);
      await p.screenshot({ path: f });
      liste.push({ f, stil, z, tx: cx / TILE, ty: cy / TILE, ...k });
    }
    console.log(stil, z, `${k.tx1 - k.tx0 + 1}×${k.ty1 - k.ty0 + 1} Kacheln`);
  }
  await b.close();
  fs.writeFileSync(path.join(tmp, 'liste.json'), JSON.stringify(liste));
  execFileSync('python3', [path.join(__dirname, 'zerschneiden.py'), path.join(tmp, 'liste.json'), AUS], { stdio: 'inherit' });
  fs.rmSync(tmp, { recursive: true, force: true });
})().catch((e) => { console.error(e); process.exit(1); });
