"""Zerlegt die gezeichneten Teilbilder in 256-px-Kacheln (z/x/y.png) und verkleinert sie."""
import json, os, sys
from PIL import Image, ImageDraw

liste = json.load(open(sys.argv[1]))
aus = sys.argv[2]
n = 0
for t in liste:
    im = Image.open(t['f']).convert('RGB')
    w, h = im.size
    for i in range(w // 256):
        for j in range(h // 256):
            x, y = t['tx'] + i, t['ty'] + j
            if x < t['tx0'] or x > t['tx1'] or y < t['ty0'] or y > t['ty1']:
                continue
            k = im.crop((i * 256, j * 256, i * 256 + 256, j * 256 + 256))
            ordner = os.path.join(aus, 'tiles' if t['stil'] == 'karte' else 'luftbild', str(t['z']), str(x))
            os.makedirs(ordner, exist_ok=True)
            if t['stil'] == 'karte':
                k.quantize(colors=256, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE).save(os.path.join(ordner, f"{y}.png"), optimize=True)
            else:
                k.save(os.path.join(ordner, f"{y}.jpg"), quality=62, optimize=True, progressive=True)
            n += 1

# Kachel außerhalb des Demo-Gebiets
leer = Image.new('RGB', (256, 256), (226, 228, 224))
d = ImageDraw.Draw(leer)
for s in range(-256, 512, 24):
    d.line([(s, 0), (s + 256, 256)], fill=(214, 217, 212), width=6)
try:
    from PIL import ImageFont
    fnt = ImageFont.truetype('DejaVuSans.ttf', 13)
except Exception:
    fnt = None
d.multiline_text((128, 128), 'außerhalb\nder Demo-Karte', fill=(140, 144, 140), font=fnt, anchor='mm' if fnt else None, align='center', spacing=4)
leer.quantize(colors=16).save(os.path.join(aus, 'leer.png'), optimize=True)
print(f'{n} Kacheln geschrieben')
