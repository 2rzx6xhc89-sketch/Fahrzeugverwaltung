/*
 * Erzeugt den Anfangs-Datenstand der Demo-Version (erfundene Einsätze, Benutzer, Übungs-Drehbücher).
 * Läuft gegen einen Demo-Server, der mit  --require demo/uhr-preload.js  und UHR_DATEI gestartet wurde.
 *   UHR_DATEI=… EV=http://127.0.0.1:18180 node demo/startdaten.js
 * Alle Namen, Rufnummern und Adressen sind erfunden.
 */
const fs = require('fs');
const path = require('path');
const WS = require('ws');

const EV = process.env.EV || 'http://127.0.0.1:18180';
const PORT = Number(new URL(EV).port);
const UHR = process.env.UHR_DATEI;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const FZ = require('./fahrzeuge');
const K = JSON.parse(fs.readFileSync(path.join(__dirname, 'karte', 'daten', 'demo-karte.json'), 'utf8'));
const ORTE = JSON.parse(fs.readFileSync(path.join(__dirname, 'karte', 'daten', 'orte.json'), 'utf8'));
const M = K.mitte;
const geo = (x, y) => [+(M.lat + y / 111320).toFixed(6), +(M.lon + x / (111320 * Math.cos((M.lat * Math.PI) / 180))).toFixed(6)];
const off = (p, dn, de) => [+(p[0] + dn / 111320).toFixed(6), +(p[1] + de / (111320 * Math.cos((p[0] * Math.PI) / 180))).toFixed(6)];

/* Uhr */
let versatz = 0;
function uhrSetzen(ms) { versatz = ms; fs.writeFileSync(UHR, String(Math.round(ms))); }
async function zeitpunkt(text) { uhrSetzen(new Date(text).getTime() - Date.now()); await sleep(60); }
const jetzt = () => Date.now() + versatz;
async function weiter(min) { uhrSetzen(versatz + min * 60000); await sleep(40); }

let CK = '';
async function api(p, body, port) {
  const r = await fetch(`http://127.0.0.1:${port || PORT}${p}`, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', Cookie: CK }, body: body ? JSON.stringify(body) : undefined });
  const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch (e) { j = t; }
  if (!r.ok) throw new Error(`${p}: ${r.status} ${t.slice(0, 200)}`);
  return j;
}
async function login(name, pin) {
  const r = await fetch(`${EV}/api/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(name.startsWith('u_') ? { userId: name, pin } : { username: name, pin }) });
  if (!r.ok) throw new Error(`Anmeldung ${name}: ${r.status}`);
  CK = (r.headers.get('set-cookie') || '').split(';')[0];
}
const bestaetigen = (pin) => api('/api/auth/bestaetigen', { pin: pin || '1234' });
function verbinden() {
  return new Promise((res) => {
    const w = new WS(`ws://127.0.0.1:${PORT}/ws`, { headers: { Cookie: CK } });
    let n = 0; const pend = {}; let data = {};
    w.on('message', (m) => {
      const d = JSON.parse(m);
      if (d.type === 'init') { data = d.data; res({ w, get: (k) => data[k], set: (k, v) => { data[k] = v; w.send(JSON.stringify({ type: 'set', key: k, value: v })); }, op: (o, a) => new Promise((r, j) => { const id = ++n; pend[id] = { r, j }; w.send(JSON.stringify({ type: 'op', id, op: o, args: a })); }) }); }
      if (d.type === 'update') data[d.key] = d.value;
      if (d.type === 'opResult') { const p = pend[d.id]; delete pend[d.id]; if (p) (d.ok ? p.r(d.data) : p.j(d)); }
    });
  });
}

(async () => {
  await login('u_admin', '1234');
  await bestaetigen();
  let c = await verbinden();
  const op = async (o, a) => { try { return await c.op(o, a); } catch (e) { console.log('FEHLER', o, JSON.stringify(a).slice(0, 140), JSON.stringify(e).slice(0, 200)); return null; } };

  /* Grunddaten */
  c.set('opta3.vehicles', FZ);
  c.set('opta3.settings', { ...(c.get('opta3.settings') || {}), city: 'Musterstadt', heimat: { name: 'Musterhausen', lat: M.lat, lon: M.lon }, stationEquipHidden: [], stationCategoryHidden: [] });
  await sleep(400);
  await op('benutzer.speichern', { id: 'u_admin', username: 'Admin', role: 'admin' });   // PIN bleibt 1234 (Standard)
  await op('benutzer.speichern', { username: 'Einsatzleitung', role: 'einsatzleiter', pin: '222222' });   // ab 5.131: PIN mindestens 6 Zeichen
  await op('benutzer.speichern', { username: 'Betrachter', role: 'betrachter', pin: '333333' });
  await sleep(300);

  const EO = [ORTE['Mühlenhof – Scheune'].lat, ORTE['Mühlenhof – Scheune'].lon];
  const FWH = [ORTE.Feuerwehrhaus.lat, ORTE.Feuerwehrhaus.lon];
  /* Feuerwehrhäuser der erfundenen Wehren (ab 4.1) */
  const fh = (id, ortswehr, p, adresse) => ({ id, ortswehr, name: 'Feuerwehrhaus ' + ortswehr, adresse, lat: p[0], lon: p[1], quelle: 'Demo', geprueft: true });
  await api('/api/standorte', { regeln: { ausrueckMin: 5, kmh: 55, umweg: 1.35 }, liste: [
    fh('fh1', 'Musterhausen', FWH, 'Hauptstraße 30, 12345 Musterhausen'),
    fh('fh2', 'Beispieldorf', off(FWH, 3200, -2600), 'Dorfstraße 4, 12346 Beispieldorf'),
    fh('fh3', 'Lindenau', off(FWH, -2800, 3400), 'Lindenweg 1, 12347 Lindenau'),
    fh('fh4', 'Neudorf', off(FWH, 4100, 2900), 'Am Teich 2, 12348 Neudorf'),
    fh('fh5', 'Beispielstadt', off(FWH, -6500, -5200), 'Wachenweg 10, 12350 Beispielstadt'),
  ] }).catch((e) => console.log('FEHLER standorte', e.message));

  /* Objekte mit Einsatzunterlagen (erfunden) – die Fahrzeug-App der zuständigen Ortsfeuerwehr bekommt sie (ab 3.37) */
  await op('objekt.speichern', { name: 'Mühlenhof Kornfeld', art: 'Landwirtschaft', adresse: 'Mühlenweg 7, 12345 Musterhausen', lat: EO[0], lon: EO[1], ortswehr: 'Musterhausen',
    merkmale: ['Gefahrstoffe', 'Tiere', 'Löschwasser vor Ort'], hinweise: 'Zufahrt über Mühlenweg, Hoftor meist offen.\nIm Anbau der Scheune: Propangasflaschen (bis zu 6 Stück).\nRinderstall mit ca. 40 Tieren, Weide hinter dem Stall.\nLöschwasser: Hydrant H 100 am Mühlenweg, Saugstelle Mühlenbach am Hof.',
    kontakte: 'Betreiber: Bernd Kornfeld, Tel. 01234 567890', stichworte: 'Bauernhof Scheune' });
  const MW = ORTE['Musterwerk GmbH – Halle 1'];
  await op('objekt.speichern', { name: 'Musterwerk GmbH', art: 'Industrie / Gewerbe', adresse: 'Industriestraße 5, 12345 Musterhausen', lat: MW.lat, lon: MW.lon, ortswehr: 'Musterhausen',
    hinweise: 'Brandmeldeanlage, Feuerwehrschlüsseldepot am Haupttor (Industriestraße).\nHalle 1: Lackiererei mit Lösemittellager (ca. 2.000 l).\nLöschwasserbehälter 200 m³ an der Nordseite.\nSammelplatz Mitarbeitende: Parkplatz Süd.',
    kontakte: 'Werkleitung: Dr. Erika Beispiel, Tel. 01234 111222\nHaustechnik (24 h): Tel. 01234 111333', stichworte: 'Firma Lackiererei BMA', merkmale: ['Feuerwehrplan', 'BMA', 'Schlüsseldepot', 'Laufkarten', 'Gefahrstoffe', 'Sprinkler'] });
  /* ab 5.64: weitere Objekte mit Symbolen und Merkmalen, Ansprechpartner mit Kategorien (alles erfunden) */
  for (const [name, art, dx, dy, merkmale, hinweise] of [
    ['Grundschule Musterhausen', 'Schule / Kita', -420, 260, ['Feuerwehrplan', 'BMA', 'Personen mit Hilfebedarf'], 'ca. 180 Kinder, Sammelplatz Schulhof Nord.'],
    ['Seniorenheim Lindenhof', 'Pflegeheim / Krankenhaus', 380, 420, ['Feuerwehrplan', 'BMA', 'Laufkarten', 'Personen mit Hilfebedarf'], '62 Bewohner, davon 20 bettlägerig. Nachtbesetzung 3 Pflegekräfte.'],
    ['Biogasanlage Feldmark', 'Landwirtschaft', 900, -650, ['Gefahrstoffe', 'Feuerwehrzufahrt'], 'Gärbehälter 2× 2.500 m³, Fackel an der Ostseite. Explosionsgefahr!'],
    ['Mehrzweckhalle', 'Versammlungsstätte', -150, -380, ['BMA', 'PV-Anlage'], 'Bis 600 Personen bei Veranstaltungen.'],
    ['Tankstelle Hauptstraße', 'Tankstelle / Energie', 220, -120, ['Gefahrstoffe'], 'Not-Aus an der Kasse, Erdtanks 3× 40.000 l.'],
  ]) { const [la, lo] = geo(dx, dy); await op('objekt.speichern', { name, art, adresse: `${name}, 12345 Musterhausen`, lat: la, lon: lo, ortswehr: 'Musterhausen', merkmale, hinweise, kontakte: '', stichworte: '' }); }
  for (const k of [
    { kategorie: 'geraet', funktion: 'Bauunternehmen', name: 'Tiefbau Albers', telefon: '01234 700100', stichworte: 'Bagger, Radlader, Tieflader', ort: 'Musterhausen', rund: true },
    { kategorie: 'geraet', funktion: 'Landwirt', name: 'Hof Ehlers', telefon: '01234 700200', stichworte: 'Gülle-/Wasserfass, Radlader', ort: 'Nordheim' },
    { kategorie: 'dienst', funktion: 'Abschleppdienst', name: 'Autohaus Kröger', telefon: '01234 700300', stichworte: 'Abschleppdienst, Kran', ort: 'Musterhausen', rund: true },
    { kategorie: 'dienst', funktion: 'Baumpflege', name: 'Grünservice Petersen', telefon: '01234 700400', stichworte: 'Gärtner/Baumpflege, Hubsteiger', ort: 'Südfeld' },
    { kategorie: 'person', funktion: 'Tierarzt', name: 'Dr. Anke Lüders', telefon: '01234 700500', stichworte: 'Tierarzt', ort: 'Musterhausen', rund: true },
    { kategorie: 'person', funktion: 'Notfallseelsorge', name: 'Pastorin Gesa Martens', telefon: '01234 700600', stichworte: 'Notfallseelsorge', rund: true },
    { kategorie: 'behoerde', funktion: 'Energieversorger (Strom)', name: 'Stadtwerke Musterhausen', telefon: '0800 1234567', stichworte: 'Strom abschalten', rund: true },
    { kategorie: 'behoerde', funktion: 'Bauhof', name: 'Bauhof Musterhausen', telefon: '01234 700800', stichworte: 'Sandsäcke, Absperrmaterial', ort: 'Musterhausen' },
  ]) await op('kontakt.speichern', k).catch((e) => console.log('FEHLER kontakt', e.message));

  /* ---------- Einsatz 1: Scheunenbrand Mühlenhof ---------- */
  await zeitpunkt('2026-09-12T14:05:00+02:00'); await bestaetigen();
  const E1 = await op('einsatz.neu', { stichwort: 'B3', meldebild: 'Brand landwirtschaftliches Anwesen (Scheune)', adresse: 'Mühlenweg 7, 12345 Musterhausen', lat: EO[0], lon: EO[1], einsatzleiter: 'OrtsBM Lehmann', meldender: 'Anwohnerin über Leitstelle', bereitstellung: 'Parkplatz Sportplatz, Am Sportplatz', alarmzeit: jetzt() });
  const F1 = ['d10', 'd11', 'd12', 'd14', 'd15', 'd20', 'd21', 'd30'];
  for (const vid of F1) await op('fz.status', { vid, st: 'A', einsatzId: E1.id });
  await weiter(2); for (const vid of ['d11', 'd10']) await op('fz.status', { vid, st: '3', einsatzId: E1.id });
  await weiter(1); for (const vid of ['d12', 'd14', 'd15']) await op('fz.status', { vid, st: '3', einsatzId: E1.id });
  await weiter(2); for (const vid of ['d20', 'd21', 'd30']) await op('fz.status', { vid, st: '3', einsatzId: E1.id });
  await weiter(1); for (const vid of ['d11', 'd10']) await op('fz.status', { vid, st: '4', einsatzId: E1.id });
  await op('tb.neu', { einsatzId: E1.id, richtung: 'Eingang', von: '77-11-40', an: 'ELW', text: 'Lage beim Eintreffen: Scheune in Vollbrand, Übergriff auf den angebauten Stall droht. Bewohner nach eigenen Angaben alle draußen, Tiere auf der Weide.' });
  await weiter(4); for (const vid of ['d12', 'd14', 'd15']) await op('fz.status', { vid, st: '4', einsatzId: E1.id });
  await op('lage', { einsatzId: E1.id, text: 'Ich sehe: Scheune in Vollbrand, starke Rauchentwicklung Richtung Nordost, Stall angebaut. Ich mache: Riegelstellung zum Stall, Brandbekämpfung von außen, Wasserversorgung über Hydranten und Mühlenbach. Ich brauche: Drehleiter, weiteres Tanklöschfahrzeug.', von: 'Einsatzleitung', an: 'Leitstelle' });
  await weiter(1); await op('fz.status', { vid: 'd20', st: '4', einsatzId: E1.id });
  const anf = await op('anforderung', { einsatzId: E1.id, was: '78-11-30', vid: 'd50', anzahl: 1, grund: 'Brandbekämpfung von oben, Schutz Stall', ziel: 'Mühlenweg 7', von: 'ELW', an: 'Leitstelle' });
  await op('fz.status', { vid: 'd50', st: 'A', einsatzId: E1.id });
  await weiter(2); for (const vid of ['d21', 'd30']) await op('fz.status', { vid, st: '4', einsatzId: E1.id });
  await weiter(2); await op('fz.status', { vid: 'd50', st: '3', einsatzId: E1.id });
  const staerken = { d10: [0, 1, 2, 0], d11: [0, 1, 7, 4], d12: [0, 1, 2, 2], d14: [0, 1, 6, 0], d15: [0, 1, 2, 0], d20: [0, 1, 7, 4], d21: [0, 0, 5, 2], d30: [0, 1, 4, 2], d50: [0, 1, 2, 0] };
  for (const [vid, s] of Object.entries(staerken)) await op('staerke', { vid, f: s[0] + s[1], uf: 0, m: s[2], agt: s[3] });
  await weiter(1);
  const A1 = await op('abschnitt', { einsatzId: E1.id, name: 'Brandbekämpfung', leiter: 'ZF Albrecht', kanal: 'DMO 307', auftrag: 'Brandbekämpfung Scheune, Riegelstellung zum Stall' });
  const A2 = await op('abschnitt', { einsatzId: E1.id, name: 'Wasserversorgung', leiter: 'GF Seidel', kanal: 'DMO 308', auftrag: 'B-Leitung vom Hydranten Mühlenweg, Saugstelle Mühlenbach' });
  const A3 = await op('abschnitt', { einsatzId: E1.id, name: 'Atemschutz / Bereitstellung', leiter: 'GF Brückner', kanal: 'DMO 307', auftrag: 'Atemschutz-Sammelplatz, Sicherheitstrupp' });
  for (const [vid, ab] of [['d11', A1], ['d12', A1], ['d20', A1], ['d15', A2], ['d30', A2], ['d14', A3], ['d21', A3]]) if (ab) await op('fz.abschnitt', { einsatzId: E1.id, vid, abschnitt: ab.id });
  if (A1) await op('abschnitt', { einsatzId: E1.id, id: A1.id, nurFlaeche: true, flaeche: [off(EO, 45, -70), off(EO, 45, 60), off(EO, -60, 60), off(EO, -60, -70)] });
  if (A2) await op('abschnitt', { einsatzId: E1.id, id: A2.id, nurFlaeche: true, flaeche: [off(EO, 40, -200), off(EO, 120, -200), off(EO, 120, -90), off(EO, 40, -90)] });
  await weiter(2);
  for (const punkt of ['Erkundung durchgeführt', 'Eigenschutz beachtet, Einsatzstelle abgesichert', 'Erste Rückmeldung an die Leitstelle', 'Bereitstellungsraum festgelegt', 'Einsatzabschnitte gebildet', 'Atemschutzüberwachung eingerichtet']) await op('check', { einsatzId: E1.id, liste: 'Allgemein', punkt, an: true });
  for (const punkt of ['Menschenrettung geprüft (vermisste Personen?)', 'Wasserversorgung aufgebaut', 'Angriffsweg und Trupps festgelegt', 'Sicherheitstrupp bereitgestellt']) await op('check', { einsatzId: E1.id, liste: 'Brand', punkt, an: true });
  await weiter(2); await op('tb.neu', { einsatzId: E1.id, richtung: 'Eingang', von: 'Wasserversorgung', an: 'ELW', text: 'Wasserversorgung aufgebaut: B-Leitung vom H 100 Mühlenweg, zweite Leitung über Saugstelle Mühlenbach (TSF-W).' });
  await weiter(2); await op('nachricht', { einsatzId: E1.id, vids: ['d21', 'd30'], text: 'Bitte zum Bereitstellungsraum Parkplatz Sportplatz, dort weitere Anweisungen abwarten.', von: 'ELW' });
  await weiter(1); await op('tb.neu', { einsatzId: E1.id, richtung: 'Ausgang', von: 'ELW', an: 'Leitstelle', text: 'Energieversorger zur Abschaltung des Hausanschlusses angefordert.' });
  await weiter(2); await op('fz.status', { vid: 'd50', st: '4', einsatzId: E1.id }); if (A1) await op('fz.abschnitt', { einsatzId: E1.id, vid: 'd50', abschnitt: A1.id });
  if (anf) await op('anforderung', { einsatzId: E1.id, id: anf.id, status: 'eingetroffen' });
  await weiter(2); await op('tb.neu', { einsatzId: E1.id, richtung: 'Eingang', von: '78-11-30', an: 'ELW', text: 'Drehleiter in Stellung an der Hofeinfahrt, Wenderohr in Betrieb.' });
  // Nachricht aus der Fahrzeug-App
  try {
    const z = await api('/api/melde/zugang', { vid: 'd11', aktion: 'holen' });
    await weiter(5);
    await fetch(`http://127.0.0.1:${PORT + 1}/api/nachricht/${z.token}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'Trupp 1 zurück, Flasche leer. Zweiter Trupp geht vor. Brandausbreitung zum Stall gestoppt.' }) });
  } catch (e) { console.log('Fahrzeug-App:', e.message); }
  await weiter(3); await op('besprechung', { einsatzId: E1.id, text: 'Riegelstellung hält, Stall geschützt. Scheune nicht zu halten – kontrolliert abbrennen lassen, Nachlöscharbeiten mit Radlader des Landwirts abstimmen. Ablösung Atemschutz über den Bereitstellungsraum.', teilnehmer: 'EL, ZF Albrecht, GF Seidel, GF Brückner', naechste: 30 });
  await weiter(5); await bestaetigen(); await op('einsatz.uebergabe', { einsatzId: E1.id, an: 'GemBM Beispiel', punkte: ['Lage und Schadensentwicklung', 'Gefahren an der Einsatzstelle', 'Eingesetzte Kräfte und Abschnitte', 'Offene Aufträge und Anforderungen', 'Atemschutz und Sicherheitstrupp', 'Wasserversorgung', 'Funk und Kommunikation'], bemerkung: 'Gasflaschen im Anbau gekühlt, Explosionsbereich 50 m abgesperrt.' });
  await weiter(4); await op('fz.ruf', { vid: 'd20', code: '5' });
  await weiter(3); await op('lage', { einsatzId: E1.id, text: 'Brandausbreitung gestoppt, Stall gehalten. Scheune brennt kontrolliert ab. Keine Verletzten. Einsatz dauert voraussichtlich noch 2 Stunden.', von: 'Einsatzleitung', an: 'Leitstelle' });
  const H1 = off(EO, 60, -150), GAS = off(EO, -18, 26);
  await op('karte.aendern', { key: 'opta3.karte.' + E1.id, aenderungen: [
    { liste: 'markers', id: 'm1', wert: { type: 'incident', lat: EO[0], lon: EO[1], text: 'Scheune Vollbrand' } },
    { liste: 'markers', id: 'm2', wert: { type: 'danger', lat: GAS[0], lon: GAS[1], text: 'Gasflaschen (4×)' } },
    { liste: 'markers', id: 'm3', wert: { type: 'command', lat: off(EO, 130, -40)[0], lon: off(EO, 130, -40)[1], text: 'Einsatzleitung' } },
    { liste: 'markers', id: 'm4', wert: { type: 'hydrant', lat: H1[0], lon: H1[1], text: 'H 100' } },
    { liste: 'markers', id: 'm6', wert: { type: 'asue', lat: off(EO, 80, -60)[0], lon: off(EO, 80, -60)[1] } },
    { liste: 'markers', id: 'm7', wert: { type: 'assembly', lat: off(EO, 150, 10)[0], lon: off(EO, 150, 10)[1], text: 'Bewohner' } },
    { liste: 'shapes', id: 's1', wert: { type: 'ringe', lat: GAS[0], lon: GAS[1], radien: [50], text: 'Explosionsbereich' } },
    { liste: 'shapes', id: 's2', wert: { type: 'kegel', lat: EO[0], lon: EO[1], windAus: 240, laenge: 450, winkel: 50, text: 'Rauch' } },
    { liste: 'shapes', id: 's3', wert: { type: 'line', stil: 'angriff', pts: [off(EO, 48, -8), off(EO, 16, -4)] } },
    { liste: 'shapes', id: 's4', wert: { type: 'line', stil: 'absperr', pts: [off(EO, 70, -30), off(EO, 70, 90)] } },
    ...[['d11', 55, -20], ['d12', 30, -75], ['d20', -20, -80], ['d15', 80, -150], ['d30', 25, -10], ['d14', 110, -60], ['d21', 115, -85], ['d10', 125, -30], ['d50', 40, 40]].map(([vid, dn, de]) => ({ liste: 'vehPos', id: vid, wert: { lat: off(EO, dn, de)[0], lon: off(EO, dn, de)[1] } })),
  ] });
  await op('karte.aendern', { key: 'opta3.taktik.' + E1.id, aenderungen: [
    { liste: 'markers', id: 't1', wert: { type: 'pumpe', lat: off(EO, 30, -75)[0], lon: off(EO, 30, -75)[1], text: 'TLF 3000' } },
    { liste: 'markers', id: 't2', wert: { type: 'verteiler', lat: off(EO, 18, -42)[0], lon: off(EO, 18, -42)[1] } },
    { liste: 'markers', id: 't3', wert: { type: 'strahlrohr_c', lat: off(EO, 14, -24)[0], lon: off(EO, 14, -24)[1], text: '1. Trupp' } },
    { liste: 'markers', id: 't4', wert: { type: 'strahlrohr_c', lat: off(EO, -6, -26)[0], lon: off(EO, -6, -26)[1], text: '2. Trupp' } },
    { liste: 'markers', id: 't5', wert: { type: 'wenderohr', lat: off(EO, 24, 34)[0], lon: off(EO, 24, 34)[1], text: 'DLK' } },
    { liste: 'markers', id: 't6', wert: { type: 'incident', lat: EO[0], lon: EO[1], text: 'Scheune' } },
    { liste: 'shapes', id: 'l1', wert: { type: 'line', art: 'B', pts: [H1, off(EO, 30, -75), off(EO, 18, -42)] } },
    { liste: 'shapes', id: 'l2', wert: { type: 'line', art: 'C', pts: [off(EO, 18, -42), off(EO, 14, -24)] } },
    { liste: 'shapes', id: 'l3', wert: { type: 'line', art: 'C', pts: [off(EO, 18, -42), off(EO, 4, -38), off(EO, -6, -26)] } },
  ] });
  await op('fz.pos', { vid: 'd11', lat: off(EO, 55, -20)[0], lon: off(EO, 55, -20)[1], acc: 8, t: jetzt() });
  try {
    await fetch(`http://127.0.0.1:${PORT + 2}/api/status`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ schema: 'asue.status/1', zeitpunkt: new Date(jetzt()).toISOString(), feuerwehr: { user: 'musterhausen', name: 'Ortsfeuerwehr Musterhausen', gemeinde: 'Gemeinde Musterstadt' }, einsatz: { id: 'asue-demo-1', evId: E1.id, art: 'Einsatz', einsatzstelle: 'Scheune Mühlenhof', datum: new Date(jetzt()).toISOString().slice(0, 10), abgeschlossen: false }, status: { bereit: { trupps: 1, personen: 2 }, imEinsatz: { trupps: 2, personen: 4 }, warenImEinsatz: { trupps: 1, personen: 2 }, gesamt: { trupps: 4, personen: 8 } } }) });
  } catch (e) { console.log('ASÜ:', e.message); }
  await op('einsatz.kontakt', { einsatzId: E1.id, funktion: 'Landwirt / Eigentümer', name: 'Bernd Kornfeld', telefon: '01234 567890', email: 'kornfeld@example.org', rolle: 'Eigentümer' });
  await op('tb.neu', { einsatzId: E1.id, richtung: 'Eingang', von: 'Bernd Kornfeld (Eigentümer)', an: 'ELW', text: 'Herr Kornfeld meldet: Im Anbau lagern 4 Propangasflaschen. Rückruf unter 01234 567890.' });
  await weiter(20); await op('tb.neu', { einsatzId: E1.id, richtung: 'Eingang', von: 'Brandbekämpfung', an: 'ELW', text: 'Scheune abgebrannt, Nachlöscharbeiten laufen. Wärmebildkamera: keine Glutnester mehr im Stall.' });
  await op('einsatz.aendern', { id: E1.id, einsatzleiter: 'GemBM Beispiel' });
  await weiter(40); await bestaetigen();
  await op('einsatz.ende', { id: E1.id });
  await sleep(800);

  /* ---------- Einsatz 2: Verkehrsunfall Waldstraße ---------- */
  const VU = geo(1112, 330);
  await zeitpunkt('2026-09-20T07:42:00+02:00'); await bestaetigen();
  const E2 = await op('einsatz.neu', { stichwort: 'TH VU', meldebild: 'PKW gegen Baum, eine Person eingeklemmt', adresse: 'Waldstraße, 12345 Musterhausen (zwischen Hauptstraße und Bahnübergang)', lat: VU[0], lon: VU[1], einsatzleiter: 'ZF Albrecht', meldender: 'Ersthelfer über Notruf', alarmzeit: jetzt() });
  const F2 = ['d10', 'd11', 'd14', 'd51', 'd97', 'd98'];
  for (const vid of F2) await op('fz.status', { vid, st: 'A', einsatzId: E2.id });
  await weiter(2); for (const vid of ['d11', 'd10', 'd97']) await op('fz.status', { vid, st: '3', einsatzId: E2.id });
  await weiter(1); for (const vid of ['d14', 'd98']) await op('fz.status', { vid, st: '3', einsatzId: E2.id });
  await weiter(3); for (const vid of ['d11', 'd10']) await op('fz.status', { vid, st: '4', einsatzId: E2.id });
  await op('tb.neu', { einsatzId: E2.id, richtung: 'Eingang', von: '77-11-40', an: 'ELW', text: 'PKW frontal gegen Baum, Fahrer eingeklemmt und ansprechbar. Betriebsstoffe laufen aus. Keine weiteren Insassen.' });
  await weiter(1); await op('fz.status', { vid: 'd97', st: '4', einsatzId: E2.id });
  await op('lage', { einsatzId: E2.id, text: 'Ich sehe: PKW gegen Baum, eine Person eingeklemmt, ansprechbar. Ich mache: Brandschutz sicherstellen, Erstversorgung mit Rettungsdienst, patientengerechte Rettung über Dachabnahme. Ich brauche: Rüstwagen (bereits alarmiert), Polizei zur Straßensperrung.', von: 'Einsatzleitung', an: 'Leitstelle' });
  await weiter(2); for (const vid of ['d14', 'd98']) await op('fz.status', { vid, st: '4', einsatzId: E2.id });
  for (const [vid, s] of Object.entries({ d10: [1, 0, 2, 0], d11: [1, 0, 7, 2], d14: [0, 0, 6, 0], d51: [1, 0, 2, 0], d97: [0, 0, 2, 0], d98: [0, 0, 2, 0] })) await op('staerke', { vid, f: s[0] + s[1], uf: 0, m: s[2], agt: s[3] });
  const B1 = await op('abschnitt', { einsatzId: E2.id, name: 'Technische Rettung', leiter: 'GF Seidel', kanal: 'DMO 307', auftrag: 'Patientengerechte Rettung, Dachabnahme' });
  const B2 = await op('abschnitt', { einsatzId: E2.id, name: 'Absicherung / Brandschutz', leiter: 'GF Brückner', kanal: 'DMO 307', auftrag: 'Einsatzstelle absichern, Brandschutz, Betriebsstoffe binden' });
  for (const [vid, ab] of [['d11', B1], ['d51', B1], ['d14', B2], ['d10', B2]]) if (ab) await op('fz.abschnitt', { einsatzId: E2.id, vid, abschnitt: ab.id });
  for (const punkt of ['Erkundung durchgeführt', 'Eigenschutz beachtet, Einsatzstelle abgesichert', 'Erste Rückmeldung an die Leitstelle']) await op('check', { einsatzId: E2.id, liste: 'Allgemein', punkt, an: true });
  await weiter(4); await op('fz.status', { vid: 'd51', st: '3', einsatzId: E2.id });
  await weiter(5); await op('fz.status', { vid: 'd51', st: '4', einsatzId: E2.id });
  await op('tb.neu', { einsatzId: E2.id, richtung: 'Eingang', von: 'Technische Rettung', an: 'ELW', text: 'Glas gemanagt, Seitenöffnung erfolgt, Dachabnahme beginnt.' });
  await op('karte.aendern', { key: 'opta3.karte.' + E2.id, aenderungen: [
    { liste: 'markers', id: 'v1', wert: { type: 'incident', lat: VU[0], lon: VU[1], text: 'PKW gegen Baum' } },
    { liste: 'markers', id: 'v2', wert: { type: 'danger', lat: off(VU, -6, 4)[0], lon: off(VU, -6, 4)[1], text: 'Betriebsstoffe' } },
    { liste: 'markers', id: 'v3', wert: { type: 'command', lat: off(VU, -60, -8)[0], lon: off(VU, -60, -8)[1], text: 'Einsatzleitung' } },
    { liste: 'shapes', id: 'v4', wert: { type: 'line', stil: 'absperr', pts: [off(VU, 80, -10), off(VU, 80, 12)] } },
    { liste: 'shapes', id: 'v5', wert: { type: 'line', stil: 'absperr', pts: [off(VU, -90, -12), off(VU, -90, 10)] } },
    ...[['d11', 18, -4], ['d51', 32, -4], ['d14', -45, -5], ['d10', -60, -2], ['d97', -25, 4], ['d98', -32, 5]].map(([vid, dn, de]) => ({ liste: 'vehPos', id: vid, wert: { lat: off(VU, dn, de)[0], lon: off(VU, dn, de)[1] } })),
  ] });
  await weiter(14); await op('tb.neu', { einsatzId: E2.id, richtung: 'Eingang', von: 'Technische Rettung', an: 'ELW', text: 'Patient befreit und an den Rettungsdienst übergeben (Transport ins Krankenhaus).' });
  await op('fz.status', { vid: 'd97', st: '1', einsatzId: E2.id });
  await weiter(3); await op('fz.status', { vid: 'd98', st: '1', einsatzId: E2.id });
  await weiter(20); await op('tb.neu', { einsatzId: E2.id, richtung: 'Ausgang', von: 'ELW', an: 'Leitstelle', text: 'Betriebsstoffe gebunden, Fahrbahn gereinigt. Einsatzstelle an die Polizei übergeben.' });
  await weiter(10); await bestaetigen();
  await op('einsatz.ende', { id: E2.id });
  await sleep(800);

  /* ---------- Einsatz 3: Ölspur ---------- */
  const OEL = geo(560, 40);
  await zeitpunkt('2026-09-25T18:10:00+02:00'); await bestaetigen();
  const E3 = await op('einsatz.neu', { stichwort: 'TH1', meldebild: 'Ölspur auf der Fahrbahn (ca. 300 m)', adresse: 'Hauptstraße / Industriestraße, 12345 Musterhausen', lat: OEL[0], lon: OEL[1], einsatzleiter: 'GF Hartwig', meldender: 'Polizei', alarmzeit: jetzt() });
  for (const vid of ['d20', 'd40']) await op('fz.status', { vid, st: 'A', einsatzId: E3.id });
  await weiter(3); for (const vid of ['d20', 'd40']) await op('fz.status', { vid, st: '3', einsatzId: E3.id });
  await weiter(6); for (const vid of ['d20', 'd40']) await op('fz.status', { vid, st: '4', einsatzId: E3.id });
  await op('tb.neu', { einsatzId: E3.id, richtung: 'Eingang', von: '77-21-44', an: 'ELW', text: 'Ölspur von der Tankstelle bis zur Industriestraße, ca. 300 m. Bindemittel wird aufgebracht, Straßenmeisterei verständigt.' });
  await weiter(25); await op('tb.neu', { einsatzId: E3.id, richtung: 'Eingang', von: '77-21-44', an: 'ELW', text: 'Bindemittel aufgenommen, Warnschilder „Ölspur“ aufgestellt. Übergabe an die Straßenmeisterei.' });
  await weiter(5); await bestaetigen();
  await op('einsatz.ende', { id: E3.id });
  await sleep(800);

  /* ---------- Atemschutz-Datenbank (ab 4.0): Gerätewart Musterhausen mit Beispielpersonen ---------- */
  uhrSetzen(0); await sleep(100); await bestaetigen();
  // ab 5.146: Gerätewart-Zugänge werden in den Datenbank-Apps angelegt (ASÜ-Port, nur Admin) – dafür kurz ein Demo-Superadmin
  const su = await op('benutzer.speichern', { username: 'demo.super', role: 'admin', pin: 'DemoSuper2026x', superadmin: true });
  await sleep(300);
  const sup = await api('/api/agw/anmelden', { user: 'demo.super', passwort: 'DemoSuper2026x' }, PORT + 2);
  const konto = async (b) => { const r = await fetch(`http://127.0.0.1:${PORT + 2}/api/agw/admin/konten`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-AGW-Token': sup.token }, body: JSON.stringify(b) }); if (!r.ok) throw new Error(`Konto ${b.user}: ${r.status} ${await r.text()}`); };
  await konto({ bereich: 'atemschutz', user: 'gw.musterhausen', name: 'Gerätewart Musterhausen (Demo)', mail: 'atemschutz@musterhausen.example', wehren: ['Musterhausen'], startpasswort: 'Start-Demo-1' });
  await konto({ bereich: 'geraete', user: 'gw.geraete', name: 'Gerätewart Musterhausen (Demo)', mail: 'geraete@musterhausen.example', wehren: ['Musterhausen'], startpasswort: 'Start-Demo-2' });
  const gdbImport = async () => { const r = await fetch(`http://127.0.0.1:${PORT + 2}/api/agw/admin/gdb-import`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-AGW-Token': sup.token }, body: '{}' }); if (!r.ok) console.log('gdb-import', r.status, await r.text()); };
  const superWeg = async () => { if (su && su.id) await op('benutzer.loeschen', { id: su.id }); };
  await api('/api/agw/kennwort', { user: 'gw.musterhausen', alt: 'Start-Demo-1', neu: 'demo12345' }, PORT + 2);
  const gw = await api('/api/agw/anmelden', { user: 'gw.musterhausen', passwort: 'demo12345' }, PORT + 2);
  const agw = async (pfad, body) => { const r = await fetch(`http://127.0.0.1:${PORT + 2}/api${pfad}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-AGW-Token': gw.token }, body: JSON.stringify(body) }); if (!r.ok) throw new Error(`${pfad}: ${r.status} ${await r.text()}`); return r.json(); };
  const tag = (d) => new Date(Date.now() + d * 864e5).toISOString().slice(0, 10);
  const PERS = [
    ['Hartwig', 'Jan', { lehrgang: -3000, g26: [-400, 700], belastung: -120, unterweisung: -60 }],
    ['Brandt', 'Lea', { lehrgang: -2000, g26: [-200, 900], belastung: -340, unterweisung: -90 }],          // Belastungsübung läuft bald ab
    ['Krüger', 'Tom', { lehrgang: -1500, g26: [-1100, -20], belastung: -100, unterweisung: -100 }],        // G 26.3 abgelaufen
    ['Neumann', 'Nina', { lehrgang: -900, g26: [-300, 800], belastung: -200, unterweisung: -380 }],        // Unterweisung abgelaufen
    ['Wolf', 'Paul', { lehrgang: -4000, g26: [-100, 1000], belastung: -30, unterweisung: -30 }],
    ['Sommer', 'Mia', { lehrgang: -700, g26: [-500, 15], belastung: -150, unterweisung: -150 }],           // G 26.3 läuft in 2 Wochen ab
  ];
  for (const [nach, vor, n] of PERS) {
    await agw('/agw/person', { nach, vor, wehr: 'Musterhausen', nachweise: { lehrgang: { d: tag(n.lehrgang) }, g26: { d: tag(n.g26[0]), bis: tag(n.g26[1]) }, belastung: { d: tag(n.belastung) }, unterweisung: { d: tag(n.unterweisung) } } });
  }
  for (const [art, nr, typ, pr] of [['geraet', 'PA-101', 'Pressluftatmer', 200], ['geraet', 'PA-102', 'Pressluftatmer', 400], ['flasche', 'F-2210', '6,8 l Composite 300 bar', 20], ['flasche', 'F-2211', '6,8 l Composite 300 bar', 600], ['la', 'LA-31', 'Lungenautomat', 300], ['maske', 'M-77', 'Vollmaske', 500]]) {
    await agw('/agw/geraet', { art, nr, typ, wehr: 'Musterhausen', pruefBis: tag(pr) });
  }
  console.log('Atemschutz-Datenbank: Zugang gw.musterhausen / demo12345 mit', PERS.length, 'Personen');

  /* ---------- Gerätedatenbank (ab 4.7, Prüfarten/Prüfprotokoll ab 5.6/5.7): eigener Gerätewart ---------- */
  await bestaetigen();
  await gdbImport(); await superWeg();
  await api('/api/agw/kennwort', { user: 'gw.geraete', alt: 'Start-Demo-2', neu: 'demo12345' }, PORT + 2);
  const gg = await api('/api/agw/anmelden', { user: 'gw.geraete', passwort: 'demo12345' }, PORT + 2);
  const gdbReq = async (methode, pfad, body) => { const r = await fetch(`http://127.0.0.1:${PORT + 2}/api${pfad}`, { method: methode, headers: { 'Content-Type': 'application/json', 'X-AGW-Token': gg.token }, body: body ? JSON.stringify(body) : undefined }); if (!r.ok) throw new Error(`${pfad}: ${r.status} ${await r.text()}`); return r.json(); };
  const NEU = [
    ['Steckleiter 4-teilig', 'Leitern', 'd11', 'Leitern – Prüfung nach DGUV 305-002', 12, 5, 'L-1140-1'],
    ['Hebekissen-Satz 3-teilig', 'Technische Hilfe', 'd11', 'Hebekissen – Prüfung nach DGUV 305-002', 12, 20, 'HK-1140'],
    ['Stromerzeuger 13 kVA', 'Strom/Beleuchtung', 'd10', 'Stromerzeuger – Prüfung nach DGUV 305-002', 12, -3, 'SE-1110'],
    ['Motorkettensäge', 'Technische Hilfe', 'd12', 'Motorkettensäge – Prüfung nach DGUV 305-002', 12, 60, 'MKS-1124'],
    ['Leitungsroller 50 m', 'Strom/Beleuchtung', 'd10', 'Ortsveränderliche elektrische Betriebsmittel (DGUV V3 / 305-002)', 12, 12, 'LR-1110'],
  ];
  for (const [bez, kat, vid, pruefArt, pruefMonate, inTagen, inv] of NEU) {
    await gdbReq('POST', '/gdb/geraet', { bez, kat, vid, wehr: 'Musterhausen', pruefArt, pruefMonate, pruefNaechste: tag(inTagen), inv, menge: 1, hersteller: '', typ: '', serien: '', notiz: '', begriffNeu: true });   // ab 5.31: einheitliche Begriffe
  }
  let G = await gdbReq('GET', '/gdb/daten');
  const finde = (t) => G.geraete.find((g) => (g.bez || '').startsWith(t));
  const tp = finde('Tauchpumpe'); if (tp) await gdbReq('POST', '/gdb/aktion', { id: tp.id, aktion: 'pruefung', datum: tag(-2), ergebnis: 'ok', text: 'Probelauf ohne Befund', protokoll: { liste: 'Elektrisch', punkte: [{ t: 'Sichtprüfung Gehäuse und Leitung', ok: true }, { t: 'Schutzleiterwiderstand', ok: true }, { t: 'Isolationswiderstand', ok: true }, { t: 'Funktionsprüfung', ok: true }], pruefer: 'Gerätewart Musterhausen (Demo)', befaehigt: 'Elektrofachkraft (Demo)' } });
  const lm = finde('Lichtmast'); if (lm) await gdbReq('POST', '/gdb/aktion', { id: lm.id, aktion: 'mangel', text: 'Kurbel schwergängig, Mast fährt nicht ganz aus' });
  G = await gdbReq('GET', '/gdb/daten');
  console.log('Gerätedatenbank: Zugang gw.geraete / demo12345 mit', G.geraete.length, 'Geräten');

  /* ---------- Übungs-Drehbücher (Live-Übung) ---------- */
  uhrSetzen(0); await sleep(100); await bestaetigen();
  for (const [eid, name] of [[E1.id, 'Übung: Scheunenbrand Mühlenhof'], [E2.id, 'Übung: Verkehrsunfall Waldstraße']]) {
    const v = await api('/api/demo/vorschau', { archivId: eid });
    const personen = v.vorschlag.map((p) => ({ ...p, aktiv: false }));   // Namen sind ohnehin erfunden
    const r = await api('/api/demo/erstellen', { archivId: eid, personen, ort: { art: 'behalten' }, maxPauseMin: 3, name });
    console.log('Drehbuch:', r.demo && r.demo.name, Math.round((r.demo && r.demo.dauer || 0) / 60000), 'min');
  }
  await op('benutzer.speichern', { id: 'u_admin', username: 'Admin', role: 'admin', pin: '123456' });   // ab 5.131: PIN mindestens 6 Zeichen (sonst Pflicht zum Ändern)
  c.w.close();
  console.log('Startdaten fertig:', E1.nummer || E1.id, E2.nummer || E2.id, E3.nummer || E3.id);
  process.exit(0);
})().catch((e) => { console.error('ABBRUCH', e); process.exit(1); });
