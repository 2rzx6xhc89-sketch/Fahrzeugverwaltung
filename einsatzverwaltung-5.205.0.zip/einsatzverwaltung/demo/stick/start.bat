@echo off
rem Einsatzverwaltung - Demo-Version starten (Windows)
chcp 65001 >nul
title Einsatzverwaltung DEMO
setlocal
set "WURZEL=%~dp0"
set "NODE="
if exist "%WURZEL%node\win-x64\node.exe" set "NODE=%WURZEL%node\win-x64\node.exe"
if not defined NODE (
  where node >nul 2>nul && set "NODE=node"
)
if not defined NODE goto keinnode
if not exist "%WURZEL%programm\node_modules\express\package.json" goto keinemodule
cd /d "%WURZEL%programm"
if not exist "data.json" copy /y "startdaten\data.json" "data.json" >nul
if not exist "wasser.json" copy /y "startdaten\wasser.json" "wasser.json" >nul
set EV_DEMO=1
set PORT=@PORT@
set PIN_BESTAETIGUNG_MIN=15
set "EV_HOST=127.0.0.1"
if "@NETZ@"=="1" set "EV_HOST="
echo.
echo  ==============================================================
echo   Einsatzverwaltung - DEMO-VERSION (alle Daten sind erfunden)
echo  ==============================================================
echo   Einsatzverwaltung:         http://localhost:@PORT@
echo   Atemschutzueberwachung:    http://localhost:@APORT@
echo   Anmeldung Admin: PIN 123456  (weitere Zugaenge: LIESMICH.html)
if "@NETZ@"=="1" (
  echo.
  echo   Auch im WLAN erreichbar. Adresse dieses Rechners:
  ipconfig | findstr /i "IPv4"
  echo   Am Handy/Tablet: http://^<Adresse^>:@PORT@   Fahrzeug-App: Port @MPORT@
  echo   Fragt die Windows-Firewall nach: "Private Netzwerke" erlauben.
)
echo.
echo   Dieses Fenster bitte offen lassen.
echo   Beenden: dieses Fenster schliessen (oder Strg+C).
echo  ==============================================================
echo.
start "" /min cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:@PORT@/"
"%NODE%" server.js
echo.
echo  Die Demo wurde beendet.
pause
exit /b 0

:keinnode
echo.
echo  Node.js wurde nicht gefunden.
echo  Bitte einmalig "Stick vorbereiten (einmalig) Windows.bat" ausfuehren
echo  (braucht Internet) - danach laeuft die Demo auf jedem Windows-PC ohne Installation.
echo.
pause
exit /b 1

:keinemodule
echo.
echo  Die Programmbibliotheken fehlen (Ordner programm\node_modules).
echo  Bitte einmalig "Stick vorbereiten (einmalig) Windows.bat" ausfuehren (braucht Internet).
echo.
pause
exit /b 1
