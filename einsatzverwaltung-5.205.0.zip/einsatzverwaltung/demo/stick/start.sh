#!/bin/bash
# Einsatzverwaltung – Demo-Version starten (Mac und Linux)
cd "$(dirname "$0")/.." || exit 1
WURZEL="$PWD"
NETZ=@NETZ@
ende() { echo; read -r -p "Enter drücken zum Schließen … " _; exit "${1:-0}"; }
os=$(uname -s); arch=$(uname -m)
case "$os-$arch" in
  Darwin-arm64) KAND="node/mac-arm64/bin/node" ;;
  Darwin-x86_64) KAND="node/mac-x64/bin/node" ;;
  Linux-x86_64) KAND="node/linux-x64/bin/node" ;;
  Linux-aarch64|Linux-arm64) KAND="node/linux-arm64/bin/node" ;;
  *) KAND="" ;;
esac
NODE=""
if [ -n "$KAND" ] && [ -f "$WURZEL/$KAND" ]; then
  # vom Stick ausführen geht nicht immer (Mac: Quarantäne, Linux: noexec) – dann eine Kopie im Benutzerordner
  if "$WURZEL/$KAND" -v >/dev/null 2>&1; then NODE="$WURZEL/$KAND"
  else
    mkdir -p "$HOME/.einsatzverwaltung-demo"
    cp "$WURZEL/$KAND" "$HOME/.einsatzverwaltung-demo/node" && chmod +x "$HOME/.einsatzverwaltung-demo/node"
    [ "$os" = Darwin ] && xattr -d com.apple.quarantine "$HOME/.einsatzverwaltung-demo/node" 2>/dev/null
    "$HOME/.einsatzverwaltung-demo/node" -v >/dev/null 2>&1 && NODE="$HOME/.einsatzverwaltung-demo/node"
  fi
fi
if [ -z "$NODE" ] && command -v node >/dev/null 2>&1; then NODE=node; fi
if [ -z "$NODE" ]; then
  echo "Node.js wurde nicht gefunden."
  echo "Bitte einmalig „Stick vorbereiten (einmalig).sh“ ausführen (braucht Internet) oder Node.js ab Version 18 installieren."
  ende 1
fi
V=$("$NODE" -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)
if [ "$V" -lt 18 ]; then echo "Node.js $V ist zu alt – benötigt wird Version 18 oder neuer."; ende 1; fi
if [ ! -f programm/node_modules/express/package.json ]; then
  echo "Die Programmbibliotheken fehlen (programm/node_modules)."
  echo "Bitte einmalig „Stick vorbereiten (einmalig).sh“ ausführen (braucht Internet)."
  ende 1
fi
cd programm || exit 1
[ -f data.json ] || cp startdaten/data.json data.json
[ -f wasser.json ] || cp startdaten/wasser.json wasser.json
export EV_DEMO=1 PORT=@PORT@ PIN_BESTAETIGUNG_MIN=15
if [ "$NETZ" = 1 ]; then unset EV_HOST; else export EV_HOST=127.0.0.1; fi
echo
echo " =============================================================="
echo "  Einsatzverwaltung – DEMO-VERSION (alle Daten sind erfunden)"
echo " =============================================================="
echo "  Einsatzverwaltung:        http://localhost:@PORT@"
echo "  Atemschutzüberwachung:    http://localhost:@APORT@"
echo "  Anmeldung Admin: PIN 123456 (weitere Zugänge: LIESMICH.html)"
if [ "$NETZ" = 1 ]; then
  if [ "$os" = Darwin ]; then IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null); else IP=$(hostname -I 2>/dev/null | awk '{print $1}'); fi
  echo "  Im WLAN: http://${IP:-<Adresse-dieses-Rechners>}:@PORT@  (Fahrzeug-App: Port @MPORT@)"
fi
echo
echo "  Dieses Fenster offen lassen. Beenden mit Strg+C."
echo " =============================================================="
( sleep 2
  if [ "$os" = Darwin ]; then open "http://localhost:@PORT@/"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "http://localhost:@PORT@/" >/dev/null 2>&1
  fi ) &
"$NODE" server.js
echo
echo "Die Demo wurde beendet."
ende 0
