@echo off
rem Einsatzverwaltung - Demo-Stick einmalig vorbereiten (Windows, braucht Internet)
chcp 65001 >nul
title Demo-Stick vorbereiten
cd /d "%~dp0"
echo.
echo  Der Stick wird jetzt einmalig vorbereitet:
echo   1. Node.js (Laufzeitumgebung, von nodejs.org) wird auf den Stick geladen und geprueft.
echo   2. Die Programmbibliotheken (express, ws) werden installiert.
echo  Danach laeuft die Demo auf jedem Windows-PC ohne Installation und ohne Internet.
echo.
choice /c JN /m "Zusaetzlich Node.js fuer Mac und Linux laden (ca. 350 MB mehr)"
set "ALLE="
if not errorlevel 2 set "ALLE=-Alle"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0programm\werkzeuge\vorbereiten.ps1" %ALLE%
echo.
pause
