# Einsatzverwaltung - Demo-Stick vorbereiten (Windows)
# Laedt Node.js (aktuelle Version 22 LTS) von nodejs.org, prueft die SHA-256-Pruefsumme und installiert
# die Programmbibliotheken. Auf den Stick kommt nur die Datei node.exe (bzw. bin/node fuer Mac/Linux).
param([switch]$Alle)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}

$Programm = Split-Path -Parent $PSScriptRoot
$Wurzel = Split-Path -Parent $Programm
$NodeDir = Join-Path $Wurzel 'node'
$Basis = 'https://nodejs.org/dist/latest-v22.x/'
$Tmp = Join-Path $env:TEMP ('ev-demo-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $Tmp, $NodeDir | Out-Null
function Schritt([string]$t) { Write-Host ''; Write-Host ('== ' + $t) -ForegroundColor Cyan }

try {
  Schritt 'Liste der Node.js-Dateien laden (nodejs.org)'
  $sums = (Invoke-WebRequest -UseBasicParsing -Uri ($Basis + 'SHASUMS256.txt')).Content
  if ($sums -is [byte[]]) { $sums = [Text.Encoding]::ASCII.GetString($sums) }
  $zeilen = $sums -split "`r?`n"

  function Hole([string]$endung) {
    $muster = '^([0-9a-f]{64})\s+(node-v[\d.]+-' + [regex]::Escape($endung) + ')$'
    $z = $zeilen | Where-Object { $_ -match $muster } | Select-Object -First 1
    if (-not $z) { throw ('Datei *-' + $endung + ' nicht in der Liste von nodejs.org gefunden.') }
    $null = $z -match $muster
    $hash = $Matches[1]; $datei = $Matches[2]
    Schritt ('Lade ' + $datei)
    $f = Join-Path $Tmp $datei
    Invoke-WebRequest -UseBasicParsing -Uri ($Basis + $datei) -OutFile $f
    $ist = (Get-FileHash -Algorithm SHA256 -Path $f).Hash.ToLower()
    if ($ist -ne $hash) { throw ('Pruefsumme von ' + $datei + ' stimmt nicht - Abbruch.') }
    Write-Host '   Pruefsumme in Ordnung.'
    return $f
  }

  # 1) Windows: komplett entpacken (fuer npm), auf den Stick nur node.exe
  $zip = Hole 'win-x64.zip'
  $ex = Join-Path $Tmp 'win'
  New-Item -ItemType Directory -Force -Path $ex | Out-Null
  Write-Host '   Entpacken ...'
  $ok = $false
  try { & tar -xf $zip -C $ex 2>$null; if ($LASTEXITCODE -eq 0) { $ok = $true } } catch {}
  if (-not $ok) { Expand-Archive -Path $zip -DestinationPath $ex -Force }
  $nodeWin = (Get-ChildItem -Path $ex -Directory | Select-Object -First 1).FullName
  $ziel = Join-Path $NodeDir 'win-x64'
  New-Item -ItemType Directory -Force -Path $ziel | Out-Null
  Copy-Item -Force (Join-Path $nodeWin 'node.exe') (Join-Path $ziel 'node.exe')
  Copy-Item -Force (Join-Path $nodeWin 'LICENSE') (Join-Path $ziel 'LICENSE') -ErrorAction SilentlyContinue
  Write-Host '   node\win-x64\node.exe ist auf dem Stick.'

  # 2) Programmbibliotheken
  Schritt 'Programmbibliotheken installieren (express, ws)'
  $env:Path = $nodeWin + ';' + $env:Path
  Push-Location $Programm
  try {
    & (Join-Path $nodeWin 'npm.cmd') install --omit=dev --no-audit --no-fund --no-package-lock --loglevel=error
    if ($LASTEXITCODE -ne 0) { throw 'npm install ist fehlgeschlagen.' }
  } finally { Pop-Location }
  if (-not (Test-Path (Join-Path $Programm 'node_modules\express\package.json'))) { throw 'express wurde nicht installiert.' }
  Write-Host '   Bibliotheken installiert.'

  # 3) optional: Mac und Linux (nur die Datei bin/node)
  if ($Alle) {
    foreach ($p in @(@('darwin-arm64.tar.gz', 'mac-arm64'), @('darwin-x64.tar.gz', 'mac-x64'), @('linux-x64.tar.gz', 'linux-x64'), @('linux-arm64.tar.gz', 'linux-arm64'))) {
      $f = Hole $p[0]
      $name = [IO.Path]::GetFileName($f) -replace '\.tar\.gz$', ''
      $ex2 = Join-Path $Tmp ('x-' + $p[1]); New-Item -ItemType Directory -Force -Path $ex2 | Out-Null
      try { & tar -xzf $f -C $ex2 ($name + '/bin/node') 2>$null } catch {}
      $bin = Join-Path $ex2 ($name + '\bin\node')
      if (-not (Test-Path $bin)) { throw ('Entpacken von ' + $name + ' fehlgeschlagen (tar).') }
      $z2 = Join-Path $NodeDir ($p[1] + '\bin'); New-Item -ItemType Directory -Force -Path $z2 | Out-Null
      Copy-Item -Force $bin (Join-Path $z2 'node')
      Write-Host ('   node\' + $p[1] + '\bin\node ist auf dem Stick.')
    }
  }

  Schritt 'Fertig'
  Write-Host 'Der Stick ist vorbereitet. Start mit "Start Windows.bat".' -ForegroundColor Green
  exit 0
} catch {
  Write-Host ''
  Write-Host ('FEHLER: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host 'Bitte Internetverbindung pruefen und erneut starten. Alternativ Node.js ab Version 18 installieren (nodejs.org).'
  exit 1
} finally {
  Remove-Item -Recurse -Force $Tmp -ErrorAction SilentlyContinue
}
