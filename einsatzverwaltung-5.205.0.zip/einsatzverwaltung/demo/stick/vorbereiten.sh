#!/bin/bash
# Einsatzverwaltung – Demo-Stick einmalig vorbereiten (Mac, Linux, Raspberry Pi; braucht Internet)
# Lädt Node.js 22 LTS von nodejs.org, prüft die SHA-256-Prüfsumme und installiert die Programmbibliotheken.
# Auf den Stick kommt nur die Datei bin/node (bzw. node.exe für Windows).
set -e
cd "$(dirname "$0")/.."
WURZEL="$PWD"
BASIS="${NODE_QUELLE:-https://nodejs.org/dist/latest-v22.x}"   # NODE_QUELLE nur für Tests
ende() { echo; read -r -p "Enter drücken zum Schließen … " _ || true; exit "${1:-0}"; }
fehler() { { echo; echo "FEHLER: $*"; echo "Bitte Internetverbindung prüfen und erneut starten."; } >&2; read -r -p "Enter drücken zum Schließen … " _ </dev/tty || true; exit 1; }
command -v curl >/dev/null 2>&1 || fehler "curl fehlt."
ALLE=0
[ "${1:-}" = "--alle" ] && ALLE=1
if [ $ALLE = 0 ]; then
  read -r -p "Zusätzlich Node.js für die anderen Systeme (Windows, Mac, Linux) laden? (ca. 350 MB mehr) [j/N] " a || true
  case "$a" in j|J|ja|Ja|JA) ALLE=1 ;; esac
fi
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
echo "== Liste der Node.js-Dateien laden (nodejs.org)"
curl -fsSL "$BASIS/SHASUMS256.txt" -o "$TMP/SHASUMS256.txt" || fehler "nodejs.org nicht erreichbar."
pruef() { if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | cut -d' ' -f1; else shasum -a 256 "$1" | cut -d' ' -f1; fi; }
hole() {   # $1 = Endung (z. B. linux-x64.tar.gz) → Pfad der geprüften Datei
  local zeile hash datei
  zeile=$(grep -E "^[0-9a-f]{64}  node-v[0-9.]+-${1//./\\.}\$" "$TMP/SHASUMS256.txt" | head -1)
  [ -n "$zeile" ] || fehler "Datei *-$1 nicht in der Liste gefunden."
  hash=${zeile%% *}; datei=${zeile##* }
  echo "== Lade $datei" >&2
  curl -fSL --progress-bar "$BASIS/$datei" -o "$TMP/$datei" || fehler "Download von $datei fehlgeschlagen."
  [ "$(pruef "$TMP/$datei")" = "$hash" ] || fehler "Prüfsumme von $datei stimmt nicht."
  echo "   Prüfsumme in Ordnung." >&2
  echo "$TMP/$datei"
}
nur_node() {   # $1 = Endung (tar.gz), $2 = Zielordner auf dem Stick
  local f name
  f=$(hole "$1"); name=$(basename "$f" .tar.gz)
  mkdir -p "$TMP/x" "$WURZEL/node/$2/bin"
  tar -xzf "$f" -C "$TMP/x" "$name/bin/node"
  cp "$TMP/x/$name/bin/node" "$WURZEL/node/$2/bin/node"; chmod +x "$WURZEL/node/$2/bin/node" 2>/dev/null || true
  echo "   node/$2/bin/node ist auf dem Stick."
}
case "$(uname -s)-$(uname -m)" in
  Darwin-arm64) EIGEN=darwin-arm64; ZIEL=mac-arm64 ;;
  Darwin-x86_64) EIGEN=darwin-x64; ZIEL=mac-x64 ;;
  Linux-x86_64) EIGEN=linux-x64; ZIEL=linux-x64 ;;
  Linux-aarch64|Linux-arm64) EIGEN=linux-arm64; ZIEL=linux-arm64 ;;
  *) EIGEN=""; ZIEL="" ;;
esac
NPM=""
if [ -n "$EIGEN" ]; then
  f=$(hole "$EIGEN.tar.gz"); name=$(basename "$f" .tar.gz)
  echo "   Entpacken …"
  tar -xzf "$f" -C "$TMP"
  mkdir -p "$WURZEL/node/$ZIEL/bin"
  cp "$TMP/$name/bin/node" "$WURZEL/node/$ZIEL/bin/node"; chmod +x "$WURZEL/node/$ZIEL/bin/node" 2>/dev/null || true
  echo "   node/$ZIEL/bin/node ist auf dem Stick."
  export PATH="$TMP/$name/bin:$PATH"; NPM="$TMP/$name/bin/npm"
elif command -v npm >/dev/null 2>&1; then NPM=npm
fi
echo "== Programmbibliotheken installieren (express, ws)"
if [ -n "$NPM" ] && (cd "$WURZEL/programm" && "$NPM" install --omit=dev --no-audit --no-fund --no-package-lock --loglevel=error); then :
elif [ -f "$HOME/einsatzverwaltung/node_modules/express/package.json" ]; then
  echo "   npm nicht möglich – übernehme die Bibliotheken der Einsatzverwaltung auf diesem Pi."
  cp -r "$HOME/einsatzverwaltung/node_modules" "$WURZEL/programm/"
else fehler "Programmbibliotheken konnten nicht installiert werden."
fi
[ -f "$WURZEL/programm/node_modules/express/package.json" ] || fehler "express fehlt."
echo "   Bibliotheken installiert."
if [ $ALLE = 1 ]; then
  f=$(hole "win-x64.zip"); name=$(basename "$f" .zip)
  mkdir -p "$WURZEL/node/win-x64"
  if command -v unzip >/dev/null 2>&1; then unzip -o -j -q "$f" "$name/node.exe" -d "$WURZEL/node/win-x64"
  else python3 -c "import zipfile,sys; z=zipfile.ZipFile(sys.argv[1]); open(sys.argv[3],'wb').write(z.read(sys.argv[2]))" "$f" "$name/node.exe" "$WURZEL/node/win-x64/node.exe"; fi
  echo "   node/win-x64/node.exe ist auf dem Stick."
  for p in darwin-arm64:mac-arm64 darwin-x64:mac-x64 linux-x64:linux-x64 linux-arm64:linux-arm64; do
    [ "${p%%:*}" = "$EIGEN" ] && continue
    nur_node "${p%%:*}.tar.gz" "${p##*:}"
  done
fi
echo
echo "== Fertig: Der Stick ist vorbereitet."
ende 0
