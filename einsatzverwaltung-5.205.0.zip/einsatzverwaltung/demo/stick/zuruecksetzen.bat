@echo off
rem Einsatzverwaltung - Demo auf den Anfangszustand zuruecksetzen (Windows)
chcp 65001 >nul
cd /d "%~dp0programm"
netstat -an | findstr ":@PORT@ " | findstr /i "LISTENING" >nul
if not errorlevel 1 (
  echo.
  echo  Die Demo laeuft noch. Bitte zuerst das Demo-Fenster schliessen.
  echo.
  pause
  exit /b 1
)
echo.
choice /c JN /m "Alle Aenderungen der Demo verwerfen und den Anfangszustand wiederherstellen"
if errorlevel 2 exit /b 0
del /q "data.json" "data.json.*" "einstellungen.json" "wasser.json" 2>nul
for %%d in (backups protokoll nachrichten berichtbilder objekte) do if exist "%%d" rmdir /s /q "%%d"
echo.
echo  Fertig. Beim naechsten Start ist die Demo wieder im Anfangszustand.
echo  (Im Browser bitte neu anmelden.)
echo.
pause
