#!/bin/bash
# Einsatzverwaltung – Demo auf den Anfangszustand zurücksetzen (Mac und Linux)
cd "$(dirname "$0")/../programm" || exit 1
if (exec 3<>/dev/tcp/127.0.0.1/@PORT@) 2>/dev/null; then
  echo "Die Demo läuft noch. Bitte zuerst das Demo-Fenster schließen (Strg+C)."
  read -r -p "Enter drücken … " _; exit 1
fi
read -r -p "Alle Änderungen der Demo verwerfen und den Anfangszustand wiederherstellen? [j/N] " a
case "$a" in j|J|ja|Ja|JA) ;; *) exit 0 ;; esac
rm -f data.json data.json.* einstellungen.json wasser.json
rm -rf backups protokoll nachrichten berichtbilder objekte
echo "Fertig. Beim nächsten Start ist die Demo wieder im Anfangszustand (im Browser neu anmelden)."
read -r -p "Enter drücken … " _
