/* Nur für das Erzeugen der Demo-Startdaten: verstellbare Uhr (Versatz in ms steht in der Datei UHR_DATEI).
   So entstehen Beispiel-Einsätze mit realistischen Zeitabständen, ohne stundenlang zu warten. */
const fs = require('fs');
const F = process.env.UHR_DATEI;
const Echt = Date;
let versatz = 0, gelesen = 0;
function off() { const n = Echt.now(); if (n - gelesen > 20) { gelesen = n; try { versatz = Number(fs.readFileSync(F, 'utf8')) || 0; } catch (e) { /* bleibt */ } } return versatz; }
class UhrDate extends Echt {
  constructor(...a) { if (a.length === 0) super(Echt.now() + off()); else super(...a); }
  static now() { return Echt.now() + off(); }
}
globalThis.Date = UhrDate;
