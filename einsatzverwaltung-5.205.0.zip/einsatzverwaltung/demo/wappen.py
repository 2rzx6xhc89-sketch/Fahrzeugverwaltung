"""Erfundene, einfache Wappen für die Demo-Version (keine echten Hoheitszeichen)."""
import os, sys, math
from PIL import Image, ImageDraw

aus = sys.argv[1]
os.makedirs(aus, exist_ok=True)
S = 4  # Überabtastung

def schild(d, w, h, farbe, rand):
    pts = [(0, 0), (w, 0), (w, h * 0.55)]
    for i in range(1, 20):
        t = i / 20
        pts.append((w - w / 2 * (1 - math.cos(t * math.pi / 2)) if False else w * (1 - t / 2) , h * 0.55 + h * 0.45 * math.sin(t * math.pi / 2)))
    pts.append((w / 2, h))
    for i in range(19, 0, -1):
        t = i / 20
        pts.append((w * t / 2, h * 0.55 + h * 0.45 * math.sin(t * math.pi / 2)))
    pts += [(0, h * 0.55)]
    d.polygon(pts, fill=farbe, outline=rand, width=3 * S)
    return pts

def wappen(name, grund, figur, farbe2):
    w, h = 120 * S, 150 * S
    im = Image.new('RGBA', (w + 8 * S, h + 8 * S), (0, 0, 0, 0))
    ebene = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(ebene)
    schild(d, w - 1, h - 1, grund, (40, 40, 40))
    cx, cy = w / 2, h * 0.45
    if figur == 'rad':        # Mühlrad
        r = 34 * S
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=farbe2, width=7 * S)
        for k in range(8):
            a = k * math.pi / 4
            d.line([(cx, cy), (cx + r * 1.25 * math.cos(a), cy + r * 1.25 * math.sin(a))], fill=farbe2, width=6 * S)
        d.ellipse([cx - 8 * S, cy - 8 * S, cx + 8 * S, cy + 8 * S], fill=farbe2)
    elif figur == 'baum':
        d.rectangle([cx - 5 * S, cy + 5 * S, cx + 5 * S, cy + 45 * S], fill=(110, 70, 30))
        d.ellipse([cx - 32 * S, cy - 40 * S, cx + 32 * S, cy + 18 * S], fill=farbe2)
    elif figur == 'welle':
        for k in range(3):
            y = cy - 20 * S + k * 20 * S
            pts = [(cx - 42 * S + i * S, y + 7 * S * math.sin(i / 9)) for i in range(0, 85)]
            d.line(pts, fill=farbe2, width=7 * S)
    elif figur == 'aehre':
        d.line([(cx, cy - 40 * S), (cx, cy + 45 * S)], fill=farbe2, width=5 * S)
        for k in range(5):
            y = cy - 35 * S + k * 14 * S
            d.ellipse([cx - 16 * S, y, cx - 2 * S, y + 10 * S], fill=farbe2)
            d.ellipse([cx + 2 * S, y, cx + 16 * S, y + 10 * S], fill=farbe2)
    elif figur == 'turm':
        d.rectangle([cx - 26 * S, cy - 20 * S, cx + 26 * S, cy + 45 * S], fill=farbe2)
        for k in range(3):
            d.rectangle([cx - 26 * S + k * 20 * S, cy - 34 * S, cx - 14 * S + k * 20 * S, cy - 20 * S], fill=farbe2)
        d.rectangle([cx - 8 * S, cy + 20 * S, cx + 8 * S, cy + 45 * S], fill=grund)
    im.paste(ebene, (4 * S, 4 * S), ebene)
    im = im.resize((im.width // S, im.height // S), Image.LANCZOS)
    im.save(os.path.join(aus, name + '.png'), optimize=True)
    return im

wappen('musterstadt', (30, 80, 160), 'turm', (240, 240, 240))
wappen('musterhausen', (190, 30, 40), 'rad', (250, 210, 60))
wappen('beispieldorf', (40, 120, 70), 'aehre', (250, 210, 60))
wappen('lindenau', (245, 245, 245), 'baum', (40, 120, 60))
im = wappen('neudorf', (30, 90, 170), 'welle', (245, 245, 245))
# JPEG-Fassung (weißer Hintergrund) für die eingebettete Grafik der ASÜ
m = Image.open(os.path.join(aus, 'musterstadt.png')).convert('RGBA')
bg = Image.new('RGB', m.size, (255, 255, 255)); bg.paste(m, (0, 0), m)
bg.resize((119, 154), Image.LANCZOS).save(os.path.join(aus, 'musterstadt.jpg'), quality=85)
print('Wappen erzeugt')
