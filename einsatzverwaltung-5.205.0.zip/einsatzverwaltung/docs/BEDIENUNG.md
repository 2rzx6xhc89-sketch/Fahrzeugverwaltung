# Einsatzverwaltung – Bedienung (Version 5.20)

Stand: 11.10.2026

Diese Anleitung beschreibt die Bedienung im Einsatz und in der Verwaltung. Einrichtung, Installation und Aktualisierung des Pi stehen in `ANLEITUNG.md`, Betrieb und Notfall in `docs/BETRIEBSHANDBUCH.md`. Kurzanleitungen für Gerätewarte, Atemschutzgerätewarte, Atemschutzgeräteträger und Fahrzeugbesatzungen liegen als eigene Dateien im Ordner `docs/`. Am Ende steht unter **„Anhang: Versionshistorie“**, was in welcher Version neu dazugekommen ist.

## Überblick: So ist die Oberfläche aufgebaut

**Kopfbereich (oben, kompakt):** Wappen, Uhr, Hinweis-Zentrale 🔔, Suche (Strg+F) und der angemeldete Benutzer. In der Mitte stehen für den gewählten Einsatz Fahrzeuge, Stärke und Atemschutzgeräteträger – antippen führt zum Einsatz. Bei schmalen Fenstern entfällt der Schriftzug neben dem Wappen.

**Hauptreiter:** Einheiten · Ausrüstung · Einsatz · Besatzung · Objekte · Gefahrstoffdatenbank · Archiv · E-Mail · Verwaltung (Archiv, E-Mail und Verwaltung nur für Einsatzleitung und Admin). Die Lagekarte ist kein Hauptreiter mehr, sie gehört zum Einsatz.

**Reiterleiste im Einsatz** – bleibt beim Scrollen fest unter dem Kopf stehen (ebenso die Reiter der Verwaltung):

| Reiter | Inhalt |
|---|---|
| Übersicht | Kopfdaten, Einsatzbericht, Einsatz beenden, Unwetter, Einsatz-Uhren und Timer, Objekte, Gefahrstoffe, letzte Lage, Kräfteanforderungen |
| Tagebuch | Einsatztagebuch; das Eingabefeld bleibt oben stehen, 🎤 Diktieren rechts neben dem Inhalt |
| Aufträge | nur bei einer Sonderlage (Großschadenslage oder vorhandene Aufträge) |
| Fahrzeuge | alle Fahrzeuge im Einsatz mit Status, Stärke, Suche nach Ausrüstung, ✉ Nachricht |
| Abschnitte | Abschnitte mit verbundenen Unterabschnitten, schmale Leiste für den Bereitstellungsraum rechts |
| Lagekarte | Karte mit Werkzeugen, Lagekarte/Einsatztaktik, Vollbild |
| Nachrichten | Unterreiter 💬 Nachrichten (öffnet zuerst) und 📷 Fotos |
| Atemschutz | Daten der geteilten ASÜ-Überwachungen |
| Gefahrstoff | nur wenn ein Gefahrstoff eingetragen ist: komplettes Einsatzblatt je Stoff |
| VU · Checklisten · Nachbereitung · Zeitstrahl | siehe die Kapitel unten |

Passt die Leiste nicht in eine Zeile, zeigt sie nur Symbole – beim Drüberfahren erscheint der Name. Die Zähler (z. B. ungelesene Nachrichten) bleiben immer sichtbar, auch über der Lagekarte. **⧉** öffnet einen Bereich in einem eigenen Fenster.

**Rollen:** *Betrachter* sehen nur an, *Einsatzleitung* arbeitet im Einsatz, *Admin* verwaltet zusätzlich Fahrzeuge, Benutzer und Einstellungen (Einzelheiten unter „Anmeldung und Rollen“).

## Inhalt

- **Teil 1 – Grundlagen:** Anmeldung und Rollen · Darstellung: Nachtmodus und Dichte · Schneller bedienen · Mehrere Bildschirme · Adresssuche
- **Teil 2 – Im Einsatz:** Einsatz · Einsatztagebuch (nach FwDV 100) · Einsatz-Uhren (Notstromaggregat, Lagemeldung) · Stärke · FMS-Status · Kräfteanforderung · Lagemeldung und Abschnitte · Lagekarte · Farben der Gefahrenkreise · Großschadenslage (Unwetter): Aufträge · Bereitstellungsräume mit Handy-Link · Wasserförderung über lange Wegstrecke · Nachrichten zwischen ELW und Fahrzeugen · Fotodokumentation · Funkskizze · Wetter an der Einsatzstelle · Unwetterwarnungen und Niederschlagsradar · Gefahrstoffdatenbank · Atemschutzüberwachung · Atemschutzüberwachung: CSA-Trupps und Sicherheitstrupp-Warnung · Atemschutz-Datenbank, QR-Codes und Sammel-App · Datenbanken als App: Benachrichtigungen, Angemeldet bleiben · Gerätedatenbank: Prüfarten, Prüfprotokoll, QR-Etikett, Wochenüberblick · Atemschutz-Datenbank: Jahresauswertung, persönlicher Link, Ausgeschiedene · Excel-Import und -Export der Datenbanken · Gerätetausch und Prüfung aus der ASÜ · Verkehrsunfall (Karte „VU“) · Checklisten · Einsatz-Zeitstrahl · Lagebesprechung · Übergabe der Einsatzleitung · Plausibilitätsprüfung und Ablösung · Pressetext · Einsatzbericht (PDF) · Einsatzmappe drucken · Nachbereitung je Fahrzeug · Atemschutz-Nachweis je Person · Expositionsnachweis
- **Teil 3 – Fahrzeuge, Apps und Objekte:** Fahrzeug-App und Standort · Fahrzeug-App: Reiter und Meldungen · Fahrzeug-App: Karte mit what3words · Objektdaten in der Fahrzeug-App · Fahrzeuge nachmelden – auch ohne Eintrag in der Fahrzeugliste · Fahrzeugstatus von außen (PowerAlarm, ab 3.22) · PowerAlarm-Anbindung: Nachalarmierung, Alarme einlesen, Status senden · Fahrzeugverwaltung: Suche und Filter · ELW-Besatzung: „Wer kommt?“ · ELW-Besatzung: Stärken sammeln · Stärken per Handy sammeln · Objekte mit Plänen · Alarmmonitor: Karte, Termine und Prüffristen · Hydrantenprüfung mit der Fahrzeug-App · Löschwasser-Abdeckung · Fahrtenbuch und Betriebsstunden · Fahrzeugfristen (HU, SP, UVV, Wartung)
- **Teil 4 – Übungen und Demo:** Übungsgenerator · Feuerwehrhäuser und Anfahrtszeiten · Demo- und Übungseinsätze aus realen Einsätzen · Übungsleitstelle – eine Person spielt Fahrzeuge und Leitstelle · Demo-Version für den USB-Stick
- **Teil 5 – Verwaltung und Betrieb:** Seite „E-Mail“ · E-Mail: Versand und Posteingang · Überwachung des Mail-Alarms · Einstellungen neu geordnet · Schnittstellen, Adressen und Schlüssel · Archiv · Jahresauswertung · Datensicherung · Datenschutz: Löschfristen · Änderungsprotokoll · Systemprotokoll · Zustand des Pi · Selbsttest · Programm aktualisieren · Superadmin · Sicherheitsübersicht: Anmeldungen und Geräte · Datenschutzhinweise und Schriften · Jahresbericht und Notfallmappe · ASÜ automatisch auf GitHub veröffentlichen · Verwaltung → Hydranten · Ansprechpartner
- **Anhang:** Versionshistorie (was ist in welcher Version neu)

# Teil 1 – Grundlagen

## Anmeldung und Rollen

- Die Anmeldung prüft der **Pi** (ab 3.17). Benutzer und PINs liegen nur dort, die PIN verschlüsselt. Ohne Anmeldung liefert der Pi keine Daten.
- Ein Gerät bleibt angemeldet, bis man oben auf den Namen tippt („Abmelden“) oder es 60 Tage nicht benutzt wird. Nach 8 falschen PINs ist der Benutzer auf diesem Gerät 10 Minuten gesperrt.
- **Rollen** (vom Pi durchgesetzt): *Betrachter* – nur ansehen. *Einsatzleitung* – alles im Einsatz, Lagekarte, Nachrichten, Übungen. *Admin* – zusätzlich Fahrzeuge, Benutzer, Einstellungen, Objekte, Archiv löschen, Sicherung, Atemschutz-Nachweis.
- Verwaltung → Benutzer: anlegen, Rolle, neue PIN (mindestens 6 Zeichen; die anderen Geräte dieses Benutzers werden dann abgemeldet). Darunter **„Angemeldete Geräte“** mit ⏻ zum Abmelden eines Geräts (z. B. verlorenes Tablet).
- Solange der Admin die **Standard-PIN 1234** hat, erscheint ein Hinweis – bitte ändern.

### PIN-Abfrage vor kritischen Aktionen (ab 3.29)

- Vor folgenden Aktionen fragt die App nach der **eigenen PIN**: Benutzer anlegen/ändern/löschen, Gerät abmelden, archivierten Einsatz löschen, Einstellungen unter „Schnittstellen, Adressen und Schlüssel“ speichern, Programm neu starten, Sicherung herunterladen, gesamte Expositionsliste öffnen oder Eintrag ausblenden, Fahrzeug-App freigeben bzw. „Alle Links erneuern“, Löschfristen „Jetzt anwenden“.
- Nach richtiger PIN gilt die Bestätigung für **5 Minuten** auf diesem Gerät (Einstellung „PIN-Abfrage vor kritischen Aktionen gilt für (Minuten)“, Gruppe Betrieb; 0 = aus). Das Fenster legt sich über das offene Formular – Eingaben bleiben erhalten. „Abbrechen“ führt die Aktion nicht aus.
- Der Pi prüft das selbst: auch ein manipuliertes Gerät kommt ohne PIN nicht weiter. Drei falsche PINs erzeugen einen Sicherheitshinweis, nach acht ist 10 Minuten Pause.

### Sicherheit: Hinweise und Check (ab 3.29, nur Admin)

- Verwaltung → **Sicherheit**:
  - **Sicherheits-Check** mit ✓/!: Standard-PIN noch in Gebrauch, mindestens zwei Admins, PIN-Abfrage an, Datensicherung verschlüsselt, externe Sicherung aktuell, Löschfristen festgelegt, HTTPS, ASÜ-Wehr-Schlüssel – jeweils mit Tipp, wo man es ändert.
  - **Auffälligkeiten** (180 Tage): mehrere fehlgeschlagene Anmeldungen, Anmeldesperre, falsche PIN bei der Bestätigung, Admin-Anmeldung von einem **neuen Gerät** (anderer Browser/anderes System), falscher ASÜ-Schlüssel, Zugriffe mit gesperrten oder ersetzten Fahrzeug-App-Links. Gleiche Ereignisse innerhalb von 6 Stunden werden zu einer Zeile mit Anzahl zusammengefasst. „Gesehen“ bzw. „Alle als gesehen markieren“ (mit Name und Zeit).
  - **Angemeldete Geräte** und **Anmeldungen** aller Apps (ab 5.6, siehe „Sicherheitsübersicht: Anmeldungen und Geräte“).
  - **Löschfristen** (siehe „Datenschutz: Löschfristen“).
- Ungesehene Auffälligkeiten erscheinen bei Admins sofort in der **Hinweis-Zentrale 🔔** (🛡, mit „Gesehen“ und „Details“) und im Änderungsprotokoll (Bereich „Sicherheit“). PINs und Schlüssel stehen nie darin.

## Darstellung: Nachtmodus und Dichte (ab 3.27)

- **Nachtmodus:** Knopf ☼ oben schaltet jetzt Systemvorgabe → Hell → Dunkel → **Nacht**. Nacht ist stark gedimmt und rotstichig, Karten und Bilder werden abgedunkelt – blendet im dunklen ELW nicht und schont die Dunkelanpassung der Augen. Auch unter Verwaltung → Einstellungen → Darstellung.
- **Dichte** (je Gerät): Verwaltung → Einstellungen → Darstellung → „Kompakt“ (mehr auf den Bildschirm, für große Monitore), „Normal“ oder „Komfortabel“ (größer, größere Knöpfe – fürs Tablet). Die Lagekarte bleibt unverändert.

## Schneller bedienen (ab 3.26)

### Suchen mit Strg+F
- **Strg+F** (oder 🔍 oben) öffnet ein Suchfeld für alles: Fahrzeuge (Funkrufname, Typ, Ortsfeuerwehr, Kennzeichen), laufende Einsätze, Objekte, Ansprechpartner, Einträge im Tagebuch, UN-Nummern (4 Ziffern → Gefahrstoffe), Reiter und Einsatz-Bereiche sowie Aktionen („Neuer Einsatz“, „Lagemeldung“, „Kräfte anfordern“, „Nachricht an Fahrzeuge“ …). Ab 4 Zeichen auch „auf der Lagekarte suchen“ für Adressen und Koordinaten.
- **↑ ↓** wählen, **Enter** öffnet, **Esc** schließt. Ein Fahrzeug öffnet sich mit den Status-Knöpfen.
- **Status direkt:** Funkrufname und Status eingeben, z. B. `14-45-20 4` oder `14-45-20 status 3`, dann Enter.

### Tastaturkürzel
| Taste | Wirkung |
|---|---|
| Strg + F | Suchen |
| Strg + M | neue Meldung im Einsatztagebuch (Cursor steht im Textfeld) |
| Strg + Enter | im Tagebuch: Eintragen |
| 1 2 3 4 6 A | im Fenster eines Fahrzeugs: Status setzen |
| 1 … 9 | im Reiter Einsatz: Bereich (1 Übersicht, 2 Tagebuch, 3 Abschnitte, 4 Atemschutz, 5 Aufträge, 6 Fahrzeuge, 7 Nachrichten, 8 Fotos, 9 VU) |
| Umschalt + 1 … 8 | Reiter (1 Einheiten, 2 Ausrüstung, 3 Einsatz, 4 Lagekarte, 5 Objekte, 6 Gefahrstoffe, 7 Archiv, 8 Verwaltung) |
| Strg + Z | letzte Aktion rückgängig (auf der Lagekarte: Zeichnung rückgängig) |
| H | Hinweis-Zentrale |
| Esc | Fenster schließen |
| ? | Übersicht der Kürzel |

Kürzel ohne Strg wirken nur, wenn gerade kein Eingabefeld aktiv ist. Strg+F ersetzt in der Einsatzverwaltung die Browsersuche.

### Mehrere Fahrzeuge auf einmal
- Einsatz → **Fahrzeuge**: Kästchen vor den Fahrzeugen ankreuzen (oben: alle angezeigten). Es erscheint eine Leiste „… ausgewählt“ mit **Status**, **Abschnitt**, **Auftrag** (bei Aufträgen), **✉ Nachricht** und **Entlassen** für alle zusammen. Fahrzeuge aus einem anderen Einsatz werden bei Abschnitt, Auftrag, Nachricht und Entlassen übersprungen (mit Hinweis). Die ganze Aktion lässt sich mit einem Klick rückgängig machen.

### Rückgängig
- Nach einer Statusänderung, dem Wechsel von Abschnitt oder Auftrag, einer Stärkeänderung oder dem Entlassen erscheint unten 10 Sekunden lang **„↶ Rückgängig“** (auch **Strg+Z**). Das stellt den vorherigen Zustand wieder her; im Tagebuch bleiben beide Einträge stehen, der zweite mit „(zurückgenommen)“ – so bleibt nachvollziehbar, was passiert ist.

### Wartende Änderungen
- Ist die Verbindung zum Pi kurz weg, wird eine Aktion nicht mehr abgelehnt: oben erscheint **„⏳ 2 Änderungen warten“**, nach dem Wiederverbinden werden sie übertragen („✓ 2 Änderungen übertragen“). Nach 2 Minuten ohne Verbindung wird eine Änderung verworfen und gemeldet.
- Die App merkt eine hängende Verbindung (z. B. WLAN im Fahrzeug weg) jetzt nach spätestens etwa 25 Sekunden und verbindet neu.
- Hinweis: Die Uhrzeit im Tagebuch ist die der Übertragung. Wichtige Meldungen nach längerem Ausfall ggf. als Nachtrag mit dem richtigen Zeitpunkt erfassen.

### Tagebuch schneller schreiben
- Unter dem Textfeld stehen **Textbausteine** (z. B. „Feuer aus“, „Wasserversorgung aufgebaut“, „Person an Rettungsdienst übergeben“) – antippen fügt sie ein. Eigene Bausteine: Verwaltung → Einstellungen → „Textbausteine im Einsatztagebuch“ (einer je Zeile).
- **„Zuletzt: ↻ …“** zeigt die letzten eigenen Meldungen in diesem Einsatz zum Wiederholen.
- Beim Tippen schlägt das Feld **Funkrufnamen** (erst die im Einsatz), **Abschnitte** und Stellen (Einsatzleitung, Leitstelle, Polizei …) vor: **Tab** oder **Enter** übernimmt, **↑ ↓** wählt, **Esc** schließt den Vorschlag.

### Hinweis-Zentrale
- **🔔** oben (Zahl = offene Hinweise, blinkt bei Notruf) oder Taste **H**: alle offenen Punkte an einer Stelle, jeweils mit Knopf zum Erledigen:
  - Notruf / Sprechwunsch → Quittieren, Fahrzeug öffnen
  - fällige Einsatz-Uhren → Lagemeldung schreiben, Nachgetankt, +10 min
  - ungelesene Nachrichten aus der Fahrzeug-App → Gelesen, Im Einsatz zeigen
  - alarmierte Fahrzeuge ohne Einsatz → Zuordnen
  - Atemschutzüberwachung ohne Meldung (Trupps im Einsatz) → Hinweis
  - Unwetterwarnungen → Anzeigen (zählen nicht mit)
  - nur Admins: Sicherheitshinweise 🛡 → Gesehen, Details (ab 3.29)

## Mehrere Bildschirme (ab 3.24)

Einzelne Reiter oder Bereiche aus dem Einsatz lassen sich in **eigenen Fenstern** öffnen und auf einen 2. oder 3. Bildschirm legen, z. B. Lagekarte links, Einsatztagebuch rechts, Fahrzeuge auf dem dritten Bildschirm.

- **Knopf ⧉ oben im Kopf** (neben Hell/Dunkel): Liste aller Reiter (Einheiten, Ausrüstung, Einsatz, Lagekarte, Objekte, Gefahrstoffe, Archiv, Verwaltung) und aller Bereiche aus dem Einsatz (Übersicht, Einsatztagebuch, Abschnitte, Atemschutz, Aufträge, Fahrzeuge, Nachrichten, Fotos, VU, Checklisten, Nachbereitung). Antippen öffnet das Fenster.
- **Im Einsatz**: das kleine **⧉ rechts in der Bereichsleiste** öffnet den gerade gewählten Bereich direkt in einem eigenen Fenster.
- Das Fenster zeigt nur diesen Bereich, ist **voll bedienbar** und bleibt **live** (eigene Verbindung zum Pi, keine neue Anmeldung nötig). Oben im Fenster:
  - Auswahl, was das Fenster zeigen soll (jederzeit umstellbar),
  - **⛶ Vollbild** (Esc beendet),
  - **Hauptfenster** holt das Hauptfenster nach vorn.
- **Alle Fenster zeigen denselben Einsatz**: Wird in einem Fenster ein anderer Einsatz gewählt, wechseln alle anderen mit.
- Das Fenster einfach auf den gewünschten Bildschirm ziehen – Größe und Position werden gemerkt und beim nächsten Öffnen wieder genutzt. Ein zweites Öffnen desselben Bereichs holt das vorhandene Fenster nach vorn statt ein neues zu öffnen.
- In Chrome/Edge über **https** (bzw. direkt am Pi) erscheint im ⧉-Menü zusätzlich **„Bildschirme erkennen“**: nach einmaliger Erlaubnis „Fenster verwalten“ kann man wählen, auf welchem Bildschirm das Fenster bildschirmfüllend aufgeht. Über normales http im Netz lassen Browser das nicht zu – dann das Fenster einmal hinüberziehen.
- Blockiert der Browser das Fenster, für die Adresse der Einsatzverwaltung **Pop-ups erlauben** (Symbol rechts in der Adresszeile).

### Arbeitsplätze (ab 3.25)

- Im ⧉-Menü unter **„Arbeitsplätze“**: erst die gewünschten Fenster öffnen und auf die Bildschirme legen, dann einen Namen eingeben (z. B. „ELW – 3 Bildschirme“) und **„Offene Fenster speichern“**. Gemerkt werden alle offenen Fenster mit Bildschirm, Größe, Anzeige-Modus und welches Fenster die Töne bekommt.
- **„Öffnen“** öffnet alle Fenster des Arbeitsplatzes auf einmal; schon offene Fenster werden nicht doppelt geöffnet. Mehrere Arbeitsplätze sind möglich (z. B. „Normaleinsatz“, „Unwetterlage“), **✕** löscht einen.
- **„beim Start“**: dieser Arbeitsplatz öffnet sich automatisch, sobald die Einsatzverwaltung im Hauptfenster geöffnet wird. Lässt der Browser das nicht zu, erscheint oben der Hinweis **„Jetzt öffnen“**.
- Arbeitsplätze gelten nur für das Gerät, auf dem sie gespeichert wurden (jeder PC hat andere Bildschirme). Damit sich mehrere Fenster auf einmal öffnen, im Browser für die Adresse der Einsatzverwaltung **„Pop-ups und Weiterleitungen immer erlauben“** einstellen.

### Auf der Karte im anderen Fenster zeigen (ab 3.25)

- **📍** bei den Fahrzeugen (Einsatz → Fahrzeuge), **„📍 auf der Karte“** bei eingezeichneten Abschnitten sowie „auf der Karte“ bei Aufträgen, Fotos, Bereitstellungsraum und Objekten: Ist in einem anderen Fenster die **Lagekarte** offen, springt diese dorthin und hebt die Stelle einige Sekunden mit einem roten Ring und Namen hervor – das eigene Fenster bleibt, wo es ist. Ohne Kartenfenster wechselt das eigene Fenster wie bisher zur Karte.

### Töne und Meldungen nur in einem Fenster (ab 3.25)

- Töne und kurze Meldungen (Einsatz-Uhren, Nachricht aus der Fahrzeug-App, **Sprechwunsch** und **Notruf** – beide ab jetzt auch mit Ton) kommen nur in **einem** Fenster, nicht mehrfach. Vorgabe: das Hauptfenster.
- Umstellen: im Nebenfenster oben **„🔕 still“** antippen → **„🔔 Töne hier“** (nochmal antippen = zurück zum Hauptfenster), oder im ⧉-Menü unter „Töne und Meldungen“. Wird das gewählte Fenster geschlossen, übernimmt automatisch das Hauptfenster. Anzeige-Fenster bekommen nie Töne.
- Die Hinweise oben im Kopf (fällige Uhren, Warnungen, neue Nachrichten) sieht man weiterhin in allen Fenstern.

### Anzeige-Modus für Wandbildschirme (ab 3.25)

- Im ⧉-Menü **„Als Anzeige öffnen“** ankreuzen, dann den Bereich wählen – oder in einem offenen Nebenfenster oben **„🖥 Anzeige“**. Anzeige heißt: nur lesen, große Schrift, keine Knöpfe und Eingabefelder. Die Leiste oben blendet sich aus und erscheint bei Mausbewegung wieder (**A− / A+** Schriftgröße, **✎ Bedienen** zurück zum normalen Fenster, **⛶ Vollbild**).
- Der Bildschirm geht nicht in den Ruhezustand (Chrome/Edge über https oder direkt am Pi; sonst Energiesparen am PC abschalten). Bricht das Netz ab, verbindet sich die Anzeige von selbst wieder.
- **Anzeigen für Wandbildschirme** im ⧉-Menü:
  - **Status-Tableau**: alle Fahrzeuge der Gemeinde (umschaltbar: alle / nur im Einsatz, Status 6 ausblenden) nach Ortsfeuerwehr, Status groß und farbig, mit Einsatz und Uhrzeit; Sprechwunsch und Notruf blinken. Oben die Summen je Status.
  - **Einsatz-Uhren**: Einsatzdauer groß (Sekunden), Lagemeldung und Notstromaggregat mit Restzeit (gelb unter 5 Minuten, rot blinkend wenn fällig), Fahrzeuge und Stärke, Atemschutztrupps im Einsatz. Bei mehreren Einsätzen nebeneinander.
  - **Lagetisch** (ab 5.138): Karte mit Einsatzort und Fahrzeugen in der Mitte; links **Jetzt wichtig** (Notruf/Sprechwunsch, fällige oder bald fällige Uhren, offene Aufträge, ASÜ ohne Meldung, Trupps unter Atemschutz); rechts die Fahrzeuge im Einsatz mit Status als Zahl und Wort; unten der **Zeitstrahl** mit den letzten Tagebucheinträgen und der nächsten fälligen Lagemeldung (gestrichelt). Zeigt den gewählten Einsatz, ohne Einsatz die Uhrzeit.
  - **Lagekarte als Anzeige**: nur die Karte, bildschirmfüllend; sie stellt sich jede Minute so ein, dass Einsatzort, Fahrzeuge, Marker und Aufträge im Bild sind.
  - Jeder andere Reiter oder Einsatz-Bereich geht ebenfalls als Anzeige (z. B. Einsatztagebuch).

## Adresssuche

Alle Adresssuchen (Einsatz, Auftrag, Bereitstellungsraum, Objekt, Lagekarte) suchen zuerst in **31855 Aerzen**, z. B. „Hauptstraße 5“. Steht eine Postleitzahl oder ein Komma in der Eingabe („Bahnhofstraße 3, Hameln“), wird genau danach gesucht; findet sich in Aerzen nichts, ebenfalls. Anderer Standardort über `GEOCODE_ORT` in der Dienstdatei.

# Teil 2 – Im Einsatz

## Einsatz

- **Eröffnen:** Reiter „Einsatz“ → „+ Neuer Einsatz“. Felder: Stichwort (z. B. B3, TH1), Meldebild, Alarmzeit, Einsatzort mit „Suchen“ (Adresssuche über OpenStreetMap, setzt die Koordinate), Einsatzleiter, Meldender, Bereitstellungsraum, Notiz. Die Einsatznummer vergibt der Server fortlaufend je Jahr (2026-001, 2026-002 …).
- **Mehrere Einsätze:** Rechts neben den Reitern steht je laufendem Einsatz ein Schalter und „+ Neuer Einsatz“ (am Handy oben in der Einsatzansicht). Die Auswahl gilt nur für dieses Gerät.
- **Kopfzeile:** In der Mitte oben stehen für den gewählten Einsatz immer die Zahl der Fahrzeuge, die Stärke F/M/G und die Atemschutzgeräteträger (mit „unter AS“ aus der ASÜ). Antippen führt zum Einsatz.
- **Reiter im Einsatz** (Reihenfolge ab 3.91): Übersicht · Tagebuch · Aufträge (nur Sonderlage) · Fahrzeuge · Abschnitte · Lagekarte · Nachrichten (mit Unterreiter Fotos) · Atemschutz · Gefahrstoff (nur mit eingetragenem Stoff) · VU · Checklisten · Nachbereitung · Zeitstrahl. Die Leiste bleibt beim Scrollen stehen.
  - *Übersicht:* Kopfdaten, **Einsatzbericht (PDF)**, Einsatz beenden, aktuelle Unwetterwarnung, **Einsatz-Uhren** und eigene **Timer**, Objekte, **☣ Gefahrstoffe** (Eintragen über die Gefahrstoffdatenbank, „Einsatzblatt“ springt in den Reiter Gefahrstoff), letzte Lage, Kräfteanforderungen. Lagekarte und Einsatztaktik erreicht man über den Reiter Lagekarte.
  - *Tagebuch:* **Meldung**, Vermerk, **Lagemeldung** und **Anforderung** in einem Formular. Der Eingabebereich bleibt beim Scrollen oben stehen; der Diktierknopf 🎤 steht rechts neben dem Inhaltsfeld. Eine Meldung mit Melder „ELW“ wird als Ausgang, alle anderen als Eingang gebucht. **Von/An** sind freie Felder mit Vorschlagsliste (eingesetzte Kräfte, ELW, Einsatzleiter, Leitstelle, Abschnitte, früher eingetragene Gesprächspartner); **⇄** tauscht Sender und Empfänger. **Nachtrag:** Haken „Nachtrag mit früherem Zeitpunkt“ setzen und Datum/Uhrzeit wählen – der Eintrag bekommt die nächste Nummer, steht mit der früheren Uhrzeit im Tagebuch und ist deutlich als „NACHTRAG · erfasst hh:mm“ markiert (auch im Druck und in der CSV). Nicht in der Zukunft und höchstens 12 Stunden vor der Alarmierung. Was man tippt, bleibt bei Live-Aktualisierungen erhalten.
  - *Aufträge:* erscheint nur bei einer Sonderlage. Übersicht mit den Spalten **Neu · Disponiert · In Arbeit · Bereitstellungsraum** und darunter „Erledigt / storniert“ (siehe „Großschadenslage“).
  - *Fahrzeuge:* alle Fahrzeuge in laufenden Einsätzen mit Suche nach Funkrufname, Typ, Wehr, **Ausrüstung**, Einsatz, Abschnitt oder Auftrag (gefundene Ausrüstung wird angezeigt). Darunter die **Kategorien** (Atemschutz, Löschmittel, Strom …) und die Auswahl **„Ausrüstung“** mit allen Gegenständen, die auf Fahrzeugen im Einsatz verlastet sind. **✉** schickt dem Fahrzeug eine Nachricht. Die **Stärke** (F, UF, M, AGT) lässt sich direkt in der Liste ändern; gespeichert wird beim Verlassen des Feldes oder mit Enter.
  - *Abschnitte:* oben gelb gestrichelt alle **freien** Fahrzeuge, darunter jeder Abschnitt als Karte in seiner **Farbe** mit Leiter, Kanal, Auftrag und Fahrzeugen. **Unterabschnitte** („+ UA“) hängen direkt unter ihrem Abschnitt, mit einer Linie in dessen Farbe verbunden. Der **Bereitstellungsraum** steht als schmale Leiste rechts (nur Funkrufname und Fahrzeug bzw. Funktion) – antippen klappt ihn auf. Fahrzeuge am Griff ⠿ in einen Abschnitt, in den Bereitstellungsraum oder zurück nach „Frei“ ziehen. ✎ bearbeitet den Abschnitt.
  - *Lagekarte:* siehe Kapitel „Lagekarte“. Die Reiterleiste mit den Zahlen bleibt über der Karte stehen, darunter Lagekarte/Einsatztaktik und Vollbild.
  - *Nachrichten:* Unterreiter **💬 Nachrichten** (Austausch mit den Fahrzeugen, siehe unten) und **📷 Fotos** (Fotodokumentation).
  - *Atemschutz:* Truppstatus-Zahlen und alle Daten der geteilten ASÜ-Überwachungen (Trupps, Namen, Geräte, Einsatzzeit, letzter Druck, Status, führendes Gerät), alle 5 Sekunden aktualisiert. „Zuschauen“ öffnet die Überwachung in der ASÜ nur zum Ansehen.
  - *Gefahrstoff:* erscheint, sobald am Einsatz ein Gefahrstoff eingetragen ist – je Stoff das komplette Einsatzblatt (siehe „Gefahrstoffdatenbank“).
  - *VU:* Unfallfahrzeuge (siehe „Verkehrsunfall“).
  - *Checklisten:* abhakbare Listen passend zum Stichwort (siehe „Checklisten“).
  - *Nachbereitung:* je Fahrzeug Einsatzbereitschaft, verbrauchtes Material, Defekte und Atemschutzgeräte (siehe „Nachbereitung“).
  - *Zeitstrahl:* alle Ereignisse des Einsatzes auf einer Zeitachse (siehe „Einsatz-Zeitstrahl“).
- **Kopf:** Stichwort, Meldebild, Nummer, Alarmzeit, laufende Dauer, Einsatzort, Einsatzleiter, Bereitstellungsraum. „Bearbeiten“ ändert die Daten; Änderungen stehen im Tagebuch.
- **Beenden:** „Einsatz beenden“ öffnet den **Abschluss-Assistenten** (Prüfen → Stärke → Atemschutz → Material & Schäden → Exposition → Beenden; jeder Schritt und der ganze Assistent lassen sich überspringen, siehe „Neu in 5.131“). Danach setzt das Programm noch aktive Fahrzeuge auf Status 2, archiviert Einsatz, Tagebuch, Zeiten, Stärke, Anforderungen, Lagemeldungen und ASÜ-Zahlen und zeigt den Einsatzbericht.

## Einsatztagebuch (nach FwDV 100)

- Fortlaufende Nummer, Uhrzeit, Art (Eingang, Ausgang, Vermerk), Von, An, Inhalt, erfasst von.
- Einträge lassen sich nicht ändern oder löschen. „Korrigieren“ legt einen neuen Eintrag an; der ursprüngliche wird durchgestrichen und verweist auf die Korrektur.
- Automatisch eingetragen werden: Eröffnung, Datenänderungen, Statuswechsel, Sprechwunsch/Notruf, Stärkemeldungen, Anforderungen, Lagemeldungen, Abschnitte, ASÜ-Meldungen, Beendigung. „Statusmeldungen zeigen“ blendet die automatischen Statuszeilen aus.
- Nummern vergibt der Server. Auch wenn mehrere Geräte gleichzeitig schreiben, geht nichts verloren.
- Drucken und CSV direkt in der Karte „Einsatztagebuch“.

## Einsatz-Uhren (Notstromaggregat, Lagemeldung)

- **Notstromaggregat:** Die Tankuhr läuft ab Einsatzbeginn (Alarmzeit). Nach **1:30 h** erscheint oben auf allen Geräten rot „Notstromaggregat nachtanken“ mit Ton. **„Nachgetankt ✓“** startet die Uhr neu (nächste Erinnerung wieder nach 1:30 h) und vermerkt es im Tagebuch; „+10 min“ erinnert später.
- In der Übersicht unter „Einsatz-Uhren“: Restzeit, „Nachgetankt“, „aus“ (Aggregat außer Betrieb, Uhr hält an) und **„+ Aggregat“** für weitere Stromerzeuger mit eigener Uhr (z. B. „Stromerzeuger LF 14-01-1“).
- **Lagemeldung:** Erinnerung alle **30 Minuten** seit Einsatzbeginn bzw. seit der letzten Lagemeldung (orange Leiste mit Ton). „Lagemeldung schreiben“ öffnet das Tagebuch mit Lagemeldung; sobald sie eingetragen ist, beginnt die Uhr neu. „+10 min“ verschiebt (steht im Tagebuch).
- **Einstellen:** Verwaltung → Einstellungen → „Einsatz-Uhren“: Minuten für Lagemeldung und Tankuhr (0 = aus) und ob die Tankuhr bei jedem Einsatz automatisch startet. Ist das abgeschaltet, legt man Aggregate im Einsatz mit „+ Aggregat“ an.
- Der Ton kommt erst, nachdem man einmal auf der Seite getippt hat (Regel der Browser).

## Stärke

Format Führer / Mannschaft / Gesamt, z. B. 1/8/9, dazu die Zahl der Atemschutzgeräteträger (AGT). Je Fahrzeug über den Stärke-Knopf oder die Fahrzeug-App; „Stärkemeldung“ zeigt die Summe des Einsatzes. Die Kachel „Atemschutzgeräteträger“ stellt die gemeldeten AGT den Personen gegenüber, die die ASÜ unter Atemschutz meldet.

## FMS-Status

| Status | Bedeutung | Wirkung |
|---|---|---|
| 1 | Einsatzbereit über Funk | frei; verlässt den Einsatz |
| 2 | Einsatzbereit auf Wache | frei (Grundzustand); verlässt den Einsatz |
| A | Alarmiert | wird dem Einsatz zugeordnet |
| 3 | Einsatzauftrag übernommen | im Einsatz |
| 4 | Am Einsatzort | im Einsatz |
| 6 | Nicht einsatzbereit | außer Dienst; verlässt den Einsatz |
| 5 / 0 | Sprechwunsch / Notruf | blinkt am Fahrzeug, bis er quittiert wird |

„A“ ist kein FMS-Status, sondern markiert die Alarmierung, bevor das Fahrzeug Status 3 meldet. Jeder Wechsel wird mit Uhrzeit gespeichert und im Tagebuch vermerkt. Daraus entstehen im Bericht die Zeiten je Fahrzeug (Alarm, S3, S4, frei, Dauer) sowie Fahrzeug- und Personalstunden.

Den Status setzt man am Status-Knopf jedes Fahrzeugs (Einheiten, Ausrüstung, Einsatz, Lagekarte) oder die Besatzung selbst in ihrer Fahrzeug-App.

## Kräfteanforderung

Einsatztagebuch → „Anforderung“ (oder „+ Anfordern“ in der Übersicht): was (Funkrufname aus der Liste oder freier Text wie „Drehleiter“), Anzahl, Grund, Anfahrt (Standard: Bereitstellungsraum), an wen. Ablauf: angefordert → alarmiert → unterwegs → eingetroffen (oder storniert). Ist ein Fahrzeug aus der Liste angefordert, folgt die Anforderung automatisch seinem Status (A → alarmiert, 3 → unterwegs, 4 → eingetroffen). Auf Wunsch wird es beim Anfordern gleich auf „A“ gesetzt.

## Lagemeldung und Abschnitte

- **Lagemeldung:** Freitext mit Zeitstempel, optional an eine Stelle (Leitstelle). Die letzte Lage steht als Kachel in der Einsatzansicht, alle im Bericht.
- **Abschnitte:** Name, Abschnittsleiter und Funkkanal. Fahrzeuge werden per Auswahl einem Abschnitt zugeteilt.

## Lagekarte

**Aufruf (ab 3.94):** Einsatz → Reiter **Lagekarte**. Ohne laufenden Einsatz über den Knopf „🗺 Lagekarte“ im Reiter Einsatz. Die Suche (Strg+F), „In der Lagekarte zeigen“ und Koordinaten (`52.04, 9.26`) bzw. what3words-Adressen (`///wort.wort.wort`) springen ebenfalls in die Karte. Die Ansicht bleibt dabei wie im Einsatz: Hauptreiter „Einsatz“ bleibt markiert, die Reiterleiste mit den Zahlen steht über der Karte, darunter **Lagekarte / Einsatztaktik** und **Vollbild**.

**Vollbild:** zeigt nur die Karte mit den Werkzeugen – ohne Kopf und Reiterleiste. „Vollbild beenden“ bzw. „← Zurück“ (nur im Vollbild) führt zurück.

**⌂ Startansicht:** zeigt 1 km um das Gerätehaus (Vorgabe 52.05477, 9.23712). Mittelpunkt und Umkreis lassen sich unter Verwaltung → Einstellungen ändern.

**Posterdruck (ab 3.92):** Werkzeuge → Karte → „📷 Ausschnitt / Poster“, Bereich aufziehen, dann „🖨 Posterdruck“. *Auf mehrere Blätter:* Blattformat (A4/A3) und **Anzahl Blätter** (1–36) wählen – die passende Anordnung (Spalten × Reihen, hoch/quer) wird ausgesucht, unter „Anordnung“ lässt sich eine andere wählen. *Eine große Seite:* A4 bis A0 für Plotter, Copyshop oder PDF. Die **Vorschau** zeigt Karte, Überschrift, Blattgrenzen, Blattnummern und Klebekanten, dazu Postergröße und Maßstab. Im Druckdialog „Tatsächliche Größe“ bzw. 100 % wählen.

**Aufbau ab 3.32:** Alle Werkzeuge stehen links in einer Seitenleiste mit Bereichen zum **Auf- und Zuklappen** (Überschrift antippen):

- **Zeichnen und Werkzeuge** – gegliedert in *Messen und Zeichnen* (Messen, Kreis, Zeichnen, Fläche, Suchraster, in der Einsatztaktik die Schlauchleitungen, Pfeile/Text, Koordinate abfragen), *Lage und Taktik* (Gefahrenkreis, Ausbreitungskegel, Abschnitt einzeichnen, Auftrag auf der Karte, DLK, Vorlage) und *Karte* (Kartenbild/Lageplan, Lagestände, Sperren, Drucken, Zeitraffer, Karte leeren).
- **Marker** bzw. in der Einsatztaktik **Symbole und Taktik**.
- **Fahrzeuge** des Einsatzes.
- **Anzeigen** – Ebenen (Fahrzeuge, Abschnitte, Marker, Fotos, Zeichnungen, Aufträge, Objekte, Wasserentnahmestellen, Radar, Warnkarte), Fahrzeugdarstellung sowie Marker- und Fahrzeug-Größe.

Auch die **Untergruppen** lassen sich auf- und zuklappen: bei den Werkzeugen *Messen und Zeichnen*, *Lage und Taktik* und *Karte* (rechts die Zahl der Knöpfe), in der Einsatztaktik die Symbolgruppen (*Lage*, *Einheiten, Führung, Fahrzeuge*, *Wasser & Löschen* …). Welche Bereiche und Untergruppen offen sind, merkt sich jedes Gerät; die Gruppe mit dem gerade aktiven Werkzeug öffnet sich von selbst. Am Handy sind die Untergruppen immer offen. **◀** oben in der Leiste klappt die ganze Leiste ein – die Karte wird breiter; **▶ Werkzeuge** links neben der Suche holt sie zurück. Über der Karte bleiben nur **↶ ↷** (Rückgängig/Wiederherstellen) und die Suche. Ist ein Werkzeug gewählt, zeigt ein blauer Hinweis über der Karte „Aktiv: …“ mit **Beenden ✕** – auch wenn sein Bereich zugeklappt ist. Am Handy stehen die Bereiche übereinander, ihr Inhalt lässt sich waagerecht wischen.

**Kartenausschnitt und Posterdruck (ab 3.33):** Werkzeuge → Karte → **„📷 Ausschnitt / Poster“**, dann auf der Karte ein Rechteck aufziehen (die Größe in Metern steht dabei im Rahmen). Es öffnet sich das Fenster „Kartenausschnitt“ mit einem Bild des Bereichs – mit Kopfzeile (Lagekarte bzw. Einsatztaktik, Einsatz, Stand), allen sichtbaren Symbolen, Zeichnungen, Abschnitten und Fahrzeugen, Nordpfeil, Maßstab und Quellenangabe. Satellitenbild, Radar und eigenes Kartenbild werden nicht übernommen.

- **✉ An Fahrzeuge senden** (Einsatzleitung, Admin): öffnet „Nachricht an Fahrzeuge“ mit dem Bild als Anhang und einem Vorschlagstext; Fahrzeuge wählen, senden. Die Besatzung sieht das Bild in der Fahrzeug-App, Nachricht und Bestätigung stehen im Tagebuch.
- **⬇ Als Bild speichern:** PNG-Datei, z. B. für E-Mail oder Lagebesprechung.
- **🖨 Posterdruck:** Postergröße A4 bis A0, Ausrichtung (passend zum Bereich, quer, hoch), Überschrift/Bemerkung und
  - *eine Seite in Postergröße* – für Plotter, Copyshop oder als PDF (Seitengröße exakt A2/A1/A0), oder
  - *auf A4- bzw. A3-Blätter verteilt* – jedes Blatt mit „Blatt 3/9 · Reihe 1, Spalte 3“ und 1 cm roter Klebekante; die Klebekante kommt unter das vorige Blatt. Kleine Reste am Rand fallen weg, das Poster wird dafür minimal kleiner.

  Angezeigt werden der Maßstab (ca. 1:…) und die Zahl der Blätter. Ist der Bereich für das Format sehr klein, warnt die App, dass die Karte unscharf wird. Vor dem Druck lädt die App die nötigen Kartenkacheln (höchstens rund 160, aus Rücksicht auf den Kartenserver) – im Druckdialog „Als PDF speichern“ oder den Drucker wählen, Skalierung „Standard/100 %“.
- Betrachter können Ausschnitte als Bild speichern und drucken, aber nicht an Fahrzeuge senden. Ohne laufenden Einsatz geht das Werkzeug ebenfalls (nur Karte, Objekte, Wasserentnahmestellen).

**Neu in 3.21:**

- **Fahrzeuge als taktisches Zeichen (DV 102):** Fahrzeuge erscheinen als Fahrzeug-Zeichen (Rechteck mit Rädern) mit Kürzel aus dem Fahrzeugtyp – Drehleitern mit Leiter, Führungsfahrzeuge mit Fahne. Über **„🚒 Fahrzeugdarstellung“** in der Zeile „Anzeigen“ per Häkchen wählen, was gezeigt wird: taktisches Zeichen (sonst das bisherige Kästchen), Fahrzeugtyp, Funkrufname, Status, Zusätze (GPS, Auftrag, Abschnitt). Die Einstellung gilt je Gerät und auch für Druck und Einsatzbericht.
- **Einheiten- und Fahrzeugzeichen** in der Einsatztaktik (Gruppe „Einheiten, Führung, Fahrzeuge“): Trupp, Staffel, Gruppe, Zug, Verband, Einsatzleitung, Abschnittsleitung und Fahrzeugzeichen (LF, HLF, TLF, DLK, RW, ELW, GW, MTF) z. B. für Kräfte der Nachbarwehren. Beschriftung wie bei allen Symbolen durch Antippen.
- **Pfeile, Linien, Text** (Knopf „➚ Pfeile/Text“): Angriffsrichtung, Vormarschweg, Rückzugsweg, Anfahrtsweg (mit Pfeilspitze in Zugrichtung), Absperrgrenze (rot-weiß), Abschnittsgrenze und Gefahrenbereich (umfahren). Linien werden beim Loslassen geglättet. Antippen: Beschriftung, Sperren, Löschen. **Text:** Stelle antippen, bis zu 4 Zeilen, Größe und Farbe wählbar; Text gedrückt halten zum Verschieben.
- **Drehleiter-Aufstellfläche** (Knopf „🪜 DLK“, in beiden Karten): Standort des Drehkranzes antippen, Modell (DLK 23/12, DLK 18/12, DLK 30/12, Hubrettungsbühne 32 m), Bezeichnung und Ausrichtung (Fahrtrichtung) wählen. Gezeichnet werden Fahrzeugumriss, Abstützfläche, der Kreis der Nennausladung (z. B. 12 m bei 23 m Rettungshöhe) und gestrichelt die größte Ausladung (änderbar). Auf Wunsch wird die Drehleiter des Einsatzes auf der Lagekarte dorthin gesetzt. Verschieben durch Ziehen am Fahrzeug oder inneren Kreis. Anhaltswerte – maßgeblich sind Arbeitsdiagramm und Untergrund.
- **Lagestände** (Knopf „📌 Lagestände“): den jetzigen Stand der offenen Karte mit Namen speichern (Symbole, Zeichnungen, Fahrzeuge mit Position und Status, Abschnittsbereiche). Gespeicherte Stände: **Ansehen**, **Drucken/PDF** (A4 quer), **Vergleich mit jetzt** (hinzugekommen, verändert – z. B. „Status 3 → 4“, „um 40 m verschoben“ –, weggefallen) und Häkchen **„Bericht“** (dann als eigene Karte im Einsatzbericht). Das Speichern steht im Einsatztagebuch; Lagestände werden mit dem Einsatz archiviert.
- **Sperren:** In jedem Symbol- und Zeichnungsfenster „Sperren“; gesperrte Teile tragen ein 🔒, lassen sich nicht verschieben und nicht löschen (auch nicht von anderen Geräten und nicht mit „Karte leeren“). Knopf „🔒 Sperren“: alle Symbole bzw. alle Zeichnungen auf einmal sperren oder entsperren.
- **Vorlagen** (Knopf „🧩 Vorlage“): VU-Absicherung mit Arbeitsbereich, Löschangriff (Pumpe, Verteiler, 2 C-Rohre), Wasserversorgung Hydrant → Pumpe → Verteiler, Riegelstellung mit zwei Wenderohren, Gefahrstoff mit Gefahren- und Absperrbereich (FwDV 500). Vorlage wählen, Mitte antippen, Ausrichtung einstellen (Schieber oder ↑ → ↓ ←), „Übernehmen“. Danach ist jedes Teil einzeln änderbar; einmal „Rückgängig“ entfernt die ganze Vorlage.
- **Wichtige Symbole ins Einsatztagebuch:** Beim Setzen z. B. von Schadensstelle, Person in Gefahr, Gefahr, Bereitstellungsraum, Einsatzleitung, Sammelstelle, Person eingeklemmt, Hochvolt, DLK-Aufstellfläche, Gefahrenbereich oder Absperrgrenze entsteht automatisch ein Vermerk mit Lage zum Einsatzort und UTMREF, z. B. „Lagekarte: Gefahr eingezeichnet – ca. 40 m nordöstlich des Einsatzorts · 32U NC …“. Welche Symbole das sind, legt der Admin unter Verwaltung → Einstellungen fest: Das Feld zeigt zugeklappt „11 von 51 …“ mit den gewählten Symbolen; antippen öffnet die Auswahlliste mit Suche, Gruppen (Lagekarte, Einsatztaktik-Gruppen, Zeichnungen) samt Zähler und „alle/keine“ je Gruppe. Jedes Häkchen wird sofort gespeichert; „Fertig“, Esc oder ein Klick daneben schließt die Liste (ab 3.34).
- Die Werkzeugleiste ist auf Bildschirmen mit wenig Höhe (z. B. Tablet quer) einzeilig und seitlich wischbar; die Karte passt ihre Höhe an, damit sie ganz auf den Bildschirm passt. Für die größte Fläche: „Vollbild“.

**Neu in 3.19:**

- **Rückgängig / Wiederherstellen:** Knöpfe ↶ ↷ ganz links in der Werkzeugleiste oder Strg+Z / Strg+Y (Strg+Umschalt+Z). Gilt für alle eigenen Änderungen an der gerade offenen Karte (Symbole, Zeichnungen, Fahrzeugpositionen, Leeren der Karte), bis zu 50 Schritte je Karte. Rückgängig nimmt nur die eigenen Änderungen zurück, nie die eines anderen Geräts. Der Verlauf gilt, solange die Seite offen ist.
- **Mehrere Bearbeiter gleichzeitig:** Jedes Gerät schickt nur noch seine Änderungen an den Pi, nicht mehr die ganze Karte. Setzen zwei Geräte gleichzeitig Symbole, bleiben beide erhalten. Neben „Lagekarte | Einsatztaktik“ steht, wer die Karte gerade noch offen hat und mit welchem Werkzeug (z. B. „👤 gf – Suchraster“), außerdem „zuletzt geändert … von …“.
- **Karte drucken / als PDF:** Knopf „🖨 Drucken / PDF“ (auch für Betrachter). Papier A4 oder A3, quer oder hoch; Ausschnitt wie auf dem Bildschirm oder „alles zeigen“; optional eine Bemerkung. Der Ausdruck enthält Kopf mit Einsatz und Zeitstempel, Nordpfeil, Maßstabsleiste, Legende der verwendeten Symbole, Leitungen mit Schlauchzahl, Flächen, Abschnitte und die Fahrzeugliste mit Status. Im Druckdialog „Als PDF speichern“ wählen.
- **Schlauchleitungen berechnen** (Einsatztaktik): Die Beschriftung einer Leitung zeigt Länge und Schlauchzahl (B 20 m, C/D 15 m, jeweils + 10 % Reserve; Saugleitung 1,6 m). Leitung antippen öffnet die Berechnung. Bei **B-Leitungen** zusätzlich *Wasserförderung über lange Wegstrecke* (seit 3.51 stark erweitert, siehe eigener Abschnitt „Wasserförderung über lange Wegstrecke“).
- **Fläche messen:** Werkzeug „▰ Fläche“, die Fläche mit Finger oder Maus umfahren. Angezeigt werden Fläche (m² bzw. ha) und beim Antippen der Umfang; dort lässt sich die Fläche benennen (z. B. „Brandfläche“). Kreise zeigen beim Antippen ebenfalls ihre Fläche.
- **Suchraster für die Personensuche:** Werkzeug „▦ Suchraster“, das Suchgebiet als Rechteck aufziehen, Name und Feldgröße (25–500 m) wählen. Die Felder heißen A1, B1 … (Spalten A–Z von links, Zeilen von oben). Feld antippen: Status *offen / wird abgesucht / abgesucht / nicht begehbar*, Trupp oder Fahrzeug, Bemerkung. Jede Änderung von Status oder Trupp kommt ins Einsatztagebuch; der Titel zeigt „x/y abgesucht“. Im Feld-Fenster auch „Suchgebiet umbenennen“ und „entfernen“.
- **Zeitraffer der Lage:** Knopf „⏱ Zeitraffer“ in der Lagekarte bzw. im Archiv beim Einsatzbericht. Mit Schieberegler oder „▶ Abspielen“ (30- bis 600-fach) läuft der Einsatz noch einmal ab: Fahrzeuge folgen ihrer GPS-Spur (sonst ihrer Kartenposition) mit Statusfarbe, Aufträge erscheinen mit ihrem Stand, Symbole und Zeichnungen ab dem Zeitpunkt, an dem sie gesetzt wurden (Einträge aus älteren Versionen sind immer sichtbar). Rechts läuft das Einsatztagebuch mit.

- **Zwei Karten je Einsatz:** Oben rechts „Lagekarte | Einsatztaktik“ (auch Knopf „Einsatztaktik“ in der Einsatzübersicht). Die **Einsatztaktik** ist eine eigene Karte mit allen Funktionen der Lagekarte und zusätzlich:
  - *Wasser & Löschen:* B- und C-Strahlrohr, Wenderohr/Werfer, Schaumrohr, Verteiler, Pumpe (FP/TS), Lüfter, Trupp.
  - *Technische Hilfe / VU:* PKW, LKW/Bus, Fahrzeugbrand, Person eingeklemmt, Rettungsgerät, Stabilisierung, Brandschutz, Geräteablage, Patientenablage, Rettungsdienst, Absicherung/Leitkegel, Betriebsstoffe, Hochvolt/E-Fahrzeug.
  - *Leitungen:* B-, C-, D- und Saugleitung als Werkzeuge – auf der Karte ziehen, Länge wird angezeigt.
  - Strahlrohre, Verteiler und Fahrzeuge lassen sich **drehen** (Symbol antippen → „Ausrichtung“).
  - Ist ein Symbol-Werkzeug aktiv, setzt ein Tippen das Symbol auch dann, wenn darunter ein Fahrzeug oder ein anderes Symbol liegt (es öffnet sich kein Fenster). Werkzeug abwählen, um Fahrzeuge/Symbole wieder anzutippen.
  - Die Einsatztaktik wird mit dem Einsatz archiviert. Der orange Rahmen zeigt, dass man in der Taktikkarte ist.
- **Ausbreitungskegel** (beide Karten): Werkzeug „◭ Ausbreitungskegel“, Austrittsstelle antippen, „Wind aus“ wählen oder „Aktuellen Wind abrufen“ (Open-Meteo, Modellwert, nur online), Länge und Öffnungswinkel (30–90°) setzen. Die gestrichelte Linie zeigt die halbe Länge. Antippen: ändern oder entfernen; am Rand ziehen: verschieben.
- **Satellitenbild:** Knopf 🛰 rechts an der Karte (nur mit Internet am Gerät; Bilder von Esri, werden nicht gespeichert). Ohne Verbindung schaltet die Karte automatisch auf die gespeicherte Straßenkarte zurück.
- **GPS-Fahrzeuge von Hand setzen:** Fahrzeuge mit GPS lassen sich jetzt verschieben. Sie tragen dann „HAND“ statt „GPS“; sobald das Fahrzeug einen neuen FMS-Status meldet, gilt wieder die GPS-Position.
- **Eigener Reiter „Lagekarte“:** jederzeit erreichbar, auch ohne laufenden Einsatz. Dann stehen Karte, Suche (Adresse, Koordinate, what3words, Objekte), „Koordinate abfragen“, Objekte und Wasserentnahmestellen zur Verfügung; Marker, Zeichnungen und Fahrzeuge gehören zu einem Einsatz. Laufen mehrere Einsätze, wird der Einsatz oben in der Kopfzeile gewählt.

- Gehört zum gewählten Einsatz und wird mit allen Geräten geteilt (der Ausschnitt gilt je Gerät).
- **OpenStreetMap, frei verschieb- und zoombar:** mit Finger oder Maus ziehen; zwei Finger, Mausrad, Doppelklick oder +/− zoomen. Knöpfe rechts: **E** zum Einsatzort, **⤢** alles zeigen (Einsatzort, Fahrzeuge, Marker, offene Aufträge), **⌂** Übersicht 50 km um den Heimatort (Verwaltung → Einstellungen, Vorgabe Aerzen).
- **Ohne Internet:** Jede Kachel, die einmal angesehen wurde, speichert der Pi im Ordner `tiles/`. Bereiche vorab ansehen (z. B. das Gemeindegebiet in mehreren Zoomstufen), dann sind sie auch offline da. Nicht gespeicherte Bereiche bleiben grau.
- **Suche** über der Karte: Adresse (OpenStreetMap), Objektname, Auftragsnummer oder eine Koordinate. Koordinaten gehen als Dezimalgrad (`52.04970, 9.26600`), Grad/Minuten/Sekunden (`52°02'58,9"N 9°15'57,6"E`), Grad/Dezimalminuten (`N 52° 02,982 E 9° 15,960`), UTM (`32U 518241 5766599`) und UTMREF/MGRS (`32U NC 18240 66599`, auch ohne Leerzeichen und mit 100-m- oder 10-m-Genauigkeit). Das Fadenkreuz antippen: Koordinate in allen Formaten, Marker setzen, Auftrag anlegen oder als Einsatzort übernehmen.
- **Koordinate abfragen:** Werkzeug wählen und auf die Karte tippen. Unten links stehen außerdem die Koordinaten unter der Maus.
- **Marker** (angelehnt an DV 102): Werkzeug links wählen, auf die Karte tippen. Ziehen verschiebt, Antippen öffnet Beschriftung, Koordinate und „Entfernen“.
- **Fahrzeuge:** mit Status-Symbol, Funkrufname, GPS-Kennzeichen und – bei Großschadenslagen – der Auftragsnummer. Fahrzeuge ohne GPS über die Liste links auf die Karte holen (erscheinen in der Kartenmitte) und hinziehen. Antippen öffnet den FMS-Status.
- **Messen, Kreis, Zeichnen:** auf der Karte ziehen. Strecken und Linien zeigen ihre Länge, Kreise den Radius. **Verschieben:** Linie bzw. Kreisrand gedrückt halten und an die neue Stelle ziehen (Größe und Form bleiben). Antippen zeigt Radius bzw. Länge und „Löschen“.
- **Gefahrenkreis:** Werkzeug „⚠ Gefahrenkreis“, Mittelpunkt antippen, Vorlage wählen oder eigene Radien eintragen (bis zu 6, z. B. „50, 100, 200“) und benennen. Die Ringe werden von innen (rot) nach außen (orange, gelb) gezeichnet und mit ihrem Radius beschriftet; die Bezeichnung steht innen am oberen Rand des inneren Rings (bei sehr kleinem Kreis über dem äußeren Ring), damit das Symbol in der Mitte frei bleibt. Vorlagen: Gefahrstoffe nach FwDV 500 (50/100 m), Gasausströmung (50/100/200 m), Explosionsgefahr (100/300/500 m), Großbrand/Rauch (200/500/1000 m) – nur Anhaltswerte, immer an die Lage anpassen. Antippen eines Rings: ändern oder entfernen. Einen Ring gedrückt halten und ziehen verschiebt den ganzen Gefahrenkreis.
- **Wasserentnahmestellen:** Hydranten (Ü = Überflur, U = Unterflur), Löschwasserbehälter (LB), Saugstellen (S) und Löschteiche (T) aus OpenStreetMap, sichtbar ab etwa 2 km Kartenbreite. Antippen zeigt Nennweite, Inhalt und Koordinate und übernimmt die Stelle auf Wunsch als Marker. Im Koordinatenfenster (Einsatzort, Suchergebnis, „Koordinate abfragen“) stehen die nächsten Stellen mit Entfernung. Der Pi lädt die Daten für 50 km um den Heimatort, speichert sie (offline nutzbar) und erneuert sie alle 30 Tage; von Hand unter Verwaltung → Einstellungen. Die Daten sind nur so vollständig wie OpenStreetMap – vor Ort prüfen.
- **Kartenbild / Lageplan:** eigenes Bild (Lageplan, Feuerwehrplan, Luftbild) maßstäblich über die Karte legen. Breite in Metern, Deckkraft, „Bild verschieben“ zum Ausrichten, wahlweise die Karte darunter ausblenden.
- **Abschnitte auf der Lagekarte:** Werkzeug „▱ Abschnitt einzeichnen“ (oder im Abschnitt „Auf der Lagekarte einzeichnen“), Abschnitt wählen und den Bereich mit Finger oder Maus umfahren. Der Bereich erscheint in der Farbe des Abschnitts mit Name, Leiter und Fahrzeugzahl; Fahrzeuge auf der Karte tragen einen Rahmen und ein Schild in der Abschnittsfarbe. Ebene „Abschnitte“ blendet sie aus.
- **Marker „ASÜ“:** steht für Atemschutzüberwachung (kurzer Name, damit er in die Knöpfe passt).
- **Anzeigen:** Fahrzeuge, Marker, Zeichnungen, Aufträge, Objekte und Wasserentnahmestellen einzeln ein- und ausblenden (je Gerät).
- Karten aus älteren Versionen werden beim ersten Start automatisch auf Geokoordinaten umgestellt; ein früheres OpenStreetMap-Bild wird durch die neue Karte ersetzt, ein eigenes Bild bleibt als Kartenbild erhalten.

**what3words:** Ist auf dem Pi ein what3words-Schlüssel hinterlegt, kann in jeder Adresssuche (Lagekarte, Einsatz, Auftrag, Bereitstellungsraum, Objekt) eine Adresse wie `///tisch.lampe.fenster` eingegeben werden, auch ohne `///`. Bei Tippfehlern schlägt die Suche passende Adressen vor. Das Fenster „Koordinate“ zeigt zusätzlich die what3words-Adresse des Punkts zum Durchgeben an Anrufer oder andere Stellen.

## Farben der Gefahrenkreise (ab 3.38)

Lagekarte → **⚠ Gefahrenkreis** (neu setzen oder einen vorhandenen Kreis antippen): Unter **„Farben der Ringe (von innen nach außen)“** hat jeder Ring eine eigene Zeile mit acht Farben (Rot, Orange, Gelb, Grün, Blau, Violett, Grau, Schwarz) und einem Feld für eine **eigene Farbe**. Kommt ein Radius dazu, erscheint sofort eine weitere Zeile. **„Standardfarben“** stellt rot – orange – gelb – blau wieder her. Die Farben gelten für Lagekarte, Einsatzbericht, Kartenausschnitt/Poster und Lagestände; Kreise ohne eigene Farben behalten die Standardfarben.

## Großschadenslage (Unwetter): Aufträge

- **Reiter „Aufträge“** (ab 3.93): erscheint im Einsatz nur bei einer Sonderlage – also wenn „Großschadenslage“ eingeschaltet ist oder schon Aufträge vorhanden sind.
- **Einschalten:** beim Eröffnen oder unter „Bearbeiten“ den Haken „Großschadenslage“ setzen (bei Stichwort Unwetter/Sturm/Hochwasser automatisch vorgeschlagen).
- **Auftrag anlegen:** „+ Auftrag“ in der Einsatzansicht, auf der Karte mit „+ Auftrag auf der Karte“ (Adresse wird zur angetippten Stelle nachgeschlagen) oder aus einem Suchergebnis. Felder: Kategorie, Priorität (1 sofort, 2 dringend, 3 kann warten – optional, ab 3.71 ohne Vorgabe), Priolage (Leitstelle), Adresse/Koordinate, Objekt, Meldender, Rückruf, Beschreibung. Nummern vergibt der Server fortlaufend.
- **Bereitstellungsraum:** wird mit der Großschadenslage automatisch eingerichtet. Adresse und Koordinate über „ändern“ im Einsatzkopf oder in der Auftragsübersicht angeben; er erscheint dann auf der Lagekarte. Alle Fahrzeuge der Lage ohne Auftrag stehen im Bereitstellungsraum.
- **Auftragsübersicht:** Knopf „Auftragsübersicht“ (bzw. „Übersicht Neu · Disponiert · BR“) öffnet eine eigene Ansicht mit drei Spalten: **Neu** (offene Aufträge nach Priorität), **Disponiert** (mit Fahrzeugen, „vor Ort“ sobald Status 4) und **Bereitstellungsraum** (freie Fahrzeuge mit Status, Stärke und Entfernung zum BR; „+ Fahrzeuge in die Lage holen“ alarmiert weitere). Zuweisen: Fahrzeug antippen, dann den Auftrag antippen – am PC auch per Ziehen mit der Maus. Ein Fahrzeug aus einem Auftrag zurück in den Bereitstellungsraum ziehen (bzw. antippen und dann den BR antippen) zieht es vom Auftrag ab. Hat ein disponierter Auftrag kein Fahrzeug mehr, fällt er auf „Neu“ zurück. Erledigte Aufträge stehen unten.
- **Kategorien:** Baum/Ast, Wasser/Keller, Dach/Gebäude, Verkehrsweg frei machen, Strom/Gas, Tier, Menschenrettung, Sonstiges – änderbar unter Verwaltung → Einstellungen (eine je Zeile, Symbol und Name).
- **Liste:** oben die Zahlen je Status, darunter die freien Fahrzeuge der Lage. Filter nach Status und Kategorie, Suche, Drucken und CSV. Sortiert nach Status, dann Priorität, dann Wartezeit. Prio-1-Aufträge blinken auf der Karte, solange sie offen sind.
- **Disponieren:** im Auftrag „+ Fahrzeug disponieren“ (freie Fahrzeuge der Lage mit Entfernung per GPS, Fahrzeuge auf anderen Aufträgen, weitere Fahrzeuge zum Alarmieren) oder ein freies Fahrzeug oben antippen und den Auftrag wählen. Ein freies Fahrzeug bekommt dabei Status „A“.
- **Status:** offen → disponiert (beim ersten Fahrzeug) → in Arbeit (sobald ein Fahrzeug Status 4 meldet) → erledigt oder storniert. Meldet ein Fahrzeug Status 1 oder 2, wird es vom Auftrag frei und bleibt in der Lage (ab 3.52: laufen mehrere Einsätze, verlässt es mit Status 2 die Lage) für den nächsten Auftrag; mit Status 6 oder „Aus der Lage entlassen“ verlässt es die Lage.
- **Auftragstagebuch:** jeder Auftrag hat ein eigenes Tagebuch (Eingang/Ausgang/Vermerk, Korrektur als neuer Eintrag). Aufnahme, Disposition, Statusmeldungen und Änderungen stehen automatisch darin.
- **Überführung:** Mit „Erledigt“ oder „Storniert“ wird das Auftragstagebuch mit einem Kopfeintrag (Kategorie, Ort, Zeiten, Fahrzeuge, Ergebnis) in das Einsatztagebuch des Haupteinsatzes übernommen; die Einträge tragen die Kennung „A12“ und die ursprüngliche Uhrzeit. Wird ein Auftrag wieder geöffnet und erneut abgeschlossen, folgen nur die neuen Einträge. Beim Einsatzende werden alle noch nicht übernommenen Aufträge übernommen.
- **Einsatzbericht und Archiv:** Auftragsliste mit Ergebnis im Bericht, „Aufträge als CSV“.

## Bereitstellungsräume mit Handy-Link (ab 3.50)

Ein Einsatz kann **mehrere Bereitstellungsräume** haben (BR 1, BR Nord, …). Für jeden Raum gibt es einen eigenen Link fürs Handy, mit dem die BR-Leitung die Fahrzeuge im Raum führt.

**Einsatzverwaltung** – im Einsatz **„🅿 Bereitstellungsräume“** (oder beim Bereitstellungsraum im Einsatzkopf „verwalten / Links“, in der Auftragsübersicht „Räume / Links“):
- **„+ Bereitstellungsraum“**: Name, Adresse (Suchen), Koordinate. Der erste Raum ist der Bereitstellungsraum im Einsatzkopf und im Bericht. ✎ ändert, 🗑 löst auf (Fahrzeuge bleiben im Einsatz, der Link wird ungültig).
- **„📱 Link / QR“**: QR-Code und Link (kopieren, teilen). „Neuer Link“ macht den alten ungültig.
- **„📤 An Fahrzeug“**: Fahrzeuge mit Fahrzeug-App auswählen → sie bekommen eine Nachricht und in der Fahrzeug-App oben im Reiter Einsatz den Knopf **„🅿 Bereitstellungsraum öffnen“**. „entziehen“ nimmt den Knopf wieder weg.
- Im Einsatz zeigt der Abschnitt **Bereitstellungsräume** je Raum die Fahrzeuge mit Stärke und die Gesamtstärke; auf der Lagekarte steht jeder Raum mit Koordinate (mit Anzahl der Fahrzeuge).

**Die BR-Seite auf dem Handy** (keine Anmeldung, nur der Link):
- Oben: Anzahl Fahrzeuge, Gesamtstärke, AGT, Adresse mit Navigation.
- **„➕ Fahrzeug kommt an“**: Fahrzeug aus dem Einsatz antippen (Schnellwahl), suchen oder – falls nicht in der Fahrzeugliste – **„als neues Fahrzeug“** anlegen. Das Fahrzeug bekommt Status 4 und kommt (falls nötig) in den Einsatz; danach öffnet sich gleich die Stärke-Eingabe.
- Je Fahrzeug: **„👥 Stärke“** (F/M/AGT, „✓ Stärke melden“) und **„🚪 Fährt ab“**: zur Einsatzstelle/zum Auftrag (Status 3), zurück zum Standort (Status 1) oder nur austragen.
- „Abgefahren“ zeigt, wer wann im Raum war. Die Seite aktualisiert sich alle 5 Sekunden.
- Meldet ein Fahrzeug selbst Status 1, 2 oder 3 (Fahrzeug-App, Funk), gilt es automatisch als abgefahren.
- Alles steht sofort im Einsatztagebuch („Im Bereitstellungsraum „BR Nord“ eingetroffen“, „… verlassen – zur Einsatzstelle“, „Stärkemeldung … (Bereitstellungsraum BR Nord)“).
- Der Link gilt, bis der Raum aufgelöst oder der Einsatz beendet wird.

## Wasserförderung über lange Wegstrecke (ab 3.51)

In der **Einsatztaktik** (Werkzeug „B-Leitung“) eine **B-Leitung** von der Wasserentnahmestelle zur Einsatzstelle zeichnen und antippen. Die Leitung beginnt am ersten gezeichneten Punkt; „⇄ Richtung umkehren“ tauscht Anfang und Ende.

- **Eingaben:** Fördermenge (400–1.600 l/min), **1 oder 2 B-Leitungen parallel** (bei zwei Leitungen trägt jede die halbe Menge), Ausgangsdruck der Pumpen (Vorgabe 8 bar), Mindest-Eingangsdruck (Vorgabe 1,5 bar).
- **Geländehöhen:** *automatisch* – der Pi hat die Höhen für den Umkreis um den Heimatort gespeichert (SRTM, ca. 30 m Raster) und rechnet **ohne Internet**. Außerhalb davon fragt der Pi online, danach das Gerät selbst. *Von Hand* – Höhe an Wasserentnahme und Einsatzstelle, dazu beliebig viele Zwischenpunkte (Kuppe, Senke) mit „nach … m“.
- **„Pumpen berechnen“:** Das Programm läuft das Höhenprofil in 10-m-Schritten ab und setzt die nächste Pumpe dort, wo der Druck unter den Mindest-Eingangsdruck fallen würde – Kuppen werden dadurch automatisch berücksichtigt. Rechnung: Reibungsverlust 1,0 bar je 100 m bei 800 l/min (quadratisch mit der Menge), 1 bar je 10 m Steigung; Gefälle gibt Druck zurück.
- **Ergebnis:** Zahl der Pumpen (Wasserentnahme + Verstärkerpumpen VP 1, VP 2 …), Höhenprofil mit Druckverlauf, Tabelle je Pumpe mit Strecke, Höhe, Eingangs- und Ausgangsdruck, Druck am Verteiler, Summen: Länge, Pumpen, B-Schläuche (+ 10 %), Füllmenge und Füllzeit.
- **Warnungen:** zu wenig Druck, zu steil, und **Überdruck bei Gefälle** (mehr als 10 bar) – mit Vorschlag, auf wie viel bar der Ausgangsdruck gesenkt werden kann, oder dem Hinweis auf ein Druckbegrenzungsventil.
- **Fahrzeuge zuweisen:** In der Tabelle je Pumpe ein Fahrzeug des Einsatzes wählen (Fahrzeuge mit Pumpe stehen oben). Jede Zuweisung kommt ins Einsatztagebuch.
- **„Pumpen auf der Karte einzeichnen“** setzt Pumpensymbole „VP 1 (500 m) · Funkrufname“ und schreibt die Förderstrecke ins Einsatztagebuch. Steht an der Wasserentnahme schon ein Pumpensymbol, wird dort kein zweites gesetzt.
- **Pumpe verschieben:** Ein Pumpensymbol der Förderstrecke auf der Karte ziehen (z. B. an eine Zufahrt) – die Strecke wird **sofort nachgerechnet**; reicht ein Abschnitt nicht mehr, erscheint eine Warnung. Im Fenster der Leitung prüft „Pumpenstandorte von der Karte prüfen“ dasselbe. Das Pumpensymbol hat „Förderstrecke öffnen“.
- **Bericht und Mappe:** Einsatzbericht und Einsatzmappe enthalten jede berechnete Förderstrecke mit Höhenprofil und Pumpentabelle.
- **Einstellungen** (Admin, Verwaltung → Einstellungen → Lagekarte): Faustwerte (Reibungsverlust, Ausgangsdruck, Mindest-Eingangsdruck, Höchstdruck, Füllmenge je Meter) und „Geländehöhen jetzt laden“ mit Stand. Unter Zustand des Pi steht der Speicherplatz der Geländehöhen.
- Es sind Faustwerte für B-Schläuche – eine Planungshilfe. Im Einsatz zählt der Druck am Manometer.

## Nachrichten zwischen ELW und Fahrzeugen

**Vom ELW an die Fahrzeuge**
- Einsatz → **Nachrichten** → „✉ Nachricht an Fahrzeuge“ (oder Einsatz → Fahrzeuge, ✉ in der Zeile bzw. im Fahrzeugfenster). Fahrzeuge einzeln, „alle“ oder je Abschnitt wählen, Text eintragen oder eine Vorlage antippen, „Senden“. Mit dem Haken **„in den Einsatzbericht übernehmen“** kommt die Nachricht gleich in den Bericht.
- Die **Fahrzeug-App** zeigt die Nachricht oben groß mit Ton und Vibration; die Besatzung tippt **„Verstanden“**. Nachricht und Bestätigung stehen mit Uhrzeit im Einsatztagebuch; in der Fahrzeugliste steht „✉ gesendet … – noch nicht bestätigt“ bzw. „✉ verstanden …“.
- **Bilder:** „📷 Foto aufnehmen / Bild wählen“ hängt bis zu 3 Bilder an (am Tablet/Handy direkt mit der Kamera). Sie werden vor dem Senden verkleinert (lange Seite 1600 Pixel). Eine Nachricht darf auch nur aus einem Bild bestehen.

**Vom Fahrzeug an den ELW (neu in 3.20)**
- In der Fahrzeug-App gibt es den Bereich **„Nachricht an die Einsatzleitung“**: Text schreiben oder Vorlage antippen (z. B. „Lage erkundet“, „Wasserversorgung steht“, „Benötigen Unterstützung“), bis zu 3 Fotos anhängen, „Nachricht senden“. Darunter steht, ob die Einsatzleitung die Nachricht **gelesen** hat. Ein angefangener Text bleibt erhalten, falls das Senden nicht klappt.
- Im ELW piept es kurz, oben erscheint eine Meldung und in der Kopfzeile **„✉ 1“** (ungelesene Nachrichten). Antippen öffnet alle Nachrichten der Fahrzeuge der letzten 24 Stunden mit „✓ Gelesen“, „↩ Antworten“ und „Im Einsatz zeigen“ – auch von Fahrzeugen, die gerade in keinem Einsatz sind.
- Im Einsatz steht die Nachricht im Einsatztagebuch (Eingang vom Fahrzeug an ELW) und unter **Einsatz → Nachrichten**.

**Einsatz → Nachrichten**
- Verlauf aller Nachrichten des Einsatzes in beide Richtungen (neueste oben): ↗ an Fahrzeuge (blau), ↙ von Fahrzeugen (grün, ungelesen rot), mit Bildern (antippen = groß, „Speichern“), Bestätigung je Fahrzeug bzw. „gelesen … von …“. Filter nach Richtung und Suche. Die Zahl auf der Karte zeigt ungelesene Nachrichten.
- **Häkchen „Bericht“** an jeder Nachricht übernimmt sie mit Text, Bildern und Bestätigung in den Einsatzbericht. Die Bilder solcher Nachrichten bewahrt der Pi dauerhaft auf (Ordner `berichtbilder/`, auch in der Datensicherung); alle anderen Bilder löscht er nach 7 Tagen.
- Setzen und entfernen können Einsatzleitung und Admins – auch nachträglich im Archiv (Einsatzbericht → „✉ Nachrichten im Bericht“).
- Ankommen kann eine Nachricht, wenn die Fahrzeug-App geöffnet ist (sie fragt alle 10 Sekunden nach) – ab 3.65 mit eingeschalteten **Benachrichtigungen** auch bei gesperrtem Handy. Wichtige Aufträge zusätzlich über Funk geben.

## Fotodokumentation (ab 3.22)

- Einsatz → **Fotos**: „📷 Fotos hinzufügen“ (mehrere auf einmal, am Tablet direkt mit der Kamera). Je Foto eine Beschreibung; **Ort**: aus dem Foto (GPS-Daten der Kamera), Standort dieses Geräts, Einsatzort oder ohne Ort. Aufnahmezeit wird aus dem Foto übernommen. Fotos werden verkleinert (1600 Pixel).
- Fotos aus der **Fahrzeug-App** (Nachricht mit Bild) kommen automatisch dazu – mit der letzten GPS-Position des Fahrzeugs als Ort.
- Antippen: groß ansehen, Beschreibung ändern, herunterladen, löschen, „Auf der Karte“. Auf der **Lagekarte** erscheinen Fotos mit Ort als kleine Vorschaubilder (Ebene „Fotos“ unter Anzeigen).
- Häkchen **„Bericht“** am Foto (oder im Einsatzbericht unter „📷 Fotos im Bericht“, auch im Archiv) übernimmt es in den Abschnitt „Fotodokumentation“ des Einsatzberichts mit Zeit, Absender, Beschreibung und Koordinate.
- Alle Einsatzfotos bewahrt der Pi dauerhaft auf (Ordner `berichtbilder/`, in der Datensicherung).

## Funkskizze (ab 3.22)

- Einsatz → Übersicht oder Abschnitte → **„📻 Funkskizze“**. Eintragen: Kanal/Gruppe zur Leitstelle, Rufname der Einsatzleitung, Führungskanal, Bemerkung. Abschnitte (mit Leiter und Kanal aus Einsatz → Abschnitte) und ihre Fahrzeuge werden automatisch gezeichnet; nicht zugeteilte Fahrzeuge stehen unter „Direkt an Einsatzleitung“.
- „Drucken / PDF“ (A4 quer, Skizze und Tabelle) für die Lagebesprechung; Häkchen „Funkskizze in den Einsatzbericht“.

## Wetter an der Einsatzstelle (ab 3.22)

- Der Pi holt bei Einsatzbeginn und danach stündlich das Wetter für die Koordinate des Einsatzorts (Open-Meteo, Modellwerte) und schreibt es als Vermerk ins Einsatztagebuch, z. B. „Wetter (Einsatzbeginn): 13 °C, leichter Regen (0,3 mm/h), Wind aus W (268°) mit 18 km/h, Böen 41 km/h, Luftfeuchte 81 %“. Ohne Koordinate gilt der Heimatort (steht dann dabei).
- Einsatzübersicht: Kachel „Wetter an der Einsatzstelle“ mit dem letzten Stand und „↻ abrufen“ (sofort abfragen und ins Tagebuch).
- Im Einsatzbericht steht das Wetter bei Einsatzbeginn im Kopf.
- Verwaltung → Einstellungen → „Wetter an der Einsatzstelle“: ein/aus und Abstand in Minuten (0 = nur bei Einsatzbeginn). Braucht Internet am Pi.

## Unwetterwarnungen und Niederschlagsradar

- Der Pi holt alle 5 Minuten die amtlichen Warnungen für den **Landkreis Hameln-Pyrmont** über die Warn-App-Schnittstelle NINA des Bundesamts für Bevölkerungsschutz: Wetterwarnungen des DWD, Hochwasserinformationen, Warnungen des Katastrophenschutzes.
- **Anzeige:** oben rechts „⚠ Zahl“ in der Farbe der höchsten Stufe (gelb Warnung, orange markant, rot Unwetter, violett extrem). Antippen zeigt Text, Gültigkeit und Handlungsempfehlungen, dazu „Jetzt abrufen“, warnung.bund.de, DWD und „Radar auf der Lagekarte“. In der Einsatz-Übersicht steht die wichtigste Warnung.
- **Tagebuch:** Jede Warnung wird in jedem laufenden Einsatz einmal als Eingang vermerkt („WARNUNG: … gültig bis …“).
- Ohne Internet am Pi bleibt der letzte Stand mit „(alt)“ stehen.
- **Lagekarte:** Ebenen „Niederschlagsradar“ und „Warnkarte DWD“ unter „Anzeigen“. Das Radar zeigt das aktuelle Bild; „▶ 1 h“ spielt die letzte Stunde in 5-Minuten-Schritten ab, „■“ hält an. Beides lädt das Gerät direkt beim Deutschen Wetterdienst – nur mit Internet am Gerät, wird nicht gespeichert. Zum Überblick herauszoomen.
- Anderer Landkreis: in der Dienstdatei `Environment=WARN_ARS=…` (12-stelliger Regionalschlüssel des Kreises, hinten mit Nullen), `aus` schaltet ab.

## Gefahrstoffdatenbank

Hauptreiter **„☣ Gefahrstoffdatenbank“** – funktioniert ohne Internet, alle Texte auf Deutsch.

**Suchen**
- Nach **UN-Nummer** oder **Name** (z. B. „1017“, „Chlor“, „Salzsäure“, „Diesel“) – mit Pfeiltasten und Enter wählbar.
- Oder die **Warntafel** wie am Fahrzeug eingeben: oben die **Gefahrnummer** (z. B. 33, 268, X423), unten die **UN-Nummer**. Gefahrzettel/Klassen können zusätzlich angehakt werden. Die Bedeutung der Gefahrnummer (ADR 5.3.2.3) und die Erstmaßnahmen nach GAMS (FwDV 500) erscheinen sofort.
- Die letzten Abfragen merkt sich jedes Gerät.

**Inhalt**
- Alle **2.347 UN-Nummern des ADR 2025** (Tabelle A) mit deutscher Benennung, Klasse, Klassifizierungscode, Verpackungsgruppe, Gefahrzetteln, Tunnelbeschränkungscode und Gefahrnummer. Mehrere Benennungen derselben UN-Nummer (z. B. 1993) stehen im Kopf mit VG und Gefahrnummer.
- Für **jeden** Stoff der **Einsatzleitfaden** nach ERG 2024 (alle 62 Leitfäden übersetzt): Gesundheits-, Brand- und Explosionsgefahr, Erstmaßnahmen, Schutzkleidung, Evakuierung, Brandbekämpfung, Leckage, Erste Hilfe.
- **Absperrung:** Sofortabsperrung, Evakuierung bei großem Austritt und bei Brand; bei giftigen Gasen und Dämpfen **ERG-Tabelle 1** (kleiner/großer Austritt, Tag/Nacht, metrische Originalwerte), **Tabelle 2** (giftige Gase bei Kontakt mit Wasser) und **Tabelle 3** (nach Behälter und Windstärke).
- **Stoffwerte** für über 100 häufige Stoffe: schwerer/leichter als Luft, Dichte (schwimmt/sinkt), Siede- und Flammpunkt, Explosionsgrenzen, Wasserlöslichkeit, Reaktion mit Wasser, CAS-Nr.
- Links zu GESTIS, ERI-Cards und CAMEO (brauchen Internet).

**Im Einsatz**
- **☣ In den Einsatz übernehmen** (in der Datenbank) oder **Übersicht → ☣ Gefahrstoff eintragen**: Suche und Nummer greifen auf die Datenbank zu; Name, Gefahrnummer und Klasse werden übernommen, darunter eine Kurzinfo (Leitfaden, giftig, Sofortabsperrung). Der Eintrag steht im Tagebuch, im Einsatzbericht und in den Einsatzdaten der E-Mail.
- **Aus der Alarmmail:** Steht in der Mail eine UN-Nummer („UN 1017“), eine Warntafel („33/1203“) oder ein bekannter Stoffname, wird der Stoff mit dem Vermerk „erkannt – bitte prüfen“ eingetragen und – bei Einsätzen mit Koordinate – ein Gefahrenkreis-Vorschlag auf die Lagekarte gesetzt.
- **Einsatz-Reiter „Gefahrstoff“** (zwischen Atemschutz und VU): erscheint, sobald ein Stoff eingetragen ist, und zeigt für jeden Stoff das komplette Einsatzblatt mit „Absperrbereich auf die Lagekarte“ und „Aus dem Einsatz entfernen“.
- **↔ Absperrbereich auf die Lagekarte:** Lage (kleiner/großer Austritt, Brand), Tag/Nacht (automatisch nach Sonnenstand), Behälter und Wind (Richtung und Stärke, „Aktuellen Wind abrufen“ braucht Internet) wählen. Gezeichnet werden der Absperrkreis und – wenn vorhanden – der Schutzbereich als Kegel in Windrichtung; dazu ein Tagebuch-Eintrag.

**Wichtig:** Das ist eine Erstinformation für die Feuerwehr. Maßgeblich bleiben Beförderungspapier, schriftliche Weisungen und Warntafel; die Lage durch Fachberater bzw. TUIS bestätigen lassen. Die deutschen Benennungen sind aus dem englischen ADR übersetzt (nicht amtlicher Wortlaut); die ERG-Werte gelten für Nordamerika. Eine Stichprobenprüfung gegen die Quellen liegt in `docs/GEFAHRSTOFFE_PRUEFBERICHT.md`.

## Atemschutzüberwachung

Die ASÜ-App (Port 8082) übernimmt den laufenden Einsatz automatisch, wenn genau einer läuft, sonst über die Auswahl unter „Einsatzdaten → Einsatz der Einsatzverwaltung“. Sie übernimmt Einsatzort, Einsatzleiter und Datum in leere Felder. Ihr Truppstatus erscheint dann im richtigen Einsatz und im Tagebuch.

Mit mehreren ASÜ-Geräten führt immer nur **ein** Gerät die Überwachung; nur dessen Truppstatus erscheint hier. Übergabe und Übernahme der Führung (mit Admin-Passwort) stehen im Systemprotokoll. Einrichtung für Mobilfunk: ANLEITUNG, Schritt 13.

**Welche Feuerwehr? (ab 3.31)** Jede Überwachung zeigt, zu welcher Feuerwehr sie gehört:

- **In der ASÜ-App**, Reiter „Überwachung“ und „Einsatzdaten“: oben „Überwachung der **Ortsfeuerwehr …** · Gemeinde“ mit Wappen und dem führenden Gerät. Ist das Gerät für eine andere Feuerwehr angemeldet (z. B. beim Zuschauen oder nach Übergabe der Führung), ist die Zeile **gelb** hinterlegt: „angezeigt wird die Überwachung einer anderen Feuerwehr“. Auch die Kopfzeile nennt dann diese Feuerwehr.
- **In der Einsatzverwaltung**, Einsatz → Karte „Atemschutz“: über jeder Überwachung „Überwachung der Ortsfeuerwehr …“ mit Wappen, bei Übergabe zusätzlich „angelegt von …“.
- Maßgeblich ist die Feuerwehr, für die das **führende Gerät** angemeldet ist; Name und Wappen kommen aus der Benutzerliste der ASÜ (`asue/benutzer.js`). Arbeitet das führende Gerät noch mit einer älteren ASÜ-Version, nimmt der Pi den Namen aus dessen Statusmeldung oder zeigt „Feuerwehr nicht übermittelt“ – nach dem Neuladen der ASÜ am Tablet ist der Name da.

## Atemschutzüberwachung: CSA-Trupps und Sicherheitstrupp-Warnung (ab 3.40)

**CSA (Chemikalienschutzanzug):** Beim Anlegen/Bearbeiten eines Trupps **„CSA (Chemikalienschutzanzug) – höchstens 20 Minuten“** ankreuzen. Der Trupp trägt das Kennzeichen **CSA** (violett).
- Gerechnet ab **Beginn**: 5 Minuten vor der Grenze Warnung **„CSA: noch … min – Rückzug einleiten“**, bei 20 Minuten Alarm **„CSA: 20 Minuten erreicht – Rückzug sofort!“** (mit Ton, Sprachansage wenn eingeschaltet).
- **„Rückzug in“** zeigt die frühere Zeit von Druck-Rechnung und CSA-Grenze (Zusatz „CSA-Grenze 20 min“); in der Übersicht steht „CSA“ an der Uhrzeit.
- Ist der Rückzug schon angetreten, bleibt nach 20 Minuten nur ein Hinweis, bis „Ende“ erfasst ist.
- Die Höchstzeit ist unter **Einstellungen → „CSA: höchste Einsatzzeit (Minuten)“** änderbar (Vorgabe 20).
- Der Atemschutz-Nachweis und die Einsatzverwaltung kennzeichnen CSA-Einsätze.

**Sicherheitstrupp-Warnung bestätigen:** Erscheint **„Kein Sicherheitstrupp bereit“**, kann sie direkt mit **„Bestätigen – hier nicht nötig“** für **diesen Einsatz** ausgeblendet werden (auch keine Sprachansage mehr) – ohne in die Einstellungen zu gehen. Darunter steht dann „Sicherheitstrupp-Warnung … bestätigt · **Wieder einblenden**“. Ein neuer Einsatz beginnt wieder mit Warnung. Die Meldung **„Sicherheitstrupp im Einsatz – neuen bereitstellen!“** lässt sich nicht wegklicken.

## Atemschutz-Datenbank, QR-Codes und Sammel-App (ab 4.0)

Die Atemschutzgerätewarte (AGW) der Ortswehren pflegen auf dem Pi der Einsatzverwaltung eine Datenbank ihrer Geräteträger und Geräte. Die ASÜ prüft damit beim Einscannen oder Auswählen einer Person, ob sie einsatzbereit ist, und schreibt Einsätze und Übungen automatisch in den Nachweis der Person.

**Zugänge der Gerätewarte (Verwaltung → Atemschutz-DB, nur Admin)**
- „+ Gerätewart anlegen“: Name, Benutzer, E-Mail für Erinnerungen und die Ortswehren, die der Zugang verwalten darf (oder „alle“ für den Gemeinde-AGW).
- **Nur die Ortswehren der eigenen Gemeinde** (ab 4.0.1): Zur Auswahl stehen die Ortswehren des Flecken Aerzen (aus den ASÜ-Zugängen der Gemeinde und den Fahrzeugen mit Gemeinde „Aerzen“). Wehren anderer Gemeinden, Kreis- und Werkfeuerwehren werden in der Datenbank nicht geführt. Das Startkennwort (Vorschlag oder eigenes, mindestens 8 Zeichen) wird mit einer kurzen Anleitung ausgedruckt.
- Bei der ersten Anmeldung legt der Gerätewart ein eigenes Kennwort fest. **Nach 4 Monaten muss ein neues gewählt werden** (ab 5.1; vorher 28 Tage – eine Woche vorher kommt eine Mail, in den letzten 14 Tagen ein Hinweis in der Datenbank); die letzten Kennwörter dürfen nicht wiederverwendet werden. Nach mehreren Fehlversuchen wird gesperrt und ein Sicherheitshinweis erzeugt.
- Zugänge lassen sich sperren, löschen oder mit einem neuen Startkennwort versehen. Personen und Nachweise bleiben dabei erhalten.

**Anmelden (Gerätewart)**
- In der ASÜ Reiter **„Atemschutz-DB“** – oder auf der Anmeldeseite der ASÜ **„Atemschutzgerätewart: nur Atemschutz-Datenbank öffnen“** (ohne Zugang der Ortswehr; es ist dann nur die Datenbank sichtbar).
- Funktioniert im Feuerwehrhaus und **von außen** über die Internetadresse der ASÜ (Tailscale Funnel, Port 8443) – auch mit der ASÜ von GitHub.
- Jeder Gerätewart sieht und ändert **nur die Personen und Geräte seiner eigenen Ortswehr(en)**.

**Personen**
- Nachname, Vorname, Ortswehr, „ruhend“ (zurzeit nicht im Atemschutz einsetzen) und „CSA-Träger“. Jede Person bekommt eine **Kennung**, die nicht angezeigt wird, aber im QR-Code steckt.
- **Prüf- und Leistungsnachweise nach FwDV 7:**
  | Nachweis | Gültigkeit | Voraussetzung für den Einsatz |
  |---|---|---|
  | Atemschutzgeräteträger-Lehrgang | einmalig | ja |
  | Eignungsuntersuchung (G 26.3) | „gültig bis“ laut Bescheinigung | ja |
  | Belastungsübung (Atemschutz-Übungsstrecke) | 12 Monate | ja |
  | Unterweisung | 12 Monate | ja |
  | Übung oder Einsatz unter Atemschutz | 12 Monate, aus der ASÜ automatisch | Hinweis |
  | CSA-Übung | 12 Monate | nur für CSA-Träger, Hinweis |
- Von der Eignungsuntersuchung werden **nur Datum und „gültig bis“** gespeichert – kein Befund.
- Die Liste zeigt je Person **einsatzbereit**, **nicht einsatzbereit** (mit Grund) oder **läuft bald ab**, dazu den nächsten Ablauf. Oben stehen die Zahlen für die Ortswehr.
- Im Personenfenster stehen unter „Einsätze und Übungen aus der ASÜ“ alle Einsätze der Person mit Datum, Trupp, Funktion und Dauer.

**Geräte**
- Pressluftatmer, Atemluftflaschen, Lungenautomaten und Masken mit Nummer, Typ, Ortswehr und **nächster Prüfung**.

**QR-Codes**
- Reiter **„QR-Codes“**: Nachname und Vorname eingeben → „Anlegen und QR-Code zeigen“. Die Person wird dabei in der Datenbank angelegt.
- Jede Person und jedes Gerät hat einen QR-Code (Symbol in der Liste). **Etiketten drucken**: Personen und Geräte ankreuzen → „Etiketten drucken“ (3 Spalten je A4-Seite, mit Name bzw. Gerätenummer).
- In der ASÜ beim Trupp **„Kamera“ → „QR- / Strichcode“** scannen: Der Personen-Code setzt Nachname und Vorname (mit Kennung), Geräte-Codes setzen Gerät, Flasche, LA oder Maske. Wird der Name danach von Hand geändert, entfällt die Kennung.

**Einsatzbereitschaft in der ASÜ**
- Die ASÜ lädt alle 5 Minuten die Liste vom Pi (nur Name, Ortswehr, einsatzbereit ja/nein und Grund) und merkt sie sich für den Betrieb ohne Verbindung.
- Ist eine Person **nicht einsatzbereit**, erscheint ein roter Hinweis im Trupp-Fenster, in der Geräteerfassung, auf der Trupp-Karte der Überwachung und beim „QR übernehmen“; beim Einscannen kommt zusätzlich eine Meldung. Erkannt wird über die Kennung aus dem QR-Code oder über einen eindeutigen Namen. Die Entscheidung bleibt beim Einheitsführer.

**Erinnerungen per E-Mail**
- Der Pi schickt jedem Gerätewart mit hinterlegter E-Mail eine Liste, sobald ein Nachweis seiner Personen oder die Prüfung eines Geräts **in den nächsten 4 Wochen abläuft** – und noch einmal bei Ablauf. Jeder Punkt kommt je Stufe nur einmal. Voraussetzung: E-Mail-Versand ist eingerichtet.

**Einsätze und Übungen übernehmen**
- Trupps, deren Personen eine Kennung tragen, landen nach der Überwachung automatisch im Nachweis der Person. Eine Übung oder ein Einsatz zählt dann als „Übung oder Einsatz unter Atemschutz“.

**Sammel-App fürs Handy**
- In der ASÜ unter „Trupps & Geräte“ → **„📱 Sammel-App“** erscheint ein QR-Code mit dem Link. Die Sammel-App kann **nur** Personen und Trupps erfassen: Personen-QR-Code scannen (danach die Geräte-Codes dieser Person) oder von Hand eintragen, Flaschendruck, zwei oder drei Personen ankreuzen → „Trupp bilden“.
- **Übergabe nur per QR-Code:** Die Sammel-App zeigt den Trupp-Code; an der ASÜ „Trupps & Geräte“ → „QR übernehmen“ scannen. Die Sammel-App sendet nichts ins Netz.

**Mehrere Geräte (neu geordnet)**
- Unter Einsatzdaten → **„Mehrere Geräte“** in drei Schritten: **1. Dieses Gerät** (Name), **2. Server der Einsatzverwaltung** (Adresse und Wehr-Schlüssel), **3. Gemeinsamer Einsatz** (freigeben oder beitreten; verbunden: Code, wer führt, Liste aller Geräte mit Rolle und „zuletzt gesehen“).
- **Jedes Gerät braucht einen Namen** (z. B. „ELW Tablet“). Ohne Namen fragt die ASÜ nach der Anmeldung danach; Freigeben und Beitreten sind erst mit Namen möglich.
- Nach dem Beitreten zeigt die ASÜ, **mit welchem Einsatz sie verbunden ist und welches Gerät die Überwachung führt**.
- **Wehr-Schlüssel per QR:** In der Einsatzverwaltung unter Verwaltung → ASÜ-Zugänge → „🔑 Wehr-Schlüssel als QR“ (Admin, PIN) – für das Netz der Feuerwehr und von außen. In der ASÜ unter „2. Server“ → „Schlüssel per QR“ scannen; Schlüssel und Adresse werden übernommen. Den Code nicht weitergeben.

### Eigene Seiten und neue Zuständigkeiten (ab 5.0)

- **Eigener Link (ab 5.188 eine App):** Gerätedatenbank und Atemschutz-Datenbank sind eine App unter `…:8082/datenbank` im Netz des Pi bzw. über die Internetadresse der ASÜ (Port 8443) von außen. Die alten Adressen `/geraete` und `/atemschutz` leiten dorthin weiter. Jeder Zugang sieht nur seine Reiter (siehe „Neu in 5.188“). Der Reiter „Datenbank“ der ASÜ öffnet die App in einem neuen Fenster.
- **Atemschutz-Nachweis:** Die Einsätze und Übungen unter Atemschutz (bisher Verwaltung → Atemschutz-Nachweis) stehen jetzt in der Atemschutz-Datenbank im Reiter **„Einsatznachweis“** – je Person mit Jahr-/Art-Filter, Suche, Verlauf, „ausblenden“ (Testdaten), CSV und Druck; jeder Gerätewart sieht seine Ortswehren. Der Reiter in der Verwaltung entfällt.
- **Außer Dienst und Prüffristen kommen aus der Gerätedatenbank:** Fahrzeuge außer Dienst setzt der Gerätewart am Fahrzeug („Fahrzeug außer Dienst …“ mit Grund und „bis“, „Wieder im Dienst“); Status 6, Schadensmeldungen und offene Fahrzeug-Checks erscheinen dort ebenfalls. Prüffristen sind Geräte mit Prüfart, Intervall und nächster Prüfung. Die bisherigen Abschnitte „Außer Dienst“ und „Prüffristen“ in Verwaltung → Alarmmonitor entfallen; vorhandene Einträge wurden beim Update einmalig übernommen (Prüffristen als Geräte im Lager mit Kategorie „Prüffrist“, Geräte außer Dienst als Geräte mit Zustand „außer Dienst“; Fristen ohne Ortswehr bei der ersten Ortswehr der Gemeinde).

### Gerätedatenbank für Gerätewarte (ab 4.7)

Neben der Atemschutz-Datenbank gibt es eine **Gerätedatenbank** für alle Geräte auf den Fahrzeugen und im Lager. Sie **ersetzt die bisherige Ausrüstungsliste** der Fahrzeuge.

**Einrichten (Admin, Verwaltung → Gerätewarte):**
1. „**Ausrüstungsliste übernehmen und Datenbank aktivieren**“ – einmalig; jede Zeile der Ausrüstungslisten wird ein Gerät am jeweiligen Fahrzeug (Bezeichnung wie bisher, z. B. „Wasser (Liter): 2800“). Ab jetzt führt die Datenbank die Ausrüstung: das Feld „Ausrüstung“ beim Fahrzeug ist gesperrt, ein Excel-Import der Fahrzeuge überschreibt die Ausrüstung nicht mehr.
2. Zugänge anlegen (ab 5.2): „+ Gerätewart anlegen“ für die Gerätedatenbank bzw. „+ Atemschutzgerätewart anlegen“ für die Atemschutz-Datenbank – zwei Personen, zwei Zugänge, gleich angelegt. Sonst wie bei den Atemschutzgerätewarten: eigene Ortswehren, Kennwort mind. 8 Zeichen, alle 28 Tage neu, Zugriff auch von außen über die ASÜ.

**Arbeiten (ASÜ → Reiter „Datenbank“ bzw. Anmeldeseite „Gerätewart: nur Datenbank öffnen“ → „🧰 Gerätedatenbank“):**
- Liste nach Fahrzeugen (und „Lager“) mit Zustand und nächster Prüfung; Suche, Filter nach Fahrzeug, Zustand und „nur Prüfung fällig“.
- **Gerät öffnen:** *Prüfung eintragen* (Datum, ohne Mängel/Mangel, Bemerkung – mit Intervall wird die nächste Prüfung automatisch gesetzt; Mangel macht das Gerät „defekt“), *Mangel melden*, *Repariert – einsatzbereit*, *Zustand setzen* (einsatzbereit, defekt, in Prüfung/Reparatur, außer Dienst), *Umsetzen* auf ein anderes Fahrzeug oder ins Lager, *Notiz*. Alles landet im **Verlauf** (wer, wann, was).
- **Stammdaten:** Bezeichnung, Inventar-Nr., Kategorie, Anzahl, Hersteller, Typ, Serien-Nr., Ortswehr, Fahrzeug, Prüfart (z. B. DGUV-Prüfung), Intervall, nächste Prüfung, Notiz.
- **QR-Etiketten:** „🖨 Etiketten“ druckt die gefilterte Liste; „📷 QR-Etikett scannen“ öffnet das Gerät direkt (z. B. bei der Prüfung am Fahrzeug).
- **Mail eine Woche vor jeder Prüfung** an die Gerätewarte der Ortswehr (Zugang mit Bereich Geräte und E-Mail-Adresse).

**Schäden aus der Fahrzeug-App (ab 4.8):** Oben in der Fahrzeug-App gibt es den Knopf **🔧 Schaden melden**: betroffenes Gerät aus der Liste des Fahrzeugs wählen (oder „Fahrzeug selbst“ bzw. „Anderes Gerät …“), Zustand **⛔ Außer Betrieb** oder **⚠️ Funktioniert noch**, kurze Beschreibung, bis zu 3 Fotos.
- **Im Einsatz** wird die Meldung im **Einsatztagebuch** als Eingang vom Fahrzeug eingetragen.
- **Sonst** bekommen die **Gerätewarte der Ortswehr** sofort eine Mail (Zugang mit Bereich Geräte und E-Mail; gibt es keinen, die System-Empfänger).
- In beiden Fällen steht die Meldung in der Gerätedatenbank oben unter **„Schadensmeldungen aus der Fahrzeug-App“** (mit Fotos, „Gerät öffnen“, „✓ Erledigt“). Ist ein Gerät aus der Datenbank gewählt, steht die Meldung in dessen Verlauf; bei „außer Betrieb“ wird es **defekt** und am Fahrzeug als nicht verfügbar gezeigt. „Fahrzeug selbst – außer Betrieb“ erscheint auf dem Alarmmonitor unter „Außer Dienst“, bis der Gerätewart die Meldung erledigt.

**Für den Gerätewart aus der Fahrzeug-App (ab 4.9):** Der Knopf 🔧 oben öffnet ein Menü:
- **🔧 Schaden melden** – wie oben, jetzt mit Schnell-Knöpfen („Schlauch geplatzt“, „Akku leer“, „Verloren / zurückgelassen“ …), die den Text füllen.
- **📦 Verbrauch nachfüllen** – Posten antippen, Anzahl optional, „Anderes“ als Freitext. Im Einsatz ins Einsatztagebuch, sonst sofort an den Gerätewart.
- **✅ Fahrzeug-Check nach dem Einsatz** – Punkte abhaken (Tank, Atemschutz, Schläuche, Beladung …). Offene Punkte gehen an den Gerätewart; das Fahrzeug steht auf dem Alarmmonitor unter „Außer Dienst“ als *nicht vollständig einsatzbereit*, bis der Gerätewart erledigt oder ein vollständiger Check kommt. Kommt ein Fahrzeug aus einem Einsatz, erinnert ein gelber Hinweis in der App an den Check.
- **🔍 Beladung prüfen** (wenn die Gerätedatenbank aktiv ist) – jedes Gerät des Fahrzeugs „✓ da“, „fehlt“ oder „defekt“; „Alle übrigen ✓ da“ hilft. Fehlende Geräte werden *außer Dienst*, defekte *defekt*; der Gerätewart bekommt eine Mail, im Fahrzeugkopf der Gerätedatenbank steht „Beladung geprüft am … (von …)“.
- **Nach dem Einsatz** bekommt der Gerätewart eine gesammelte Mail mit allen Schäden und Verbrauch aus diesem Einsatz (sobald das Fahrzeug den Einsatz verlassen hat).
- **Rückmeldung:** Beim „✓ Erledigt …“ kann der Gerätewart einen Satz an die Besatzung schreiben (z. B. „Ersatz liegt im Gerätehaus, Regal 3“) – er erscheint in der Fahrzeug-App unter „Zuletzt gemeldet“.
- Die Listen für Verbrauch und Fahrzeug-Check legt der Gerätewart je Ortswehr fest („☰ Listen Verbrauch / Check“ in der Gerätedatenbank).

**Ausleihen:** Im Gerät „⇢ Ausleihen an …“ (z. B. „Ortswehr Grießem“, optional bis wann) – das Gerät steht dann in der Liste als ausgeliehen und am Fahrzeug als nicht verfügbar („ausgeliehen an …“); „⇠ Zurück erhalten“ beendet das.

**Im Einsatz:** Am Fahrzeug (Einheiten → Fahrzeug antippen), in der Ausrüstungssuche und bei den Vorschlägen im Einsatz zählen nur **einsatzbereite** Geräte. Nicht verfügbare stehen am Fahrzeug rot durchgestrichen mit Grund („defekt“, „in Prüfung / Reparatur“, „außer Dienst“). Auf dem **Alarmmonitor** erscheinen sie unter „Außer Dienst“, die Prüftermine unter „Termine“ und im Kalender-Abo.

### Einsatzbereitschaft auf einen Blick (ab 4.2)

In der Atemschutz-Datenbank öffnet sich zuerst der Reiter **Einsatzbereitschaft**: oben die Summe (einsatzbereit, mögliche Trupps, läuft in 28 Tagen ab, nicht einsatzbereit), darunter je Ortswehr eine Karte.

- Große Zahl = einsatzbereite Atemschutzgeräteträger, dazu „von X“ und die Zahl möglicher Trupps (÷ 2). Der Balken zeigt grün einsatzbereit, gelb läuft bald ab, rot nicht einsatzbereit.
- **Rot umrandet** mit „Weniger als 2 Trupps einsatzbereit“, wenn eine Wehr unter vier einsatzbereite Träger fällt; gelb, wenn etwas abläuft oder fehlt.
- Darunter: die Gründe (z. B. „Eignungsuntersuchung: 2“), wer bald abläuft, Anzahl CSA-Träger, ruhend Gemeldete und wer im letzten Jahr keine Übung oder keinen Einsatz unter Atemschutz hatte.
- „Liste“ springt in den Reiter „Personen“, gefiltert auf diese Wehr. Ruhend gemeldete zählen nicht mit. Wer gerade erreichbar ist, weiß die Datenbank nicht – das bleibt Sache der Alarmierung.

### Prüftermine der Geräte (ab 4.4)

Je Gerät (Pressluftatmer, Flasche, Lungenautomat, Maske) gibt es **zwei Prüftermine im Jahr**, die von Hand eingetragen werden: im Reiter **Geräte** über „Bearbeiten“ (Prüftermin 1 und 2) oder für viele Geräte auf einmal über **„📅 Prüftermine setzen“** (Ortswehr, beide Termine, Gerätearten wählen – überschreibt die bisherigen Termine dieser Geräte).

- **Eine Woche vor jedem Termin** geht eine Mail an die Atemschutzgerätewarte der Ortswehr – an jeden ASÜ-DB-Zugang mit E-Mail-Adresse, der für diese Wehr zuständig ist. Mehrere Geräte kommen gesammelt in einer Mail; Nachweise der Personen, die gerade ablaufen, stehen mit in derselben Mail.
- In der Liste ist der nächste Termin fett, gelb markiert in der Woche davor. Sind beide Termine vorbei, steht dort „neue Termine eintragen“ – die Termine für das nächste Jahr wieder von Hand setzen.
- Voraussetzung: E-Mail-Versand der Einsatzverwaltung eingerichtet und beim Zugang des Gerätewarts eine E-Mail-Adresse hinterlegt (Verwaltung → Atemschutz-DB).

### Gerätepflege, Gerätetausch und Formblatt (ab 4.3)

Reiter **Gerätepflege** in der Atemschutz-Datenbank. Jede Benutzung aus Übungen und Einsätzen der ASÜ erscheint dort automatisch – je Einsatz/Übung, mit Träger, Trupp, Pressluftatmer-, Flaschen-, LA- und Masken-Nummer, Druck Beginn → Ende und Einsatzzeit. Grundlage ist der Atemschutz-Nachweis (letzte 365 Tage).

- **Haken „FTZ“:** Geht ein Gerätesatz zur Kontrolle an die FTZ, reicht der Haken. „Alle → FTZ“ hakt einen ganzen Einsatz ab.
- **„…“:** Tauschgerät von der FTZ eintragen (Nummern), „selbst gepflegt“ (z. B. Maske im Haus gereinigt) oder eine Bemerkung bzw. einen Mangel festhalten.
- **„zurück“**, wenn die Geräte von der FTZ wiederkommen; ↶ macht den Haken rückgängig.
- Filter: Offen · Bei der FTZ · Alle. Die Zahl am Reiter zeigt die offenen Benutzungen.
- **📄 Formblatt:** je Einsatz/Übung ein vorausgefülltes A4-Blatt (quer) zum Drucken: Feuerwehr, Art, Datum, Einsatznummer, Einsatzstelle, je Träger die Nummern, Drücke, Einsatzzeit, Mängel, FTZ-Haken, drei Leerzeilen, Tauschgeräte und Unterschriften (Gerätewart, Übergabe, Übernahme FTZ).
- Im Reiter **Geräte** steht je Gerät, wie oft und wie lange es in den letzten 365 Tagen benutzt wurde, wann zuletzt und ob es noch zur Pflege muss oder bei der FTZ ist. Gestrichelte Nummern sind (noch) nicht in der Datenbank erfasst.

Damit die Nummern im Formblatt stehen, müssen Gerät, Flasche, LA und Maske in der ASÜ beim Trupp eingetragen bzw. per QR-Code eingelesen werden; fehlende Werte bleiben zum Ausfüllen frei.

## Datenbanken als App: Benachrichtigungen, Angemeldet bleiben (ab 5.5)

Ab 5.188 sind Gerätedatenbank und Atemschutz-Datenbank **eine App** (`/datenbank`, Symbol: Klemmbrett mit Atemschutzmaske). Bereits installierte Apps mit `/geraete` bzw. `/atemschutz` funktionieren weiter (Weiterleitung); wer möchte, installiert die neue App und löscht die alten Symbole.

- **Installieren:** Android, Chrome, Edge: oben **„📲 Als App installieren“**. iPhone/iPad: in Safari „Teilen“ → „Zum Home-Bildschirm“ (für Benachrichtigungen nötig, ab iOS 16.4).
- **🔔 Benachrichtigungen** → „Auf diesem Gerät einschalten“, danach „Test senden“. Bis zu 5 Geräte je Zugang. Die Meldungen kommen auch bei geschlossener App, ein Tipp öffnet die passende Datenbank.
  - Gerätewart: Geräteprüfung eine Woche vorher, sofort bei Schadensmeldungen aus der Fahrzeug-App, montags der Wochenüberblick.
  - Atemschutzgerätewart: Prüftermine der Atemschutzgeräte, ablaufende Nachweise (G 26.3, Belastungsübung, Unterweisung), neue Atemschutz-Nutzungen aus dem Einsatz (Geräte zur Pflege), Gerätetausch / Prüfung aus der ASÜ.
  - Beide: 7 Tage bevor das Kennwort abläuft. Superadmin: zusätzlich Sicherheitshinweise.
  - Jeder bekommt nur Meldungen seiner eigenen Ortswehr. Die Mails kommen weiterhin; ohne Mail-Adresse kommen nur die Benachrichtigungen.
- **Angemeldet bleiben (30 Tage, ab 5.6):** Haken bei der Anmeldung – nur auf dem eigenen Gerät. Ein Kennwortwechsel, das Sperren des Zugangs oder „Abmelden“ beendet die Anmeldung; der Admin kann einzelne Geräte unter Verwaltung → Sicherheit abmelden.

## Gerätedatenbank: Prüfarten, Prüfprotokoll, QR-Etikett, Wochenüberblick (ab 5.6)

- **Prüfarten (ab 5.7):** Das Feld „Prüfart“ bietet eine Liste (Leitern, Hebekissen, hydraulisches Rettungsgerät, Stromerzeuger, elektrische Betriebsmittel, Schläuche, Leinen, Motorsäge, Sprungpolster, Herstellerprüfung …). Die Auswahl übernimmt das Intervall; freie Eingabe geht weiterhin. Die Liste gilt für die ganze Gemeinde und wird unter **„☰ Listen & Prüfarten“** bearbeitet (je Zeile `Name | Monate`). Die Intervalle der Vorgabe sind Vorschläge – mit DGUV Grundsatz 305-002 und den Herstellerangaben abgleichen.
- **Prüfprotokoll mit Unterschrift:** Gerät öffnen → „📝 Mit Prüfprotokoll + Unterschrift“. Prüfliste wählen, je Punkt „i. O.“, „Mangel“ oder „entfällt“, Bemerkung, Prüfer, Befähigung, mit dem Finger unterschreiben. Ein Mangel setzt das Gerät auf defekt. Das Protokoll öffnet sich als Druckseite (drucken oder als PDF speichern) und bleibt im Verlauf des Geräts unter „📄 Protokoll“ abrufbar.
- **QR-Etikett:** Neue Etiketten enthalten einen Link – die normale Handy-Kamera öffnet damit direkt die Gerätekarte (nach der Anmeldung). In der App: „📷 Etikett scannen“ (Live-Kamera) oder „🖼 aus Foto“. Alte Etiketten gelten weiter.
- **📋 Wochenüberblick:** offene Schadensmeldungen, Fahrzeuge außer Dienst, nicht einsatzbereite Geräte, überfällige Prüfungen, Prüfungen der nächsten 4 Wochen, ausgeliehene Geräte. Kommt jeden Montag ab 7 Uhr per Mail und Benachrichtigung.

## Atemschutz-Datenbank: Jahresauswertung, persönlicher Link, Ausgeschiedene (ab 5.6)

- **📊 Jahresauswertung:** je Ortswehr Geräteträger, davon einsatzbereit, Einsätze, Übungen und Minuten unter Atemschutz je Person, fehlende Nachweise. Jahr wählbar, „🖨 Drucken / PDF“. Gezählt werden Nutzungen, die einer Person per QR-Kennung zugeordnet sind.
- **🔗 Persönlicher Link:** in der Personenkarte. Der Geräteträger sieht damit seine eigenen Fristen und Einsätze (nur Lesen). Weitergeben als QR-Code, kopiert oder „Teilen“. Ein neuer Link macht den alten ungültig, „Link sperren“ beendet ihn.
- **Öffentlich und mit Passwort (ab 5.11):** Der Link läuft über die **externe Adresse der Fahrzeug-App** (Verwaltung → Einstellungen → Fahrzeug-App; ist keine eingetragen, gilt er nur im Netz des Pi – die Datenbank weist darauf hin) und funktioniert damit von unterwegs. Beim **ersten Öffnen legt der Geräteträger ein eigenes Passwort** fest (mindestens 6 Zeichen); mit „Auf diesem Handy angemeldet bleiben“ (90 Tage) muss er es danach nicht mehr eingeben. Auf einem anderen Gerät wird das Passwort abgefragt; nach 8 Fehlversuchen ist der Link 10 Minuten gesperrt (Sicherheitshinweis an den Admin). **Passwort vergessen:** Atemschutzgerätewart → Personenkarte → 🔗 Persönlicher Link → **„Passwort zurücksetzen“** – alle angemeldeten Handys werden abgemeldet, beim nächsten Öffnen wird ein neues Passwort festgelegt. „Auf diesem Gerät abmelden“ steht unten auf der Seite.
- **Ausgeschieden am:** Datum in der Personenkarte eintragen (setzt die Person auf ruhend). Nach der Löschfrist (Einstellungen → Datenschutz) werden Name, Nachweise und Link automatisch entfernt; die Einsatzzeiten bleiben ohne Namen für die Statistik.
- Bezeichnung des Nachweises ab 5.7: „Eignungsuntersuchung Atemschutz (G 26.3)“ – gespeichert werden weiterhin nur Datum und „gültig bis“.

## Excel-Import und -Export der Datenbanken (ab 5.11)

In der **Gerätedatenbank** (Werkzeugleiste) und in der **Atemschutz-Datenbank** (Reiter Personen und Atemschutzgeräte) gibt es den Knopf **„📊 Excel“** – je Ortswehr oder für alle eigenen Ortswehren:

- **Exportieren:** Ortswehr wählen → „⬇ Excel-Datei herunterladen“. Die Datei (.xlsx) enthält alle Einträge mit festen Spalten (ID, Bezeichnung, Inventar-Nr., Fahrzeug, Zustand, Prüfart, Prüfungen … bzw. Nachname, Vorname, Ortswehr, Lehrgang, G 26.3, Belastungsübung, Unterweisung … bzw. Art, Nummer, Typ, Prüftermine) und ein Blatt „Hinweise“. Datumsangaben sind echte Excel-Daten; Filter und fixierte Kopfzeile sind schon gesetzt.
- **Leere Vorlage:** dieselben Spalten ohne Inhalt – zum Erfassen einer ganzen Ortswehr am PC.
- **Importieren:** Datei wählen → **„Datei prüfen“**. Die Prüfung zeigt, wie viele Zeilen neu angelegt, geändert oder unverändert bleiben, und listet Fehler mit Zeilennummer (z. B. unbekanntes Fahrzeug, falsches Datum, fremde Ortswehr). Erst **„✓ Jetzt einspielen“** schreibt in die Datenbank – und nur, wenn keine Fehler mehr gemeldet werden (alles oder nichts).
- **Zuordnung:** Zeilen mit **ID** ändern den vorhandenen Eintrag (die Spalte nicht bearbeiten). Zeilen ohne ID werden über Inventar-Nr. + Ortswehr (Geräte), Nachname + Vorname + Ortswehr (Personen) bzw. Art + Nummer + Ortswehr (Atemschutzgeräte) gefunden, sonst neu angelegt. Leere Datumszellen lassen den gespeicherten Wert stehen; ein „-“ löscht ihn.
- **Grenzen:** Löschen geht nicht über Excel (Geräte auf „außer Dienst“ setzen, Personen „ausgeschieden am“). Spalten „nur Anzeige“ (Einsatzbereit, Hinweise, Ausgeliehen an) werden nicht eingelesen. Jeder Gerätewart sieht und bearbeitet nur seine Ortswehren; jeder Export und Import steht im Änderungsprotokoll.

## Gerätetausch und Prüfung aus der ASÜ (ab 5.3)

- In der ASÜ gibt es den Reiter **Tausch / Prüfung**. Jede Feuerwehr kann dort Geräte aus einem Einsatz oder einer Übung „zur Prüfung (FTZ)“ melden, ein Tauschgerät eintragen und die Rückkehr bestätigen – auch für Geräte anderer Ortswehren.
- Die Einträge erscheinen in der Atemschutz-Datenbank unter Gerätepflege (mit Feuerwehr und Name), der zuständige Atemschutzgerätewart bekommt eine Benachrichtigung.
- **Trupp-Stärke (ab 5.7, FwDV 7):** Beim Beginn eines Trupps mit weniger als 2 eingetragenen Personen fragt die ASÜ nach (nur für Nachträge bestätigen). Ein laufender Trupp unter 2 Personen zeigt die Warnung „Weniger als 2 Personen im Trupp (FwDV 7)“.

**Ab 5.15 – Tausch direkt am Gerät:** Im Reiter **Tausch / Prüfung** das Gerät **scannen** (Kamera auf das QR-Etikett; 🖼 wertet ein Foto aus) oder die Nummer eintippen → „Gerät öffnen“. Der Dialog zeigt alle offenen Benutzungen des Geräts **aus Einsatz bzw. Übung**: Datum und Uhrzeit, Minuten unter Atemschutz, Druck, **wer** damit unterwegs war (Träger, Trupp/Funktion, Ortswehr). Dann entscheiden:
- **🏭 Zur FTZ – Gerät tauschen:** Die angehakten Geräte (PA, Flasche, Lungenautomat, Maske) gehen zur Prüfung an die FTZ. Für jedes wird ein Tauschgerät eingetragen – **vorhanden** (Nummer aus der Datenbank wählen) oder **neu anlegen** (Nummer, Typ, Prüftermine). Das Tauschgerät wird der **Ortswehr zugewiesen, die gerade tauscht** (Vorgabe = angemeldete Wehr); auch jede andere Ortswehr der Gemeinde ist wählbar. Für neu angelegte Geräte wird gleich das **QR-Etikett** gedruckt.
- **⇄ Nur Elemente tauschen:** Flasche, Lungenautomat oder Maske wechseln, der Pressluftatmer bleibt im Dienst; die Benutzung gilt als selbst gepflegt.
Beides wird mit Träger, Zeit und Dauer am Pflege-Eintrag festgehalten; der Atemschutzgerätewart sieht es in der Atemschutz-Datenbank unter Gerätepflege (mit dem Tauschgerät bzw. „Elemente getauscht: …“). Hat ein Gerät mehrere offene Benutzungen, werden sie zusammen abgehakt.

## Verkehrsunfall (Karte „VU“)

- **„+ Unfallfahrzeug“** legt ein Fahrzeug an (Nummer 1, 2, …). Felder: Art, Kennzeichen, Hersteller, Modell, Farbe, **Antrieb**, Lage (auf den Rädern / Seite / Dach), Personen, davon eingeklemmt, Rettungsart (Crashrettung, schnelle, schonende Rettung), Notiz. Jede Änderung steht mit Uhrzeit im Tagebuch.
- **Antrieb:** Bei Elektro, Hybrid und Plug-in-Hybrid wird das Fahrzeug gelb markiert („⚡ HOCHVOLT“) und die Hochvolt-Hinweise erscheinen; bei Autogas/Erdgas und Wasserstoff die Hinweise zum Gasantrieb. Solange der Antrieb „unbekannt“ ist, steht dort, woran man ihn erkennt. Der Airbag-Abstand (30/60/90 cm) steht immer da.
- **Maßnahmen** je Fahrzeug antippen (z. B. „Zündung aus“, „Batterie bzw. HV getrennt“, „Patient befreit“) – Uhrzeit und Tagebucheintrag entstehen automatisch; nochmal antippen nimmt zurück.
- **Rettungsdatenblatt:** Knöpfe **Euro Rescue** (rescue.euroncap.com, nach Hersteller/Modell/Baujahr) und **ADAC Rettungskarten** – brauchen Internet am Gerät. „Leitstelle fragen“ trägt eine Anfrage nach Rettungsdatenblatt/Fahrzeugdaten mit Kennzeichen ins Tagebuch ein (dann per Funk/Telefon weitergeben).
- Die Hinweise ersetzen nicht das Rettungsdatenblatt des Herstellers.

## Checklisten

- Karte „Checklisten“: Die Liste **Allgemein** gilt für jeden Einsatz, dazu die Liste(n), deren Stichwort-Anfang zum Einsatzstichwort passt – bei mehreren die genaueste (z. B. „TH VU“ → Verkehrsunfall statt Technische Hilfe).
- Vorgabe: Allgemein · Brand (B, F, BMA) · Verkehrsunfall (TH VU, VU) · Technische Hilfe (TH, H) · Gefahrgut/GAMS (ABC, CBRN, GSG) · Unwetter (UNWETTER, STURM, WASSER).
- Punkt antippen = erledigt mit Uhrzeit und Name, steht im Tagebuch („Checkliste „Brand“: ✓ …“). „Weitere Checkliste …“ nimmt eine andere Liste dazu.
- **Anpassen:** Verwaltung → Einstellungen → „Checklisten im Einsatz“. Eine Zeile `# Name | Stichwort, Stichwort` beginnt eine Liste (`*` = jeder Einsatz), darunter ein Punkt je Zeile. „Vorgabe wiederherstellen“ setzt zurück.
- **Excel (ab 5.13):** Im selben Abschnitt „⬇ Als Excel exportieren“ – jede Checkliste ist ein **Tabellenblatt, der Blattname ist der Name der Checkliste**; Zeile 1 die Stichwörter (Spalte B), darunter ein Punkt je Zeile. Am PC Blätter ergänzen, umbenennen oder löschen und mit „⬆ Excel importieren“ zurückspielen: Die Einsatzverwaltung zeigt erst, welche Listen mit wie vielen Punkten erkannt wurden, und ersetzt nach Bestätigung (PIN) alle Checklisten durch die Datei.

## Einsatz-Zeitstrahl (ab 3.27)

- Einsatz → **Zeitstrahl**: je Fahrzeug ein Balken mit den Status-Zeiten (Alarmiert, 3, 4, 1/2, 6 farbig), darunter die Ereignisse (L = Lagemeldung, B = Lagebesprechung, E = Übergabe der Einsatzleitung, N = Anforderung). Mit der Maus auf einen Balken zeigen: genaue Zeiten. „Drucken / PDF“ im Querformat.
- Der Zeitstrahl steht auch im **Einsatzbericht** (nach „Fahrzeuge und Zeiten“).

## Lagebesprechung (ab 3.27)

- Einsatz → Übersicht → **„🗣 Lagebesprechung“** (auch über Strg+F): Übersicht für die Besprechung – letzte Lage, Kräfte und Stärke, Atemschutz, Gefahren und Personen von der Lagekarte, Abschnitte, Offenes (Anforderungen, Aufträge, Uhren), Warnungen.
- Teilnehmer und **Ergebnis / Maßnahmen** eintragen, **nächste Besprechung** wählen (15 … 120 min) → „Ins Tagebuch“. Die nächste Besprechung erscheint als Einsatz-Uhr (Erinnerung oben, Ton, Hinweis-Zentrale, „+10 min“).
- „Drucken“ gibt die Übersicht mit freiem Feld für Notizen aus.

## Übergabe der Einsatzleitung (ab 3.27)

- Übersicht → beim Einsatzleiter **„Übergabe“**: neuer Einsatzleiter, Checkliste (Lage, Gefahren, Kräfte/Abschnitte, offene Aufträge/Anforderungen, Atemschutz/Sicherheitstrupp, Wasserversorgung, Funk, Ansprechpartner/Presse) und Bemerkung. Fehlen Punkte, fragt die App nach. Die Übergabe steht mit allen Punkten im Tagebuch, im Zeitstrahl und im Änderungsprotokoll.

## Plausibilitätsprüfung und Ablösung (ab 3.27)

- In der **Hinweis-Zentrale (🔔)** erscheinen zusätzlich:
  - Fahrzeug seit … **alarmiert, kein Status 3** (Vorgabe 15 min)
  - **Status 3 ohne Status 4** (Vorgabe 30 min)
  - **Status 4, laut GPS aber … km vom Einsatzort** (Vorgabe 5 km)
  - **mehr AGT als Personen** in der Stärke
  - **noch keine Lagemeldung** (Vorgabe 20 min nach Alarm)
  - **Einsatzort ohne Koordinate**
  - **Ablösung prüfen** (Vorgabe 3 h im Einsatz) und **Verpflegung** (Vorgabe 4 h)
- Jeder Hinweis hat einen passenden Knopf (Fahrzeug, Stärke, auf der Karte, Lagemeldung …) und „Ausblenden“ (bis sich etwas ändert bzw. 1 h bei Ablösung).
- Schwellen: Verwaltung → Einstellungen → „Plausibilitätsprüfung und Ablösung“ (0 = aus).
- **Einsatz beenden** warnt jetzt, wenn laut ASÜ noch Trupps unter Atemschutz sind, Fahrzeuge noch auf Status 3/4 stehen oder es keine Lagemeldung gibt.

## Pressetext (ab 3.22)

- Einsatz → Übersicht **„📰 Pressetext“** oder im Archiv beim Einsatzbericht. Erzeugt einen Entwurf: Tag und Tageszeit, Alarmzeit, Meldebild, Ort **ohne Hausnummer** (Straße nur auf Wunsch), beteiligte Ortsfeuerwehren, Fahrzeuge, ungefähre Zahl der Einsatzkräfte, Atemschutztrupps, Unfallfahrzeuge und Einsatzdauer – einzeln abwählbar.
- Platzhalter [ … ] ergänzen, dann kopieren oder als Textdatei speichern. Keine Namen, Kennzeichen oder Angaben zu Verletzungen; vor dem Veröffentlichen freigeben lassen.

## Einsatzbericht (PDF)

- **Laufender Einsatz:** Übersicht → „Einsatzbericht (PDF)“ (als *vorläufig* gekennzeichnet). **Beendeter Einsatz:** erscheint nach „Einsatz beenden“ automatisch und im Archiv.
- Inhalt: Kopfdaten, Kennzahlen (Dauer, Fahrzeuge, Stärke, AGT, Fahrzeug- und Personalstunden), **Lagekarte** (und Einsatztaktik, wenn gezeichnet) mit Einsatzort, Symbolen, Zeichnungen, Abschnittsbereichen und Fahrzeugen, Fahrzeuge mit Zeiten, Abschnitt und Auftrag, Einsatzabschnitte, Unfallfahrzeuge mit Maßnahmen, Kräfteanforderungen, Lagemeldungen, Checklisten (erledigt mit Uhrzeit, offen), **Atemschutz** mit Trupps, Namen, Geräten, Zeiten und Drücken aus der ASÜ, Aufträge, vollständiges Einsatztagebuch, Unterschriftsfeld.
- **„Als PDF speichern / Drucken“** öffnet den Druckdialog: als Drucker „Als PDF speichern“ wählen. Am iPad/iPhone: Teilen → Drucken → Vorschau mit zwei Fingern aufziehen → Teilen → „In Dateien sichern“. Der Dateiname ist „Einsatzbericht 2026-001“.
- **Filter (neu in 3.20):** Über dem Bericht „Absender“ und „Empfänger“ wählen (alle Namen aus Tagebuch und Nachrichten, z. B. ein Fahrzeug, ELW, Leitstelle) und/oder im Suchfeld nach Text suchen. Einsatztagebuch und Nachrichten zeigen dann nur passende Einträge; oben steht „Gefiltert: …“ mit der Trefferzahl. „nur Nachrichten und Tagebuch“ blendet alle anderen Abschnitte aus (Auszug). Drucken/PDF und „Tagebuch als CSV“ übernehmen den Filter; „Filter zurücksetzen“ zeigt wieder alles.
- **Nachrichten im Bericht:** Über dem Bericht „✉ Nachrichten im Bericht: x von y – auswählen“ aufklappen und Häkchen setzen oder entfernen (laufend und im Archiv). Die angehakten Nachrichten stehen im Abschnitt „Nachrichten Einsatzleitung ↔ Fahrzeuge“ mit Bildern.

## Einsatzmappe drucken (ab 3.27)

- Übersicht → **„🗂 Mappe drucken“**: A4 für das Klemmbrett mit Einsatzdaten und Koordinate, Kräfteübersicht (Fahrzeug, Typ, Wehr, Status, Abschnitt, Stärke, AGT, seit, Notiz) plus leere Zeilen, Abschnitte, Funk, Ansprechpartner, offene Anforderungen und einer Seite **Einsatztagebuch von Hand**. Rückfallebene, falls Strom, Netz oder Pi ausfallen – danach als Nachtrag übernehmen.

## Nachbereitung je Fahrzeug

- Einsatz → **Nachbereitung** (auch später: Archiv → Einsatz → „Nachbereitung“). Je Fahrzeug aufklappen:
  - **Nach dem Einsatz:** einsatzbereit / eingeschränkt / nicht einsatzbereit, dazu eine Bemerkung.
  - **Verbrauchtes Material** (zum Nachfüllen, mit Menge; Vorschläge wie Ölbindemittel, Schaummittel).
  - **Defekte / verschmutzte Geräte** (Gerät und was kaputt ist).
  - **Atemschutz zur Werkstatt** (Pressluftatmer, Lungenautomat, Maske, Flasche mit Nummer).
  - „Nachbereitung abgeschlossen ✓“, wenn das Fahrzeug fertig ist.
- **Atemschutz (ASÜ):** „Geräte aus der ASÜ übernehmen“ trägt alle Geräte-, Lungenautomat-, Masken- und Flaschennummern der Trupps dieses Einsatzes ein.
- Jeder Punkt lässt sich als **erledigt** abhaken (mit Zeit und Name). Alles steht im Tagebuch und im Einsatzbericht.
- **Gerätewart:** Reiter Archiv → „Gerätewart – offene Punkte“ sammelt alles Offene aus laufenden Einsätzen und den letzten 12 Monaten: nicht einsatzbereite Fahrzeuge, Defekte, Atemschutz, Material – mit „erledigt ✓“, Drucken/PDF und CSV.

## Atemschutz-Nachweis je Person

- Verwaltung → **Atemschutz-Nachweis** (nur Admins). Entsteht automatisch aus der Atemschutzüberwachung: jeder Trupp mit „Beginn“ zählt je Mitglied – als Einsatz oder Übung, wie in der ASÜ unter „Art“ eingetragen.
- Liste je Person: Einsätze, Übungen, Zeit unter Atemschutz, zuletzt; Filter nach Jahr und Art, Suche. Antippen zeigt alle Einsätze mit Datum, Einsatzstelle, Funktion, Trupp, Gerät und Dauer.
- Drucken/PDF je Person oder als Liste, CSV für alle Einträge. Falsche Einträge (z. B. Testdaten) mit ✕ ausblenden – steht im Systemprotokoll.
- Die Einträge bleiben dauerhaft auf dem Pi, auch wenn die ASÜ-Daten nach 90 Tagen gelöscht werden. Wichtig: Namen in der ASÜ immer gleich schreiben (Nachname, Vorname), sonst entstehen zwei Personen.

## Expositionsnachweis (ab 3.27)

- Einsatz → **Nachbereitung → „Expositionen erfassen“** oder im Archiv **„☣ Exposition“**: je Person Art (Brandrauch, Gefahrstoff, Asbest, Biologisch/Infektion, Radioaktiv, Sonstiges), Stoff/UN-Nummer, Tätigkeit, Dauer, Atemschutz (Pressluftatmer, Filtergerät, FFP-Maske, ohne) und Kontakt mit Haut/Kleidung. Atemschutzgeräteträger aus der ASÜ sind mit ihrer Zeit vorausgefüllt, die Art wird aus dem Stichwort vorgeschlagen, „+ Person“ für alle anderen (z. B. Maschinisten ohne Atemschutz). „Für alle angekreuzten“ setzt Art und Stoff auf einmal.
- Verwaltung → **Exposition** (nur Admin): alle Personen mit Anzahl, Gesamtdauer und „ohne Atemschutz“; je Person Nachweis zum Drucken (mit Unterschriftfeld), CSV für alle, „+ Eintrag“ für ältere Einsätze, Einträge ausblenden.
- Gesundheitsbezogene Daten: nur auf dem Pi, nicht an die Geräte verteilt, nur Admins sehen die Liste. In der Datensicherung enthalten.

# Teil 3 – Fahrzeuge, Apps und Objekte

## Fahrzeug-App und Standort

- **Link und QR-Code:** Fahrzeug antippen → „Stärke …“ → „Fahrzeug-App für dieses Fahrzeug“. Das Fenster zeigt QR-Code und Link, prüft, ob die Adresse von diesem Gerät aus erreichbar ist, und druckt mit „QR-Code drucken“ ein Blatt für das Fahrzeug.

- Jedes Fahrzeug hat eine eigene App (Link über Fahrzeug → „Stärke …“ → „Fahrzeug-App für dieses Fahrzeug“). Sie meldet FMS-Status, Sprechwunsch, Stärke und alle 2 Minuten den Standort.
- Der Standort wird nur gesendet, solange die App geöffnet ist, und nur bei Status 1, A, 3 und 4 (auf Wunsch auch bei 2 und 6). Er braucht eine https-Adresse (siehe Anleitung, Schritt 8).
- In der Einsatzverwaltung erscheint bei jedem Fahrzeug „GPS hh:mm · x km vom Einsatzort“ (gelb, wenn älter als 5 Minuten). In der Fahrzeugansicht gibt es einen Link zur Karte.
- Auf der Lagekarte stehen Fahrzeuge mit GPS automatisch an ihrer echten Position (Kennzeichen „GPS“). Solche Fahrzeuge lassen sich nicht von Hand verschieben. Positionen älter als 30 Minuten werden nicht mehr verwendet.
- Die Fahrspur je Einsatz wird mit archiviert.

### Zugang der Fahrzeug-App erneuern oder sperren (ab 3.28)

- **Handy verloren, Link in falschen Händen?** Im Fenster „Fahrzeug-App für dieses Fahrzeug“ gibt es unten den Bereich **Zugang**:
  - **🔄 Neuer Link** – der bisherige Link ist **sofort ungültig**; Handys mit dem alten Link zeigen „Link ungültig“ und löschen die dort gespeicherten Daten. Danach den neuen QR-Code drucken und an die Besatzung geben.
  - **⛔ Sperren** – die App des Fahrzeugs ist ganz abgeschaltet (kein Status, keine Nachrichten, kein Standort); das Handy zeigt „Zugang gesperrt“. Freigeben kann nur ein Admin: „Freigeben mit neuem Link“ (empfohlen, wenn der Link in falsche Hände geraten ist) oder „Mit bisherigem Link freigeben“.
  - Neuer Link und Sperren dürfen Einsatzleiter und Admins, Freigeben nur Admins. Ein Grund kann angegeben werden.
- **Verwaltung → Fahrzeug-App** (Einsatzleiter und Admins): alle Fahrzeuge mit App – Zustand (aktiv/gesperrt), Link gültig seit, zuletzt benutzt, **Zugriffsversuche mit altem oder gesperrtem Link** (⚠). Admins haben dort zusätzlich **„Alle Links erneuern (Notfall)“** – z. B. wenn eine Liste oder ein Ausdruck der QR-Codes verloren gegangen ist (Bestätigung durch Eintippen von ERNEUERN).
- Alle Aktionen stehen im **Änderungsprotokoll** (ohne die Schlüssel).
- Die Schlüssel der Links kennt nur noch der Pi: Sie werden nicht mehr an die Geräte verteilt, nicht mit „Stammdaten sichern (JSON)“ exportiert und nicht importiert. Betrachter sehen keine Links.

## Fahrzeug-App: Reiter und Meldungen (ab 3.39)

Die Fahrzeug-App ist in vier Reiter unten am Bildschirm aufgeteilt (der zuletzt gewählte bleibt beim nächsten Öffnen):

- **🚒 Einsatz** – laufender Einsatz, Objektdaten, FMS-Status und Sprechwunsch; Hinweis auf ungelesene Nachrichten.
- **✉️ Nachrichten** – Nachrichten der Einsatzleitung (mit „Verstanden“) und Nachricht/Fotos an die Einsatzleitung. Die Zahl am Reiter zeigt offene Nachrichten.
- **👥 Stärke** – Stärke melden.
- **📍 Standort** – Standortübertragung; ein gelber Punkt am Reiter zeigt einen Fehler.

**Meldungen auf der offenen Seite** (oben eingeblendet, egal in welchem Reiter; antippen öffnet den passenden Reiter, × schließt):
- 🚨 **Alarm**: das Fahrzeug wurde einem Einsatz zugeordnet (je Einsatz einmal, auch nach Neuladen nicht doppelt) – mit Ton/Vibration.
- ✉️ **Nachricht der Einsatzleitung** mit dem Text – mit Ton/Vibration, bleibt stehen bis zum Antippen.
- 🏢 **Objektdaten verfügbar**, **vergeben** an ein anderes Fahrzeug oder **nicht mehr verfügbar**.
- 🚦 **Status geändert** durch die Einsatzleitung (eigene Statusmeldungen lösen keine Meldung aus), ✅ **Sprechwunsch erledigt**, ✅ **Nachricht gelesen**.

Die App fragt alle 10 Sekunden und sofort beim Zurückkehren in die App nach; höchstens drei Meldungen stehen gleichzeitig.

## Fahrzeug-App: Karte mit what3words (ab 3.46)

Neuer Reiter **🗺️ Karte** in der Fahrzeug-App:
- OpenStreetMap-Karte (Kacheln kommen über den Pi und werden dort zwischengespeichert; nur rund 100 km um den Heimatort). Verschieben mit dem Finger, Zoomen mit zwei Fingern, Doppeltipp oder **+ / −**.
- **Auf die Karte tippen:** zeigt die **what3words-Adresse** (///wort.wort.wort) und die Koordinate des Punktes. Knöpfe: **📋 Kopieren**, **✉ An Einsatzleitung** (kommt als Nachricht mit ///-Adresse und Koordinate in der Einsatzverwaltung an), **🧭 Navigation** (Routenplaner des Handys).
- **◎ Mein Standort** (GPS des Handys) mit what3words – z. B. um der Leitstelle oder Einsatzleitung den eigenen Standort durchzugeben.
- **🚒 Einsatzort:** Ist das Fahrzeug einem Einsatz mit Koordinate zugeordnet, steht der Einsatzort auf der Karte.
- **Suche:** „///tisch.lampe.garten“ (auch ohne ///; bei Tippfehlern Vorschläge „Meinten Sie …“) oder eine Koordinate „52.05, 9.26“.
- Der what3words-Schlüssel bleibt auf dem Pi. Ohne Schlüssel zeigt die Karte nur Koordinaten.
- **Einstellung** (Schnittstellen → Fahrzeug-App → „Karte in der Fahrzeug-App“): `an` (Vorgabe, mit Einsatzort für Fahrzeuge im Einsatz), `ohne-einsatzort`, `aus`.
- Schutz: nur mit gültigem Fahrzeug-Link, höchstens 600 Kacheln und 30 what3words-Abfragen je Minute und Fahrzeug.

## Objektdaten in der Fahrzeug-App (ab 3.37)

Liegt der Einsatzort bei einem **Objekt** (dem Einsatz zugeordnet, gleiche Anschrift oder höchstens 50 m entfernt), bekommt die Fahrzeug-App die **Objektdaten** – aber nur **ein Fahrzeug**:

- **Nur die Ortsfeuerwehr des Einsatzortes:** Nur alarmierte Fahrzeuge (im Einsatz) dieser Ortsfeuerwehr der eigenen Gemeinde sehen überhaupt einen Hinweis. Welche Ortsfeuerwehr zuständig ist, steht beim Objekt (**Verwaltung → Objekte → bearbeiten → „Zuständige Ortsfeuerwehr“**). Ist dort „automatisch aus der Adresse“ eingestellt, wird der Ortsteil aus der Anschrift genommen (z. B. „…, Reher, 31855 Aerzen“ → Reher; ohne Ortsteil → Kernort). Ist kein Ort erkennbar, bekommt **kein** Fahrzeug die Daten – die Einsatzübersicht weist darauf hin.
- **Nur das erste Fahrzeug:** In der App erscheint „Objekt am Einsatzort“ mit Name und Art. Mit **„Einsatzleitung übernehmen – Objektdaten öffnen“** übernimmt das Fahrzeug die Einsatzleitung vor Ort und sieht Adresse, Hinweise, Ansprechpartner (Rufnummern antippbar) und Pläne. Alle anderen Fahrzeuge sehen danach nur „Die Objektdaten hat 14-17-11“. Drücken zwei Fahrzeuge gleichzeitig, gewinnt das erste.
- **Einsatztagebuch:** „14-17-11 übernimmt die Einsatzleitung vor Ort und hat die Objektdaten … geöffnet“. In der **Einsatzübersicht** steht über dem Objekt, wer die Daten hat; Einsatzleitung/Admin können mit **„Freigabe zurücksetzen“** sperren – dann kann das nächste berechtigte Fahrzeug übernehmen.
- **Ende:** Verlässt das Fahrzeug den Einsatz, endet der Einsatz oder ist die Ortsfeuerwehr nicht mehr zuständig, sind die Daten in der App sofort weg. Die App speichert Objektdaten nicht auf dem Handy; Pläne werden jedes Mal vom Pi geladen.

## Fahrzeuge nachmelden – auch ohne Eintrag in der Fahrzeugliste (ab 3.49)

Kommt an der Einsatzstelle ein Fahrzeug dazu, das nicht alarmiert wurde oder noch gar nicht in der Fahrzeugliste steht (Nachbarwehr, THW, DLRG, Werkfeuerwehr …), lässt es sich direkt erfassen:

- **Einsatzverwaltung:** im Einsatz **„＋ Fahrzeug“** oder in der **Stärkemeldung „＋ Fahrzeug hinzufügen“**.
  - Oben suchen: vorhandenes Fahrzeug antippen → es kommt in den Einsatz.
  - Nicht gefunden: unten **Funkrufname** (Pflicht), Fahrzeugtyp, Organisation/Ortswehr, Status (4 an der Einsatzstelle / 3 auf Anfahrt) und optional die Stärke eintragen → **„Anlegen und zuordnen“**.
- **Besatzungs-App (📋 Stärke):** im Feld „+ Weiteres Fahrzeug“ suchen → **„➕ … als neues Fahrzeug anlegen“** → Funkrufname, Typ, Organisation → „Hinzufügen“, Stärke eintragen und senden.
- **Sammelseite ohne App:** „weitere Einheiten“ werden beim Einlesen in der Einsatzverwaltung automatisch als **„➕ als neues Fahrzeug anlegen“** vorgeschlagen (oder einem vorhandenen Fahrzeug zuordnen).

Das neue Fahrzeug bekommt Status 4 (bzw. 3) im Einsatz, der Vorgang steht im Einsatztagebuch. Gibt es den Funkrufnamen schon, wird kein zweites Fahrzeug angelegt, sondern das vorhandene genommen.
In der **Fahrzeugverwaltung** sind solche Fahrzeuge mit **„🆕 nachgemeldet · Einsatz …“** markiert (Suche „nachgemeldet“). Daten prüfen (z. B. Gemeinde ergänzen) und speichern – dann verschwindet die Markierung; nicht mehr benötigte Fahrzeuge nach dem Einsatz löschen.

## Fahrzeugstatus von außen (PowerAlarm, ab 3.22)

- Verwaltung → Einstellungen → **„Fahrzeugstatus von außen“** (nur Admin): Häkchen „annehmen“, „Speichern“. Es entsteht eine Adresse mit geheimem Schlüssel – über den Meldeserver (Port 8081, aus dem Internet) und im eigenen Netz (Port 8080).
- In **PowerAlarm** einen Kontakt vom Typ **HTTP** mit dieser Adresse anlegen (JSON oder Parameter) und ihn der Meldungsgruppe zuordnen, die bei Statuswechseln der Fahrzeuge informiert wird. Andere Systeme, die eine Adresse aufrufen können, funktionieren genauso.
- Übernommen werden Status 1, 2, 3, 4, 6 sowie 5 (Sprechwunsch) und 0 (Notruf); im Tagebuch steht „(PowerAlarm)“. Das Fahrzeug wird am Funkrufnamen erkannt. Unbekannte Kennungen (z. B. ISSI oder FMS-Kennung) erscheinen als „neu“ und werden einmal einem Fahrzeug zugeordnet. Die Feldnamen erkennt die Einsatzverwaltung selbst (fahrzeug, vehicle, funkrufname, fms, issi … bzw. status); abweichende Namen lassen sich eintragen.
- „Zuletzt empfangen“ zeigt jede Meldung mit Inhalt und Ergebnis – damit lässt sich die Einrichtung prüfen. „Neue Adresse erzeugen“ macht die alte ungültig.
- Hinweis: Das genaue Nachrichtenformat von PowerAlarm ist nicht öffentlich beschrieben. Nach der ersten echten Meldung im Protokoll prüfen, ob Fahrzeug und Status erkannt wurden, und sonst die Feldnamen eintragen.

## PowerAlarm-Anbindung: Nachalarmierung, Alarme einlesen, Status senden (ab 5.12)

Zusätzlich zum Empfang des Fahrzeugstatus (Kapitel oben) kann die Einsatzverwaltung PowerAlarm über dessen **JSON-Schnittstelle** selbst ansprechen. Dafür braucht der Pi einen **API-Key** aus PowerAlarm (Administration → Verwaltung → „API-Keys für Schnittstellen“, Rechte „Gruppen/Kontakte lesen“ und „Alarm auslösen“). Eintragen unter Verwaltung → Einstellungen → Schnittstellen, Adressen und Schlüssel → **PowerAlarm**; der Schlüssel bleibt auf dem Pi.

- **Verwaltung → Einstellungen → Alarmierung → „PowerAlarm-Anbindung“:** Zustand, geladene Gruppen mit **Zuordnung** (unter „Gruppen und Ortswehren“ von Hand änderbar): zur Wahl stehen nur die **Ortswehren der eigenen Gemeinde** und deren **Fahrzeuge und Funktionen** aus der Fahrzeugliste. Erkannt wird automatisch aus dem Gruppennamen – „Aerzen Groß“ → Aerzen, gleiche Ortsnummer im Kürzel („1410…“) = gleiche Ortswehr, „Groß Berkel TLF“ → das TLF Groß Berkel, „Aerzen OrtsBM“ → die Funktion OrtsBM Aerzen, „GemBM 14-02-01“ → der Funkrufname. Je Gruppe lassen sich **mehrere Fahrzeuge/Funktionen** anhaken (✎) – sie werden beim Alarm dieser Gruppe (gelesen oder nachalarmiert) in der Einsatzverwaltung mit alarmiert (Status A); „Keine“ = keine automatische Fahrzeug-Alarmierung. Die Spalte **„Einsatz anlegen“** steuert je Gruppe, ob ein von PowerAlarm gelesener Alarm einen Einsatz erzeugt (Vorgabe: ja bei …A, nein bei …I/…V) – so kann „Alarme einlesen“ auf „einsatz“ stehen und ihr entscheidet trotzdem pro Gruppe, ob ein Einsatz entsteht, **„Verbindung prüfen“** (lädt die Gruppen), **„Alarme jetzt einlesen“**, **„Probealarm senden“** an eine Gruppe (mit Rückfrage und PIN – alarmiert wirklich alle Kontakte der Gruppe), Protokoll der letzten Aktionen.
- **📣 Nachalarmierung aus dem Einsatz** (Einsatz → Übersicht → Kräfteanforderungen → „📣 PowerAlarm“, Einsatzleitung und Admin): Die Gruppen stehen **nach Ortswehr sortiert** – die Ortswehren, deren Fahrzeuge im Einsatz sind (oder deren Name in der Einsatzadresse steht), zuerst und aufgeklappt, dann die übrigen, zuletzt „Gemeinde“ (übergreifende Gruppen wie GemBM, Führungsgruppe, AGT, CSA, Presse). Standard sind nur die **Alarm-Gruppen** (Kürzel …A); „auch Info- und Verteilergruppen zeigen“ blendet …I und …V ein. Gruppe(n) anhaken (Vorauswahl aus der Einstellung „Vorgewählte Gruppe“). Darunter (ab 5.14) **„Einzelne Fahrzeuge und Funktionen der Gemeinde“** nach Ortswehr – weil sich manche PowerAlarm-Gruppen aus mehreren Orten und Fahrzeugen zusammensetzen: angehakte Fahrzeuge/Funktionen werden in der Einsatzverwaltung alarmiert (Status A, dem Einsatz zugeordnet, Tagebuch-Vermerk) und als Einsatzmittel an PowerAlarm mitgeschickt; schon im Einsatz befindliche sind markiert. Ohne Gruppe wird nur in der Einsatzverwaltung alarmiert. Alarmtext vorbelegt mit Stichwort, Meldebild, Adresse und Einsatznummer, optional Einsatzmittel. PowerAlarm bekommt zusätzlich Koordinate und Adresse, die Apps zeigen den Einsatzort. Rückfrage und PIN, danach Eintrag im Einsatztagebuch (Ausgang an PowerAlarm). Bei Übungen erscheint eine deutliche Warnung.
- **ℹ Lage-Info:** Im selben Dialog an alle bereits alarmierten Gruppen eine Info-Nachricht schicken (z. B. „Lage unter Kontrolle“, „Nachrücker nicht mehr nötig“) – kommt als Info in die PowerAlarm-Apps; auch im Tagebuch.
- **Alarme aus PowerAlarm einlesen** (Einstellung „Alarme aus PowerAlarm einlesen“): „hinweis“ = jeder neue Alarm erscheint als Hinweis in der Einsatzverwaltung und im Systemprotokoll · „einsatz“ = aus jedem neuen Alarm wird wie bei der Leitstellen-Mail ein Einsatz (bzw. ein Auftrag in einer Großschadenslage) angelegt – Stichwort, Meldebild, Adresse und Fahrzeuge werden aus dem Alarmtext gelesen. Abfrage jede Minute, nur Alarme der letzten 30 Minuten, keine Doppelten. Eine Ergänzung zur Leitstellen-Mail, kein Ersatz für den Melder.
- **Ein Einsatz je Alarm (ab 5.14):** Nur **Alarm-Gruppen** (…A) erzeugen einen Einsatz; Info- und Verteilergruppen (…I, …V) werden nur protokolliert. Werden mehrere Gruppen mit demselben Alarmtext ausgelöst (z. B. „Dehmke Groß“ und „Aerzen Groß“), entsteht **ein** Einsatz; die Ortswehren der Gruppen stehen als „Alarmierte Feuerwehren“ im Alarmtext – damit greift die Kräfte-Zuordnung (Verwaltung → E-Mail → Alarmierte Kräfte) und der Alarmmonitor zeigt die alarmierten Ortsfeuerwehren.
- **PowerAlarm und Leitstellen-Mail zusammen (ab 5.14):** Kommt zum selben Einsatz zuerst der PowerAlarm-Alarm und danach die Leitstellen-Mail (oder umgekehrt), wird **kein zweiter Einsatz** angelegt. Die Einsatzverwaltung erkennt den Einsatz an der Leitstellen-Nummer oder – innerhalb von 30 Minuten – an gleichem Stichwort und gleicher Adresse bzw. Koordinate (unter 400 m). Die E-Mail ergänzt dann: weitere Fahrzeuge werden alarmiert, Leitstellen-Nummer, Koordinate, Adresse und Meldebild nachgetragen, der Text steht im Tagebuch („Ergänzung per E-Mail zum Alarm über PowerAlarm“).
- **Fahrzeugstatus an PowerAlarm senden** (Einstellung „an“): Setzt die Einsatzleitung in der Einsatzverwaltung einen Status von Hand, geht er an PowerAlarm, damit Apps und PA-Monitor dasselbe zeigen. Dafür beim Fahrzeug (Verwaltung → Fahrzeuge) die **PowerAlarm-Kennung** eintragen (BOS-Kennung 8-stellig, OPTA oder ISSI – wie in PowerAlarm unter Administration → Fahrzeuge). Von PowerAlarm empfangene Status werden nicht zurückgeschickt.
- Nicht enthalten: Rückmeldungen („wer kommt“) über die PowerAlarm-Websocket-Schnittstelle – sie braucht eine gesonderte Freischaltung durch den Anbieter. Für „Wer kommt?“ bleibt die Besatzungs-App.
- In der Demo-Version wird nichts an PowerAlarm gesendet.

## Fahrzeugverwaltung: Suche und Filter (ab 3.44)

Verwaltung → **Fahrzeuge** hat über der Liste eine Such- und Filterleiste:
- **Suchfeld:** findet Funkrufname, Name, Typ/Funktion, Ortswehr, Gemeinde, Kennzeichen, Sondereinheit und Ausrüstung. Mehrere Wörter müssen alle passen („hlf aerzen“). Funkrufnamen und Kennzeichen auch ohne Striche/Leerzeichen („144610“ → 14-46-10).
- **Auswahllisten:** Gemeinde/Stadt → Ortswehr (nur die der gewählten Gemeinde) → Typ/Funktion, dazu Sondereinheit.
- **Sortierung:** nach Funkrufname (Vorgabe), Ortswehr, Typ oder wie in der Liste.
- Der Zähler zeigt „x von y Fahrzeugen“; **Zurücksetzen** hebt alle Filter auf. Suche und Filter bleiben auf dem Gerät gespeichert. Bearbeiten/Löschen geht direkt aus der gefilterten Liste; in jeder Zeile stehen jetzt auch Kennzeichen und Sondereinheit.

## ELW-Besatzung: „Wer kommt?“ (ab 3.47)

**Reiter „👥 Besatzung“** (neben der Lagekarte): zeigt für den **ELW 14-11-10** (einstellbar: Schnittstellen → Fahrzeug-App → „Fahrzeug der Besatzungs-App“)
- Status und Einsatz des ELW, die Zahlen **kommen / kommen nicht / ohne Rückmeldung** (grüne Zahl auch am Reiter),
- **Kommen** mit Ankunftszeit („19:34 – in 5 min“, „da“), **Kommen nicht**, **Ohne Rückmeldung** (Namen),
- **Standort des ELW** (aus der Fahrzeug-App des ELW mit eingeschaltetem Standort) mit „Auf der Lagekarte zeigen“,
- „Rückmeldungen zurücksetzen“. Die Rückmeldungen sind **nur informativ** – sie stehen nicht im Einsatztagebuch und nicht im Einsatzbericht.

**Personen und Links** (unten im Reiter, Einsatzleitung/Admin): Name eintragen → „+ Person“ → QR-Code/Link erscheint (drucken, kopieren). Jede Person hat einen **eigenen Link**; „Neuer Link“ macht den alten ungültig (z. B. Handy verloren), „Sperren“ schaltet ab, ✎ ändert den Namen, 🗑 löscht.

**Die App der Besatzung** (Handy, über den Meldeserver wie die Fahrzeug-App):
- Oben der **Alarm** des ELW (rot, mit Ton/Vibration, solange die App offen ist) bzw. „Kein Einsatz“.
- **Ankunft in 5 / 10 / 15 / 20 / 30 min** wählen → **„Ich komme“** oder **„Ich komme nicht“**. Danach „✅ Bin da“, „Ändern“, „Zurücknehmen“.
- **Wer kommt?** – Liste der anderen mit Ankunftszeit.
- **Karte** mit dem Standort des ELW, dem Einsatzort (Einstellung „Karte in der Fahrzeug-App“) und dem eigenen Standort (◎).
- Eine Rückmeldung kurz vor der Alarmierung des ELW (z. B. Melder schon ausgelöst) bleibt erhalten; nach dem Einsatzende beginnt eine neue Runde.
- Die App fragt alle 10 Sekunden nach, solange sie offen ist. Eine Benachrichtigung bei geschlossener App gibt es nicht – alarmiert wird weiter über den Melder.

## ELW-Besatzung: Stärken sammeln (ab 3.48)

Die Besatzungs-App hat oben zwei Reiter: **👥 Wer kommt?** und **📋 Stärke**. Damit sammelt die ELW-Besatzung an der Einsatzstelle die Stärken ein – die Rückmeldung geht **sofort online** in die Einsatzverwaltung.

1. **Einsatzverwaltung:** Einsatz → Fahrzeuge → Stärkemeldung → **„📱 Per Handy sammeln“** – der QR-Code enthält alle Fahrzeuge des Einsatzes mit den bisherigen Stärken.
2. **Besatzungs-App → 📋 Stärke:** „📷 QR-Code scannen“ (Kamera, nur über https), „🖼 Foto aufnehmen / wählen“ oder „Link / Code einfügen“. Die Fahrzeugliste erscheint.
3. Je Fahrzeug **F / UF / M / AGT** mit − / + oder direkt eintippen. Geänderte Fahrzeuge sind grün markiert, oben steht die Gesamtstärke.
4. **Weitere Fahrzeuge:** Im Feld „+ Weiteres Fahrzeug“ Funkrufname, Typ oder Ort eintippen und antippen (✕ entfernt es wieder).
5. **„✅ An Einsatzverwaltung senden“** – die Stärken sind sofort übernommen (mit Tagebuch-Eintrag „Stärkemeldung … (Besatzungs-App, Name)“), in der Einsatzverwaltung erscheint ein Hinweis.
   - Neu hinzugefügte Fahrzeuge, die noch in keinem Einsatz sind, werden dem Einsatz mit **Status 4** zugeordnet (Vermerk im Tagebuch).
   - Fahrzeuge, die in einem **anderen Einsatz** sind, werden nicht umgesetzt – die App sagt das.
   - Ist der Einsatz beendet oder keine Verbindung, bleibt alles in der App gespeichert und kann erneut gesendet werden.
6. Die Liste bleibt im Handy, bis „Liste schließen“ oder „Andere Liste scannen“ gedrückt wird – nachkorrigieren und erneut senden geht jederzeit.

Der bisherige Weg **ohne App** (Handykamera → Sammelseite → Rück-QR-Code → „📷 Ergebnis vom Handy einlesen“) funktioniert weiter, z. B. ohne Netz.

## Stärken per Handy sammeln (ab 3.36)

Für größere Lagen, wenn die Stärken an der Einsatzstelle zu Fuß eingesammelt werden: Einsatz → Fahrzeuge → **Stärkemeldung** → **„📱 Per Handy sammeln“**.

1. **QR-Code mit dem Handy scannen** (normale Kamera-App). Es öffnet sich die Seite **„Stärken sammeln“** mit allen Fahrzeugen des Einsatzes, die bisherigen Stärken sind vorbelegt.
2. Am Handy je Fahrzeug **F / UF / M / AGT** mit + / − oder per Eingabe setzen; stimmen die Werte schon, **„✓ Werte stimmen“** tippen. Erfasste Fahrzeuge werden grün, oben stehen Fortschritt („4 von 6 erfasst“) und Gesamtstärke. Einheiten, die nicht in der Liste stehen, unten unter **„Weitere Einheit“** mit Namen anlegen.
3. Die Eingaben bleiben auf dem Handy gespeichert – auch ohne Netz, bei Neuladen oder wenn das Handy zwischendurch gesperrt wird.
4. **„Fertig → QR-Code“**: Das Handy zeigt einen QR-Code mit allen erfassten Fahrzeugen (noch nicht erfasste werden genannt und **nicht** übertragen).
5. In der Einsatzverwaltung: **Stärkemeldung → „📷 Ergebnis vom Handy einlesen“**. Den QR-Code des Handys vor die Kamera halten (Live-Kamera nur bei Aufruf über HTTPS oder am Pi selbst). Sonst **„📷 Foto aufnehmen / wählen“** – am Tablet öffnet sich die Kamera, am Laptop ein Foto auswählen. Oder den Code einfügen, den das Handy über **„Code teilen / kopieren“** z. B. per Messenger geschickt hat.
6. Eine **Vorschau** zeigt je Einheit *bisher → neu*. Geänderte Fahrzeuge sind angehakt, unveränderte und nicht mehr eingesetzte nicht. Weitere Einheiten werden – wenn möglich – über den Funkrufnamen einem Fahrzeug zugeordnet, sonst von Hand. **„Stärken übernehmen“** setzt die Stärken; im Tagebuch steht je Fahrzeug „Stärkemeldung … (Sammelerfassung per Handy)“.

Hinweise: Die Fahrzeugliste steht **nur im QR-Code** (Teil hinter „#“ der Adresse) und wird nicht an den Server geschickt; enthalten sind Funkrufnamen, Typen, bisherige Stärken, Nummer und Stichwort des Einsatzes – keine Adresse, keine Namen. Die Seite liegt auf dem Meldeserver (Port 8081, Adresse wie die Fahrzeug-App); das Handy braucht nur zum **Öffnen** einmal Verbindung, danach arbeitet es offline. Erzeugt die Liste für einen anderen Einsatz als den geöffneten, warnt die Vorschau.

## Objekte mit Plänen

- **Eigener Reiter „Objekte“:** Suche, Karten je Objekt mit Hinweisen, „Öffnen“, „Auf der Karte“ (auch ohne Einsatz) und – für Admins – „+ Objekt anlegen“ und „Bearbeiten“. Im Einsatz erscheinen Objekte in der Nähe weiterhin als Hinweis in der Übersicht.

- **Pflegen (Admin):** Verwaltung → Objekte → „+ Objekt anlegen“: Name, Art, Adresse/Koordinate, Hinweise für den Einsatz (BMA, FSD, Zufahrt, Gefahrstoffe, Löschwasser), Ansprechpartner, Suchbegriffe. Danach Pläne und Dokumente hochladen (PDF, Bilder, Office, DWG/DXF, ZIP; je Datei bis 40 MB). Die Dateien liegen auf dem Pi im Ordner `objekte/`.
- **Im Einsatz:** Liegt der Einsatzort weniger als 150 m von einem Objekt entfernt oder wurde das Objekt im Einsatz gewählt, erscheint es als blaue Kachel unter den Einsatzknöpfen. Antippen zeigt Hinweise, Ansprechpartner (Telefonnummern zum Anrufen) und die Pläne.
- **Überall:** Knopf „Objekte“ in der Einsatzansicht (Suche), Objektsymbol auf der Lagekarte (ab Zoom 13) und Suche über der Karte.

## Alarmmonitor: Karte, Termine und Prüffristen (ab 4.5)

Der Alarmmonitor (Verwaltung → Alarmmonitor, eingeführt in 3.69) zeigt im **Ruhezustand** jetzt zusätzlich:

- **Unterwegs · Status 1:** eine Karte mit allen Fahrzeugen der Ortswehr, die im Status 1 sind und deren Standort die Fahrzeug-App meldet (🏠 = Gerätehaus). Ist der letzte Standort älter als 15 Minuten, wird das Fahrzeug blasser gezeigt. Ist kein Fahrzeug im Status 1, entfällt die Karte.
- **Termine:** die nächsten Termine (Vorgabe 14 Tage) aus bis zu fünf eingebundenen Kalendern und die **Prüffristen** (⚠). Heute steht grün „Heute“.
- **Im Alarm (ab 5.13):** Block **„Alarmierte Ortsfeuerwehren“** – die Ortswehren der alarmierten Fahrzeuge (eigene rot hervorgehoben) und Ortswehren, die in den „Kräften laut Alarmierung“ der Leitstellen-Mail genannt sind – vor den alarmierten Fahrzeugen.

**Kalender einbinden** (Monitor → Bearbeiten → „Kalender einbinden“, eine Adresse pro Zeile):
- **Google:** Kalender-Einstellungen → „Kalender integrieren“ → „Privatadresse im iCal-Format“ kopieren.
- **Apple/iCloud:** Kalender teilen → „Öffentlicher Kalender“ einschalten → Link (webcal://…) kopieren.
- Auch Outlook, Nextcloud usw. mit iCal-Adresse. Der Pi braucht Internet und lädt alle 15 Minuten neu; Serientermine (z. B. wöchentlicher Dienstabend), Ausnahmen und Sommer-/Winterzeit werden berücksichtigt. In der Monitorliste steht je Kalender die Zahl der Termine oder der Fehler; der Selbsttest meldet einen nicht abrufbaren Kalender.

**Prüffristen** (Verwaltung → Alarmmonitor → „Prüffristen“): eigene Fristen mit Bezeichnung, Ortswehr, Datum, Wiederholung (monatlich bis alle 5 Jahre) und Erinnerung – z. B. Leitern, Hebekissen, Feuerlöscher, Fahrzeug-HU. Die **Prüftermine der Atemschutzgeräte** aus der Atemschutz-Datenbank kommen automatisch dazu (je Tag und Wehr zusammengefasst, z. B. „Prüfung Atemschutzgeräte Aerzen – 2× PA, 1× Flaschen“). Namen von Atemschutzgeräteträgern erscheinen nie auf dem Monitor.

**Kalender-Abo** (Knopf „📅 Kalender-Abo“ beim Monitor): die Prüffristen dieser Ortswehr als abonnierbarer Kalender für Google, Apple oder Outlook – mit Erinnerung (Atemschutzgeräte 7 Tage vorher, eigene Fristen wie eingestellt). Google und Apple holen den Kalender aus dem Internet, dafür muss die externe Adresse (Meldeserver, https) eingetragen sein; Port 8080 bleibt intern. Der Link ist geheim – „Neuer Link“ beim Monitor macht ihn ungültig.

**Außer Dienst** (ab 4.6, Verwaltung → Alarmmonitor → „Außer Dienst“): Der Monitor zeigt im Ruhezustand unter den Fahrzeugen, was nicht einsatzbereit ist:
- Fahrzeuge im **Status 6** erscheinen automatisch (mit „seit …“). Mit „+ Fahrzeug“ lassen sich Grund und „voraussichtlich bis“ ergänzen – ein solcher Eintrag zeigt das Fahrzeug auch an, wenn der Status 6 (noch) nicht gesetzt ist. Den Status selbst setzt weiterhin die Leitstelle bzw. PowerAlarm.
- Mit „+ Gerät“ beliebige Geräte, z. B. „Hebekissen-Satz HLF – Prüfung“ oder „Wärmebildkamera defekt“.
- **Atemschutzgeräte bei der FTZ** kommen aus der Gerätepflege der Atemschutz-Datenbank (nur Anzahl, keine Namen).
- Einträge mit Datum verschwinden danach von selbst; „Wieder im Dienst“ entfernt sie sofort. Eintragen dürfen Einsatzleitung und Admins.

**Nachtmodus** (ab 4.6, Monitor → Bearbeiten → „Nachts“): Zwischen zwei Uhrzeiten (Vorgabe 23:00–06:00) wird der Bildschirm schwarz, wahlweise mit einer kleinen, dunklen Uhr, die jede Minute die Stelle wechselt. **Bei einem Alarm ist sofort alles wieder da** – auch der Gong. Der Fernseher selbst bleibt eingeschaltet (ein Browser kann ihn nicht ausschalten); ein schwarzes Bild spart bei OLED- und LED-Fernsehern trotzdem deutlich Strom und verhindert Einbrennen.

## Hydrantenprüfung mit der Fahrzeug-App (ab 5.9)

Die regelmäßige Sichtprüfung der Hydranten (Vorgabe: alle 12 Monate) wird direkt mit der **Fahrzeug-App** am Hydranten erledigt – ohne Papierliste.

**So geht's (Fahrzeug-App → Reiter 🗺️ Karte):**
1. **💧 Hydranten** einblenden und zum Hydranten zoomen. Farben: grau = ungeprüft, grün = geprüft und in Ordnung, orange = Mangel, rot = außer Betrieb, gestrichelt = Prüfung fällig.
2. Den Hydranten **antippen** → unten erscheint das Prüfblatt mit sechs Prüfpunkten: Hinweisschild vorhanden und lesbar · frei zugänglich (nicht zugeparkt, zugewachsen, überbaut) · Straßenkappe/Deckel bzw. Säule unbeschädigt und gängig · lässt sich öffnen und schließen · Wasser läuft nach dem Spülen klar · entleert sich nach dem Schließen (frostsicher).
3. Jeden Punkt mit ✓ oder ✗ bewerten – oder **„Alles in Ordnung“** antippen. Wahlweise Druck (bar), Bemerkung und bis zu **zwei Fotos** (z. B. vom Mangel) anhängen. **„Außer Betrieb“** meldet den Hydranten als nicht nutzbar.
4. **Speichern.** Der Zustand steht sofort in der Lagekarte der Einsatzverwaltung, auf dem Alarmmonitor und in der Verwaltung.

**Hydrant fehlt in der Karte?** An der richtigen Stelle auf die Karte tippen → „Hydranten hier melden und prüfen“. Selbst gemeldete Hydranten sind in der Verwaltung als „gemeldet“ gekennzeichnet und können dort bei einer Fehlmeldung gelöscht werden. **„Hydranten in der Nähe …“** listet bis zu 15 ungeprüfte, fällige oder mangelhafte Hydranten im Umkreis – praktisch, um eine Prüfrunde abzuarbeiten.

**Was passiert bei Mängeln:** Bei „Mangel“ oder „außer Betrieb“ schickt der Pi eine E-Mail mit Prüfpunkten, Bemerkung und Fotos an die unter Einstellungen → Hydrantenprüfung → „Mängel melden an“ eingetragenen Adressen (z. B. Wasserversorger oder Gemeinde); ohne Eintrag an die System-Empfänger. Jeder Hydrant hat eine kleine Historie (die letzten 12 Prüfungen).

**Einsatzverwaltung – Lagekarte:** Die Hydranten-Ebene zeigt die Prüfzustände in denselben Farben; antippen zeigt Datum, Ergebnis und Mängel. Ein Hydrant „außer Betrieb“ wird in der Einsatzplanung sofort sichtbar.

## Löschwasser-Abdeckung (ab 5.10)

Kartenebene **„Löschwasser-Abdeckung“** (Lagekarte → Ebenen): grüne Flächen = im Umkreis (Vorgabe 300 m, Einstellung `Löschwasser-Abdeckung: Umkreis`) einer Entnahmestelle, die nicht außer Betrieb ist. Lücken zwischen Häusern zeigen, wo Löschwasser fehlt; außer Betrieb gemeldete Hydranten erscheinen als rot gestrichelter Kreis. Unter Verwaltung → Hydranten steht dazu die Auswertung **„Objekte ohne Löschwasser im Umkreis“** – Objekte aus der Objektdatenbank, in deren Umkreis keine nutzbare Entnahmestelle liegt.

## Fahrtenbuch und Betriebsstunden (ab 5.10)

Die Fahrzeug-App führt je Fahrzeug ein **Fahrtenbuch** – ohne Kosten oder Gebühren, nur die Fahrzeugdaten. Reiter 🚒 Einsatz → Abschnitt **„Fahrtenbuch“**:

- **🚗 Fahrt:** Es wird nur der **aktuelle km-Stand** eingegeben (große Eingabe; beim allerersten Eintrag zusätzlich der km-Stand zu Beginn). **Zweck** ist vorausgewählt (im Einsatz „Einsatz“, sonst der zuletzt gewählte), **Ziel** als Auswahlliste (vorgegebene Ziele aus den Einstellungen – Vorgabe „Feuerwehrtechnische Zentrale | Ortsgebiet | Aerzen“ – plus die zuletzt eingetragenen Ziele des Fahrzeugs; „Neues Ziel“ frei eintragen). **Fahrer** aus der Liste der zuletzt eingetragenen Fahrer oder neu; die App merkt sich den zuletzt gewählten Fahrer.
- **Abfahrt und Ankunft** setzt der Pi aus dem **FMS-Status**: Wechsel von Status 2 (oder 6) auf einen anderen Status = Abfahrt, zurück auf Status 2 = Ankunft. Beide Zeiten stehen vorausgefüllt im Formular und sind änderbar (die Ankunft darf nicht vor der Abfahrt liegen).
- Läuft für das Fahrzeug ein Einsatz, trägt der Pi die **Einsatznummer** automatisch ein.
- **⛽ Getankt:** Liter (und AdBlue) mit km-Stand. **⏱ Betriebsstunden:** Zählerstände Pumpe und Aggregat.
- **Plausibilität:** km-Stand darf nicht kleiner als der letzte sein, Sprünge über 2000 km werden abgelehnt, Zählerstände dürfen nicht sinken – Tippfehler fallen sofort auf.
- **Erinnerung (ab 5.10.3):** Kommt das Fahrzeug nach einer Fahrt zurück auf **Status 2**, bekommt die Fahrzeug-App eine Benachrichtigung („Zurück auf Status 2 – bitte den km-Stand eintragen“), und das Fahrtenbuch öffnet sich von selbst mit dem Abzeichen „km“, bis die Fahrt eingetragen ist. Einstellung `Fahrtenbuch: Erinnerung bei Status 2` (an/aus).
- Die letzten fünf Einträge stehen unter dem Formular.

**Gerätedatenbank (Gerätewarte):** Beim Fahrzeug der Knopf **„🚗 Fahrtenbuch & Fristen“** – Fahrtenbuch je Jahr mit Abfahrt/Ankunft, km, Zweck, Ziel, Fahrer, Liter, Betriebsstunden; **CSV-Export** (Excel); falsche Einträge werden mit Grund als „falsch“ markiert (bleiben sichtbar, zählen nicht). Im **Jahresbericht** steht der Abschnitt „Fahrleistung“ (Fahrten, km, Liter je Fahrzeug).

## Fahrzeugfristen: HU, SP, UVV, Wartung, Pumpenprüfung (ab 5.10)

Im Dialog **„Fahrtenbuch & Fristen“** der Gerätedatenbank trägt der Gerätewart je Fahrzeug ein: **Hauptuntersuchung (HU), Sicherheitsprüfung (SP), UVV-Prüfung, Wartung (Datum und/oder „Wartung bei km“), Pumpenprüfung** sowie eine Notiz. Die Fristen zeigen oben im Dialog Ampelfarben (rot = abgelaufen, gelb = in 28 Tagen bzw. 500 km, grün = in Ordnung).

- **Erinnerung:** Ist eine Frist in 28 Tagen fällig oder abgelaufen (km-Wartung: noch 500 km), bekommen die Gerätewarte der Ortswehr eine E-Mail und eine Push-Benachrichtigung (Datenbank-App).
- **Alarmmonitor (ab 5.10.3):** Fahrzeugfristen erscheinen wie die Prüftermine der Atemschutzgeräte unter „Termine“ (28 Tage vorher); überfällige mit „⚠ überfällig“. Sie sind auch im **Kalender-Abo** der Ortswehr enthalten.
- Die Fahrzeug-App zeigt im Fahrtenbuch die nächsten Fristen (bis 60 Tage bzw. 1000 km) als Hinweis an.

# Teil 4 – Übungen und Demo

## Übungsgenerator

Eigene kleine App für Übungen: **Verwaltung → Einstellungen → „Übungsgenerator öffnen“** oder direkt `http://<Pi>:8080/uebung/`.

- **Szenario** = eine Übung mit Einsätzen und Aufträgen, jeweils mit **Zeit ab Start** (Minuten). Einsatz: Stichwort, Meldebild, Adresse/Koordinate, Meldender, „Großschadenslage“, Fahrzeuge zum Alarmieren (Funkrufnamen), Hinweis. Auftrag: für welchen Einsatz (aus dem Szenario oder „laufender Einsatz“), Kategorie, Priorität, Adresse, Beschreibung, Meldender.
- **🎲 Zufällig erzeugen:** Anzahl Einsätze (Brand, Technische Hilfe, Verkehrsunfall, Gefahrstoff) und Unwetter-Aufträge, Zeitraum; auf Wunsch echte Adressen im Umkreis des Heimatorts (Umkreis unter „Einstellungen“). Für Aufträge wird ein Unwetter-Einsatz (Großschadenslage) angelegt. Danach alles prüfen und anpassen. 🎲 an einer Adresse würfelt nur diese neu, „Suchen“ holt die Koordinate zur Adresse.
- **Vorbereiten geht überall**, auch ohne Verbindung zur Einsatzverwaltung (z. B. zu Hause über GitHub Pages, siehe ANLEITUNG Schritt 16). Die Szenarien bleiben auf dem Gerät gespeichert. **Verschicken geht nur im Netzwerk der Wehr** – oben steht dann grün „Im Netzwerk – Verschicken möglich“.
- **Ins Netzwerk bringen:** „Im Netzwerk übernehmen“ (Adresse der Einsatzverwaltung einmal unter „Einstellungen“ eintragen, im WLAN der Wehr antippen) – oder „Exportieren“ und in der App im Netzwerk „Importieren“. Im Netzwerk kann ein Szenario mit „Auf dem Pi ablegen“ für andere Geräte bereitgestellt werden.
- **Verschicken:** „▶ Ablauf starten“ schickt jeden Eintrag zu seiner Zeit (die Seite muss offen bleiben; Anhalten/Fortsetzen/Beenden), „Alles sofort senden“ oder „Jetzt senden“ je Eintrag. Jeder Eintrag zeigt „gesendet hh:mm · 2026-005 · Auftrag 3“ oder den Fehler.
- **Kennzeichnung:** Jeder Übungseinsatz hat „ÜBUNG:“ im Meldebild, einen Tagebuchvermerk „ÜBUNG – Einsatz aus dem Übungsgenerator“ und die Notiz; Aufträge enden mit „(ÜBUNG)“. Übungseinsätze werden wie echte beendet und archiviert.
- **Anmelden:** Im Netzwerk braucht der Übungsgenerator eine Anmeldung (Einsatzleitung oder Admin). Ist der Browser schon in der Einsatzverwaltung angemeldet, gilt das auch hier; sonst oben auf „bitte anmelden“ tippen.
- **Auswertung:** Nach dem Verschicken „Zeiten laden“ bzw. „Aktualisieren“: Median-Zeiten Alarm → erstes Fahrzeug Status 3 / Status 4 / erste Lagemeldung, bei Aufträgen Eingang → disponiert → erledigt; darunter jeder Einsatz und jeder Auftrag mit seinen Zeiten (offene Aufträge gelb). Funktioniert auch nach Einsatzende (aus dem Archiv). Drucken/PDF und CSV für die Nachbesprechung.
- **Vorsicht beim Alarmieren:** Beim Verschicken von hier werden eingetragene Fahrzeuge wirklich auf Status A gesetzt und dem Übungseinsatz zugeordnet – das sehen alle Geräte. Nur im Übungsbetrieb verwenden.
- **Besser über die Übungsleitstelle (ab 3.99):** „🎛 In der Übungsleitstelle abspielen“ spielt das Szenario nur mit virtuellen Übungsfahrzeugen ab – echte Fahrzeuge und Fahrzeug-Apps bleiben unberührt (siehe „Übungsleitstelle“).

## Feuerwehrhäuser und Anfahrtszeiten (ab 4.1)

**Verwaltung → Feuerwehrhäuser** führt die Standorte der Feuerwehrhäuser. Daraus schätzt das Programm, wie lange eine Ortswehr bis zu einer Einsatzstelle braucht.

- **Formel:** Ausrückzeit + Luftlinie × Umwegfaktor ÷ Durchschnittstempo. Vorgabe: 5 min Ausrücken, 55 km/h, Umwegfaktor 1,35. Die Werte lassen sich oben ändern („Regeln speichern“), die Ausrückzeit auch je Feuerwehrhaus (z. B. tagsüber schwächer besetzte Wehren). Es ist **eine Schätzung ohne Routenplaner** – Berge, Bahnübergänge oder Umwege kennt das Programm nicht.
- **Startwerte:** Die 13 Ortswehren des Flecken Aerzen sind mit Adresse eingetragen (Königsförde und Selxen als eine Ortsfeuerwehr „Königsförde/Selxen“ mit zwei Feuerwehrhäusern). Aerzen ist geprüft, die übrigen Koordinaten sind recherchiert und **ungefähr** – rot „prüfen“. Über „Bearbeiten“ die Adresse suchen oder die Koordinate direkt eintragen (z. B. aus der Karte kopiert) und „geprüft“ setzen.
- **Nachbarwehren:** „+ Feuerwehrhaus“ für einzelne Häuser, oder **„🛰 Aus OpenStreetMap ergänzen“** – holt alle Feuerwehrhäuser im eingestellten Umkreis um den Heimatort (braucht Internet auf dem Pi). Treffer, deren Name zu einer Ortswehr der Fahrzeugliste passt, werden zugeordnet; die übrigen lassen sich einzeln übernehmen.
- **Anfahrtszeiten testen:** Adresse eingeben – die Liste zeigt die nächsten Wehren mit geschätzter Zeit und ihren Fahrzeugen.
- Fehlt einer Ortswehr der Gemeinde noch ein Haus, steht oben ein Hinweis.

**Wo es genutzt wird:**
- **Übungsgenerator:** am Einsatz „🚒 Nächste Wehren eintragen“ – wählt die nächsten Wehren, trägt je Wehr bis zu zwei Fahrzeuge zum Alarmieren ein und merkt sich die **erwartete Anfahrtszeit**. Beim „🎲 Zufällig erzeugen“ geht das automatisch (je nach Stichwort 1–3 Wehren). In der Auswertung steht unter „1. Status 4“ die erwartete Zeit – rot, wenn die Wehr mehr als 20 % länger brauchte.
- **Übungsleitstelle:** Übungsfahrzeuge starten an ihrem Feuerwehrhaus (🏠 auf der Karte). Im Alarmformular erscheinen die nächsten Wehren mit Zeit; Fahrzeuge lassen sich direkt anhaken oder als Übungsfahrzeug „dazunehmen“. Die 🤖 Automatik rückt nach der Ausrückzeit der Wehr aus; Tempo „realistisch (Feuerwehrhäuser)“ fährt mit den Regeln oben.

- **Nach Gemeinde geordnet (ab 5.13):** Die Liste ist nach Gemeinde/Stadt gruppiert (Zuordnung über die Fahrzeugliste), die eigene Gemeinde zuerst, danach die übrigen alphabetisch.

## Demo- und Übungseinsätze aus realen Einsätzen (ab 3.30)

Aus einem echten, archivierten Einsatz wird ein **anonymisiertes Drehbuch** – für Übungen, Unterricht und zum Vorführen. Alles passiert auf dem Pi; echte Daten verlassen ihn nicht.

**Erstellen (nur Admin):** Archiv → Einsatz öffnen → **„🎭 Demo daraus erstellen“**.

1. **Personen:** Der Pi sucht Namen in Einsatzleiter, Meldender, Abschnittsleitern, Übergabe, Lagebesprechung, Ansprechpartnern, Aufträgen, Atemschutztrupps, Tagebuch (von/an) und in Texten nach Titel oder Dienstgrad („Herr …“, „ZF …“, „GemBM …“). Jeder bekommt einen **fiktiven Namen** (änderbar, Vornamen passend ersetzt). Nachnamen, die auch normale Wörter sind (z. B. „Brand“, „Wolf“), werden nur mit Titel, Dienstgrad oder Vorname ersetzt. Häkchen weg = nicht ersetzen.
2. **Weitere Ersetzungen** je Zeile `alt => neu` – für Spitznamen, Firmen, Hofnamen o. Ä.
3. **Automatisch:** Rufnummern → `01234 …`, E-Mail → `…@beispiel.invalid`, Kfz-Kennzeichen → `XX-DE …`, Benutzer → „Bediener 1, 2 …“, Einsatznummer → Nummer der Demo. **Fotos und Bilder werden nicht übernommen.**
4. **Einsatzort:** Hausnummern entfernen (Vorgabe) · Adresse unverändert · an einen **anderen Ort verlegen** (Adresse suchen oder Koordinate eintragen) – Karte, Symbole, Einsatztaktik, Abschnittsflächen und Fahrspuren wandern mit, die alte Straße wird in Texten ersetzt, Koordinaten in Texten werden zu „(Koordinate siehe Karte)“.
5. **Zeit:** Das Datum fällt weg, die Tageszeit des Alarms bleibt. **Lange Pausen kürzen auf … Minuten** (Vorgabe 10; 0 = Originalablauf). Uhrzeiten in Texten („um 14:32“) werden mitverschoben.
6. **Kontrolle:** Die Vorschau zeigt alle Texte, Ersetztes grün. Erst nach dem Haken „Ich habe die Texte geprüft …“ lässt sich speichern.

Das Drehbuch enthält keinen Verweis auf den Originaleinsatz. Im Änderungsprotokoll (nur Admin) steht, aus welchem Einsatz es entstand.

**Verwenden (Einsatzleitung und Admin):** Archiv → **„🎭 Demo-Einsätze“**:

- **📂 Ins Archiv:** Der ganze Einsatz erscheint mit Nummer „DEMO-001 …“ und frei wählbarer Alarmzeit im Archiv – mit Bericht, Zeitraffer, Lagekarte und Einsatztaktik. Zählt nicht in der Jahresauswertung (Übung) und nicht im Atemschutz-Nachweis.
- **▶ Live-Übung:** Eröffnet **jetzt** einen Übungseinsatz („ÜBUNG: …“). Im Rhythmus des Originals (Tempo 1×–10×) treffen ein: Fahrzeugstatus, Stärkemeldungen, Eingänge im Tagebuch, Nachrichten aus der Fahrzeug-App, ASÜ-Meldungen, Fahrzeugpositionen und Aufträge (Großschadenslage). **Nicht** vorgespielt werden die Entscheidungen der Einsatzleitung (Abschnitte, Lagemeldungen, Anforderungen, Karte) – die machen die Übenden. Zur Nachbesprechung kann dieselbe Demo „ins Archiv“ gestellt und verglichen werden.
  - „Fahrzeuge wirklich alarmieren“: Status erscheint auf allen Geräten. Fahrzeuge, die gerade in einem echten Einsatz sind, lässt das Drehbuch aus (Vermerk im Tagebuch). Ohne Haken erscheinen die Status nur als Tagebucheingang.
  - Im Einsatz zeigt eine **gelbe Leiste** Fortschritt und nächstes Ereignis: **⏸ Anhalten / ▶ Weiter**, **⏭** nächstes Ereignis sofort, **Tempo**, **⏹ Drehbuch beenden**. Der Übungseinsatz bleibt offen, bis er normal beendet wird.
- **⬇ Export / ⬆ Import:** Demo als Datei für andere Wehren (nur das anonymisierte Drehbuch; Import nur Admin, Bilder werden verworfen). ✎ umbenennen, 🗑 löschen (Admin).

## Übungsleitstelle – eine Person spielt Fahrzeuge und Leitstelle (ab 3.98)

Für Übungen der Einsatzleitung: Eine Person übernimmt am eigenen Gerät die Leitstelle und alle Fahrzeuge – auch bei einer Sonderlage mit vielen Einsatzstellen. Aufruf: Reiter Einsatz → **„🎛 Übungsleitstelle“** (ohne laufenden Einsatz) oder direkt `http://<Pi>:8080/uebleitstelle/` – Anmeldung mit Benutzer und PIN der Einsatzverwaltung (Einsatzleitung oder Admin).

**Was bleibt im Netz?** Alles. Für die Übung werden **Übungsfahrzeuge** angelegt – Kopien der gewählten Fahrzeuge mit gleichem Funkrufnamen. Alarm, Status, Stärke, Position, Aufträge und Nachrichten gehören nur zu diesen virtuellen Fahrzeugen. **Echte Fahrzeuge, echte Fahrzeug-Apps, Push-Meldungen, Alarmmonitor und „Wer kommt?“ bleiben unberührt**; Mails und Meldungen nach außen gibt es nicht. In einen Übungseinsatz können keine echten Fahrzeuge, in einen echten Einsatz keine Übungsfahrzeuge – ein echter Alarm während der Übung läuft ganz normal.

**Ablauf**
1. **Übung starten:** Namen eintragen, mitspielende Fahrzeuge ankreuzen (Filter nach Funkrufname, Typ, Ortswehr), „Übung starten“. Weitere Fahrzeuge lassen sich später unten links hinzufügen.
2. **Leitstelle:** Stichwort, Meldebild, Einsatzort (Adresse suchen oder 📍 auf der Karte) und Fahrzeuge wählen → **„Alarmieren“**. Der Einsatz erscheint in der Einsatzverwaltung mit „ÜBUNG:“ und einem lila Hinweisbalken. Je Einsatz: **Nachalarmieren**, **Meldung Leitstelle** (ins Einsatztagebuch), **Auftrag**; Kräfteanforderungen der Einsatzleitung werden angezeigt.
3. **Fahrzeuge:** je Fahrzeug Status 1, 2, 3, 4, 6, A sowie 5 (Sprechwunsch) und 0 (Notruf), **Nachricht an ELW** (mit Vorlagen), **Stärke melden**, **Anfahrt simulieren** (fährt mit der gewählten Geschwindigkeit zum Ziel, Status 4 bei Ankunft), **Fahren nach …** und **Standort** auf der Karte.
4. **Posteingang:** Nachrichten und Aufträge der Einsatzleitung an die Übungsfahrzeuge – mit Ton, „✓ Verstanden“ und „↩ Antworten“.
5. **Übung beenden:** Übungseinsätze werden beendet (bleiben als Übung im Archiv), die Übungsfahrzeuge mit allen Daten gelöscht.

**Sonderlage üben (ab 3.99)**
- **Eröffnen:** Beim Alarm den Haken **„Sonderlage“** setzen (bei Stichwort Unwetter/Sturm/Hochwasser automatisch), optional mit Bereitstellungsraum. In der Einsatzverwaltung läuft der Einsatz als Großschadenslage mit Auftragsverwaltung.
- **Aufträge der Leitstelle:** „📌 Auftrag“ – Kategorie, Adresse (Suchen oder 📍 Ort auf der Karte), Beschreibung mit Vorlagen, Meldender, Rückruf und **⚡ Priolage**. Die Priorität vergibt wie im Ernstfall die Einsatzleitung. **„🎲 Aufträge würfeln“** erzeugt beliebig viele Aufträge an zufälligen Orten, sofort oder über einen Zeitraum verteilt.
- **Überblick:** Die Einsatzkarte zeigt die Zahlen neu · disponiert · in Arbeit · erledigt und alle offenen Aufträge mit Status, disponierten Fahrzeugen und 📍; auf der Karte stehen die Aufträge (📌/⚡ mit Nummer, farbig nach Status) und der Bereitstellungsraum.
- **Fahrzeuge in der Sonderlage:** Disponiert die Einsatzleitung ein Fahrzeug, steht der Auftrag blau in der Fahrzeugkarte (und im Posteingang). Knöpfe **„Zum Auftrag fahren“**, **„Im Einsatz“** und **„✓ Auftrag erledigt …“** (mit Ergebnis, danach Status 1 – frei für den nächsten Auftrag) – genau wie in der Fahrzeug-App. **„📌 Einsatzstelle melden“**: Die Besatzung meldet unterwegs eine weitere Schadensstelle; ohne Adresse gilt der Standort des Fahrzeugs.

**🤖 Automatik (ab 3.99)** – damit eine Person auch viele Fahrzeuge führen kann (rechts oben, auf- und zuklappbar):
- **Bei Alarm selbst ausrücken:** alarmierte Übungsfahrzeuge melden nach 1–2 Minuten Status 3, fahren zur Einsatzstelle (in der Sonderlage ohne Auftrag in den Bereitstellungsraum), melden Status 4 und ihre Stärke.
- **Aufträge selbst abarbeiten:** disponierte Fahrzeuge fahren zum Auftrag (Status 3 → 4), arbeiten die eingestellte Zeit (z. B. 5–15 min) und melden dann „Auftrag erledigt“ mit einem passenden Ergebnis und Status 1.
- Was die Automatik tut, sieht die Einsatzleitung wie echte Meldungen. In der Fahrzeugkarte steht, was als Nächstes passiert (z. B. „🤖 rückt aus in 0:40“). Von Hand eingreifen geht jederzeit.

**🎲 Drehbuch aus dem Übungsgenerator (ab 3.99)**
- Im Bereich **„Drehbuch / Übungsgenerator“** stehen alle Szenarien des Übungsgenerators – die auf diesem Gerät gespeicherten und die auf dem Pi abgelegten. Szenario wählen, Einträge prüfen, **„▶ Nach Zeitplan starten“** oder **„Alles sofort“**.
- **Der Pi spielt das Drehbuch ab** – die Seite muss dafür nicht offen bleiben. Anzeige mit Uhr, „gesendet hh:mm · 2026-005 · Auftrag 3“ bzw. Fehler je Eintrag, **jetzt** für einzelne Einträge, Anhalten, Fortsetzen, Beenden.
- Alle Einsätze und Aufträge laufen nur mit **Übungsfahrzeugen**: Im Szenario genannte Funkrufnamen, die noch nicht mitspielen, werden automatisch als Übungsfahrzeug dazugenommen. Echte Fahrzeuge werden nie alarmiert.
- **„🎲 Neu würfeln“** erzeugt direkt hier ein Szenario (Einsätze nach Art, Aufträge einer Unwetter-Sonderlage, Zeitraum, Umkreis, auf Wunsch mit Adressen). Freie Übungsfahrzeuge werden je nach Stichwort automatisch alarmiert (1–3). Das Szenario wird wie im Übungsgenerator gespeichert und kann dort mit **„✎ Im Übungsgenerator bearbeiten“** angepasst werden.
- Umgekehrt hat der Übungsgenerator den Knopf **„🎛 In der Übungsleitstelle abspielen“**: Er öffnet die Übungsleitstelle mit dem Szenario; beim Start der Übung sind die darin genannten Fahrzeuge schon angekreuzt.

**Tipp:** Die Übungsleitstelle auf einem zweiten Gerät (Laptop, Tablet) öffnen und die Einsatzleitung im ELW wie gewohnt arbeiten lassen. Für eine Unwetterübung: Sonderlage alarmieren, Automatik einschalten, „🎲 Aufträge würfeln“ (z. B. 20 Aufträge über 60 min) – die Einsatzleitung disponiert, die Fahrzeuge arbeiten selbstständig ab.

## Demo-Version für den USB-Stick (ab 3.35)

Eine eigenständige **Demo-Version** zum Vorführen, Schulen und Weitergeben (Datei `Einsatzverwaltung-Demo.zip`). Sie läuft auf einem normalen Windows-, Mac- oder Linux-Rechner direkt vom Stick – **ohne Pi, ohne Installation, ohne Internet**.

- **Alles erfunden:** Ort „Musterhausen“ (Gemeinde Musterstadt), 21 Fahrzeuge und Funktionen (Ortsfeuerwehren Musterhausen, Beispieldorf, Lindenau, Neudorf, Nachbarstadt, Kreis, Rettungsdienst), Kennzeichen „XY-…“, eigene Wappen, drei Beispiel-Einsätze im Archiv und zwei Übungs-Drehbücher für die **▶ Live-Übung**. Es ist **nichts** aus dem echten Datenstand enthalten (keine Fahrzeugliste mit Namen, keine ASÜ-Zugänge, keine Schlüssel, keine Wappen).
- **Kleine Karte:** eine eigens gezeichnete Karte von Musterhausen (ca. 3 × 2,4 km, Zoomstufen 15–19, Straßenkarte und gezeichnetes Luftbild). Die Karte lässt sich nur in diesem Ausschnitt bewegen; außerhalb erscheint eine graue Fläche.
- **Ersatzdienste statt Internet:** Adresssuche (alle Straßen und Hausnummern von Musterhausen), Koordinate → Adresse, Wetter, eine Übungs-Unwetterwarnung, Hydranten/Wasserentnahmestellen, what3words (erfundene Wortadressen), Höhenprofil. Der Server ruft in der Demo keine Internetadresse auf.
- **Einmal vorbereiten (mit Internet):** „Stick vorbereiten (einmalig)“ lädt Node.js von nodejs.org (Prüfsumme wird geprüft) und installiert die Programmbibliotheken; auf Wunsch auch für Mac und Linux. Danach den Stick beliebig kopieren.
- **Starten:** „Start Windows.bat“ (nur dieser Rechner) oder „Start Windows - mit Handy im WLAN.bat“; Mac/Linux im Ordner „Mac und Linux“. Ports **8180** (Einsatzverwaltung), **8181** (Fahrzeug-App), **8182** (ASÜ).
- **Zugänge:** Admin PIN 1234, Einsatzleitung 2222, Betrachter 3333; ASÜ: musterhausen, beispieldorf, lindenau, neudorf / demo1234, admin / admin1234. Die Anmeldeseite zeigt die Zugänge, Kopfzeile „DEMO“.
- **Zurücksetzen:** Demo-Fenster schließen, „Demo zuruecksetzen“ starten → beim nächsten Start Anfangszustand.
- **Auch in der Demo (ab 3.98):** Gefahrstoffdatenbank (ohne Internet, Wind für den Absperrbereich von Hand eintragen), Lagekarte mit Posterdruck und die **Übungsleitstelle** unter `http://localhost:8180/uebleitstelle/` – damit lässt sich eine Übung allein durchspielen.
- Die Demo ist **nicht** für echte Einsätze gedacht – bitte keine echten Personendaten eintragen. Alles Weitere steht in `LIESMICH.html` auf dem Stick.

# Teil 5 – Verwaltung und Betrieb

## Seite „E-Mail“ (ab 3.42)

Neuer Reiter **✉️ E-Mail** in der oberen Leiste (zwischen Archiv und Verwaltung, nur Einsatzleitung und Admins). Die rote Zahl am Reiter zeigt neue, verarbeitete Mails (Leitstelle, Testalarm, Erkunder).

- **✏️ Neue E-Mail:** Einsatz wählen (laufend oder aus dem Archiv, oder „ohne Einsatz“ für eine freie Nachricht), Empfänger eintippen oder mit „+ Bericht-/Lage-/System-Empfänger“ bzw. Kontakten übernehmen, Betreff (wird aus dem Einsatz vorgeschlagen), eigener Text. Unter **„Mitsenden“** anhaken, was dazu soll:
  - **Einsatzdaten** (Stichwort, Einsatzort mit OpenStreetMap-Link, Alarm/Ende, Einsatzleiter, Bereitstellungsraum),
  - **Lagemeldungen**, **Fahrzeuge mit Status und Stärke** (mit Summe), **Einsatztagebuch (vollständig)**, **Aufträge** (Großschadenslage),
  - **Einsatzbericht als PDF** und **Fotos des Einsatzes** (höchstens 10) als Anhang.
  Die Zahl in Klammern zeigt, wie viel vorhanden ist; leere Punkte sind ausgegraut. „alle“/„keine“ setzt die Häkchen. Die **Vorschau** zeigt den Text genau so, wie er verschickt wird. Weitere Dateien zusammen bis 20 MB. Der Entwurf bleibt beim Wechsel der Reiter erhalten.
- **📥 Eingang:** alle eingegangenen Mails beider Postfächer (90 Tage, höchstens 300) mit Ergebnis – grün verarbeitet (Einsatz angelegt, Auftrag, Tagebuch), grau ignoriert, rot abgelehnt. Suche und Filter „Verarbeitet“ / „Ignoriert / abgelehnt“. Antippen zeigt die ganze Mail mit Fotos; **„Zum Einsatz“** öffnet den Einsatz (oder den Archiv-Eintrag), **„↩ Antworten“** füllt Empfänger, „AW: …“ und das Zitat vor. Kennwörter freigegebener Absender werden nie angezeigt. Neue Mails erscheinen sofort.
- **📤 Gesendet:** alle verschickten Mails (auch automatische Lage-, Bericht- und Systemmails) mit Empfängern, Art, Benutzer, Anhängen und Ergebnis.
- **↻ Abrufen** holt sofort neue Mails aus den Postfächern.

## E-Mail: Versand und Posteingang (ab 3.41)

**Einrichten (Admin):** Verwaltung → Einstellungen → **Schnittstellen → „E-Mail (Versand und Empfang)“**: SMTP-Server, Port und Verschlüsselung (465 = SSL, 587 = STARTTLS), IMAP-Server/Port (993 = SSL), Benutzer, **Passwort** (wird wie alle Geheimnisse nur in `einstellungen.json` gespeichert, nie angezeigt), Absender (z. B. `Feuerwehr Aerzen ELW <elw@…>`) und **„Posteingang abrufen alle … Sekunden“** (0 = kein Empfang). Funktioniert mit jedem Anbieter, der SMTP/IMAP anbietet (GMX, Web.de, Strato, IONOS, Gmail/Outlook mit App-Passwort …). Am besten ein **eigenes Postfach nur für die Einsatzverwaltung** verwenden.

**Vorbelegt (ab 3.41.1): Strato-Postfach `elw@gemeindefeuerwehr-aerzen.de`** – Postausgang `smtp.strato.de` Port 465 (SSL), Posteingang `imap.strato.de` Port 993 (SSL), Benutzername = vollständige Adresse, Absender „Feuerwehr Aerzen – ELW“. Es fehlt nur noch das **Passwort** (Schnittstellen → E-Mail → Passwort, speichern). Solange es fehlt, bleiben Versand und Abruf aus und der Block „E-Mail“ zeigt rot **„Passwort fehlt noch“**. Danach: **Test-Mail senden** und unter „Freigegebene Absender“ die Leitstelle bzw. eigene Leute eintragen.

Darunter im Block **„E-Mail“**: Status (letzter Versand/Abruf), **Test-Mail senden**, **Posteingang jetzt abrufen**, Empfängerlisten und Schalter:

- **Empfänger Einsatzbericht / Lagemeldungen / Systemmeldungen** (je Zeile eine Adresse).
- ☑ **Einsatzbericht nach „Einsatz beenden“ automatisch** an die Bericht-Empfänger (nicht bei Übungen/Demos).
- ☑ **Jede Lagemeldung zusätzlich per E-Mail** an die Lage-Empfänger (Vermerk im Tagebuch, auch bei Fehlschlag).
- ☑ **Systemmeldungen**: Sicherheitsereignisse, fehlgeschlagene Datensicherung, rote Pi-Warnungen – je Thema höchstens alle 6 Stunden.

**Versenden (Einsatzleitung):** Im Einsatz **„✉ E-Mail“**, im Einsatzbericht (Archiv) **„✉ Per E-Mail senden“**. Empfänger eintippen oder mit **„+ Bericht-Empfänger“, „+ Lage-Empfänger“** bzw. Kontakten mit E-Mail übernehmen; Betreff, Text, **☑ Einsatzbericht anhängen** und eigene Dateien/Fotos (zusammen höchstens 20 MB). Der Bericht wird auf dem Pi zum **PDF** (dafür muss `chromium` installiert sein – `sudo apt install chromium`; sonst geht er als HTML-Datei mit). Jede gesendete Mail steht im **Einsatztagebuch** (Ausgang) und im Änderungsprotokoll. Lehnt der Server einzelne Empfänger ab, gehen die übrigen trotzdem raus.

**Posteingang – nur freigegebene Absender** (Tabelle „Freigegebene Absender“; alle anderen Mails werden ignoriert):

| Art | Was passiert |
|---|---|
| **Leitstelle** (feste Form) | Felder wie `Stichwort:`, `Meldebild:`, `Straße:`, `Hausnummer:`, `Ortsteil:`, `PLZ:`, `Ort:`, `Objekt:`, `Meldender:`, `Telefon:`, `Einsatznummer:`, `Alarmierte Einsatzmittel:`/`Fahrzeuge:`, `Koordinate:`, `Priorität:` werden gelesen → **neuer Einsatz** mit Adresse (ohne Koordinate: Geocodierung). Genannte Fahrzeuge mit bekanntem Funkrufnamen werden **alarmiert** (Status A); unbekannte stehen als Vermerk im Tagebuch. Kommt eine weitere Mail mit **derselben Einsatznummer**, ist das eine **Nachalarmierung** im selben Einsatz. |
| **Erkunder / eigene Leute** | Freitext und Fotos → **Tagebuch des laufenden Einsatzes** (neuester), Fotos in die Einsatzfotos. Ohne laufenden Einsatz wird ein neuer angelegt. Ort aus einer Zeile `Adresse: …`, „Straße Nr.“ im Text oder Koordinaten. |
| **Großschadenslage** (ab 3.45) | Steht in einer Leitstellen-Mail das Wort **„Auftrag“**, ist es eine Großschadenslage: die Mail wird zum **Auftrag** in der laufenden Großschadenslage – läuft keine, wird sie angelegt (Stichwort der ersten Mail, Meldebild „Großschadenslage – …“). Genannte Einsatzmittel und Kräfte werden **dem Auftrag zugeordnet** (Status A). Leitstellen-Mails **ohne** „Auftrag“ werden auch während einer Großschadenslage zu einem eigenen Einsatz. Erkunder-Mails werden während einer Großschadenslage zu Aufträgen (Kategorie „Erkundung“). |

**Testalarme per E-Mail (ab 3.41.4):** Absender-Art **„Testalarm (wie Leitstelle, als Übung)“** – vorab eingetragen: **`joern-preuss@web.de`** mit Kennwort **`TESTALARM`** (muss im Betreff oder Text stehen). Die Mail wird wie eine Leitstellen-Mail gelesen, der Einsatz aber als **Übung** angelegt, Meldebild beginnt mit „TEST:“. Keine automatischen Mails, nicht in der Jahresauswertung, nie ein Auftrag in einer echten Großschadenslage; Fahrzeuge in echten Einsätzen werden nicht umgesetzt. Schalter **„Testalarme alarmieren die genannten Fahrzeuge“** (Vorgabe an – Status A erscheint auch in der Fahrzeug-App). Vorlagen: `docs/Vorlage_Testalarm_per_Mail.txt`. Mails von web.de/GMX im Format „format=flowed“ (weich umbrochene Zeilen) werden richtig zusammengesetzt.

**Zweites Postfach – nur Empfang (ab 3.41.3):** Unter Schnittstellen → **„E-Mail: zweites Postfach (nur Empfang)“** ist **`elw@feuerwehr-aerzen.de`** (Strato, `imap.strato.de` Port 993 SSL) vorbelegt; es fehlt nur das Passwort. Aus diesem Postfach werden Mails genauso abgerufen und verarbeitet (gleiche freigegebene Absender, Einsätze/Aufträge/Tagebuch), **versendet wird darüber nie etwas** – alle ausgehenden Mails laufen über das erste Konto. Kommt dieselbe Mail an beide Adressen, entsteht nur ein Einsatz (die zweite steht als „doppelt“ im Protokoll). Der Block „E-Mail“ zeigt den Stand beider Postfächer; im Protokoll steht, in welchem Postfach eine Mail einging. Fällt ein Postfach aus (z. B. falsches Passwort), wird das andere trotzdem abgerufen. Feld „Posteingangsserver“ leeren = zweites Postfach aus.

**Alarmmail der Kooperativen Regionalleitstelle Weserbergland (ab 3.41.2):** Absender `els@krl-wb.de` ist als Leitstelle vorab freigegeben. Gelesen wird:
- `Einsatznummer:` → Leitstellen-Nummer (weitere Mail mit derselben Nummer = Nachalarmierung), `Eröffnung:` → Alarmzeit.
- Zeile `H3 X: Gefahrgutunfall` → Stichwort „H3 X“, Meldebild „Gefahrgutunfall“, die Zeile darunter („Chlorgaswarnanlage ausgelöst“) wird angehängt.
- `EINSATZORT:` mit der Zeile darunter „Objekt Gemeinde Ortsteil Straße Nr“ (z. B. „Hallenbad Aerzen Aerzen Aerzen Hopfenweg 16“) → Adresse „Hopfenweg 16, Aerzen“, Objekt „Hallenbad Aerzen“ in der Notiz. Ortsteile kennt die Einsatzverwaltung aus den Ortsfeuerwehren der Fahrzeugliste.
- `[lat=…][long=…]` → Koordinate.
- `Alarmierte Einsatzmittel:` → diese Fahrzeuge auf **Status A** (erkannt über die Kennung, „FL HM 14-46-10“ = 14-46-10). Nicht vorhandene (z. B. 80-71-1) stehen als Vermerk im Tagebuch.
- `Alarmierte Kräfte:` → Kürzel (Einstellungen → E-Mail → „Alarmierte Kräfte“, je Zeile „Kürzel = Ortsfeuerwehr“ oder „Kürzel = Funkrufnamen“). Vorgaben: **Aer = Aerzen, GrB = Groß Berkel, Reh = Reher**, **GBM-AE = 14-01-1, 14-02-1, 14-02-2**, **WF Aerzener Maschinenfabrik = Aerzener Maschinenfabrik GmbH**, **Drohnenstaffel = 89-59-1** (ab 3.45; in bestehende Einstellungen einmalig ergänzt). Bei einer Ortsfeuerwehr werden – ist „alle Fahrzeuge … alarmieren“ an (Vorgabe) – ihre Fahrzeuge alarmiert (eigene Gemeinde bevorzugt; auch Werkfeuerwehren), ohne Feuerwehrhäuser, Funkmeldeempfänger und Führungspersonen. Bei Funkrufnamen genau diese (auch Personen wie GemBM). Nicht zugeordnete Kräfte (DRK, BAL …) stehen als Vermerk im Tagebuch.

- Eine ganze Domain freigeben: `@leitstelle-beispiel.de`.
- **Kennwort (optional)** je Absender: Die Mail muss es in Betreff oder Text enthalten, sonst wird sie abgelehnt; im Einsatz erscheint der Text ohne Kennwort.
- Meldet der Mailserver eine **fehlgeschlagene SPF/DKIM/DMARC-Prüfung** (gefälschter Absender), wird die Mail abgelehnt und ein **Sicherheitsereignis** erzeugt.
- Jede Mail wird nur einmal verarbeitet und danach im Postfach als gelesen markiert. Das Protokoll unten im Block zeigt die letzten Ein- und Ausgänge mit Ergebnis.
- Angelegt wird alles als Benutzer „E-Mail“ – im Tagebuch und Protokoll erkennbar.

## Überwachung des Mail-Alarms (ab 3.43)

Kann ein Postfach länger als **5 Minuten** (einstellbar: Schnittstellen → E-Mail → „Warnung, wenn der Posteingang … Minuten nicht abgerufen werden konnte“; mindestens 3 Abrufe) nicht abgerufen werden, erscheint auf **allen Geräten** eine **rote Leiste**: „E-Mail-Alarmierung gestört: Postfach … seit … Uhr nicht abrufbar – Alarmierung über Melder und Funk beachten“. Admins sehen die Ursache und „Prüfen“ (öffnet die E-Mail-Einstellungen); „Ausblenden“ blendet sie auf diesem Gerät 30 Minuten aus. Gleichzeitig geht eine Mail an die **Systemempfänger**, der Fall steht im Änderungsprotokoll und unter „Zustand des Pi“. Wird wieder abgerufen, verschwindet die Leiste und es kommt die Mail „E-Mail-Alarmierung wieder in Ordnung“. Ein hängender Abruf wird nach 3 Minuten abgebrochen.

## Einstellungen neu geordnet (ab 3.42)

Verwaltung → Einstellungen hat links (am Handy oben) eine **Bereichsliste** und ein **Suchfeld**:

| Bereich | Inhalt |
|---|---|
| 🏠 Allgemein | Standardstadt, Heimatort, Design, Dichte |
| 🚒 Einsatz | Einsatz-Uhren, Funkrufnamen, Checklisten, Textbausteine, Plausibilitätsprüfung und Ablösung, Wetter (mit Zugangsdaten Unwetter/Wetter), FeWIS, Waldbrandeinsatzkarte |
| 🗺️ Lagekarte & Aufträge | Auftragskategorien (GSL), Symbole ins Tagebuch, Wasserentnahmestellen (mit Zugangsdaten Hydrantenprüfung), Rettungspunkte, Wasserförderung, Pendelverkehr, **Kartendienste und Adresssuche** |
| 📨 Alarmierung & E-Mail | E-Mail (mit Zugangsdaten beider Postfächer), Fahrzeugstatus von außen, PowerAlarm-Anbindung (mit API-Key) |
| 📱 Fahrzeug-App & ASÜ | externe Adresse (mit Zugangsdaten Fahrzeug-App), **Atemschutzüberwachung (ASÜ)** |
| 🧰 Stationen | Ausrüstungskategorien und -filter |
| 🔒 Datenschutz | Hinweise für die Nutzer, Löschfristen für beendete Einsätze |
| 💾 Sicherung & System | **Betrieb** (u. a. Sicherungs-Passwort, Feedback-Adresse), Feedback, Datensicherung, Update, Übungen, Daten und dieses Gerät, **Ports und Zertifikate** |

Ab 5.158 gibt es **keinen eigenen Bereich „Schnittstellen & Schlüssel“** mehr: Die Zugangsdaten stehen beim jeweiligen Thema im Abschnitt **„🔌 Zugangsdaten und Adressen“** bzw. in einem eigenen Block. Jeder Block lässt sich über seine Überschrift **auf- und zuklappen** (Zustand bleibt auf dem Gerät), oben gibt es „Alle aufklappen / Alle zuklappen“.

Die **Suche** (z. B. „Passwort“, „Tankuhr“) zeigt alle passenden Abschnitte aus allen Bereichen und klappt passende Schnittstellen-Gruppen auf. Der zuletzt gewählte Bereich bleibt auf dem Gerät gespeichert. Links im E-Mail-Block führen direkt zu den Zugangsdaten.

## Schnittstellen, Adressen und Schlüssel (ab 3.23)

Verwaltung → Einstellungen (nur Admin) – ab 5.158 **beim jeweiligen Thema** (siehe Tabelle oben). Hier stehen **alle** Internet-Adressen, API-Schlüssel und Kennungen, die das Programm nutzt – nach Themen aufklappbar. Schnittstellen, die in späteren Versionen dazukommen, erscheinen automatisch hier.

- **Gruppen:** Unwetterwarnungen und Wetter (Regionalschlüssel, NINA, Open-Meteo, Wind für den Ausbreitungskegel, DWD-Radar), Karten und Adressen (Kartenkacheln, Satellitenbild, Adresssuche, Ort für die Adresssuche, Overpass/Wasserentnahmestellen mit Umkreis, Höhenprofil, what3words-Schlüssel und -Adresse, Kennung gegenüber den Kartendiensten), Atemschutzüberwachung (Wehr-Schlüssel, erlaubte Herkunft der ASÜ-App, Aufbewahrung), Betrieb (Sicherungsziel, Aufbewahrung der Sicherungen, Sicherungs-Passwort, PIN-Abfrage, Anmeldedauer, Dateigröße bei Objekt-Plänen), Datenschutz (Löschfristen), Ports und Zertifikate. Speichern verlangt die PIN-Bestätigung.
- Neben jedem Namen steht, **woher der Wert kommt**: *in der App* (hier eingetragen), *Dienstdatei* (`Environment=…` in `/etc/systemd/system/einsatzverwaltung.service`) oder *Vorgabe*. Ein Wert aus der App gilt vor der Dienstdatei. **„Zurücksetzen“** entfernt den App-Wert – danach gilt wieder die Dienstdatei bzw. die Vorgabe. Feld leeren und „Speichern“ wirkt genauso.
- **Schlüssel** (what3words, ASÜ-Wehr-Schlüssel) werden **nie angezeigt**, nur „gesetzt“ / „nicht gesetzt“. Zum Ändern den neuen Schlüssel eintippen und „Speichern“; leer lassen = alter Schlüssel bleibt. Der neue ASÜ-Schlüssel gilt sofort – danach in allen ASÜ-Geräten eintragen.
- Eingaben werden geprüft (Adressen mit `http://` oder `https://`, Kartenadressen mit `{z}`, `{x}`, `{y}`, Regionalschlüssel 12 Ziffern oder „aus“, Zahlen, Ports 1–65535). Fast alles wirkt **sofort**; geänderte Warn-Einstellungen laden die Warnungen gleich neu, geänderte Browser-Adressen (Satellit, Radar, Wind, Höhenprofil) gehen sofort an alle Geräte.
- **Ports und Zertifikate** wirken erst nach einem Neustart: Hinweis „wirkt nach Neustart“ und Knopf **„Programm jetzt neu starten“** (Geräte sind ca. 10 Sekunden getrennt, Einsätze bleiben erhalten). Port 8080 nie aus dem Internet erreichbar machen.
- Gespeichert wird nur auf dem Pi in der Datei `einstellungen.json` (nur für den Dienst lesbar). Sie ist **nicht** in `data.json` und **nicht** in der Datensicherung – nach einer Neuinstallation die Werte neu eintragen (oder die Datei mitnehmen). Ein Update lässt sie unverändert.

## Archiv

Reiter „Archiv“: Suche, Filter nach Jahr, Einsatzstunden, Liste als CSV (für die Jahresstatistik). Ein Eintrag zeigt den vollständigen Einsatzbericht (siehe oben) mit „Als PDF speichern“ und Tagebuch-CSV. Löschen können nur Admins.

## Jahresauswertung (ab 3.22)

- Archiv → **„📊 Jahresauswertung“**: Jahr wählen, optional eine Ortsfeuerwehr, Übungen ein- oder ausblenden (erkannt an „Übung“ im Stichwort oder Meldebild).
- Kennzahlen: Einsätze, Einsatzstunden, Personalstunden (Stärke × Dauer je Fahrzeug), Fahrzeug-Einsätze, **Ausrückzeit** (Alarm bis Status 3, Median) und **Anfahrt** (Status 3 bis 4, Median).
- Diagramme: Einsätze je Monat, nach Uhrzeit der Alarmierung, nach Art (Brand, Brandmeldeanlage, Technische Hilfe, Unwetter/Wasser, Gefahrstoff, Sonstige – nach Stichwort) und je Ortsfeuerwehr; Werte beim Darüberfahren bzw. Antippen. Tabelle je Ortsfeuerwehr und Karte aller Einsatzorte.
- „Drucken / PDF“ für Jahreshauptversammlung oder Bedarfsplan, „Liste als CSV“ mit allen Einsätzen.

## Datensicherung

- Automatisch: täglich und stündlich auf der SD-Karte des Pi und – sobald eingerichtet – auf **USB-Stick oder Netzlaufwerk** (beim Start, stündlich bei Änderungen und nach jedem Einsatzende). Einrichtung: ANLEITUNG, Schritt 15.
- Verwaltung → Einstellungen → „Datensicherung“: Stand je Ziel (grün = gesichert, gelb = Problem, 🔒 = verschlüsselt), **„Jetzt sichern“** und **„Sicherung herunterladen“** (vollständiger Stand als Datei auf dieses Gerät, mit PIN-Abfrage). Gelber Hinweis „Keine aktuelle externe Sicherung“, solange kein Stick/Laufwerk gesichert hat, und „nicht verschlüsselt“, solange kein Sicherungs-Passwort gesetzt ist.

### Verschlüsselte Sicherung (ab 3.29)

- Einschalten: Verwaltung → Einstellungen → Sicherung & System → Betrieb → **„Passwort für die Datensicherung“** (mindestens 12 Zeichen) → Speichern. Ab der nächsten Sicherung ist alles auf Stick/Netzlaufwerk verschlüsselt (AES-256-GCM, Schlüssel aus dem Passwort per scrypt): Tagesstände (`data-JJJJ-MM-TT.json.enc`), Bilder, Objekt-Pläne, Änderungsprotokoll und ASÜ-Zugänge. Unverschlüsselte Tagesstände entfernt der Pi dabei vom Stick. Auch „Sicherung herunterladen“ liefert dann eine `.json.enc`.
- **Passwort getrennt vom Stick aufbewahren** (z. B. versiegelter Umschlag beim Wehrführer/in der Gemeinde). Ohne Passwort sind die Sicherungen nicht mehr lesbar – auch nicht für uns.
- Die stündlichen Stände auf der SD-Karte des Pi bleiben unverschlüsselt (der Pi selbst braucht sie zum Wiederherstellen); Pi deshalb unter Verschluss.
- **Passwort ändern:** einfach neues eintragen. Der Pi verschlüsselt Bilder, Pläne und Protokoll neu; ältere Tagesstände bleiben mit dem alten Passwort lesbar (Hinweis in der Anzeige).
- Was kommt auf den Stick: `LIESMICH.txt` (Kurzanleitung), `sicherung-entschluesseln.js` (Werkzeug), `passwort-pruefung.enc` (erkennt ein falsches Passwort).
- **Entschlüsseln** (auf dem Pi oder jedem Rechner mit Node.js):
  `node sicherung-entschluesseln.js /media/usb/einsatzverwaltung-sicherung ~/wiederherstellung`
  Das Programm fragt nach dem Passwort (unsichtbar) und legt alle Dateien ohne `.enc` im Zielordner ab. Bei falschem Passwort: „falsches Passwort oder Datei beschädigt“, es wird nichts geschrieben. Eine einzelne heruntergeladene Datei geht genauso (`node sicherung-entschluesseln.js sicherung.json.enc ~/ziel`).
- Gelöschte Dateien (z. B. nach Löschfristen) verschwinden bei der nächsten Sicherung auch vom Stick.

## Datenschutz: Löschfristen (ab 3.29)

- Einstellen: Verwaltung → Einstellungen → 🔒 Datenschutz → **„Löschfristen für beendete Einsätze“**. Vorgabe überall 0 = nie löschen. Fristen bitte mit dem Datenschutzbeauftragten der Gemeinde abstimmen.
  - GPS-Spuren und Fahrzeugpositionen nach … Monaten
  - Fotos nach … Monaten
  - Nachrichten der Fahrzeug-App nach … Monaten
  - ganze Einsätze nach … Jahren
- Gerechnet ab **Einsatzende**; laufende Einsätze sind nie betroffen. Der Pi prüft 2 Minuten nach dem Start und dann alle 6 Stunden.
- **Einsatztagebuch** und **Expositionsnachweis** bleiben erhalten, solange nicht der ganze Einsatz gelöscht wird. Im Archiv steht dann, was wann gelöscht wurde.
- Verwaltung → Sicherheit → „Löschfristen“: aktuelle Fristen, **Vorschau** („Beim nächsten Lauf werden gelöscht: …“), letzter Lauf, „Fristen ändern“ und „Jetzt anwenden“ (mit Rückfrage und PIN).
- Jeder Lauf mit Löschungen steht im Änderungsprotokoll (Bereich „Datenschutz“). Die Tagesstände der Datensicherung (bis 90 Tage) enthalten gelöschte Daten noch, bis sie ablaufen.

## Änderungsprotokoll (ab 3.27)

- Verwaltung → **Protokoll** (nur Admin): jede Änderung mit Zeit und Benutzer – Einsätze, Status (auch aus Fahrzeug-App und PowerAlarm), Tagebuch, Lagekarte, Stärke, Nachrichten, Objekte, Ansprechpartner, Fahrzeugliste, Einstellungen, Schnittstellen (nur Namen, nie Schlüssel), Benutzer, Anmeldungen und Fehlversuche, Neustarts, Expositionen.
- Filter nach Zeitraum (24 h … 1 Jahr), Benutzer, Bereich und Suchtext; „Als CSV“.
- Gespeichert im Ordner `protokoll/` (je Monat eine Datei), in der externen Datensicherung enthalten. Aufbewahrung: Verwaltung → Einstellungen → Schnittstellen → Betrieb → „Änderungsprotokoll aufbewahren (Monate)“, Vorgabe 13.

## Systemprotokoll

Verwaltung → Einstellungen → „Systemprotokoll“: Ereignisse außerhalb von Einsätzen (z. B. Status ohne Einsatz, Selbstmeldungen, eröffnete und beendete Einsätze).

## Zustand des Pi

- Verwaltung → **Zustand des Pi**: Temperatur (mit Verlauf der letzten 24 Stunden), Stromversorgung (Unterspannung), freier Speicher auf der SD-Karte, Arbeitsspeicher, Last, Laufzeit, verbundene Geräte, letzte externe Sicherung und die Größe der Daten (Datenbestand, Kartenkacheln, Backups, Pläne, Bilder). Aktualisiert sich alle 10 Sekunden.
- Warnungen: ab 70 °C gelb, ab 80 °C rot; Unterspannung (Netzteil!); weniger als 1 GB frei; keine externe Sicherung seit mehr als 26 Stunden.
- Bei Warnungen erscheint oben **„⚠ Pi“** (Admins sehen alle, andere nur rote). Antippen öffnet die Seite.

### Selbsttest (ab 4.2)

Unter **Verwaltung → Zustand des Pi → Selbsttest** prüft der Pi jeden Morgen (Vorgabe 06:45 Uhr) seine wichtigsten Teile und schickt das Ergebnis per Mail an die **System-Empfänger** (Einstellungen → Schnittstellen → E-Mail):

- Speicher auf der SD-Karte, Temperatur und Stromversorgung, ob `data.json` geschrieben werden kann
- Stündliche Sicherung und Sicherung auf USB-Stick/Netzlaufwerk
- E-Mail-Versand und Abruf der Alarm-Mails
- Fahrzeug-App von außen erreichbar (wenn eine Internetadresse eingetragen ist)
- PowerAlarm: letzte Statusmeldung (Hinweis, wenn 14 Tage nichts kam)
- Atemschutz: wie viele Geräteträger einsatzbereit sind, Wehren mit weniger als 2 Trupps
- Feuerwehrhäuser, die noch nicht geprüft sind

Zeichen: ✓ in Ordnung · ⚠ bitte ansehen · ✕ Störung · ℹ Hinweis. „Mail nur bei Störung oder Hinweis“ spart die tägliche Mail, wenn alles grün ist – dann fehlt aber das tägliche Lebenszeichen. **Tipp:** die tägliche Mail eingeschaltet lassen; bleibt sie aus, ist der Pi aus oder der Mailversand gestört. „Jetzt prüfen“ zeigt das Ergebnis sofort, „Prüfen und Mail senden“ schickt es zusätzlich. Rote Pi-Warnungen kommen wie bisher sofort per Mail.

## Programm aktualisieren (ab 3.43)

Verwaltung → Einstellungen → **Sicherung & System → „Programm aktualisieren“** (Admin, PIN):
1. ZIP-Datei **einsatzverwaltung-pi.zip** auswählen → **„Paket prüfen“**. Der Pi prüft Inhalt und Programmcode und **startet die neue Version zur Probe** auf Testports (ohne eure Daten, ohne Sicherung/Mails). Angezeigt werden Versionen, Neuerungen und Hinweise (ältere Version, laufender Einsatz).
2. **„Jetzt einspielen und neu starten“**: Vorher werden die Daten gesichert (wie stündlich + `data.json.vor-update-…`) und das **bisherige Programm** in `backups/programm/` abgelegt (die letzten 3). Danach Neustart (etwa 10 Sekunden); die Seite lädt von selbst neu.
3. **„Frühere Programmversionen“** → „Zurück zu …“ stellt eine gesicherte Version wieder her (Daten bleiben).

Abgelehnt werden: keine ZIP-Datei, fremder Inhalt, Fehler im Programmcode, Absturz beim Probestart. Startet der Pi nach einem Update gar nicht mehr: `bash ~/einsatzverwaltung/backups/programm/<Ordner>/zuruecksetzen.sh`. Für die **Erstinstallation** oder wenn die Neuerungen es verlangen, weiter `install.sh` nutzen. Braucht `unzip` auf dem Pi (Raspberry Pi OS hat es; sonst `sudo apt install unzip`).

## Superadmin (ab 5.4)

- Ein Admin kann unter Verwaltung → Benutzer als **Superadmin** markiert werden (nur einer). Mit demselben Kennwort kommt er in Einsatzverwaltung, ASÜ (als Admin) sowie Geräte- und Atemschutz-Datenbank aller Ortswehren.
- Kennwort mindestens 12 Zeichen mit Buchstaben und Ziffern, Wechsel alle 4 Monate (sonst sind die Datenbanken für ihn gesperrt). Bei der Anmeldung erscheint statt der Ziffern-PIN ein Kennwortfeld. Jede Anmeldung steht im Sicherheitsprotokoll.

## Sicherheitsübersicht: Anmeldungen und Geräte (ab 5.6)

Verwaltung → **Sicherheit** zeigt zusätzlich:

- **Angemeldete Geräte (Datenbank-Apps):** jedes Gerät mit „Angemeldet bleiben“ – Zugang, Gerät, zuletzt benutzt, gültig bis. „Abmelden“ je Gerät oder „Alle abmelden“ (z. B. bei verlorenem Handy).
- **Anmeldungen der letzten 90 Tage** aus Einsatzverwaltung, ASÜ und Datenbanken mit Ergebnis, Gerät und Adresse. Filter: alle, nur fehlgeschlagen, von außen, je App.
- Gelingt eine Anmeldung nach mindestens 3 Fehlversuchen, entsteht ein Sicherheitshinweis. Sicherheitshinweise gehen per Mail an die System-Empfänger und als Benachrichtigung an den Superadmin.
- Der Sicherheits-Check prüft ab 5.7 auch: Zugang von außen nur über HTTPS, Datenschutzhinweise ausgefüllt, Schriften auf dem Pi, ASÜ auf GitHub aktuell (ab 5.8).

## Datenschutzhinweise und Schriften (ab 5.7)

- **Datenschutzhinweise** nach Art. 13 DSGVO stehen in allen Apps unter `/datenschutz` und sind bei den Anmeldungen, in der Fahrzeug-App (Feedback-Fenster) und auf dem persönlichen Link verlinkt. Verantwortliche Stelle und Datenschutzbeauftragte/n unter Einstellungen → Datenschutz eintragen (Zeilen mit „ | “ trennen); die Speicherdauern kommen aus den Löschfristen.
- **Schriften vom Pi:** Die Apps laden ihre Schriften nicht mehr bei Google. Der Pi holt sie einmal selbst und liefert sie aus – die Geräte der Nutzer haben dafür keine Verbindung zu Dritten. Bis dahin erscheint die Systemschrift.
- **Löschfrist für ausgeschiedene Atemschutzgeräteträger** (Einstellungen → Datenschutz, in Jahren, 0 = aus), siehe „Atemschutz-Datenbank: Jahresauswertung, persönlicher Link, Ausgeschiedene“.

## Jahresbericht und Notfallmappe (ab 5.8)

Verwaltung → **Berichte & Notfall**:

- **📊 Jahresbericht:** Jahr wählen → „Jahresbericht öffnen“. Einsätze nach Art (Brand, Technische Hilfe, Gefahrgut/ABC, Brandmeldeanlage, Sonstige) und Monat, häufigste Stichworte, je Ortswehr Einsätze, Fahrzeugeinsätze und Personenstunden, Einsatz- und Personenstunden gesamt, Atemschutz, Geräteprüfungen und Mängel, Schadensmeldungen und Expositionen. Darunter steht die Kurzfassung des gewählten Jahres. Druckseite – drucken oder als PDF speichern.
- **🗂 Notfallmappe:** für den Ausfall der Einsatzverwaltung – Ansprechpartner (Einstellungen → Betrieb), Checkliste „Was tun bei Ausfall?“, Fahrzeugliste, Feuerwehrhäuser und leere Vordrucke für Einsatztagebuch (FwDV 100), Stärkemeldung und Atemschutzüberwachung (FwDV 7). Je ein Exemplar in den ELW und ins Feuerwehrhaus, nach Änderungen neu drucken.

## ASÜ automatisch auf GitHub veröffentlichen (ab 5.8)

- Verwaltung → **ASÜ-Zugänge** → „Direkt auf GitHub veröffentlichen“: Repository (`konto/name`), Branch, Zugriffsschlüssel von GitHub (Fine-grained Token, nur dieses Repository, „Contents: Read and write“). Einrichten: ANLEITUNG Schritt 26.
- **„⬆ Jetzt auf GitHub veröffentlichen“** lädt alle Dateien in einem Schritt hoch – kein ZIP und kein Hochladen von Hand mehr. Mit **„Nach jedem Update automatisch veröffentlichen“** macht der Pi das etwa 90 Sekunden nach jedem Update selbst.
- Die Zeile „Stand auf GitHub“ zeigt die veröffentlichte Version; ist sie älter als die auf dem Pi oder schlug die Veröffentlichung fehl, steht das dort und im Sicherheits-Check. Der Schlüssel bleibt auf dem Pi.
- Das ZIP („⬇ Paket für GitHub erzeugen“) gibt es weiterhin, z. B. für einen anderen Webspace.

## Verwaltung → Hydranten (ab 5.9)

Die Seite **Verwaltung → Hydranten** (Einsatzleitung und Admin) ist die Übersicht für die Hydrantenprüfung:

- **Hydranten je Ortswehr** (jeder Hydrant ist dem nächsten Feuerwehrhaus zugeordnet) mit Anzahl, geprüft in Prozent, Mängeln und außer Betrieb. **Nur die eigene Gemeinde (ab 5.13):** Es zählen nur Hydranten, deren nächstes Feuerwehrhaus zu einer Ortswehr der Heimatgemeinde (Einstellung „Stadt/Gemeinde“, Fahrzeugliste) gehört – Hydranten der Nachbargemeinden aus OpenStreetMap erscheinen nicht in Liste, Übersicht und CSV. Lagekarte und Fahrzeug-App zeigen weiterhin alle Entnahmestellen.
- **Liste** mit Filter (Alle · Offene Mängel · Außer Betrieb · Prüfung fällig · Behoben · Neu gemeldet), letzter Prüfung, Prüfpunkten, Bemerkung, Fotos und Fahrzeug/Wehr; **„Karte ↗“** springt in die Lagekarte.
- **„✓ behoben“** mit Text („Was wurde gemacht?“), z. B. nach Reparatur durch den Wasserversorger; der Hydrant gilt dann wieder als in Ordnung (zurücknehmbar). Selbst gemeldete Hydranten lassen sich bei Fehlmeldung löschen.
- **„⬇ Liste als CSV (Excel)“** für den Wasserversorger oder die Gemeinde.
- **Löschwasser-Abdeckung:** Objekte ohne Entnahmestelle im Umkreis (siehe Teil 3).
- **Einstellungen → Hydrantenprüfung:** Prüfintervall in Monaten (Vorgabe 12), Umkreis der Löschwasser-Abdeckung (Vorgabe 300 m), E-Mail-Empfänger für Mängel.

## Ansprechpartner

- **Pflegen im Reiter „Objekte“:** oben „Objekte | Ansprechpartner“ umschalten. Je Eintrag **Funktion, Name, Telefon, E-Mail**, dazu Telefon 2 (mobil/Bereitschaft) und Bemerkung. „+ Ansprechpartner anlegen“, ✎ Bearbeiten, 🗑 Löschen, Suche über alle Felder. Funktionen werden vorgeschlagen (Bürgermeister/in, Bauhof, Wasserversorger, Energieversorger, Straßenmeisterei, Polizei …).
- **CSV:** dort auch „Als CSV exportieren“ und „CSV importieren“ (Spalten Funktion; Name; Telefon; Telefon 2; E-Mail; Bemerkung – z. B. aus Excel „CSV (Trennzeichen-getrennt)“). Gleiche Funktion+Name werden aktualisiert statt doppelt angelegt.
- **Im Einsatz nur suchen und hinzufügen:** Einsatz → Übersicht → Block „Ansprechpartner“ → „+ Ansprechpartner“, suchen, „Zum Einsatz“. Anlegen, Ändern und Löschen gehen im Einsatz nicht; der Knopf „Ansprechpartner pflegen (Reiter Objekte)“ führt direkt dorthin. In der Übersicht lassen sich Telefonnummern und E-Mail-Adressen antippen (am Handy/Tablet direkt anrufen). ✕ entfernt einen Ansprechpartner aus dem Einsatz, in der Datenbank bleibt er.
- Hinzufügen und Entfernen stehen im Einsatztagebuch; die Ansprechpartner stehen im Einsatzbericht (als Kopie – spätere Änderungen in der Datenbank ändern alte Einsätze nicht).
- Pflegen und zum Einsatz hinzufügen können Einsatzleitung und Admins; Betrachter können nur suchen und lesen.

---

## Hilfe in der App und „Was ist neu“ (ab 5.136)

- **ⓘ Hilfe** (oben in der Leiste, in den Datenbanken „ⓘ Hilfe“, im Berichtswesen ebenso) öffnet diese Anleitung genau beim Abschnitt des Bereichs, in dem man gerade ist – ist ein Fenster offen, beim Thema dieses Fensters. Taste **F1** macht dasselbe. Oben in der Hilfe kann man suchen.
- **Was ist neu:** Nach einem Update zeigt jede App einmal je Gerät und Benutzer die Neuerungen seit dem letzten Besuch („Verstanden“ schließt).

## Digitalfunk (Gerätedatenbank)

Gerätedatenbank → **📻 Digitalfunk**: Funkgeräte (ISSI, OPTA, Fahrzeug, Programmierstand, Sicherheitskarte), Sicherheitskarten (BSI-Karten, ohne PIN/PUK) und Akkus (Ladezyklen, Kapazitätstests). Oben „📌 Heute zu tun“ (veralteter Programmierstand, ablaufende Karten, Akkus tauschen/testen, offene Schäden), darunter Suche und Ortswehr.
- **Pflege** nur durch den Funkbeauftragten (Häkchen am Zugang unter ⚙ Verwaltung) und die von ihm benannten Beauftragten; Ortsgerätewarte sehen ihre Geräte und melden Schäden.
- **OPTA** eintippen → Ortswehr und Fahrzeug werden gewählt. **Soll-Stand** → Mail an die Gerätewarte, welche Geräte aktualisiert werden können.
- **QR-Codes:** Jedes Funkgerät und jeder Akku hat einen QR-Code („🏷 QR“ im Gerät, „🏷 Etiketten“ druckt alle angezeigten). „📷 Scannen“ öffnet das Funkgerät bzw. beim Akku die Testeingabe (Ortsgerätewarte: Ansicht mit „Schaden melden“).
- **Excel** exportieren (alle) und einlesen (Funkbeauftragter).

## Verpflegung im Einsatz

Einsatz → **🍽 Verpflegung**: Kräfte zählen, Bestellungen mit Status bestellt → geliefert → ausgegeben, Hinweis nach eingestellter Zeit ohne Verpflegung. Alles steht im Tagebuch.

## Berichtswesen: Fristen je Person und Monatsbericht

- **👤 Fristen:** Atemschutz-Nachweise je Person mit Ampel (rot/gelb/grün), Filter, Druck.
- **📬 Monatsbericht:** Jeder Zugang stellt Versandtag, Inhalte und Ortswehren selbst ein; Vorschau und Probe-Mail.

# Anhang: Versionshistorie

Neueste Version zuerst. Die Beschreibungen geben den Stand der jeweiligen Version wieder – was später geändert wurde, steht in der neueren Version und in den Kapiteln oben.

### Neu in 5.205 – Reiterleiste im Einsatz springt nicht mehr

- Die Reiter im Einsatz (Übersicht, Tagebuch, Aufträge, Fahrzeuge, Nachrichten …) haben jetzt einen **festen Platz für die Zahl**. Kommt eine Zahl dazu oder verschwindet, bleiben alle Reiter an ihrer Stelle – vorher rutschte die Leiste nach rechts oder in die zweite Zeile, und man tippte daneben.
- Gilt auch für die Reiterleiste über der Lagekarte.

### Neu in 5.204 – Aufträge: „Sonstiges“ mit Text, what3words in der Übersicht

- **„Sonstiges“ braucht eine Beschreibung:** Wählt man beim Auftrag die Kategorie **Sonstiges**, springt das Feld **„Was ist los / was ist zu tun?“** direkt unter die Kategorien und muss ausgefüllt werden (z. B. „Ölspur 50 m“). Ohne Text lässt sich der Auftrag nicht anlegen. Gleiches gilt beim Melden aus der Fahrzeug-App.
- Der Text steht dann überall statt nur „Sonstiges“: **„Sonstiges: Ölspur 50 m …“** – in der Auftragsübersicht (Spalten), der ausführlichen Liste, im Auftrag und in der Unwetter-Liste.
- **///what3words in der Auftragsübersicht:** Hat ein Auftrag eine Koordinate und ist what3words eingerichtet, stehen die drei Wörter in der Übersicht (Spalten und ausführliche Liste), im Auftrag unter „Ort“ und im Kopf der Disposition. **Antippen kopiert** die Adresse. In der gedruckten Auftragsliste stehen sie hinter der Koordinate.

### Neu in 5.203 – E-Mail-Alarm: auch schon gelesene Mails werden verarbeitet

- **Fehler behoben:** Die Einsatzverwaltung holte bisher nur **ungelesene** Mails ab. Wird das Alarm-Postfach zusätzlich auf einem Handy, Tablet oder im Webmail geöffnet, markiert das Mailprogramm neue Mails oft sofort als gelesen – kam das vor dem nächsten Abruf (alle 60 Sekunden), wurde die Mail **übersprungen**.
- Jetzt merkt sich der Pi je Postfach, welche Mails er schon verarbeitet hat, und holt zusätzlich **alle Mails der letzten 2 Tage** ab, die er noch nicht kennt – egal ob gelesen oder nicht. Doppelte Verarbeitung verhindert weiterhin die Message-ID.
- Im Mail-Protokoll steht dann „… schon als gelesen markierte Mail(s) nachgeholt (Postfach wird anderswo mitgelesen)“ – ein Hinweis, dass jemand das Postfach mitliest.
- **Beim ersten Abruf nach dem Update** werden ältere, schon gelesene Mails **nicht** nachgeholt (sonst kämen alte Alarme als neue Einsätze); erst ab dann gilt das neue Verfahren.
- Weiterhin gilt: Mails von Absendern, die nicht unter „Freigegebene Absender“ stehen, werden ignoriert (sie stehen auf der Seite „E-Mail“ im Posteingang mit „ignoriert – Absender nicht freigegeben“).

### Neu in 5.202.1 – PowerAlarm-Gruppen aller Ortswehren geprüft

- **Führungs- und Datengruppen alarmieren keine Fahrzeuge der Ortswehr** – auch nicht, wenn die Ortswehr von Hand zugeordnet ist und auch bei Schreibfehlern im Gruppennamen: OrtsBM (auch „OrtsB“, „OrstBM“), GemBM, Gemeindebrandmeister, Führungsgruppe, Stellv., Einsatzdatenübermittlung/-übernahme (z. B. „Einsatzdatenübernahme Fireboard“), Sonderlage, Pressesprecher, Team ….
- **Gruppen mit Funkrufnamen** wie „GemBM 14-02-01“ finden jetzt das Fahrzeug „14-02-1“ (führende Null egal).
- Alles, was unter Einstellungen → PowerAlarm je Gruppe an Fahrzeugen fest eingetragen ist, geht weiterhin vor.

### Neu in 5.202 – PowerAlarm/Leitstelle: alarmierte Ortswehren werden mit ihren Fahrzeugen alarmiert

- **Fehler behoben:** Kam ein Alarm über PowerAlarm für mehrere Gruppen (z. B. „Gemeindebrandmeister“, „Dehmkerbrock OrtsBM“, „Dehmkerbrock Groß“, „Herkendorf Groß“), wurde nur das Fahrzeug alarmiert, das einer Gruppe fest zugeordnet war (hier der Gemeindebrandmeister 14-01-1). Die Ortswehren standen nur als „Weitere alarmierte Kräfte“ im Tagebuch, weil sie nicht in der Kürzel-Liste unter Einstellungen → E-Mail-Alarm → „Alarmierte Kräfte“ standen.
- Jetzt gilt: Steht eine **Ortswehr der eigenen Gemeinde** (laut Fahrzeugliste) als alarmierte Feuerwehr bzw. Kraft im Alarm, werden ihre **Einsatzfahrzeuge** alarmiert – auch ohne Eintrag in der Kürzel-Liste (wie bisher nur, wenn unter Einstellungen → E-Mail-Alarm „Bei „Alarmierte Kräfte“ alle Fahrzeuge der genannten Ortsfeuerwehr alarmieren“ angehakt ist – das ist die Vorgabe; sonst als Vorschlag „Alarmierte Fahrzeuge übernehmen“). Das gilt auch für Leitstellen-Mails.
- **Führungsgruppen alarmieren nicht die ganze Ortswehr:** Gruppen wie „… OrtsBM“, „Gemeindebrandmeister“, „Führungsgruppe“ oder Gruppen mit fest zugeordnetem Fahrzeug bringen nur ihr Fahrzeug/ihre Funktion mit – nicht alle Fahrzeuge der Ortswehr. Nur Gruppen wie „Dehmkerbrock Groß“ alarmieren die Ortswehr.
- Im Tagebuch heißt die Zeile mit den PowerAlarm-Gruppen jetzt **„PowerAlarm-Gruppen:“** (vorher „Alarmierte Gruppen:“ – wurde fälschlich als Einsatzmittel gelesen).
- **Tipp:** Unter Einstellungen → PowerAlarm kann man jeder Gruppe weiterhin genau festlegen, welche Fahrzeuge sie alarmiert (z. B. bei „Aerzen Groß“) – das geht immer vor.

### Neu in 5.201 – Fahrzeug-App: nach Einsatzende nichts Altes mehr

- Wird ein Einsatz **beendet**, zeigt die Fahrzeug-App nichts mehr aus diesem Einsatz an:
  - **Nicht bestätigte Nachrichten** der Einsatzleitung (und von anderen Fahrzeugen) aus diesem Einsatz gelten als erledigt: kein roter Zähler, kein „Neu – bitte bestätigen“, kein Hinweis „neue Nachricht“ und keine Benachrichtigung mehr. Im **Verlauf** stehen sie weiter – mit dem Vermerk **„Einsatz beendet“** statt „✓ verstanden“.
  - Offene **Einblendungen** oben (Alarm, Nachricht, Auftrag, Objektdaten) verschwinden; die Statusmeldung „Status 2“ zum Einsatzende wird nicht mehr extra eingeblendet.
  - **Benachrichtigungen** der Fahrzeug-App auf dem Gerät (Mitteilungszentrale) werden beim nächsten Abruf entfernt, sobald die App geöffnet ist.
- In der Einsatzverwaltung bleibt im Einsatzverlauf sichtbar, dass die Nachricht nicht bestätigt wurde.
- Nachrichten außerhalb eines Einsatzes bleiben wie bisher stehen, bis sie bestätigt werden.

### Neu in 5.200.2 – Fahrzeug-App wie in 5.200

- Der Knopf „➕ Neuen Hydranten melden“ aus 5.200.1 ist wieder entfernt. Neue Hydranten meldet man wie bisher: Hydrantenprüfung (🔧) einschalten und auf der Karte **eine freie Stelle antippen**, an der der Hydrant steht → „➕ Neuen Hydranten hier melden und prüfen“.

### Neu in 5.200 – Neue Hydranten direkt in OpenStreetMap eintragen

- **Verwaltung → Hydranten** hat die neue Karte **„🌍 OpenStreetMap verbinden“** (nur Admin). Einmalig einrichten:
  1. Auf openstreetmap.org mit dem Konto der Feuerwehr anmelden → Mein Konto → **OAuth 2-Anwendungen** → „Neue Anwendung registrieren“: Name z. B. „ELW Aerzen“, Weiterleitungs-URI **`urn:ietf:wg:oauth:2.0:oob`**, „Vertrauliche Anwendung“ angehakt, nur die Berechtigung **„Karte bearbeiten“ (write_api)**.
  2. OSM zeigt danach **Client-ID** und **Client-Secret** (das Secret nur einmal!) – beides in der Karte eintragen und **Speichern**.
  3. **„🔑 Bei OpenStreetMap anmelden“** → in OSM „Autorisieren“ → OSM zeigt einen **Code** → in das Feld „Code von OpenStreetMap“ einfügen → **Verbinden**.
- Danach hat jeder **geprüfte und übernommene** neue Hydrant (Karte „🆕 Neu gemeldete Hydranten“ → „Übernommen, aber noch nicht in der Wasserkarte …“) den Knopf **„🌍 Direkt in OSM eintragen“**. Nach einer Sicherheitsfrage trägt die Einsatzverwaltung den Hydranten mit Art (Unterflur/Überflur/Wand) und Nennweite ein; als Quelle steht „vor Ort geprüft“.
- **Kein doppelter Eintrag:** Vorher wird nachgesehen, ob in OpenStreetMap im Umkreis von 15 m schon ein Hydrant steht – dann wird nichts eingetragen und die Knotennummer angezeigt (dann ggf. „⇄ zusammenführen“ bzw. Wasserentnahmestellen neu laden).
- Eingetragene Hydranten zeigen **„✓ in OpenStreetMap“** mit Link zum Knoten. Sobald die Wasserentnahmestellen neu geladen sind, wird der Hydrant automatisch zusammengeführt und verschwindet aus der Liste.
- Ohne Verbindung (oder zusätzlich über **„✎ iD-Editor“**) geht es weiter wie bisher über den OSM-Editor.
- **Wichtig:** Nur selbst vor Ort geprüfte Hydranten eintragen (keine Daten aus Plänen der Wasserversorger – Urheberrecht/Lizenz). Die Einträge laufen unter dem verbundenen OSM-Konto und sind für alle sichtbar. Client-Secret und Anmeldung liegen nur auf dem Pi und tauchen in keiner Liste, keinem Export und keinem Bericht auf. **„Verbindung trennen“** löscht die Anmeldung.

### Neu in 5.199 – Berichtswesen: Filter speichern und schnell wieder aufrufen

- In den Reitern **🗺 Karte**, **👤 Fristen** und **📝 Anforderungen** gibt es oben die Leiste **„⭐ Gespeicherte Filter“**:
  - Filter wie gewünscht einstellen → **„⭐ Filter speichern“** → Namen vergeben (z. B. „Hydranten mit Mangel“, „Nur Aerzen – Handlungsbedarf“).
  - Antippen eines gespeicherten Filters stellt alles wieder ein; **✕** löscht ihn. Gleicher Name = überschreiben.
  - Gespeichert wird je Reiter: **Karte** – was (Fahrzeuge, Hydranten …), Auswahl, Abdeckung (Radius/Anfahrtszeit, Minuten), Einsätze mit Zeitraum und Färbung; **Fristen** – Ortswehr, Namenssuche, „nur mit Handlungsbedarf“; **Anforderungen** – Status (offen, bestellt …), Ortswehr, Suche, Haushaltsjahr, Sortierung, Ansicht und Spalten.
- Im Reiter **📊 Berichte** heißt der bisherige Knopf jetzt **„⭐ Filter speichern (Berichtsform)“** – dort werden wie bisher Quelle, Filter, Suche, Sortierung, Spalten, Zeitraum und Gruppierung gespeichert (mit E-Mail-Abo).
- Die gespeicherten Filter gehören zum **eigenen Zugang** und liegen auf dem Pi – sie stehen auf jedem Gerät zur Verfügung, auf dem man sich anmeldet.

### Neu in 5.198.4 – Etikettenbögen genau ausrichten (Vier-Punkt-Ausrichtung)

- Unter **„Ausrichtung anpassen“** im Fenster „Blanko-Etiketten drucken“ gibt es jetzt vier Werte statt zwei: **Oberste Reihe, Unterste Reihe, Linke Spalte, Rechte Spalte** (in mm; Plus = nach unten bzw. rechts, Minus = nach oben bzw. links).
- Die App verteilt die Korrektur **gleichmäßig auf alle Reihen und Spalten dazwischen**. Damit lassen sich auch Bögen ausrichten, bei denen der Abstand der Etiketten nicht ganz passt – nicht nur verschobene.
- **So geht's:** Probedruck auf normales Papier → gegen das Licht auf einen Bogen legen → messen, wie weit die oberste und unterste Reihe sowie die linke und rechte Spalte verschoben werden müssen → eintragen → erneut Probedruck.
  - Beispiel: oberste Reihe 3 mm zu tief, unterste 6 mm zu hoch, rechte Spalte 6 mm zu weit links → **Oberste −3, Unterste +6, Linke 0, Rechte +6**.
- **Vorher prüfen:** Im Druckdialog **„Tatsächliche Größe / 100 %“** (nicht „An Seite anpassen“) und Ränder „Keine“ wählen. Sind die Codes in beide Richtungen etwas zu eng beieinander, liegt es meist an dieser Einstellung.
- Die Werte gelten je Bogenart und werden auf dem jeweiligen Gerät gespeichert (auch für einzeln gedruckte Etiketten). Alte Einstellungen werden übernommen.

### Neu in 5.198.3 – Etikettenbögen ohne Leerseiten

- **Fehler behoben:** Beim Drucken mehrerer Blanko-Bögen kam nach jedem Bogen eine leere Seite – beim Durchdrucken eines Stapels Etikettenbögen wurde so jeder zweite Bogen verschwendet. Jetzt folgt Bogen auf Bogen ohne Leerseite.

### Neu in 5.198.2 – Vorgedruckte Etiketten auch für Fahrzeuge, Funkgeräte, Akkus und Lager

- Der Knopf **„🏷 Etikett …“** mit Menü (scannen, eintippen, einzeln drucken, lösen) gibt es jetzt zusätzlich bei:
  - **🚒 Fahrzeugen** – im Fahrzeug-Fenster der Gerätedatenbank (Daten/Beladung/Fristen). Scannen öffnet wie der bisherige Fahrzeug-QR die Geräteliste mit Ampel.
  - **📻 Funkgeräten** und **🔋 Akkus** – im Digitalfunk beim Bearbeiten bzw. in der Ansicht. Scannen öffnet das Funkgerät bzw. beim Akku den Kapazitätstest (Funkbeauftragter) – wie bisher.
  - **📦 Lagerartikeln** – beim Bearbeiten des Materials (z. B. Etikett am Regalfach). Scannen öffnet den Artikel im Lager der richtigen Ortswehr.
- Im Fenster **„Freies Etikett – wem soll es gehören?“** stehen diese Bereiche zur Auswahl, soweit der Zugang dafür freigeschaltet ist.
- Standard-Bogen für diese Bereiche: **Avery L7872** (wählbar).
- Nicht möglich (bewusst): **Sicherheitskarten (BSI)** – sie stecken im Funkgerät und werden über das Funkgerät verwaltet; **Hydranten** – die Hydrantenprüfung findet den Hydranten in der Fahrzeug-App über den Standort.

### Neu in 5.198.1 – Etikett jederzeit neu zuweisen oder einzeln drucken

- Der Knopf **„🏷 Etikett …“** bei Gerät, Atemschutzgerät und Person öffnet jetzt ein Menü – jederzeit, auch wenn schon ein Etikett zugewiesen ist:
  - **📷 Neues Etikett scannen** – vorgedrucktes Etikett zuweisen.
  - **⌨ Code vom Etikett eintippen** – falls die Kamera nicht scannt.
  - **🖨 Neues Etikett sofort drucken** – kein Blanko-Bogen zur Hand? Neuer Code wird erzeugt, sofort zugewiesen und als **einzelnes Etikett** gedruckt. Bogen (L7872 oder L6146) und **Position auf dem Bogen** wählbar, damit angebrochene Bögen weiter genutzt werden.
  - **🔓 Etikett lösen** – sperrt das aktuelle Etikett (z. B. verloren), ohne ein neues zuzuweisen.
- Bei jedem neuen Etikett wird das bisherige automatisch gesperrt.
- Gerätewarte und Atemschutzgerätewarte dürfen jetzt beide Bogenarten drucken (z. B. Folien-Etikett L6146 für ein Gerät, das nass wird).

### Neu in 5.198 – Vorgedruckte QR-Etiketten (Blanko-Etiketten) zuweisen

QR-Etiketten lassen sich jetzt **vorab auf Vorrat drucken** und später einem Gerät, Atemschutzgerät oder Geräteträger **zuweisen**. Jeder Code ist zufällig und enthält **keinen Namen und keine Gerätedaten** – ein verlorenes Etikett verrät nichts.

**Drucken**
- **Geräte:** Datenbank → Gerätedatenbank → Menü „⋯“ → **„🏷 Blanko-Etiketten (Avery L7872)“** – 35,6 × 16,9 mm, 80 je Bogen.
- **Atemschutzgeräte und Geräteträger:** Datenbank → Atemschutz → **QR-Codes** → **„🏷 Blanko-Bogen drucken (Avery L6146)“** – 63,5 × 33,9 mm, 24 je Bogen, abziehsichere Folie.
- Wählbar: Anzahl Bögen (bis 10) und **erstes freies Etikett** auf dem ersten Bogen (für angebrochene Bögen).
- **Probedruck (ohne Codes)** auf normales Papier mit gestrichelten Rahmen – gegen das Licht auf einen Etikettenbogen legen. Ist der Druck verschoben, unter „Ausrichtung anpassen“ in mm korrigieren (wird je Gerät gemerkt). Im Druckdialog **„Tatsächliche Größe / 100 %“** wählen.
- Auf jedem Etikett steht neben dem QR-Code der Code in Klarschrift (z. B. **K7M3-PX9Q**) – zum Eintippen, falls die Kamera nicht will.

**Zuweisen – zwei Wege**
1. **Beim Eintrag:** Gerät, Atemschutzgerät oder Person öffnen → **„🏷 Etikett zuweisen“** → Etikett scannen (oder „Code vom Etikett eintippen“). Danach zeigt der Knopf den Code an, z. B. „🏷 Etikett K7M3-PX9Q“.
2. **Mit der Handykamera:** Freies Etikett scannen → die Datenbank öffnet sich mit **„Freies Etikett … – wem soll es gehören?“** → Gerät / Atemschutzgerät / Geräteträger wählen, suchen, antippen. Auch der „📷 Scannen“-Knopf in der Datenbank erkennt freie Etiketten und bietet das Zuweisen an.

**Danach** funktioniert das Etikett überall wie die bisherigen: Handykamera öffnet die Gerätekarte bzw. den Eintrag, die **ASÜ** übernimmt beim Scannen Name bzw. Gerätenummer (auch offline, die Zuordnungsliste wird mit der Tauglichkeitsliste geladen), die Datenbank-Scanner (Geräte, Tausch/Prüfung) erkennen es.

**Ersetzen und Sperren**
- Bekommt ein Eintrag ein **neues** Etikett, wird das alte automatisch **gesperrt** (z. B. beschädigtes Etikett).
- Ist ein Etikett schon jemand anderem zugewiesen, fragt die App nach, bevor sie es umhängt.
- Die bisherigen Etiketten (mit Daten im Code) gelten weiter – beides funktioniert nebeneinander.
- Jede Erzeugung und Zuweisung steht im Protokoll.

### Neu in 5.197 – Fälschungssicheres Einsatztagebuch (Prüfsummen-Kette)

- Jeder neue Tagebucheintrag bekommt auf dem Pi eine **Prüfsumme (SHA-256)**, die auch die Prüfsumme des vorherigen Eintrags enthält. So entsteht eine Kette: Wird später ein Eintrag außerhalb der Einsatzverwaltung **verändert, gelöscht, eingefügt oder umsortiert**, bricht die Kette an dieser Stelle – das ist nachweisbar.
- **Anzeige im Tagebuch** (neben „Statusmeldungen zeigen“): **„🔒 Tagebuch unverändert“**. Antippen bzw. darüber fahren zeigt die Prüfsumme des letzten Eintrags. Bei einem Bruch erscheint rot **„⚠ Tagebuch verändert“** – antippen zeigt, welcher Eintrag betroffen ist (z. B. „Inhalt nachträglich verändert“, „Eintrag Nr. 2 fehlt“).
- **Korrekturen** nach FwDV 100 (neuer Eintrag „Korrektur zu Nr. …“) sind erlaubt und brechen die Kette nicht.
- **Beim Einsatzende** wird der Stand festgehalten (Anzahl Einträge + Prüfsumme). Fehlen später im Archiv Einträge am Ende, wird auch das erkannt.
- **Ausdruck** (Tagebuch drucken, Einsatzbericht): Unter dem Tagebuch steht die Prüfsumme des letzten Eintrags. Ein Papierexemplar oder PDF ist damit ein unabhängiger Nachweis für später.
- **Schwärzung im Archiv** (Datenschutz): Vor dem Schwärzen wird die Kette geprüft und das Ergebnis gespeichert; danach zeigt das Tagebuch „Vor der Schwärzung geprüft: unverändert“.
- Einträge, die **vor diesem Update** entstanden sind, haben keine Prüfsumme; die Anzeige lautet dann „unverändert ab Nr. …“.
- Hinweis: Die Kette macht Änderungen **sichtbar**, sie verhindert sie nicht. Wer Zugriff auf den Pi hat, könnte die Kette theoretisch neu berechnen – genau dafür ist die gedruckte Prüfsumme der unabhängige Anker.

### Neu in 5.196 – ASÜ: Ruhezeit nach dem Atemschutzeinsatz (FwDV 7)

- Nach FwDV 7 ist zwischen zwei Einsätzen unter Atemschutz eine **Ruhepause** nötig; ihre Dauer richtet sich nach der Belastung des ersten Einsatzes.
- Ist ein Trupp **beendet**, zeigt die ASÜ je Geräteträger **„⏳ Ruhezeit bis …“** – an der Truppkarte bzw. in der Übersicht – mit dem Hinweis **„Flüssigkeit ersetzen“**.
- Beim Zusammenstellen eines neuen Trupps steht die Ruhezeit direkt beim Namen.
- Wird jemand **vor Ablauf** wieder eingesetzt („Beginn“), kommt eine deutliche Warnung mit der Restzeit. Der Einheitsführer kann trotzdem einsetzen („Trotzdem einsetzen“).
- **Einstellungen → Überwachung & Warnungen → „Ruhezeit nach dem Atemschutzeinsatz“:** Richtwert in Minuten ab „Ende“, Vorgabe 30 Minuten, 0 = aus. Die FwDV 7 nennt keine feste Zeit – bitte in der Gemeinde festlegen.

### Neu in 5.195 – Träger pflegen Übungsstrecke und G 26 selbst

- In der **Träger-App „Mein Atemschutz“** trägt jeder Atemschutzgeräteträger unter **📅 Meine Termine** selbst ein:
  - **Übungsstrecke absolviert am:** das Datum, an dem die Belastungsübung gemacht wurde (heute oder früher). Gilt 12 Monate.
  - **G 26 gültig bis:** das zukünftige Datum von der Bescheinigung (= nächste Untersuchung), höchstens 3 Jahre ab heute. Kein Befund.
- Nach „Speichern“ werden **Status und Atemschutz-Datenbank sofort aktualisiert**. Vorher waren das nur Termin-Erinnerungen, die Nachweise änderten sich dadurch nicht – deshalb wirkte es so, als würde nichts übernommen.
- Unsinnige Eingaben werden abgelehnt (Übungsstrecke in der Zukunft, G 26 in der Vergangenheit oder mehr als 3 Jahre).
- **In der Datenbank** steht beim Nachweis **„✍️ vom Träger selbst eingetragen am …“**. Speichert der Atemschutzgerätewart die Person, ist der Eintrag bestätigt. Jede Eintragung steht im Protokoll.

### Neu in 5.194 – Nur den QR-Code drucken

- **In allen Apps mit QR-Codes** (Einsatzverwaltung, ASÜ, Datenbank) steht unter jedem angezeigten QR-Code der Knopf **„▦ Nur QR-Code drucken“**. Gedruckt wird nur der Code, ohne Überschrift, Link oder Erklärtext.
  - **Größe** wählbar: 2,5 cm (kleines Geräteetikett) bis 15 cm (Aushang).
  - **Wie oft:** 1× oder **ganze Seite füllen** – z. B. viele Aufkleber desselben Codes zum Ausschneiden.
  - Die zuletzt gewählte Größe merkt sich das Gerät.
  - Gilt u. a. für: Fahrzeug-App, Besatzungs-App, ELW-Info-App, Alarmmonitor-Links, Bereitstellungsraum, Stärken sammeln, Hydranten-App des Wassermeisters (jetzt als Fenster statt neuer Seite), Sammel-App, Geräte-, Personen-, Fahrzeug- und Funk-Etiketten.
- **Etikettendruck in Datenbank und ASÜ** (einzeln über „🖨 Drucken“ oder als Bogen, z. B. „QR-Etiketten“ der Gerätedatenbank, Funkgeräte/Akkus): Vor dem Druck fragt die App **„Mit Beschriftung“** (wie bisher: Code, Nummer, Bezeichnung) oder **„Nur QR-Code“** (mit Größenwahl).
- Beim Drucken im Druckdialog „Tatsächliche Größe“ bzw. „100 %“ wählen, damit die Größe stimmt.
- Keinen Knopf gibt es bei QR-Codes, die nur zum Übergeben gedacht sind (Trupp-Übergabe, Beitreten zu einem Einsatz) und bei Zugangsblättern mit Kennwort.

### Neu in 5.193.4 – Träger-App: Terminfelder passen aufs Handy

- In der Atemschutz-Träger-App (📅 Meine Termine) waren die Datumsfelder **Übungsstrecke** und **G 26-Untersuchung** auf dem Handy zu breit: Sie überlappten sich und ragten über den Rand.
- Jetzt stehen sie auf Handys untereinander und nutzen die volle Breite, auf Tablet und PC weiter nebeneinander.
- Die App aktualisiert sich beim nächsten Öffnen von selbst.

### Neu in 5.193.3 – Sicherheitsabfragen in Datenbank und ASÜ gehen wieder

- **Fehler behoben:** In der Datenbank-App (Atemschutz und Geräte) und in der ASÜ erschien bei „Löschen“ und anderen Aktionen mit Rückfrage keine Abfrage. Die Aktion wurde dann stillschweigend nicht ausgeführt. Aufgefallen ist das beim Löschen eines Gerätewart-Zugangs, der sich noch nie angemeldet hatte.
- Ursache war eine gleichnamige ältere Funktion („Einsatz anschließen?“), die die Sicherheitsabfrage verdeckt hat. Sie heißt jetzt anders, die Frage zum Anschließen an einen laufenden Einsatz funktioniert weiter wie gewohnt.
- Betroffen waren u. a.: Zugänge löschen, Personen/Geräte/Einträge löschen, Trupp-Mitglieder entfernen, Schulungen löschen, Doppelt-Anlage bestätigen.
- Die Apps aktualisieren sich beim nächsten Öffnen von selbst.

### Neu in 5.193.2 – Fahrzeug-App: rote Punkte nur bei Inhalt

- In der unteren Leiste der Fahrzeug-App (Einsatz, Nachrichten, Melden) erscheint der rote Punkt jetzt nur noch, wenn es dort wirklich etwas gibt, z. B. ungelesene Nachrichten (mit Anzahl). Vorher waren leere rote Punkte immer zu sehen.
- Die App aktualisiert sich beim nächsten Öffnen von selbst.

### Neu in 5.193.1 – Gemeindebrandmeister bleibt nach Updates erhalten

- **Fehler behoben:** Nach jedem Update (Neustart des Servers) zeigte die Benutzerverwaltung beim Gemeindebrandmeister den Haken **„Gemeindebrandmeister“** nicht mehr an. Auch Superadmin-Kennzeichen, E-Mail und Fahrzeug-App-Eintrag fehlten in der Anzeige. Wer den Benutzer danach gespeichert hat (z. B. für eine neue PIN), hat damit die Funktion unbemerkt entfernt.
- Jetzt bleiben diese Angaben auch nach Updates sichtbar und erhalten.
- **Einmal prüfen:** Unter ⚙ Verwaltung → Benutzer den Gemeindebrandmeister öffnen. Fehlt der Haken, bitte einmal setzen und speichern (E-Mail-Adresse prüfen). Der zentrale Zugang zu Datenbanken und Berichtswesen wird dann automatisch wieder freigeschaltet.

### Neu in 5.193 – Neu gemeldete Hydranten übernehmen
- **Melden in der Fahrzeug-App:** Bei „➕ Neuen Hydranten hier melden und prüfen“ fragt die App jetzt **Art** (Unterflur, Überflur, Wand) und **Nennweite** (DN 80 … 300, vom Hinweisschild „H 100“). Mit **„📍 Auf meinen Standort setzen“** kommt der Punkt genau auf den eigenen Standort; ein Foto vom Schild hilft beim Übernehmen. Steht schon ein Hydrant aus OpenStreetMap höchstens 25 m daneben, wird die Prüfung wie bisher diesem zugeordnet.
- **Sofort sichtbar:** Ein gemeldeter Hydrant erscheint gleich in Lagekarte, Monitor und Fahrzeug-App – mit Art und Nennweite.
- **Übernehmen:** Verwaltung → Hydranten → Karte **„🆕 Neu gemeldete Hydranten“** – je Meldung Kartenausschnitt (antippen = in der Lagekarte zeigen), Fotos, wer und wann. Art, Nennweite und Lage (Breite/Länge) prüfen bzw. korrigieren und **„✓ Übernehmen“**; **„✗ Fehlmeldung“** entfernt den Punkt überall. Steht ein anderer Hydrant höchstens 30 m daneben, erscheint ein Hinweis und **„⇄ Mit dem Hydranten daneben zusammenführen“** (die Prüfungen bleiben erhalten). Übernehmen dürfen Admin und Einsatzleitung.
- **Wassermeister:** In seiner App gibt es den Reiter **„Neu“** mit denselben Möglichkeiten (Bestätigen mit Art/DN, Fehlmeldung, „Ist der daneben“, Navigation). Die Sonntagsmail und „Alle offenen Mängel senden“ enthalten unten den Abschnitt **„Neu gemeldete Hydranten“** mit Karte und Fotos.
- **OpenStreetMap:** Knopf **„🌍 In OpenStreetMap eintragen“** – öffnet den OSM-Editor genau an der Stelle und kopiert die Merkmale (emergency=fire_hydrant, Art, Nennweite) zum Einfügen; Anmeldung mit dem eigenen OSM-Konto. Übernommene Hydranten, die noch nicht in OSM stehen, sind unter „Übernommen, aber noch nicht in OpenStreetMap“ aufgelistet.
- **Keine doppelten Hydranten:** Taucht der Hydrant später in OpenStreetMap auf (höchstens 15 m daneben), führt die Einsatzverwaltung beim nächsten Laden der Wasserentnahmestellen beide automatisch zusammen – Prüfungen und Angaben bleiben erhalten (Protokolleintrag).

### Neu in 5.192.1 – Mängel per Knopfdruck an den Wassermeister
- Verwaltung → Hydranten → „Wassermeister: Wochenmail und App“ → **„📤 Alle offenen Mängel jetzt an den Wassermeister senden“** (Admin): nach Rückfrage geht sofort eine Mail mit **allen derzeit offenen Mängeln** raus – egal, wann geprüft wurde – im selben Aufbau wie die Wochenmail (je Hydrant Mängel, Hinweis, Fotos, Karte, Link zur App).
- „Nur die letzten 7 Tage senden“ schickt wie bisher nur die neuen. Vorschau und „Test an mich …“ zeigen jetzt ebenfalls alle offenen Mängel. Die nächste Sonntagsmail enthält danach nur, was neu dazukommt.

### Neu in 5.192 – Hydrantenprüfung: Wochenmail und App für den Wassermeister
- **Wochenmail sonntags abends (ab 18 Uhr):** Wurden in der Woche Hydranten mit Mangel oder „außer Betrieb“ geprüft, bekommt der Wassermeister **eine Mail** mit **einem Abschnitt je Hydrant**: Art und Nennweite, Koordinaten, Prüfdatum und Fahrzeug, die Mängel, der Hinweis der Prüfer, Druck, **die Fotos** und **ein Kartenausschnitt** mit Markierung (dazu Links „Karte öffnen“ und „Navigation“). Ohne neue Mängel kommt keine Mail; inzwischen behobene Mängel fehlen. „Außer Betrieb“ steht oben.
- **Empfänger:** Einstellungen → Hydrantenprüfung → „Mängel melden an“. Dort auch „Mängel melden“: **woche** (Vorgabe) oder **sofort** (wie bisher nach jeder Prüfung) und die Uhrzeit am Sonntag.
- **App für den Wassermeister:** Verwaltung → Hydranten → Karte „Wassermeister: Wochenmail und App“ → **„+ Link für den Wassermeister erstellen“**. Den Link (Kopieren oder ▦ QR zum Ausdrucken) bekommt der Wassermeister; er steht auch in jeder Wochenmail. Die App läuft über die Internetadresse der Fahrzeug-App, also auch von außen, ohne Anmeldung.
  - Reiter **Offen / Behoben / Alle**; je Hydrant Mängel, Hinweis, Druck, Fotos (antippen = groß), Kartenausschnitt, **🧭 Navigation** und frühere Prüfungen.
  - **„✓ Behoben“** mit kurzem Text („Was wurde gemacht?“) – erscheint sofort in Verwaltung → Hydranten, in der Lagekarte und im Protokoll („… (Wassermeister)“). Versehentlich abgehakt: „↩ Wieder offen“.
  - Link löschen (🗑) sperrt den Zugang sofort. Wer den Link hat, kann die Mängel sehen und abhaken – nur an den Wassermeister geben.
- **Zum Ausprobieren** (Admin): „👁 Vorschau“, „✉ Test an mich …“ und „📤 Jetzt senden“ (jeweils die letzten 7 Tage).

### Neu in 5.191 – Fahrzeug-App: alle Eingaben ohne Netz speichern
- **Gilt jetzt für alles, was die Fahrzeug-App sendet:** Bereitschaft (im Einsatz / verfügbar, Auftrag erledigt), Stärke, Nachrichten an die Einsatzleitung und an andere Fahrzeuge (auch mit Fotos), Lagemeldung, Standort aus der Karte senden, „Verstanden“-Quittung, Auftrag melden (mit Fotos), Schaden melden, Verbrauch nachfüllen, Fahrzeug-Check, Beladung, Fahrtenbuch, Feedback und Hydrantenprüfung.
- **Ohne Netz** erscheint „📴 Kein Netz – auf dem Handy gespeichert“. Die Anzeige in der App wird gleich umgestellt (z. B. Knopf „verfügbar“, Stärke), Eingabefelder werden geleert.
- **Senden:** Sobald wieder Netz da ist, gehen die Meldungen **in der Reihenfolge der Eingabe** raus (etwa alle 3–4 Sekunden eine). Oben in der App steht, wie viele warten; unter „Was wartet?“ die Liste, Knopf „📤 Senden“.
- **Bei der Einsatzleitung** steht bei nachgereichten Texten „(ohne Netz geschrieben 22.10., 07:50, nachgereicht)“, im Protokoll „Fahrzeug-App (ohne Netz 07:50, nachgereicht)“. Doppelt Gesendetes wird nur einmal übernommen.
- **Nicht gespeichert** wird der Standort (GPS): Ohne Netz gibt es keine Positionen, mit Netz wird sofort wieder der aktuelle Standort gesendet. Benachrichtigungen einrichten und „Freigabe anfragen“ gehen nur mit Netz.
- **Wichtig im Einsatz:** Eine Meldung, die ohne Netz gespeichert ist, kommt erst bei Netz an – dringende Rückmeldungen bei Funkloch weiter per Funk geben.

### Neu in 5.190 – Hydrantenprüfung ohne Netz (Fahrzeug-App)
- **Prüfung im Funkloch speichern:** Ist beim Speichern kein Netz da, wird die Prüfung **auf dem Handy gespeichert** – mit Prüfpunkten, Druck, Bemerkung und Fotos. Meldung: „📴 Kein Netz – Prüfung auf dem Handy gespeichert“. Der Hydrant bekommt auf der Karte ein ⏳.
- **Automatisch senden:** Sobald wieder Netz da ist (beim Wiederverbinden, beim Öffnen der App und alle 30 Sekunden), schickt die App die gespeicherten Prüfungen nacheinander. Meldung: „📤 … gesendet“. Im Prüfmodus steht die Liste der wartenden Prüfungen mit Knopf **„📤 Jetzt senden“**.
- **Prüfzeit bleibt erhalten:** In der Verwaltung, im Protokoll und in der Mail an den Wasserversorger steht die Zeit am Hydranten (Protokoll: „ohne Netz geprüft am …, nachgereicht“). Doppelt Gesendetes wird nur einmal übernommen; eine nachgereichte ältere Prüfung überschreibt keine neuere.
- **Karte und Hydranten ohne Netz:** Beim Einschalten der Hydrantenprüfung (mit Netz) merkt sich die App alle Hydranten der Gemeinde und die Prüfpunkte. Im Funkloch zeigt sie die Hydranten und „Offen oder fällig in der Nähe“ aus diesem Speicher. Kartenkacheln, die schon einmal angezeigt wurden, bleiben gespeichert – am besten das Prüfgebiet vorher einmal mit Netz auf der Karte ansehen.
- **App ohne Netz öffnen:** Wird die Fahrzeug-App im Funkloch neu geöffnet, startet sie mit dem zuletzt bekannten Stand. Oben steht dann „📴 Kein Netz – Anzeige vom …“; Meldungen an die Einsatzleitung (Status, Nachrichten) gehen erst wieder mit Netz.
- Die Speicherung liegt nur auf diesem Handy. Wird der Link des Fahrzeugs ersetzt, bevor gesendet wurde, gehen die gespeicherten Prüfungen verloren – also nach der Prüfrunde einmal mit Netz die App öffnen.

### Neu in 5.189.1 – Automatisches Abmelden nur für Admin, Einsatzleitung und Ortsbrandmeister
- Das Abmelden nach 30 Minuten ohne Bedienung gilt nur noch für die Rollen **Admin**, **Einsatzleitung** und **Ortsbrandmeister**.
- **Betrachter bleiben immer angemeldet** (z. B. Anzeige-Bildschirme im Feuerwehrhaus oder ELW) – bei ihnen erscheint auch kein Hinweis „Noch angemeldet?“.
- In „Angemeldete Geräte“ steht die Restzeit nur bei Geräten, die abgemeldet werden können.

### Neu in 5.189 – Automatisch abmelden nach 30 Minuten ohne Bedienung
- **Einsatzverwaltung:** Jedes angemeldete Gerät wird abgemeldet, wenn es **30 Minuten nicht bedient** wurde (kein Tippen, Klicken, Scrollen, keine Eingabe). Was im Hintergrund nachgeladen wird, zählt nicht. Das gilt auch für Geräte, die ausgeschaltet oder liegen geblieben sind – deren Anmeldung verfällt auf dem Pi.
- **Eine Minute vorher** erscheint „Noch angemeldet?“ mit Countdown und Knopf **„Angemeldet bleiben“**. Jede Bedienung – auch in einem anderen Fenster derselben Anmeldung – setzt die Zeit zurück.
- **Einstellbar:** Einstellungen → Betrieb → „Abmelden nach … Minuten ohne Bedienung“ (Vorgabe 30, **0 = aus**).
- **Übersicht:** Verwaltung → Benutzer → „Angemeldete Geräte“ zeigt je Gerät, wann es zuletzt bedient wurde und in wie vielen Minuten es abgemeldet wird. Im Protokoll steht „Nach 30 Minuten ohne Bedienung automatisch abgemeldet“.
- Gilt auch für die Übungsleitstelle. **Nicht betroffen:** Alarmmonitor (eigener Link mit Schlüssel), Fahrzeug-App, ASÜ, Datenbank, Berichtswesen und Träger-App.
- **Hinweis für Bildschirme im ELW/Feuerwehrhaus**, die nur anzeigen (z. B. Lagekarte an der Wand): ab 5.189.1 mit einem Betrachter-Zugang anmelden – der bleibt angemeldet.

### Neu in 5.188 – Eine Datenbank-App für Gerätewarte und Atemschutzgerätewarte
- **Eine App, eine Anmeldung:** Gerätedatenbank und Atemschutz-Datenbank sind zusammengeführt. Adresse: `/datenbank` (ASÜ-Port, auch von außen). Alle melden sich mit ihrem bisherigen Zugang an – Benutzername und Kennwort bleiben. Die alten Links `/geraete` und `/atemschutz` (auch QR-Etiketten, Lesezeichen, installierte Apps und Benachrichtigungen) leiten automatisch weiter.
- **Jeder sieht nur seine Bereiche:**
  - **Atemschutzgerätewart:** Personen (mit Einsatznachweis), Atemschutzgeräte (mit Gerätepflege und Inbetriebnahme), Kalender, Jahresauswertung, QR-Codes – **neu: 📦 Lager** der eigenen Ortswehr (Bestand ändern, Material anlegen, aus dem Lager Gemeinde anfordern).
  - **Gerätewart:** Gerätedatenbank, Kalender, Lager, Digitalfunk, Übersicht – **neu: 🧯 Atemschutzgeräte** der eigenen Ortswehr sehen und bearbeiten (anlegen, ändern, löschen, Prüftermine, Excel, QR-Code), dazu Gerätepflege und Inbetriebnahme. Personen, Nachweise und Auswertungen der Atemschutzgeräteträger sieht der Gerätewart weiterhin nicht.
  - **Admin / Superadmin** (beide Bereiche): oben umschalten **„😷 Atemschutz | 🧰 Geräte“**; die Verwaltung zeigt die Zugänge des gewählten Bereichs.
- **Zugänge bleiben getrennt:** Ein Zugang gehört weiter zu einem Bereich (Gerätewart oder Atemschutzgerätewart); die Leitung je Ortswehr ebenfalls je Bereich. Benachrichtigungen wie bisher je Bereich.
- **ASÜ:** Der Reiter „Datenbank“ und der Knopf auf der Anmeldeseite öffnen die Datenbank-App (aus dem laufenden Einsatz in einem neuen Fenster, die Überwachung bleibt offen).
- **Einsatzverwaltung:** Verwaltung → Apps und das Zugangsblatt der Gemeindebrandmeister nennen nur noch den Link `/datenbank`.


### Neu in 5.187.2 – Regenradar zeigt den Regen wieder
- **Ursache gefunden:** Der DWD führt zu jedem Radarbild die Messzeit mit. Für frühere Zeitpunkte lieferte er ohne diese Angabe ein leeres Bild – deshalb war meist kein Regen zu sehen und nur kurz etwas.
- **„jetzt“** zeigt immer das neueste gemessene Bild (wie bis 5.186). Beim Zurückschieben werden die Bilder der letzten Stunde mit ihrer eigenen Messzeit geladen, beim Vorschieben die Vorhersage des neuesten Laufs (bis +2 h).
- Es wird das Niederschlagsradar des DWD verwendet; es enthält inzwischen selbst die 2-Stunden-Vorhersage.

### Neu in 5.187.1 – Regenradar repariert
- **Radar zeigt wieder zuverlässig ein Bild:** Der Pi fragt beim DWD ab, welche Radarbilder es gerade wirklich gibt (Ebenen-Name und Zeitpunkte), und die Karte fordert nur noch diese an. Bisher wurden feste Zeitpunkte erraten – passten sie nicht, blieb die Karte leer.
- **Vorhersage nur, wenn der DWD sie liefert:** Gibt es Bilder für die nächsten zwei Stunden, erscheinen Zeitschieber und „+2 h“. Sonst gibt es den Verlauf der letzten Stunde bzw. nur das aktuelle Bild.
- **Notlösung eingebaut:** Klappt die Abfrage nicht (Pi ohne Internet, DWD gestört) oder fehlt das aktuelle Bild, wird automatisch das einfache Niederschlagsradar ohne Zeitangabe geladen – so wie bis Version 5.186.

### Neu in 5.187 – Radar mit 2-Stunden-Vorhersage, Reiter in Berichtswesen und Datenbanken

- **Radar auf der Lagekarte** (Ebenen → Niederschlagsradar): jetzt das 1-km-Radarkomposit des DWD **mit Vorhersage für die nächsten 2 Stunden**. Unten links ein **Zeitschieber von −1 h bis +2 h** (rote Marke = jetzt); Vorhersagebilder sind gelb als „Prognose +… min“ gekennzeichnet. **▶** spielt den ganzen Zeitraum ab, **jetzt** springt zurück. **Legende** klappt die Farbskala des DWD auf. Das Bild wird auf Tablets/Handys in doppelter Auflösung geladen (schärfer). Ist die neue Ebene nicht erreichbar, wird automatisch das bisherige Niederschlagsradar (nur gemessen, letzte Stunde) gezeigt. Braucht weiterhin Internet am Gerät; Prognose ohne Gewähr.
- **Reiter wie in ASÜ und Einsatzverwaltung:** Berichtswesen, Gerätedatenbank und Atemschutz-Datenbank zeigen ihre Bereiche am PC als unterstrichene Reiter oben, am Handy/Tablet als Leiste unten mit Symbol und Kurzname (z. B. Geräte · Kalender · Lager · Funk · Übersicht). Das Menü „☰ Bereich ▾“ entfällt dort. In der Gerätedatenbank stehen „+ Gerät · Scannen · Prüfen · Mehr“ am Handy jetzt als Zeile über der Geräteliste.

### Neu in 5.186 – Eigene Dialoge, Rückgängig, feste Statusleiste, Aufräumen

- **Eigene Dialoge statt Browser-Fenster:** Alle Rückfragen und Eingaben (z. B. „Ablehnen“, „Bestellt“, „Ausgegeben an …“, „Trupp löschen?“) erscheinen jetzt in allen Apps als eigenes Fenster im App-Design mit großen Knöpfen. Wo sinnvoll mit **Vorschlägen zum Antippen** – z. B. Ablehnungsgründe oder die Ortswehren bei „Ausgegeben an“. Pflichtfelder melden sich, wenn sie leer bleiben. Esc oder „Abbrechen“ schließt.
- **↶ Rückgängig** (8 Sekunden) jetzt auch in den Apps:
  - **Fahrzeug-App:** nach „Im Einsatz“/„Verfügbar“ (nicht, wenn dabei ein Auftrag übernommen oder erledigt wurde) und nach „Stärke melden“.
  - **ASÜ:** nach jedem erfassten Zeitpunkt (Beginn, Abfrage, Rückzug, Ende).
  - **Gerätedatenbank:** nach Geräteaktionen (Prüfung, Mangel, Reparatur, Umsetzen, Ausleihe …) – bis 2 Minuten, solange das Gerät nicht weiter geändert wurde.
- **Fahrzeug-App – feste Leiste:** Sobald die großen Knöpfe „Im Einsatz / Verfügbar“ aus dem Bild gescrollt sind, erscheinen sie als schmale Leiste über der unteren Reiterleiste.
- **Kopfzeile mit Wappen** auch in der Fahrzeug-App (wie in allen anderen Apps).
- **Suchfelder einheitlich:** überall mit Lupe, gleich hoch, oben über der Liste; im Berichtswesen steht die Suche jetzt direkt neben „Bereich“.
- **Leere Seiten erklärt:** z. B. Berichtswesen ohne Treffer („Zeitraum erweitern, Filter entfernen …“), Besatzung ohne Rückmeldung.
- **Aufgeräumt:** Die alte Designvorschau („Aa“, „Signal Klar“, Aufbau „Leitstand“, Alt+D) ist entfernt – das einheitliche Aussehen ist Standard.

### Neu in 5.185 – Durchgängiges Design und bessere Lesbarkeit

- **Symbole auch in der Einsatzverwaltung:** Einsatz-Reiter, Knöpfe und Überschriften zeigen jetzt dieselben einfarbigen Symbole wie die Apps (vorher gemischt bunt/grau).
- **Knopf „Aa“ ausgeblendet:** Die alte Designvorschau-Schaltfläche unten links verdeckte in allen Apps den ersten Reiter der unteren Leiste („Einsatz“, „Gerät“, „Überw.“). Sie ist jetzt standardmäßig aus; bei Bedarf mit **Alt+D** oder `?design=klar` in der Adresse wieder einblenden.
- **Kontrast:** Nebentexte und nicht gewählte Reiter sind dunkler (erfüllen jetzt WCAG AA, auch draußen bei Sonne besser lesbar); gelbe Hinweise („1 Prüfung fällig“) mit dunklerer Schrift.
- **Mindestschrift 12 px:** Reiterbeschriftungen der ASÜ am Handy, Kennzahlen im Berichtswesen und Tabellenköpfe sind nicht mehr kleiner als 12 px.
- Gerätewart-Menü der Fahrzeug-App, „Heute zu tun“ und Meldungen der Gerätedatenbank mit einheitlichen Symbolen.

### Neu in 5.184 – Einheitliches, übersichtlicheres Erscheinungsbild aller Apps

- **Gemeinsames Stilblatt:** Fahrzeug-App, ASÜ, Gerätedatenbank, Berichtswesen, Träger-App, Sammel-Seite, Monitor und Übungsleitstelle verwenden jetzt dieselben Knöpfe, Karten, Eingabefelder, Überschriften und Abstände wie die Einsatzverwaltung.
- **Eigene Symbole statt Emoji:** In Reiterleisten, Überschriften und Knöpfen werden die bunten Emoji automatisch durch einheitliche, einfarbige Symbole ersetzt – auf allen Geräten gleich und auch im Dunkel-/Nachtmodus gut lesbar.
- **Berichtswesen:** Oben nur noch die Hauptreiter **Berichte · Karte · Jahresbericht · Anforderungen**; Fristen, Monatsbericht, Benachrichtigungen, Verwaltung, Hilfe und Abmelden stehen unter **⋯ Mehr**. Der Datenschutz-Hinweis („Namen ausgeblendet“) lässt sich mit **Verstanden** wegklicken (bleibt als kleine Zeile mit ⓘ zum Wiederanzeigen).
- **Gerätedatenbank – Startseite:** „Heute zu tun“ als Kacheln mit großer Zahl (Prüfungen fällig, nicht einsatzbereit, Haltbarkeit, Meldungen) – rot/gelb hinterlegt, antippen filtert die Liste.
- **ASÜ – Truppübersicht (Tablet):** Status und „ST“ überlappen nicht mehr, Zeiten größer; bald fällige Abfragen gelb, überfällige rot blinkend hinterlegt.
- **Einsatzverwaltung am Handy:** Kopfzeile kompakter (rund ein Viertel weniger Höhe), Erinnerungen (Lagemeldung fällig …) als je eine schmale Zeile.

### Neu in 5.183 – Anforderungen aus Vorjahren erneut stellen

- **📂 Aus Vorjahren übernehmen** (Berichtswesen → Anforderungen, neben „Anfordern“): Liste aller Anforderungen aus früheren Haushaltsjahren sowie abgelehnter/zurückgezogener – mit Suche. Antippen füllt das Formular (Ortswehr, Was, Kosten, Link, Begründung) vor und setzt das Haushaltsjahr auf das aktuelle Jahr; alles lässt sich noch ändern, dann **Anfordern**.
- **🔁 Erneut anfordern** steht auch direkt an jeder abgelehnten, zurückgezogenen oder älteren Anforderung in der Liste.
- **Schon angefordert in …:** Jede Anforderung zeigt, in welchen Jahren sie schon einmal gestellt wurde, mit Nummer und Ausgang (z. B. „2024 (Nr. 7, abgelehnt) · 2025 (Nr. 19, zurückgezogen)“). Erkannt wird das über den Verweis beim Übernehmen und über gleichlautenden Text derselben Ortswehr. In der Tabelle gibt es dafür die Spalte **Schon gestellt**; im Verlauf steht „Erneut angefordert (vorher Nr. …)“.

### Neu in 5.182.1 – Berichtswesen: Monats- und Jahresbericht übersichtlicher

- Die Inhalte-Auswahl im **Monatsbericht** und **Jahresbericht** ist neu aufgebaut: Jede Option ist eine eigene Zeile mit Kästchen, Symbol und Text (gewählte Zeilen sind rot hinterlegt), gruppiert nach **Einsätze**, **Atemschutz** und **Fahrzeuge, Geräte …**. Am Handy eine Spalte, am Tablet/PC zwei bis drei.
- „alle / keine“ steht jetzt direkt neben der Überschrift „Inhalte“ – auch im Monatsbericht. Die Ortswehren des Monatsberichts sind in derselben Darstellung.

### Neu in 5.182 – Einsatz-Uhren: kein Notstrom-Timer bei ÖEL, Lagemeldung frei verschieben

- **Notstromaggregat:** Bei Einsätzen, die die **ÖEL** führt (Führungsstelle „ÖEL“ bzw. Großschadenslage), läuft der automatische Timer „Notstromaggregat nachtanken“ nicht mehr mit. Wird die Führungsstelle auf ELW gestellt, ist er wieder da. Von Hand angelegte Aggregate („+ Aggregat“) bleiben unberührt.
- **Lagemeldung später erinnern:** Neben „+10 min“ gibt es jetzt **⏰ später …** – im Banner oben und im Block „Einsatz-Uhren“. Es öffnet sich eine Auswahl (5 min bis 2 h) oder man gibt die Minuten selbst ein (1–720). Die Verschiebung steht wie bisher im Einsatztagebuch. Auch bei eigenen Timern gibt es den Knopf.

### Neu in 5.181.2 – Prüflauf: Darstellung auf Handy und Tablet

Alle Reiter, Unterbereiche und Apps wurden in Desktop-, Tablet- und Handybreite durchgeprüft (Skript-Fehler, Serverfehler, Überlauf). Keine Programmfehler gefunden; behoben wurden Darstellungsfehler auf schmalen Bildschirmen:

- **Aufträge (Handy):** Der Hinweistext oben wurde neben den Knöpfen zu einer schmalen Spalte gequetscht – bricht jetzt in eine eigene Zeile um.
- **Neuer Einsatz / Neuer Auftrag (Handy):** Das Adressfeld war neben „Suchen“ und „🗺 Auf Karte suchen“ nur wenige Zeichen breit – die Knöpfe rutschen jetzt unter das Feld.
- **Ansprechpartner (Handy):** „+ Ansprechpartner anlegen“ ragte rechts aus dem Bild.
- **Änderungsprotokoll, Einsatzbericht-Tabellen (Handy/Tablet):** breite Tabellen lassen sich jetzt seitlich schieben statt die Seite zu verbreitern.
- **ASÜ und Gerätedatenbank – Anmeldung (Handy):** Der Anmeldekasten war breiter als der Bildschirm (Überschrift).
- **Gerätedatenbank (Handy):** Fahrzeug-/Zustandsfilter konnten über den Rand hinauslaufen; in der Druckvorschau („Diesen Monat fällig“, Prüfprotokoll) überlagerte der Drucken-Knopf den Kopf.
- **Einstellungen (Handy):** Link „Erweiterte Einstellungen“ wird bei Platzmangel gekürzt.

### Neu in 5.181.1 – Darstellungs-Knopf entfernt

- Der schwebende runde Knopf **◐** (Hell / Dunkel / Nacht) unten links ist aus allen Apps entfernt: Fahrzeug-App, ASÜ, Gerätedatenbank, Träger-App, Berichtswesen, Sammel-Seite, Monitor und Übungsleitstelle. Eine einmal gewählte Darstellung bleibt auf dem Gerät erhalten; in der Einsatzverwaltung selbst gibt es den Wechsel weiterhin oben im Kopf.
- Falls der Knopf auf einem Handy noch zu sehen ist: App einmal ganz schließen und neu öffnen (lädt die neue Version).

### Neu in 5.181 – Vorgegebene Stärke je Fahrzeug

- **Verwaltung → Fahrzeuge → Fahrzeug bearbeiten:** neues Feld **Vorgegebene Stärke (Soll-Besatzung)** mit Führer, Mannschaft und Atemschutzgeräteträgern. Vorlagen (z. B. „LF 20 1/8“, „TSF 1/5“) füllen die Felder mit einem Tipp; leer lassen = keine Vorgabe.
- **Stärkemeldung:** Beim Fahrzeug steht die Vorgabe als „Soll“; der Knopf **Vorgabe übernehmen** trägt sie in die Felder ein, danach nur noch Abweichungen korrigieren und **Stärke melden**. In der Stärke-Übersicht des Einsatzes steht das Soll unter dem Fahrzeug.

### Neu in 5.180.1 – Aufträge in der Auftragsansicht per Drag & Drop

- In der Auftragsansicht (Einsatz → Aufträge) lässt sich jede Auftragskarte mit der Maus in eine andere Spalte ziehen (Einsatzleitung/Admin). Der Status wird sofort geändert und im Auftragstagebuch vermerkt; der Hinweis unten bietet **↶ Rückgängig**.
- **Neu**, **Disponiert**, **In Arbeit** setzen den jeweiligen Status; auf **Erledigt / storniert** ziehen schließt den Auftrag ab (Fahrzeuge werden frei). **In Dispo** öffnet die Disposition des Auftrags.
- Fahrzeuge werden wie bisher auf einen Auftrag oder in den Bereitstellungsraum gezogen. Auf der Lagekarte bleiben Auftragssymbole fest.

### Neu in 5.180 – Einsatzstelle auf der Karte suchen

- **🗺 Auf Karte suchen:** Beim Anlegen oder Bearbeiten eines **Einsatzes** und eines **Auftrags** steht neben „Suchen“ der Knopf **🗺 Auf Karte suchen**. Es öffnet sich eine Karte; eine schon eingetragene Adresse wird gleich gesucht. Treffer oder angetippte Stelle mit **Übernehmen** bestätigen – Koordinate und (falls leer) Adresse werden eingetragen.

### Neu in 5.179 – Gefahrstoffdatenbank drucken

- In der **Gefahrstoffdatenbank** steht oben rechts – auf Höhe der Überschrift – **🖨 Drucken**: Es druckt das gerade angezeigte Datenblatt (Stoff mit Warntafel, Gefahren, Maßnahmen und Absperrabständen) bzw. die allgemeinen Hinweise – ohne Knöpfe, auf weißem Papier, mit Datum.

### Neu in 5.178 – Auftragstagebuch mit Fahrzeug-Vorauswahl

- Im **Auftragstagebuch** (Auftrag öffnen) stehen über dem Eintrag jetzt **alle Fahrzeuge, die gerade an diesem Auftrag arbeiten**, als Schnellwahl: Funkrufname antippen = **Von** (An wird die Führungsstelle), „an“ antippen = **An**. Auch in der Vorschlagsliste der Felder stehen diese Fahrzeuge zuerst.

### Neu in 5.177.1 – Auftragskarten aufgeräumt

- Bei einer **Priolage** zeigt die Auftragskarte oben nur noch **⚡ PRIOLAGE** – die Priorität („Sofort“) steht dann nicht zusätzlich da.
- Das Schild **„vor Ort“** auf den Karten entfällt – die Spalte „In Arbeit · vor Ort“ sagt das schon.

### Neu in 5.177 – Aufträge: Adresse statt Beschreibung

- In **Einsatz → Aufträge** steht auf jeder Auftragskarte unter der Kopfzeile jetzt die **Adresse** (📍, ohne Adresse die Koordinate). Die Kopfzeile zeigt nur noch Nummer, Priorität und Kategorie. Die Beschreibung erscheint beim Darüberfahren mit der Maus und wie bisher im geöffneten Auftrag.

### Neu in 5.176 – Lagekarte im Vollbild: volle Höhe

- Im **Vollbild der Lagekarte** ist alles oberhalb der Karte ausgeblendet (Zurück, Titel, Lagekarte/Einsatztaktik, Suchzeile) – die Karte nutzt die **ganze Bildschirmhöhe**, links bleiben die Werkzeuge.
- Oben über der Karte schwebt eine kleine Leiste: **🔍 Suche** (blendet die Suchzeile mit Rückgängig/Wiederholen ein und aus), **Lagekarte / Einsatztaktik** und **✕ Vollbild** (oder Esc).

### Neu in 5.175 – Aufträge kompakt

- **Einsatz → Aufträge** zeigt die Aufträge jetzt **kompakt** (Vorgabe): kleinere Schrift, Kopfzeile und Beschreibung je **eine Zeile** (ganzer Text beim Darüberfahren bzw. im Auftrag), kleinere Fahrzeug-Knöpfe. Jede Spalte (Neu, In Dispo, Disponiert, In Arbeit, Bereitstellungsraum) scrollt für sich, die Überschrift bleibt stehen – so passen deutlich mehr Aufträge auf den Bildschirm.
- Mit **☰ Ausführlich** / **▤ Kompakt** oben rechts lässt sich umschalten; jedes Gerät merkt sich die Wahl.

### Neu in 5.174 – Fenster im Vollbild der Lagekarte

- Im **Vollbild der Lagekarte** (und anderer Bereiche) erscheinen Fenster, Rückfragen („Wirklich löschen?“), PIN-Abfrage und Meldungen jetzt **im Vollbild** – vorher lagen sie unsichtbar dahinter, sodass sich z. B. Zeichen nicht löschen ließen. Nach dem Verlassen des Vollbilds ist alles wie gewohnt.

### Neu in 5.173 – Fahrzeug-App ohne Darstellungs-Knopf

- Der schwebende runde Knopf **◐ (Hell/Dunkel/Nacht)** unten links ist aus der **Fahrzeug-App** entfernt – er lag über den Bedienelementen (z. B. „Stärke melden“). Die App folgt der Einstellung des Handys (hell/dunkel); eine früher gewählte Darstellung bleibt erhalten.

### Neu in 5.172 – Fahrzeug-App ohne Textvorschläge

- In der **Fahrzeug-App** sind die Textvorschläge entfernt: Unter „Nachricht senden“ gibt es keine Schnelltext-Knöpfe mehr („Lage erkundet“, „Wasserversorgung steht“ …), und die Eingabefelder für Nachricht, Lagemeldung, Schadensmeldung und Meldung bei Sonderlage zeigen keine Beispieltexte mehr, sondern nur noch einen neutralen Hinweis.

### Neu in 5.171 – E-Mail „Gesendet“ nur aus der Einsatzverwaltung

- Reiter **E-Mail → Gesendet** zeigt jetzt nur noch E-Mails **aus der Einsatzverwaltung**: Einsatzberichte (auch automatisch nach Einsatzende), Lagemeldungen und alles, was ein Benutzer der Einsatzverwaltung selbst verschickt hat.
- **Automatische Systemmails** (Systemmeldungen, Selbsttest, Erinnerungen, Schadensmeldungen, Wochen-/Monatslisten, Feedback, Benachrichtigungen aus Berichtswesen und Datenbanken, Tests) sind ausgeblendet. Mit dem Häkchen **„auch automatische Systemmails anzeigen (n)“** lassen sie sich bei Bedarf einblenden; die Einstellung merkt sich das Gerät.

### Neu in 5.170.1 – Kurzanleitungen für alle Apps

- Im Ordner `docs` gibt es jetzt für **jede App** eine Kurzanleitung: Einsatzverwaltung, Fahrzeug-App (bisher „Fahrzeugbesatzung“, jetzt mit Einsatz, Nachrichten, Karte, Fahrtenbuch, Hydranten und Benachrichtigungen für Orts-/Gemeindebrandmeister), Atemschutzüberwachung (ASÜ), Alarmmonitor, Gerätedatenbank, Atemschutz-Datenbank, Mein Atemschutz und Berichtswesen – dazu ein Sammel-PDF „Kurzanleitungen für alle Apps“.

### Neu in 5.170 – Speicherbelegung

- **Verwaltung → Zustand des Pi → 💽 Speicherbelegung** (nur Admin) zeigt, wofür wie viel Platz gebraucht wird:
  - **SD-Karte:** belegt, frei und wie viel davon die Einsatzverwaltung braucht (Rest = Betriebssystem und andere Programme).
  - **Ordner der Einsatzverwaltung** mit Größe, Anteil und Anzahl Dateien: Sicherungen, Programm-Bibliotheken, Programm, Datenbestand, Kartenkacheln, Geländehöhen, Objekt-Pläne, Fotos (Hydranten, Schäden, Berichte, Nachrichten), Schulungsunterlagen, E-Mail-Anhänge, Änderungsprotokoll, alte Datenstände.
  - **Datenbestand nach Bereichen:** Einsatzarchiv, laufende Einsätze, Übungen, Fahrzeuge, Atemschutz, Gerätedatenbank, Berichtswesen, E-Mail, Benutzer/Anmeldungen, Objekte, Einstellungen – dazu die 15 größten Einträge.
  - Tipps, wie man Platz schafft (Löschfristen, Aufbewahrung der Sicherungen, alte Datenstände).
- Die Berechnung wird 10 Minuten zwischengespeichert; „↻ Neu berechnen“ holt sofort den aktuellen Stand.

### Neu in 5.169 – Benachrichtigungen selbst einstellen, Haushaltsjahr, Lager-Protokoll

- **🔔 Benachrichtigungen im Berichtswesen:** Ortsbrandmeister und Gemeindebrandmeister stellen **selbst** ein, worüber sie informiert werden – je Art per **E-Mail** und/oder über **ihren Eintrag in der Fahrzeug-App**:
  - *Gemeindebrandmeister:* neue Anforderung einer Ortswehr · Erinnerung an lange wartende Anforderungen · Lager Gemeinde unter Mindestbestand.
  - *Ortsbrandmeister:* eigene Anforderungen freigegeben / abgelehnt / eingetroffen / ausgegeben · Einsatzberichte der eigenen Ortswehr (Mail).
  - Darunter: was die eigene Fahrzeug-App sonst meldet (Nachrichten, Aufträge, Alarm/Einsatz, Termine, Fahrtenbuch, Anforderungen, Lager) – gilt für alle Handys dieses Eintrags.
  - „Test senden“ prüft Mail und Fahrzeug-App. Ortsbrandmeister können ihre E-Mail-Adresse dort selbst eintragen.
- **Fahrzeug-App-Eintrag zuweisen:** Der Admin weist jedem Orts-/Gemeindebrandmeister seinen Eintrag zu (z. B. „OrtsBM“, „GemBM“): beim Gemeindebrandmeister in der Einsatzverwaltung (Verwaltung → Benutzer, Häkchen Gemeindebrandmeister), beim Ortsbrandmeister im Berichtswesen (⚙ Verwaltung → Zugang). Auf dem Handy die Fahrzeug-App dieses Eintrags öffnen und Benachrichtigungen einschalten.
- **E-Mail des Gemeindebrandmeisters** wird in der Einsatzverwaltung beim Benutzer eingetragen und gilt in allen Apps.
- **Erinnerung an wartende Anforderungen:** einmal pro Woche eine Sammel-Mail bzw. -Nachricht an den Gemeindebrandmeister, wenn Anforderungen länger als **x Tage** auf „Wartend“ stehen – die Frist (1–365 Tage, Vorgabe 30) stellt er selbst ein.
- **Haushaltsjahr** bei Anforderungen (Anlegen und Ändern), Filter „Haushaltsjahr“ (auch „ohne Jahr“), Spalte in Tabelle, Druck und Excel.
- **Lager: Bewegungsprotokoll** – je Artikel jede Entnahme, Einbuchung, Korrektur und Änderung mit Zeit, Menge, Bestand und Name (Material → Bearbeiten → 📜 Bewegungen). Ortswehren sehen im Lager Gemeinde kein Protokoll.
- **Kurzanleitungen** für Gerätewart, Atemschutzgerätewart, Geräteträger und **neu für das Berichtswesen** auf Stand 5.169.

### Neu in 5.168 – Anforderungen, Gemeindelager, Datenschutz, Fahrzeuge

- **Anforderung ändern:** Mit **✎ Ändern** lassen sich Was, Menge, ca. Kosten, Link und Begründung nachträglich anpassen – vom Anfordernden oder vom Gemeindebrandmeister, solange noch nicht bestellt wurde. Jede Änderung steht im Verlauf.
- **Mail bei Bewertung:** Der Ortsbrandmeister der anfordernden Ortswehr bekommt jetzt auch eine E-Mail, wenn der Gemeindebrandmeister eine Anforderung **ablehnt** (mit Begründung) oder **zur Anschaffung freigibt** – zusätzlich zu „Eingetroffen“.
- **Drucken und Excel:** Über der Liste stehen **🖨 Drucken** (A4 quer, mit Summe) und **⬇ Excel (CSV)** – jeweils für die aktuelle Auswahl (Filter, Ortswehr, Suche). Neue Spalte „Menge“ in der Tabelle.
- **Lager Gemeinde – Mindestbestand:** Fällt ein Artikel im Lager Gemeinde unter den Mindestbestand, bekommen Gemeindebrandmeister und Gemeindegerätewart (Zugänge für alle Ortswehren mit E-Mail-Adresse) eine Mail. Ist keine Adresse hinterlegt, sagt das Programm das sofort.
- **Lager Gemeinde – Anfordern:** Ortswehren sehen bei öffentlichen Artikeln den Knopf **📝 Anfordern** (Menge und Begründung). Daraus wird direkt eine Anforderung im Berichtswesen („… (aus Lager Gemeinde)“), die der Gemeindebrandmeister wie gewohnt bewertet.
- **Anonyme Kennung besser zugeordnet:** Einsatznachweise aus der ASÜ werden der richtigen Person zugeordnet – über die Personen-ID, sonst über Nach- und Vorname (auch vertauscht, unabhängig von Umlauten und Leerzeichen, gleiche Ortswehr bevorzugt). Dadurch hat dieselbe Person beim Gemeindebrandmeister überall dieselbe Kennung „Person n“.
- **Kein leeres Komma, sichtbarer Hinweis:** Anonyme Personen erscheinen ohne „, “ dahinter. Gemeindebrandmeister sehen in Berichtswesen und Atemschutz-Datenbank oben den Hinweis **„🔒 Namen ausgeblendet (Datenschutz)“**.
- **Fahrzeug oder Funktion überall gleich:** Die Unterscheidung aus dem Filter „Fahrzeuge“ (ohne Fahrzeugtyp = Funktion; OrtsBM, Fachberater, Feuerwehrhaus usw. = Funktion; „KdoW StBM“ = Fahrzeug) gilt jetzt auch bei der automatischen Alarmierung der Fahrzeuge einer Ortswehr, bei „Alarmierte Kräfte“ aus der Alarm-Mail, im Berichtswesen (Fahrzeuge, Ausrüstung), im Jahresbericht und in der Übersicht der Gerätedatenbank.
- **Bedienungsanleitung (PDF)** neu erstellt – mit allen Neuerungen bis 5.168.

### Neu in 5.167 – Namen: Ortsbrandmeister ja, Gemeindebrandmeister nein

- **Ortsbrandmeister** (und Atemschutzgerätewarte, Admins) sehen im Berichtswesen wieder die **Namen** ihrer Personen.
- Der **Gemeindebrandmeister** (zentraler GBM-Zugang) sieht im **Berichtswesen** und in der **Atemschutz-Datenbank** keine Namen: statt dessen eine feste Kennung „Person 17“. Auch Kontaktdaten (E-Mail, Telefon, Geburtsdatum, Personalnummer, Bemerkung) und Prüfer-/Trägernamen werden für ihn ausgeblendet.
- In der Atemschutz-Datenbank kann der Gemeindebrandmeister **nur ansehen**: Personen, Nachweise, Pflege, Inbetriebnahmen und Geräte ändern sowie die Excel- und FeuerON-Listen mit Namen herunterladen geht für ihn nicht („Datenschutz“).
- Die Anonymisierung macht der Server – die Namen kommen beim Gemeindebrandmeister gar nicht an.

### Neu in 5.166 – Berichtswesen ohne Namen

- Im **Berichtswesen** erscheinen **keine Namen von Personen** mehr – weder in Tabellen, Auswertungen, Jahresbericht, Karte, Excel-/CSV-Export noch in Berichten per Mail.
- Betroffen sind **Atemschutzgeräteträger** (Geräteträger-Liste, Einsätze/Übungen unter PA, ablaufende Nachweise): Statt des Namens steht eine feste Kennung **„Person 17“**. Sie bleibt je Person gleich, sodass Auswertungen je Person (Anzahl, Minuten) weiter funktionieren. Die Spalte heißt „Person (anonym)“.
- Bei den **Inbetriebnahmen** entfällt die Spalte „Prüfer“.
- Die Auswahl „Namen im Bericht“ im Jahresbericht entfällt – anonym ist jetzt immer so.
- Die Anonymisierung macht der Server; die Namen verlassen den Pi für das Berichtswesen nicht. In der Atemschutz-Datenbank selbst bleiben die Namen für die Atemschutzgerätewarte sichtbar.

### Neu in 5.165 – Anforderung eingetroffen: Mail an den Ortsbrandmeister

- Neuer Schritt bei Anforderungen: **📬 Eingetroffen** (zwischen „Bestellt“ und „Ausgegeben“, nur Gemeindebrandmeister). Optional lässt sich ein Hinweis mitgeben, z. B. „liegt im Gerätehaus Aerzen zur Abholung“.
- Dabei bekommt der **Ortsbrandmeister der anfordernden Ortswehr eine E-Mail** (Nr., was, angefordert von/am, eingetroffen am, Hinweis, Link). Empfänger sind die Ortsbrandmeister-Zugänge des Berichtswesens mit hinterlegter E-Mail-Adresse – wie bei den Einsatzberichten.
- Ist kein Ortsbrandmeister mit E-Mail eingetragen oder der Mailversand nicht eingerichtet, sagt das Programm das sofort; der Schritt wird trotzdem vermerkt. Im Verlauf steht, an wen die Mail ging (oder warum nicht).
- Neuer Status **„Eingetroffen“** (Badge), neue Spalte **„Eingetroffen am“** in der Tabelle; der Filter „Bestellt“ zeigt auch eingetroffene, noch nicht ausgegebene Anforderungen.

### Neu in 5.164 – Lager „Gemeinde“ in der Gerätedatenbank

- In der Gerätedatenbank → **Lager** gibt es in der Auswahl oben das **🏛 Lager Gemeinde**.
- **Pflegen** (Material anlegen, bearbeiten, löschen, entnehmen, einbuchen) dürfen nur **Gemeindebrandmeister** und **Gemeindegerätewart** – also Zugänge für *alle Ortswehren* – sowie der Superadmin.
- Beim Material im Lager Gemeinde gibt es das Häkchen **🌐 Öffentlicher Artikel**. Öffentliche Artikel sehen **alle Ortswehren** mit Bestand, Mindestbestand und Lagerplatz – **nur lesend**, ohne − / + und ohne Bearbeiten. Nicht öffentliche Artikel sehen nur die Gemeinde-Zugänge.
- Der Server prüft das auch: Ein Ortswehr-Zugang kann im Lager Gemeinde nichts buchen oder ändern.

### Neu in 5.163 – Fahrzeug-Filter auch in Kräfte & Mittel

- Der Filter **„Fahrzeuge“ in Kräfte & Mittel** (Leiste über der Liste) blendet jetzt ebenfalls alle Funktionen aus: Einträge **ohne Fahrzeugtyp** gelten als Funktion, ebenso OrtsBM, Fachberater, Feuerwehrhaus usw. (wie der Schnellfilter oben seit 5.161).

### Neu in 5.162 – Link bei Anforderungen

- **Berichtswesen → 📝 Anforderungen:** Beim Anfordern lässt sich optional ein **Link** angeben (z. B. Produktseite oder Angebot). „www.…“ wird automatisch zu „https://www.…“ ergänzt; nur echte Internet-Adressen (http/https) werden angenommen.
- Der Link erscheint in der Karte und in der Tabelle des Gemeindebrandmeisters (neue, ausblendbare Spalte „Link“) als „🔗 seite.de“ und öffnet sich in einem neuen Fenster.

### Neu in 5.161 – Filter „Fahrzeuge“ ohne Funktionen

- **Kräfte & Mittel → Filter „Fahrzeuge“** zeigt jetzt nur noch echte Fahrzeuge. Funktionen wie OrtsBM, GemBM, StBM, KBM, BAL, Fachberater, Pressewart, Zugführer, Leiter, Beauftragte sowie Feuerwehrhäuser werden ausgeblendet (vorher nur Einträge mit Personennamen). Kommandowagen wie „KdoW StBM“ bleiben als Fahrzeug sichtbar.

### Neu in 5.160 – Ortsfeuerwehr Königsförde/Selxen

- **Königsförde und Selxen sind jetzt eine Ortsfeuerwehr „Königsförde/Selxen“** – in allen Apps: Fahrzeuge, Feuerwehrhäuser, Kräfte & Mittel, Alarmierung, PowerAlarm-Gruppen, Atemschutz- und Gerätedatenbank, Berichtswesen, Anforderungen, Zugänge und Auswertungen. Auch der ASÜ-Zugang heißt jetzt „Ortsfeuerwehr Königsförde/Selxen“.
- Die beiden **Feuerwehrhäuser bleiben getrennt** (Feuerwehrhaus Königsförde, Feuerwehrhaus Selxen) – Anfahrt und Karte rechnen weiter mit beiden Standorten.
- Die Umstellung läuft nach dem Update **automatisch** und stündlich nach (z. B. wenn eine ältere Fahrzeugliste eingespielt wird). Einsatzorte, Adressen und Tagebuchtexte werden nicht verändert. Der Lauf steht im Änderungsprotokoll.
- PowerAlarm-Gruppen, deren Name mit „Königsförde“ oder „Selxen“ beginnt, werden der neuen Ortsfeuerwehr zugeordnet.

### Neu in 5.159 – Einstellungen: Zustand, Tests, Assistent

- **Statuspunkt je Bereich:** In der Bereichsliste der Einstellungen zeigt ein Punkt, ob dort alles eingerichtet ist (grün), etwas Optionales fehlt (gelb) oder etwas Wichtiges fehlt (rot).
- **„Was fehlt noch?“** oben in den Einstellungen: alle offenen Punkte (Sicherungs-Passwort, externe Sicherung, E-Mail, Datenschutzhinweise, Löschfristen, zweiter Admin, Standard-PIN …) mit **„Einstellen →“** – der Klick springt genau zum passenden Block und klappt ihn auf.
- **Zuletzt geändert:** Unter jedem Block steht, wann und von wem er zuletzt geändert wurde.
- **🔌 Verbindung testen** direkt bei PowerAlarm, E-Mail (Test-Mail an das eigene Postfach und Abruf), Wetter/Unwetterwarnungen, Kartendienste/Adresssuche/what3words und Fahrzeug-App von außen. Fehler stehen im Klartext da (z. B. „Adresse nicht gefunden – Internet oder DNS prüfen“).
- **Anbindungen – Zustand** (Sicherung & System): Tabelle aller Verbindungen nach außen mit Zustand, letztem Kontakt und letzter Meldung, „Testen“ je Zeile und „Alle eingerichteten testen“.
- **Nicht gespeichert:** Geänderte, noch nicht gespeicherte Blöcke werden gelb markiert („● nicht gespeichert“); beim Wechsel des Bereichs kommt eine Rückfrage.
- **Erweiterte Einstellungen:** Selten gebrauchte Blöcke (Ports und Zertifikate, Kartendienste, Fahrzeugstatus von außen, automatische Symbole, Ausrüstungsfilter, Export/Import) sind ausgeblendet, bis „Erweiterte Einstellungen zeigen“ angehakt ist. Die Suche und Direktsprünge finden sie trotzdem.
- **Direktsprung aus Hinweisen:** Fehlende wichtige Einstellungen stehen (für Admins) im 🔔 Hinweisfenster mit „Einstellen →“; auch der Sicherheits-Check hat bei jedem offenen Punkt einen Sprungknopf.
- **🧭 Einrichtungs-Assistent** (links unter der Bereichsliste): führt Schritt für Schritt durch Heimatort, zweiten Admin, eigene PINs, E-Mail, Alarm-Mails, PowerAlarm, Fahrzeug-App, Sicherungs-Passwort, externe Sicherung, Datenschutzhinweise, Löschfristen und Ansprechpartner. „Jetzt einstellen“ springt zur Stelle; unten rechts führt „Zurück zum Assistenten“ wieder hinein.
- **Einstellungen sichern und übertragen** (erweitert, Sicherung & System): Export als Datei – **ohne** Kennwörter und Schlüssel – und Einspielen auf einem anderen Pi (wahlweise allgemeine Einstellungen und/oder Werte der Anbindungen). Beides mit PIN und im Protokoll.
- **🚪 Mitglied ausgeschieden** (Verwaltung → Benutzer): entfernt den Zugang, meldet alle Geräte ab, sperrt gleichnamige bzw. verknüpfte Zugänge in Geräte-/Atemschutz-Datenbank und Berichtswesen und nennt, was noch zu tun ist (Ausscheidedatum in der Atemschutz-Datenbank, Schlüssel und Melder zurückfordern).

### Neu in 5.158 – Verwaltung aufgeräumt

- **Verwaltung neu gruppiert:** 🚒 Fahrzeuge & Orte (Fahrzeuge, Feuerwehrhäuser, Hydranten) · 👥 Benutzer & Zugänge (Benutzer, Apps & Zugänge, Fahrzeug-Geräte, Sicherheit) · 📋 Berichte & Nachweise (Berichte & Notfall, Exposition, Protokoll) · 🖥 Alarmmonitor · ⚙️ Einstellungen & System. Unter den Reitern steht jeweils **ein Satz, wofür der Bereich da ist**.
- **Schnittstellen beim Thema:** Der Bereich „Schnittstellen & Schlüssel“ entfällt. PowerAlarm-Key steht bei der PowerAlarm-Anbindung, E-Mail-Zugangsdaten beim E-Mail-Block, Wetter beim Wetter, Hydrantenprüfung bei den Wasserentnahmestellen, Karten als „Kartendienste und Adresssuche“, ASÜ unter „Fahrzeug-App & ASÜ“, Datenschutz im neuen Bereich 🔒 Datenschutz, Betrieb sowie Ports und Zertifikate unter Sicherung & System. Jeder Abschnitt hat seinen eigenen „Speichern“-Knopf.
- **Zuklappen:** Jeder Einstellungs-Block klappt per Klick auf die Überschrift auf und zu; zugeklappt bleibt die Kurzbeschreibung sichtbar. „Alle aufklappen / Alle zuklappen“ oben rechts; die Suche zeigt Treffer immer aufgeklappt.
- **Beschreibungen:** Jeder Bereich hat oben eine Kurzbeschreibung, Blöcke ohne Erklärung haben eine bekommen.

### Neu in 5.157 – Anforderungen als Tabelle für den Gemeindebrandmeister

- **Berichtswesen → 📝 Anforderungen** zeigt dem Gemeindebrandmeister die Anforderungen als **Tabelle – eine Zeile je Anforderung** (Umschalter „☰ Tabelle / ▦ Karten“, wird gemerkt).
- **Filter:** Status (Offen, Bestellt, Ausgegeben, Abgelehnt, Zurückgezogen, Alle), **Ortswehr** und **Suche** (Was, Begründung, Name, Ausgabe an, Hinweise).
- **Spalten ein-/ausblenden:** „⚙ Spalten“ – Nr., Angefordert, Ortswehr, Von, Was, ca. Kosten, Begründung, Status, Bewertet am/von, Begründung/Hinweis GBM, Bestellt am, Bestell-Notiz, Ausgegeben am, Ausgegeben an. Die Auswahl bleibt auf dem Gerät gespeichert.
- **Sortieren** per Klick auf den Spaltenkopf; unter der Tabelle Anzahl und Summe der angezeigten Anforderungen (ca.). Bewerten, Bestellt und Ausgegeben direkt in der Zeile.

### Neu in 5.156 – Anforderungsliste im Berichtswesen

- **Berichtswesen → 📝 Anforderungen:** Ortsbrandmeister stellen Anforderungen mit **Was**, **ca. Kosten (€)** und **Begründung** (Pflicht) für ihre Ortswehr.
- **Sichtbarkeit:** Ortsbrandmeister sehen nur die Anforderungen ihrer Ortswehr(en) – mit Status und Verlauf. Gemeindebrandmeister (und Admin) sehen alle.
- **Bewerten (nur Gemeindebrandmeister):** **Wartend**, **Anschaffen** (optional mit Hinweis, z. B. Haushaltsjahr) oder **Abgelehnt** – Ablehnen nur mit Begründung; die Begründung sieht der Ortsbrandmeister.
- **Weiter bis zur Ausgabe:** bei „Anschaffen“ → **🛒 Bestellt** (optional Notiz, z. B. Lieferant/Bestellnummer) → **📦 Ausgegeben an …** (Ortswehr, Fahrzeug oder Person, Pflicht).
- Jeder Schritt steht mit **Datum, Uhrzeit und Name** in der Ablaufleiste der Anforderung (Angefordert → Bewertet → Bestellt → Ausgegeben) und im Änderungsprotokoll.
- Filter: Offen · Bestellt · Ausgegeben · Abgelehnt · Zurückgezogen · Alle. Der Gemeindebrandmeister sieht die Summe der freigegebenen, noch nicht bestellten Anforderungen (ca.).
- Wer angefordert hat, kann bis zur Bestellung **zurückziehen**.

### Neu in 5.155 – Priorität der Aufträge einheitlich: sofort · dringend · kann warten

- Die Priorität der Aufträge (Sonderlage/Großschadenslage) heißt jetzt **überall gleich**: **Sofort** (rot), **Dringend** (gelb), **Kann warten** (grün) – in Auftragsliste, Disposition, Erkundung, Übersicht, Tagebuch, Benachrichtigungen und in der Fahrzeug-App. Die Bezeichnungen „hoch / mittel / niedrig“ gibt es nicht mehr.

### Neu in 5.154 – Gemeindebrandmeister: Rechte in der Einsatzverwaltung frei wählbar (Vorgabe Betrachter)

- „Gemeindebrandmeister“ ist jetzt ein **Häkchen** im Benutzer-Dialog (Verwaltung → Benutzer) statt einer eigenen Rolle. Es gibt den zentralen Zugang zu Atemschutz-Datenbank, Gerätedatenbank und Berichtswesen (alle Ortswehren, ein Kennwort).
- Die **Rechte in der Einsatzverwaltung** kommen aus der **Rolle** darüber: beim Anlegen mit Häkchen automatisch **Betrachter** (nur Ansicht), je Person änderbar auf Einsatzleitung oder Admin.
- In der Benutzerliste steht bei diesen Benutzern das Schild **GBM**.
- **Umstellung beim Update:** Bisherige Benutzer mit der Rolle „Gemeindebrandmeister“ bekommen das Häkchen und die Rolle **Betrachter**. Wer mehr Rechte braucht, bekommt die Rolle von Hand zurück (z. B. Einsatzleitung).

### Neu in 5.153 – Gemeindebrandmeister zentral: ein Zugang für alles

- **Anlegen nur noch in der Einsatzverwaltung:** Verwaltung → Benutzer → Benutzer mit Rolle **Gemeindebrandmeister** anlegen (oder einem Benutzer die Rolle geben) und eine PIN vergeben.
- Damit gilt **derselbe Benutzername und dasselbe Kennwort** automatisch für Einsatzverwaltung, **Atemschutz-Datenbank, Gerätedatenbank und Berichtswesen** – jeweils für alle Ortswehren der Gemeinde (keine Admin-Rechte in den Datenbanken).
- Nach dem Speichern erscheint **„📄 Zugangsblatt (PDF)“** mit Name, Benutzer, Einmal-Kennwort und **allen Links** (Einsatzverwaltung, Berichtswesen, Atemschutz-Datenbank, Gerätedatenbank – mit QR-Codes) und kurzer Anleitung; „⧉ Kopieren“ für eine Nachricht.
- Die vergebene PIN ist ein **Einmal-Kennwort**: Bei der ersten Anmeldung in der Einsatzverwaltung muss ein eigenes Kennwort festgelegt werden; vorher lassen die Datenbanken keine Anmeldung zu. Danach gilt das eigene Kennwort überall; geändert wird es nur in der Einsatzverwaltung. Andere angemeldete Geräte in den Datenbanken werden dabei abgemeldet.
- Rolle entfernt oder Benutzer gelöscht → der Zugang in den Datenbanken wird sofort gesperrt.
- In den Datenbanken erscheinen diese Zugänge in der Liste, können dort aber nicht geändert werden („wird zentral in der Einsatzverwaltung verwaltet“).
- Die ASÜ-Tablets bleiben bei ihren Feuerwehr-Zugängen (unverändert).

### Neu in 5.152 – Zugangsblatt als PDF für neue Zugänge

- **Gerätedatenbank, Atemschutz-Datenbank und Berichtswesen → Verwaltung → Zugang anlegen** (oder neues Startkennwort vergeben): Nach dem Speichern erscheint statt des kleinen Hinweisfensters eine Übersicht mit Name, Benutzer, Einmal-Kennwort und Link sowie den Knöpfen:
  - **📄 Zugangsblatt (PDF)** – A4-Blatt mit Name, Ortswehr, Benutzer, Einmal-Kennwort, Link (in Gerätedatenbank und Atemschutz-Datenbank zusätzlich als QR-Code) und kurzer Anleitung. Im Druckfenster „Als PDF speichern“ wählen und per Mail verschicken oder ausdrucken.
  - **⧉ Kopieren** – dieselben Angaben als Text, z. B. für eine Nachricht.
- Das Einmal-Kennwort wird nur in diesem Moment angezeigt; bei der ersten Anmeldung muss ein eigenes Kennwort festgelegt werden.

### Neu in 5.151.4 – Alte Standorte verschwinden

- Hat ein Fahrzeug **länger als 24 Stunden** keinen Standort mehr gesendet, wird sein letzter Standort entfernt – von der Lagekarte, aus Entfernungsangaben und aus „Nächste Fahrzeuge“. Sobald die Fahrzeug-App wieder einen Standort schickt, erscheint das Fahrzeug wieder. Geprüft wird alle 15 Minuten.

### Neu in 5.151.3 – Gerätanfrage ablehnen

- Hinweis „…: zweites Gerät bittet um Freigabe“ hat jetzt **„✕ Ablehnen“** (auch im Fahrzeugfenster unter Zugang → Endgerät neben „✓ Auf … wechseln“). Die Fahrzeug-App bleibt auf dem bisherigen Gerät, der Hinweis verschwindet, der Vorgang steht im Änderungsprotokoll. Enthält alle Korrekturen aus 5.151.2.

### Neu in 5.151.2 – Datendatei geschützt (wichtig)

- **Speichern nur noch nacheinander:** Vorher konnten zwei Speichervorgänge gleichzeitig in dieselbe Zwischendatei schreiben. Bei großer Datendatei auf der Speicherkarte entstand so eine vermischte, unlesbare `data.json` (z. B. nach Stromausfall oder Update). Vor Update und Neustart wird jetzt vollständig und ohne Verzögerung gespeichert.
- **Nie mehr leerer Start:** Ist `data.json` beim Start beschädigt oder fast leer, lädt das Programm automatisch die neueste vollständige Sicherung (Kopie vor Update, stündlich, täglich), hebt die defekte Datei als `data.json.defekt-…` auf und meldet es per Mail an die System-Empfänger und im Änderungsprotokoll. Gibt es keine lesbare Sicherung, startet es nicht (statt leer).
- **Sicherungen werden nicht mehr mit einem leeren Stand überschrieben** (stündlich, täglich, USB-Stick, Kopie vor Update). Die Kopie vor einem Update trägt jetzt Datum und Uhrzeit im Namen.

### Neu in 5.151.1 – Zweite Meldung ergänzt den Einsatz vollständig

- Kommt zum selben Einsatz eine zweite Meldung (Leitstellen-Mail nach PowerAlarm oder umgekehrt), wird alles Weitere **ergänzt**, ohne Vorhandenes zu überschreiben:
  - **alarmierte Fahrzeuge** und Kräfte (Status A im selben Einsatz; nicht zuordenbare stehen als Vermerk im Tagebuch, nicht automatisch alarmierte unter „Alarmierte Fahrzeuge übernehmen ✓“),
  - Leitstellen-Nummer, fehlende Adresse und Koordinate, Meldender/Telefon,
  - Objekt, alarmierte Kräfte und Zusatztext als „Ergänzung per …“ in der Notiz,
  - Gefahrstoffe, Bilder und der vollständige Text im Tagebuch.
- Wurde der Einsatz zuerst aus dem kurzen PowerAlarm-Text angelegt, übernimmt er **Stichwort und Meldebild aus der Leitstellen-Mail** (die genauer ist).
- Der PowerAlarm-Text „Alarmierte Kräfte: Reher Groß Alarm B1 …“ wird nicht mehr als Kräfteliste gelesen; die Ortswehren kommen aus der Zuordnung der PowerAlarm-Gruppen.

### Neu in 5.151 – Kein doppelter Einsatz mehr bei Mail und PowerAlarm zum selben Alarm

- Alarm-Mails und PowerAlarm-Alarme werden jetzt **strikt nacheinander** verarbeitet. Vorher konnten zwei Meldungen zum selben Einsatz gleichzeitig laufen (die zweite kam, während für die erste noch die Adresse gesucht wurde) – beide fanden keinen Einsatz und legten je einen an.
- Die **Leitstellen-Nummer** (z. B. HM202654823) wird auch erkannt, wenn sie ohne Feldname im Text steht, wie im PowerAlarm-Alarmtext („… BMA 169 **HM202654823**“). Schreibweisen mit Leerzeichen oder Strichen gelten als gleich.
- Steht die Nummer eines laufenden Einsatzes irgendwo im Text, wird die Meldung diesem Einsatz zugeordnet.
- Zusätzlich (innerhalb von 30 Minuten): gleiches Stichwort und gleicher Straßenname im Text – auch wenn die Adresse in beiden Meldungen unterschiedlich aufgebaut ist.
- Hatte der zuerst angelegte Einsatz kein brauchbares Stichwort, übernimmt er das Stichwort aus der zweiten Meldung.

### Neu in 5.150 – FeuerON: Atemschutz-Nachweise als Import-Datei, Ausfüllhilfe für den Einsatzbericht

- **Atemschutz-Datenbank → 📊 Excel → Personen → „🗂 FeuerON (CSV für den Personen-Import)“:** erzeugt eine CSV-Datei im Format des NLBK-Imports (Drägerware.ZMS/FeuerON):
  - Stammdaten `PV_DB` (Personalnummer, Nachname, Vorname, Geburtsdatum),
  - als Ausbildung `PV_AUSB` (Erfolg = 1): AGT-Lehrgang, Belastungsübung, Unterweisung, CSA-Übung – jeweils mit Datum,
  - als Tauglichkeit `PV_UNTSU`: G 26.3 mit Datum und „gültig bis“ – **nie** ein Befund.
  - Nur Personen mit eingetragener **Personalnummer (FeuerON)**; ausgeschiedene und anonymisierte Personen nie. „Prüfen“ zeigt, wer dabei ist und wem die Nummer fehlt. Zeichensatz Windows (ANSI, Standard) oder UTF-8.
  - In FeuerON: Einstellungen → Im-/Export → CSV-Import, Option „vorhandene Stammdaten erhalten“, zuerst mit einer Person testen. Jeder Export steht im Änderungsprotokoll.
- **Person bearbeiten → „FeuerON-Abgleich (freiwillig)“:** Personalnummer und Geburtsdatum – nur für diesen Export nötig. Beide Felder stehen auch im Excel-Export/-Import der Personen. Bei der Anonymisierung nach Löschfrist werden sie mit gelöscht.
- **Einsatzbericht → „🗂 Für FeuerON“:** Ausfüllhilfe für den Bericht in FeuerON. Die Grunddaten kommen dort per FDS von der Leitstelle („Bericht aus Berichtsdaten anlegen“) – hier stehen sie zum Prüfen, dazu Personal (gesamt, Führung, Mannschaft, Atemschutz, Personenstunden), Fahrzeuge mit Zeiten (Alarm, ausgerückt, an, eingerückt) und Stärke, Atemschutzgeräteträger aus der ASÜ mit Trupp und Dauer, Lagetext und Einsatzverlauf. ⧉ kopiert einen Wert, „Alles als Text kopieren“ den ganzen Block.

### Neu in 5.149 – Einheitliches Aussehen aller Apps

- **Gleiche Farben und Schrift überall:** Träger-App „Mein Atemschutz“, Alarmmonitor und „Atemschutz – Sammeln“ verwenden jetzt dieselben Farben (Feuerwehr-Rot, Grautöne) und dieselbe Schrift (Barlow) wie Einsatzverwaltung, ASÜ, Gerätedatenbank, Berichtswesen und Fahrzeug-App.
- **Gleicher Kopf:** Wappen, App-Name und Untertitel in allen Apps; „Sammeln“ hat keinen roten Balken mehr. Die Übungsleitstelle behält zur Unterscheidung ihr Violett, zeigt aber ebenfalls das Wappen.
- **Gleiche Anmeldeseite:** mittige Karte mit Wappen und App-Name in Gerätedatenbank, Träger-App, Berichtswesen und Übungsleitstelle (wie in Einsatzverwaltung und ASÜ).
- **Hell / Dunkel / Nacht in allen Apps:** Knopf ◐ unten links neben „Aa“ (Fahrzeug-App: über der Fußleiste). Antippen wechselt: wie das Gerät → Hell → Dunkel → Nacht (gedimmtes Rot für die Nacht im Fahrzeug). Gilt je Gerät. Der Alarmmonitor bleibt immer dunkel.
- Gerätedatenbank: Häkchen „Angemeldet bleiben“ steht wieder in einer Zeile mit dem Text.
- Die Designvorschau „Aa“ gibt es jetzt auch in der Übungsleitstelle.

### Neu in 5.148 – Mehr Übersicht: einklappen statt scrollen

- **Übersicht – Blöcke einklappbar:** Überschrift eines Blocks (Einsatz-Uhren, Ansprechpartner, Kräfteanforderungen, Gefahrstoffe …) antippen klappt ihn zu ▸ bzw. auf ▾. Im Einsatzkopf blendet **„▾ Details“** Einsatzort, Einsatzleiter, Meldender und Notiz aus. Der Zustand bleibt auf diesem Gerät gespeichert – auch für die nächsten Einsätze.
- **Tagebuch – Eingabe einklappbar:** „▴ einklappen“ oben rechts im Eingabebereich; dann steht nur noch die Zeile **„✎ Neuer Eintrag ▸“**. Für Betrachter ist die Eingabe von vornherein eingeklappt. Strg+M klappt sie wieder auf.
- **Abschnitte – leere klein:** Knopf **„▸ Leere klein“** zeigt Abschnitte ohne Fahrzeuge nur als schmale Kopfzeile (bleiben Ziel zum Hineinziehen). „▾ Leere normal“ schaltet zurück; gilt je Gerät.
- **Entlassene Fahrzeuge** stehen in Abschnitte und Fahrzeuge als eine einklappbare Zeile am Ende („3 entlassen: …“) mit Zeiten.
- **Kopfleiste schmaler:** Feedback, Hilfe, eigenes Fenster, Einsatzmodus und Hell/Dunkel/Nacht liegen jetzt im Menü **„⋯“** oben rechts. Suche, Hinweise, Verbindung, Benutzer und Uhr bleiben direkt sichtbar. F1 und die Tastenkürzel funktionieren weiter.

### Neu in 5.147 – Weniger Klicks: Ziehen, Alarm direkt offen, kürzerer Abschluss, Kürzel an den Knöpfen

- **Kräfte & Mittel → Liste: Fahrzeug in den Einsatz ziehen.** Läuft ein Einsatz, steht über den Fahrzeugen die Leiste „⤵ Fahrzeug hierher ziehen“ mit allen laufenden Einsätzen und den Abschnitten des gewählten Einsatzes. Fahrzeugkarte mit der Maus daraufziehen:
  - freies Fahrzeug → wird als alarmiert (A) in den Einsatz übernommen,
  - alarmiertes Fahrzeug ohne Einsatz → wird zugeordnet,
  - Fahrzeug aus einem anderen Einsatz → wird umgesetzt,
  - auf einen Abschnitt gezogen → kommt zusätzlich gleich in diesen Abschnitt.
  Rückgängig wie gewohnt mit „↶ Rückgängig“ bzw. Strg+Z.
- **Neuer Alarm öffnet sich selbst.** Legt PowerAlarm oder die Alarm-Mail der Leitstelle einen Einsatz an und lief vorher keiner, springt die Einsatzverwaltung direkt in dessen Übersicht. Läuft schon ein Einsatz, ist ein Fenster offen oder wird gerade geschrieben, erscheint nur ein Hinweis. Abschaltbar je Gerät unter ⧉ → Töne und Meldungen („Neuen Alarm … automatisch öffnen“).
- **„Alarmierte Fahrzeuge übernehmen ✓“.** Nennt die Alarm-Mail Kräfte (z. B. eine Ortswehr), die laut Einstellung nicht automatisch alarmiert werden, stehen deren Fahrzeuge oben in der Übersicht zum Ankreuzen – ein Klick übernimmt alle angekreuzten als alarmiert. „Ausblenden“ blendet den Kasten auf diesem Gerät aus.
- **Abschluss-Assistent kürzer.** Schritte ohne offene Punkte werden automatisch übersprungen (Chip „✓“, Hinweis „nichts offen“): Prüfen, wenn alles in Ordnung ist; Atemschutz ohne ASÜ; Exposition ohne ASÜ und ohne B-/ABC-Stichwort; Stärke und Material ohne Fahrzeuge. Über die Chips oben lassen sie sich trotzdem öffnen.
- **Tastenkürzel an den Knöpfen.** Klein neben Reitern und Knöpfen steht das Kürzel (⇧1 … ⇧9 für die Reiter, 1 … 9 für die Bereiche im Einsatz, Strg+F Suche, H Hinweise, Strg+↵ Eintragen, im Fahrzeugfenster die Statusziffern). Vorgabe: an bei Maus und Tastatur, aus auf Touch-Geräten. Umschalten mit „?“ → „Kürzel klein an den Knöpfen anzeigen“.

### Neu in 5.146 – Auswahl bleibt, Wasserstelle als Nachricht

- **Kräfte & Mittel** behält beim Zurückkommen die zuletzt gewählte Einstellung: Ansicht (Liste/Nach Ortswehr/Matrix), Schnellfilter (z. B. ABC-Zug oder „alle“) und gewählte Ortswehr – auch nach dem Neuladen.
- **Wasserentnahmestelle / Hydrant** (Lagekarte, antippen): Knopf **„✉ Nachricht an Fahrzeug“** öffnet eine Nachricht an die Fahrzeuge des Einsatzes mit Art, DN, Entfernung zum Einsatzort, ///what3words und Koordinate.

### Neu in 5.145 – Bericht-Inhalt wählen, Einsatzort auf der Karte, Anfordern aus Kräfte & Mittel

- **Einsatzbericht (PDF):** In der Vorschau oben „Im Bericht:“ mit Häkchen für Karten, Zeitstrahl, Abschnitte, Wasserförderung, Verkehrsunfall, Anforderungen, Nachbesprechung, Lagemeldungen, Checklisten, Atemschutz, Nachbereitung, Aufträge, Funkskizze, Fotos, Nachrichten, Tagebuch, Ansprechpartner. Die Auswahl wird auf dem Gerät gemerkt; „alle“ setzt alles wieder.
- **Einsatz eröffnen – Einsatzort:**
  - **📍 Karte:** Ort auf der Karte antippen (ziehen, +/−, Suche auch nach ///what3words). Übernimmt Koordinate und – wenn leer – die Adresse (Straße aus OpenStreetMap) bzw. die what3words-Adresse.
  - Im Adressfeld ///drei.wort.adresse eintippen → wird beim Verlassen des Felds gesucht.
  - Zur Koordinate wird die what3words-Adresse angezeigt.
  - **Objekt wählen** übernimmt Straße und Koordinate des Objekts (fehlt die Straße, wird sie aus der Koordinate ermittelt).
- **Kräfte & Mittel → „📣 Anfordern“** (Nach Ortswehr und Matrix, bei laufendem Einsatz): z. B. „Faltbehälter“ suchen → beim GW „Anfordern“ → Anforderung mit Grund „Ausrüstung: Faltbehälter“ im Tagebuch (Ausgang an Leitstelle) und unter Anforderungen; wahlweise gleich alarmieren.

### Neu in 5.144 – Funkskizze bearbeiten, Tagebuch-Filter, what3words für Wasserstellen u. a.

- **Funkskizze bearbeitbar:** Alle Kästen (Leitstelle, Einsatzleitung, Abschnitte, Unterabschnitte, „Direkt an Einsatzleitung“, weitere Funkbereiche) lassen sich mit Maus oder Finger **verschieben**; Linien und Kanäle wandern mit. „Anordnung zurücksetzen“ stellt die automatische Anordnung wieder her.
  - **Weitere Funkbereiche** (+ Funkbereich): Name, Kanal/Gruppe, Leiter/Rufname, Farbe, verbunden mit (Leitstelle, Einsatzleitung oder einem Abschnitt) und Teilnehmer – z. B. Atemschutz, Wasserversorgung, Rettungsdienst, Polizei.
  - Leitstellen-Name sowie **Leiter und Kanal der Abschnitte** direkt in der Funkskizze änderbar (ändert auch den Abschnitt im Einsatz).
- **Reiter „Einsatz“** steht jetzt ganz links als erster Reiter.
- **Kräfte & Mittel** öffnet immer die zuletzt gewählte Ansicht (Liste, Nach Ortswehr oder Matrix).
- **Hydranten und Wasserentnahmestellen mit what3words:** Der Pi rechnet für alle Stellen der Gemeinde einmalig die ///drei.wort.adresse aus und merkt sie sich (braucht den what3words-Schlüssel unter Einstellungen). Sie erscheint in den Infos zur Wasserstelle (Lagekarte, nächste Wasserstellen) und als Spalte „what3words“ im Berichtswesen (Hydranten / Löschwasser).
- **Tagebuch-Filter:** Alle · Von Hand · Meldungen · Lagemeldungen · Anforderungen · Lagekarte · Status/FMS · Atemschutz · Aufträge · Nachrichten · Abschnitte, dazu Suche und **„Automatische Einträge ausblenden“**. Die Wahl wird auf dem Gerät gemerkt.
- **Automatische Einträge** erscheinen im Tagebuch schwächer (grau, dünner), von Hand eingetragene kräftiger mit Strich am Rand.
- **Nachrichten kopieren:** Bei jeder Nachricht „⧉ Kopieren“ (Zwischenablage) und „↪ Weiterleiten“ (als neue Nachricht an Fahrzeuge).
- **Abschnitte einklappbar:** Pfeil ▾/▸ am Abschnitt klappt die Fahrzeuge zusammen (dann nur Funkrufnamen in einer Zeile); „Alle einklappen / aufklappen“ oben. Ziehen in eingeklappte Abschnitte geht weiter.
- **Lagebesprechung:** neuer Block **Anforderungen** mit „Was rollt bereits?“ (vorbelegt mit laufenden Anforderungen) und „Was wird noch benötigt – und wer kümmert sich darum?“; beides steht im Tagebuch und im Ausdruck.

### Neu in 5.143 – Kräfte & Mittel kompakter

- „Nach Ortswehr“ und „Ausrüstungs-Matrix“: Umschalter, Status, Suche und Ausrüstungsfilter in **einer Zeile**; Kategorien als kleine Chips; Ortswehren als **Chips mit Anzahl** statt großer Kacheln („Alle (Aerzen) 54“, „Aerzen 12“ …).
- Matrix mit flacheren Zeilen – deutlich mehr Fahrzeuge auf einen Blick.

### Neu in 5.142 – „Kräfte & Mittel“: Einheiten und Ausrüstung in einem Reiter

- Die Reiter **Einheiten** und **Ausrüstung** sind zu **Kräfte & Mittel** zusammengefasst. Oben der Umschalter:
  - **Liste** – alle Fahrzeuge wie bisher unter „Einheiten“ (Schnellfilter, Status, Suche).
  - **Nach Ortswehr** – wie bisher „Ausrüstung“: Ortswehr-Kacheln, Kategorien, Ausrüstungsfilter, Bestand.
  - **Ausrüstungs-Matrix** – Fahrzeuge der Gemeinde (gefiltert wie „Nach Ortswehr“) mit Wasser, Schaum, AGT, B/C/D, Strom, Licht und Kettensäge, WBK, Tauchpumpe, Hebekissen, Hilfeleistung, Sprungretter, Messgerät. Zeile antippen öffnet das Fahrzeug.
- **Eine Suche für alles:** In der Liste findet die Suche auch Ausrüstung – z. B. „Kettensäge“ zeigt „als Ausrüstung auf 10 Fahrzeugen, davon 7 frei“ mit Sprung zu „Nach Ortswehr“ oder zur Matrix. Beim Umschalten wird der Suchbegriff mitgenommen.
- Fenster und Arbeitsplätze mit dem alten Reiter „Ausrüstung“ öffnen weiter. In der einfachen Ansicht (ohne Ausrüstung) bleibt nur die Liste.

### Neu in 5.141 – Übung beim Einsatz anlegen

- Beim **Einsatz eröffnen** gibt es das Häkchen **Übung – kein Realeinsatz**. Verhalten wie eine Übung aus dem Übungsgenerator: Meldebild beginnt mit „ÜBUNG:“, Notiz „Übungseinsatz“, Vermerk im Tagebuch „ÜBUNG – … Kein Realeinsatz.“, alarmiert werden die echten Fahrzeuge.

### Neu in 5.140 – Aufbau „Leitstand“ zum Ausprobieren

- Im Fenster **„Aa“** (unten links, Alt+D) gibt es in der Einsatzverwaltung jetzt **Aufbau: Bisher / Leitstand**. Alle bisherigen Seiten und Reiter bleiben, der Leitstand legt nur einen Rahmen darum:
  - **Instrumentenleiste oben (immer sichtbar):** Einsatz, Dauer, Stärke, Atemschutz, Countdown Lagemeldung und nächste Uhr, Wetter/Wind, offene Anforderungen, Funk (Sprechwunsch/Notruf), Uhrzeit. Antippen öffnet die passende Karte im Einsatz. Gelb = bald, rot = fällig.
  - **Rechte Spalte:** Fahrzeuge im Einsatz als Statuskacheln (antippen = Status ändern), Atemschutz je ASÜ, Anforderungen mit Stand, offene Aufträge, letzte Tagebucheinträge. Ohne Einsatz: Fahrzeuge, die nicht auf der Wache sind.
  - **Band unten:** fällige und bald fällige Uhren sowie die automatischen Erinnerungen.
- Gut zusammen mit **Signal Klar**. Direkt einschalten mit `?design=leitstand` an der Adresse. Unter 1000 px Breite entfällt die rechte Spalte.

### Neu in 5.139 – Meldungen erkennen, Diktieren, automatische Erinnerungen

- **Tagebuch erkennt frei geschriebene Meldungen:** Unter dem Textfeld erscheinen Vorschläge, z. B. bei „14 23 1 am Einsatzort, wir benötigen eine DLK“:
  - **Von: 14-23-1** – Funkrufname auch mit Leerzeichen („14 23 1“) oder ein eindeutiger Fahrzeugtyp („das TLF“).
  - **Status 4 für 14-23-1 setzen** – erkennt „Status 4“, „am Einsatzort“, „eingetroffen“, „auf Anfahrt“, „einsatzbereit“, „auf der Wache“, „außer Dienst“.
  - **Als Anforderung erfassen: DLK** – bei „benötigen“, „nachfordern“, „brauchen“ …; öffnet die Anforderung mit Was und Grund ausgefüllt.
  - Nichts passiert ohne Klick – nur ein erkanntes Fahrzeug wird als „Von“ eingesetzt, wenn „Von“ bei einer Meldung leer ist.
- **Diktieren (🎤)** funktioniert zusammen mit der Erkennung: gesprochen „vierzehn dreiundzwanzig eins Wasser steht“ → Vorschläge erscheinen. Die Spracherkennung des Browsers braucht Internet und eine sichere Verbindung (https); sie schickt die Sprache an Google bzw. Apple.
- **Automatische Erinnerungen** oben (blau, bei Funkrufen rot) zusammen mit den Einsatz-Uhren:
  - Sprechwunsch/Notruf seit 2 Minuten unbeantwortet
  - Fahrzeug seit 15 Minuten auf Anfahrt (Status 3)
  - Anforderung seit 10 Minuten ohne Rückmeldung – Knopf **Eingetroffen ✓**
  - Fahrzeug seit 3 Stunden am Einsatzort – Ablösung, Verpflegung, Atemschutz-Reserve prüfen
  - **Erledigt ✓** / **+10 min** gelten auf diesem Gerät. Ausschalten unter ⧉ → Töne und Meldungen. Auch im **Lagetisch** unter „Jetzt wichtig“.

### Neu in 5.138 – Lagetisch für Wandbildschirme

- Neue Anzeige **Lagetisch** unter ⧉ → **Anzeigen für Wandbildschirme**: Karte in der Mitte, links „Jetzt wichtig“, rechts die Fahrzeuge, unten der Zeitstrahl aus dem Tagebuch.
- Nur lesen, aktualisiert sich selbst; am besten als **Anzeige** und mit ⛶ Vollbild auf dem Wandbildschirm.

### Neu in 5.137 – Designvorschau „Signal Klar“ zum Ausprobieren

- In allen Apps unten links ein kleiner gelber Knopf **„Aa“** (oder Taste **Alt+D**): Designvorschau umschalten zwischen **Bisher** und **Signal Klar**.
- Bei „Signal Klar“ drei **Stufen**: **Büro** (kompakt), **Einsatz** (größere Schrift und Knöpfe), **Außen** (dunkel, höchster Kontrast, Knöpfe ab 56 px für Handschuhe und Sonne).
- Nur zum Testen: Die Wahl gilt nur auf diesem Gerät und in dieser App; Funktionen ändern sich nicht. „Bisher“ stellt das gewohnte Aussehen wieder her.
- Knopf ausblenden über „ausblenden“ im Fenster; wieder einblenden mit Alt+D oder `?design=klar` an der Adresse.

### Neu in 5.136 – Hilfe in der App, Neuigkeiten, QR-Codes im Digitalfunk

- **ⓘ Hilfe** in allen Apps (Einsatzverwaltung, Atemschutz- und Gerätedatenbank, Berichtswesen) und Taste **F1**: öffnet die Bedienungsanleitung beim passenden Abschnitt, mit Suche.
- **Was ist neu:** nach einem Update einmal die Neuerungen seit dem letzten Besuch.
- **Digitalfunk:** QR-Codes für Funkgeräte und Akkus („🏷 QR“, „🏷 Etiketten“ für alle angezeigten), „📷 Scannen“ für alle Gerätewarte.

### Neu in 5.135.2 – Hinweis „ASÜ-Schnittstelle: falscher Schlüssel“ entfällt

Zugriffe auf die ASÜ-Schnittstelle mit falschem oder ohne Wehr-Schlüssel erscheinen nicht mehr in den Sicherheitshinweisen (nur noch im Server-Protokoll). Vorhandene Hinweise dieser Art werden beim Start entfernt. Falsche Kennwörter bei ASÜ-, Datenbank- und Träger-Anmeldungen werden weiterhin gemeldet.

### Neu in 5.135.1 – Digitalfunk übersichtlicher

Die Überschrift „Digitalfunk“ entfällt. Oben steht jetzt wie bei den Fahrzeugen **„📌 Heute zu tun“** (Programmierstand veraltet, Sicherheitskarten ablaufend/verloren, Akkus tauschen, Akku-Tests fällig, Schäden offen) – Antippen filtert die Liste, „✕ Filter“ hebt das auf. Darunter die Suche über die ganze Breite und die Ortswehr. Reiter und Knöpfe (+ Funkgerät, Excel, Fahrzeugfilter) stehen in einer Zeile.

### Neu in 5.135 – Funkbeauftragter in der Verwaltung

Der Funkbeauftragte wird jetzt wie die anderen Rechte der Gerätewarte festgelegt: **Gerätedatenbank → ⚙ Verwaltung → Zugänge der Gerätewarte → Bearbeiten → Häkchen „📻 Funkbeauftragter Digitalfunk“**. In der Liste der Zugänge steht dann „📻 Funkbeauftragter“ (bzw. „📻 Beauftragter“). Der Funkbeauftragte benennt weitere Beauftragte im Digitalfunk unter „👥 Beauftragte“ per Häkchen; der Admin sieht diesen Reiter nicht mehr, er nutzt die Verwaltung.

### Neu in 5.134 – Digitalfunk: Funkbeauftragter, Excel, Schäden

- **Rollen:** Funkgeräte, Sicherheitskarten und Akkus legt nur noch der **Funkbeauftragte der Gemeinde** an und pflegt sie (für alle Ortswehren) – dazu weitere **Beauftragte**, die der Funkbeauftragte selbst benennt, und der Admin. Festgelegt wird das im Reiter „👥 Beauftragte“: Den Funkbeauftragten bestimmt der Admin, weitere Beauftragte der Funkbeauftragte.
- **Ortsgerätewarte** sehen nur die Funkgeräte, Karten und Akkus ihrer Ortswehr. Antippen öffnet die Ansicht mit „🛠 Schaden melden“ (wahlweise „außer Betrieb“). Der Funkbeauftragte und die Beauftragten bekommen eine E-Mail und eine Push-Nachricht. Im Reiter „🛠 Schäden“ stehen alle Meldungen; der Funkbeauftragte setzt sie auf „Erledigt“ (auf Wunsch wieder einsatzbereit).
- **OPTA:** Beim Eintippen der OPTA werden Ortswehr und Fahrzeug automatisch gewählt, wenn der Funkrufname in der OPTA steht (z. B. „FW HM 14-40-32“ → Fahrzeug 14-40-32 der Ortswehr Dehmke). Gilt auch beim Excel-Import.
- **Excel:** „⇩ Excel“ exportiert Funkgeräte, Sicherheitskarten und Akkus (Ortsgerätewarte nur ihre Ortswehr). „⇪ Excel einlesen“ (nur Funkbeauftragter/Beauftragte) liest Funkgeräte ein – Spalten wie im Export (Art, Modell, Seriennummer, ISSI, OPTA, Ortswehr, Fahrzeug, Fach, Firmware, Programmierung, Status, Bemerkung); vorhandene Geräte werden über die ISSI (sonst Seriennummer) erkannt und aktualisiert. Vor dem Einspielen zeigt eine Prüfung, wie viele neu bzw. geändert werden und welche Zeilen Fehler haben.

### Neu in 5.133 – Fristen, Verpflegung, Monatsbericht, Digitalfunk

- **Berichtswesen → 👤 Fristen:** Alle Atemschutz-Nachweise (G 26.3, Übungsstrecke, Unterweisung, Übung/Einsatz) je Person auf einen Blick – rot = abgelaufen oder fehlt, gelb = läuft in 60 Tagen ab, grün = gültig. Filter nach Ortswehr, Name und „nur mit Handlungsbedarf“, druckbar. (Die Erinnerungen an Gerätewarte und Träger gab es schon.)
- **Berichtswesen → 📬 Monatsbericht:** Jede Orts- bzw. Gemeindebrandmeisterin stellt selbst ein, ob sie einmal im Monat eine E-Mail über den Vormonat bekommt, an welchem Tag (1.–28.), mit welchen Inhalten (Einsätze, Einsatzstunden und Kräfte, Atemschutz unter PA, nicht einsatzbereite Geräteträger, ablaufende Nachweise, offene Schadensmeldungen, Geräte nicht einsatzbereit/Prüfung überfällig, Fahrzeuge mit Einschränkungen, Digitalfunk-Hinweise) und für welche Ortswehren. „Vorschau“ zeigt den Bericht, „Probe an mich senden“ schickt ihn sofort.
- **Einsatz → 🍽 Verpflegung:** Zahl der zu versorgenden Kräfte (aus den Fahrzeugen plus weitere), Bestellungen mit Was, Portionen, Lieferant, Lieferort und Uhrzeit, Status bestellt → geliefert → ausgegeben (oder storniert). Hinweis, wenn der Einsatz länger als eingestellt (Vorgabe 3 Stunden) ohne Verpflegung läuft. Alles steht im Tagebuch. Keine Kosten.
- **Digitalfunk:** Funkgeräte nach Fahrzeug gruppiert, Filter „Fahrzeug“ (auch „Lager / ohne Fahrzeug“). Wird ein neuer Soll-Stand gespeichert, bekommen die Gerätewarte jeder Ortswehr eine E-Mail mit ihren Funkgeräten, die aktualisiert werden können (abschaltbar).

### Neu in 5.132 – Digitalfunk

**Gerätedatenbank → 📻 Digitalfunk** (neuer Bereich im Menü):
- **Funkgeräte:** Art (HRT, MRT, FRT …), Modell, Seriennummer, ISSI (jede ISSI nur einmal), OPTA, Ortswehr, Fahrzeug und Fach, Firmware, Programmierung/Codeplug, programmiert am, Status. Jede Änderung steht im Verlauf des Geräts. Klick auf die Zeile öffnet das Gerät.
- **Soll-Stand:** Unter „⚙ Soll-Stand“ Firmware und Programmierung eintragen – Geräte mit anderem Stand sind rot markiert und stehen oben unter „Hinweise“.
- **Sicherheitskarten (BSI-Karten):** Kartennummer, gültig bis, Status (aktiv, gesperrt, verloren, zurückgegeben) und in welchem Funkgerät sie steckt (eine Karte je Gerät). Erinnerung 60 Tage vor Ablauf und bei Ablauf (wie die anderen Fristen per Mail/Push an die Gerätewarte). PIN und PUK werden bewusst nicht gespeichert.
- **Akkus:** Nummer, Typ, Funkgerät bzw. Fahrzeug, Inbetriebnahme, Ladezyklen und Kapazitätstests. Liegt der letzte Test unter der Grenze (Vorgabe 80 %, unter „Soll-Stand“ einstellbar), wird der Austausch empfohlen; ohne Test seit einem Jahr erscheint „Test fällig“. Jeder Akku hat einen QR-Code („QR“) – „📷 Akku scannen“ öffnet direkt die Testeingabe.
- Ausgesonderte Geräte, Karten und Akkus verschwinden aus der Liste, bleiben aber gespeichert.

**Einsatz → Funkskizze → „📻 Rufgruppe an die Fahrzeuge senden“:** Rufgruppe eintragen und „An alle Fahrzeuge senden“. Die Rufgruppe erscheint groß in der Fahrzeug-App und kommt als Nachricht; Fahrzeuge, die später zum Einsatz kommen, bekommen sie automatisch (innerhalb weniger Sekunden). Wahlweise erhalten Fahrzeuge in Abschnitten mit eigenem Kanal stattdessen den Kanal ihres Abschnitts. „Geänderte Rufgruppe senden“ verteilt eine Änderung, „Senden beenden“ hört auf. Es wird nichts automatisch vorgeschlagen.

**Tagebuch → Schnellwahl:** Über „▾ Fahrzeuge für die Schnellwahl“ die gewünschten Fahrzeuge des Einsatzes ankreuzen (gilt je Gerät und Einsatz). Sie erscheinen als Knöpfe: Name = Absender (Von, An wird die Einsatzleitung), „an“ = Empfänger. Die Rufgruppen des Einsatzes (Leitstelle, Führungskanal, Rufgruppe der Fahrzeuge, Abschnitts-Kanäle) stehen als „📻 …“-Knöpfe daneben und hängen „über …“ an den Text an.

### Neu in 5.131.4 – Objektliste kompakter

Jedes Objekt in der Liste ist höchstens drei Zeilen hoch: Name mit Merkmalen, Ort · Art · Adresse und Pläne/Hinweise. Was nicht passt, wird mit „…“ gekürzt (vollständig unter „Öffnen“). Die Objekte stehen als eigene Kästen mit Abstand untereinander.

### Neu in 5.131.3 – Berichtswesen nur mit Fahrzeugen

Im Berichtswesen erscheinen in „Fahrzeuge“, „Ausrüstung“ und in der Fahrzeugspalte bzw. Fahrzeuganzahl der Einsätze nur noch echte Fahrzeuge – Funktionen wie GemBM oder Stellv. GemBM nicht mehr. Die Stärke der Einsätze zählt die Funktionen weiterhin mit.

### Neu in 5.131.2 – Abmelden nach Schließen, Personen direkt öffnen

- **Einsatzverwaltung:** War der Browser länger als 30 Sekunden geschlossen, ist man beim nächsten Öffnen abgemeldet. Neuladen der Seite und Verbindungsabbrüche zum Pi zählen nicht. Für feste Anzeigen (z. B. Einsatz-Uhren im Gerätehaus) gibt es bei der Anmeldung „Auf diesem Gerät angemeldet bleiben (feste Anzeige)“.
- **Atemschutz-Datenbank → Personen:** Ein Klick auf die Zeile öffnet die Person zum Bearbeiten; der Knopf „Bearbeiten“ entfällt. QR-Code und die übrigen Knöpfe in der Zeile funktionieren wie bisher.

### Neu in 5.131.1 – Links für den Zugriff von außen

**Behoben:** In der Atemschutz-Datenbank (und Gerätedatenbank) → Verwaltung → „🔗 Links für die Apps“ zeigten die Links auf die Internetadresse der Fahrzeug-App. Dort gibt es Atemschutz-Datenbank, ASÜ, Träger-App und Sammel-App nicht – der Link lief ins Leere. Jetzt zeigen die Links auf die Internetadresse der ASÜ (z. B. `https://name.tailXXXX.ts.net:8443/atemschutz`). Bereits verschickte Links bitte neu kopieren bzw. QR-Codes neu ausdrucken.

### Neu in 5.131 – Abschluss-Assistent, Exposition, Offline-Betrieb und Sicherheit

**Einsatz-Abschluss-Assistent.** „Einsatz beenden“ führt jetzt in sechs Schritten durch den Abschluss: *Prüfen* (Trupps noch unter Atemschutz, Lagemeldung, Fahrzeuge auf Status 3/4, offene Aufträge), *Stärke* je Fahrzeug, *Atemschutz* (Geräte mit einem Klick zur Atemschutzwerkstatt), *Material & Schäden* (Nachbereitung je Fahrzeug), *Exposition* und *Beenden*. Jeder Schritt hat „Schritt überspringen“; „Assistent überspringen und direkt beenden“ führt zur bisherigen Abfrage. Mit „Assistent auf diesem Gerät nicht mehr anzeigen“ wird er auf diesem Gerät abgeschaltet.

**Exposition der Atemschutzgeräteträger.** Alle Kräfte, die laut ASÜ unter Atemschutz waren, werden automatisch in den Expositionsnachweis eingetragen (Art nach Stichwort, z. B. Brandrauch bei B-Einsätzen; Dauer aus der ASÜ). Die Abfrage je Person – Art und Stoff, Haut- oder Kleidungskontakt, Hygienemaßnahmen (Grobreinigung, Kleidung gewechselt, Kleidung zur Reinigung, Hände/Gesicht gereinigt, Duschen) und Beschwerden – wird im Assistenten oder später im Archiv unter „☣ Exposition“ beantwortet. Atemschutzgeräteträger lassen sich nicht abwählen. Unbeantwortete Abfragen zeigt die Verwaltung → Exposition als „Abfrage offen“ an; die CSV-Liste enthält Hygiene, Beschwerden und den Stand der Abfrage.

**Offline-Betrieb.** Bricht die Verbindung zum Pi ab, werden Tagebucheinträge, Lagemeldungen, Stärke, Nachbereitung und neue Aufträge auf dem Gerät gespeichert – auch über ein Neuladen der Seite hinweg – und beim Wiederverbinden automatisch übertragen („📴 … offline gespeichert“ oben neben dem Verbindungsstatus). Tagebucheinträge behalten die Uhrzeit der Eingabe (als Nachtrag gekennzeichnet). Der Pi führt jede Änderung nur einmal aus, auch wenn sie doppelt ankommt. In der ASÜ bleiben wartende Änderungen ebenfalls über Neustart und leeren Akku erhalten; das Abgleich-Symbol zeigt „📴 … warten“.

**Rückgängig-Verlauf.** Die letzten 10 Änderungen der letzten 2 Minuten lassen sich zurücknehmen (Strg+Z oder „↶ Rückgängig“; „▾“ zeigt die Liste). Neu rückgängig zu machen: Auftragsstatus (bei „erledigt/storniert“ werden die Fahrzeuge wieder zugewiesen), Checklisten-Haken und erledigt-Haken der Nachbereitung.

**Sicherheit und Betrieb.**
- **Signierte Updates:** Jedes Update-Paket trägt eine digitale Signatur. Die Update-Prüfung zeigt „🔏 Signiert“. Ein verändertes oder falsch signiertes Paket wird abgelehnt; ein nicht signiertes Paket kann nur der Superadmin nach ausdrücklicher Bestätigung einspielen.
- **Bibliotheken lokal:** Excel-Export und Bildschirmfoto (Feedback) kommen aus dem Programmpaket, QR-Erkennung und Texterkennung lädt der Pi einmal aus dem Internet und liefert sie danach selbst aus (mit Prüfsumme). Die Tablets brauchen dafür kein Internet mehr.
- **PIN mindestens 6 Zeichen** für alle Rollen. Wer sich mit einer kürzeren PIN anmeldet, muss sie sofort ändern.
- **Wiederherstellungsprobe:** Einmal pro Woche liest der Pi die jüngste Sicherung auf SD-Karte, USB-Stick und Netzlaufwerk testweise ein (entschlüsseln, Umfang prüfen, Stichprobe der Dateien). Ergebnis unter Verwaltung → Einstellungen → Datensicherung, Knopf „Wiederherstellung testen“. Bei Fehlern geht eine Mail an die System-Empfänger.
- **Selbstüberwachung des Pi** zusätzlich: Uhrzeit-Abgleich (NTP), SD-Karte beschreibbar, Programmneustarts in 24 Stunden, Wiederherstellungsprobe. Gelbe Hinweise, die länger als 6 Stunden bestehen, gehen einmal am Tag per Mail raus.

### Neu in 5.130 – Sicherheit und Cyber Resilience Act

Behobene Sicherheitspunkte:
- **Standard-PIN 1234:** Wer sich mit 1234 anmeldet, muss sofort eine neue PIN (mind. 6 Zeichen) festlegen.
- **Anmeldeprotokoll und Atemschutz-Inbetriebnahmen** wurden an alle angemeldeten Geräte mitgesendet (auch an Betrachter) – jetzt nur noch für Berechtigte über die Verwaltung.
- **ASÜ-Schnittstelle ohne Wehr-Schlüssel** ist über den öffentlichen Internet-Zugang (Tailscale Funnel) gesperrt; im eigenen Netz unverändert.
- **Sicherheits-Header** in allen Apps (kein Einbetten in fremde Seiten, nosniff, Referrer-Policy, Berechtigungen für Kamera/Mikrofon/Standort nur für die eigene Seite, HSTS bei HTTPS).
- **Excel-Import der Fahrzeuge** wird auf dem Pi gelesen statt mit der veralteten Browser-Bibliothek (SheetJS 0.18.5 mit bekannten Lücken).
- **Update:** Die Prüfung zeigt die SHA-256-Prüfsumme des Pakets zum Abgleich.
- Kleinere Härtungen (Escaping beim Plakatdruck, Excel-Einlesen).

Neu im Paket: **SECURITY.md** (Schwachstellen melden, Fristen), **docs/sbom.cdx.json** (Software-Stückliste), **docs/CRA.md** (Stand der CRA-Anforderungen und offene Punkte).

### Neu in 5.129 – Darstellungsprüfung

Alle Apps wurden auf PC (1440 px), Tablet (1024 px) und Handy (390/360 px) geprüft. Behoben:
- **Einsatzverwaltung:** Überschriften mit Knöpfen (z. B. „Kräfteanforderungen + Anfordern / PowerAlarm“) brechen am Handy um statt aus dem Bild zu laufen; lange Namen auf Kacheln (Werkfeuerwehr) umbrechen; Auswahllisten (Protokoll → Benutzer) nicht breiter als der Bildschirm; Einsatz-Uhren-Anzeige mit mehreren Einsätzen am Handy einspaltig.
- **Erinnerungen** (Lagemeldung fällig, Nachtanken …) am Handy nur noch eine oben, kompakt – der Rest gesammelt unter „weitere Erinnerungen“.
- **Ablaufplan:** Fehler beim Öffnen ohne gewählten Platz behoben.
- **Atemschutz-Datenbank → Inbetriebnahme:** Datum/Uhrzeit nicht mehr zeichenweise umgebrochen.
- **Berichtswesen:** Reiter am Handy in einer wischbaren Zeile, Uhr am Handy ausgeblendet.
- **Übungsleitstelle (2. Bildschirm)** und **Alarmmonitor (Termine)**: kein seitliches Überlaufen am Handy.

### Neu in 5.128

- **Karte drucken / PDF** (🖨, A4 quer mit Titel und Kennzahlen); Einsätze wahlweise **nach Stichwortgruppe gefärbt**.
- **Jahresbericht mit Vorjahresvergleich** (Kennzahlen mit Vorjahr und Veränderung, Monatsvergleich).
- **Stichwort-Hitliste je Ortsteil** (Diagramme und Jahresbericht).
- **Atemschutz-Belastung je Person** (Einsätze, Übungen, Minuten; Diagramme und Jahresbericht).
- **Kennzahlen-Kacheln** über jeder Tabelle (Σ, Ø, min, max der Zahlenspalten).
- **Datenschutz:** Namen voll / gekürzt / ausgeblendet – für Anzeige, Druck, Excel und Jahresbericht.

### Neu in 5.127

- **📈 Diagramme** im Bericht (Monat; Einsätze nach Stichwortgruppe, Uhrzeit, Wochentag; Ortswehr, Typ, Zustand …).
- **😷 Atemschutz – ablaufende Nachweise (Vorschau):** abgelaufen / 30 Tage / 3 / 6 Monate.
- **Karte:** Abdeckung nach **Anfahrtszeit** (Minuten) statt Radius; **Hydranten nach Zustand gefärbt**; ablaufende Nachweise als Ebene.
- **E-Mail-Abo** je gespeicherter Berichtsform: monatlich (Vormonat) oder jährlich (Vorjahr) als Excel; ✉ = sofort testen.
- **📄 Jahresbericht:** Jahr, Ortswehr und Inhalte auswählen → Druck/PDF.

### Neu in 5.126

- **Berichtswesen – neue Bereiche:** 🚒 Fahrzeuge, 🚰 Hydranten / Löschwasser, 🧰 Ausrüstung der Fahrzeuge (zusätzlich zu Einsätzen und Atemschutzgeräteträgern) – mit Filtern, Sortieren, Gruppieren, PDF und Excel wie gewohnt.
- **Reiter 🗺 Karte:** Fahrzeuge (Typ, Fahrzeug, Ortswehr), Hydranten (Art, Zustand), Ausrüstung (Gegenstand) oder Geräteträger auswählen; **Radius einstellbar** (100 m – 20 km); Abdeckungskreise um die Standorte. **Einsätze** aus dem Archiv mit Zeitraum: rot im Radius, grau außerhalb, mit Anteil in Prozent.

### Neu in 5.125

- **Übungsleitstelle – Scrollen:** linke Spalte (Leitstelle, Drehbuch) und rechte Spalte (Posteingang, Fahrzeuge) scrollen unabhängig; die Karte bleibt stehen.
- **Alle Fahrzeuge in der Übung:** Beim Start werden automatisch alle Fahrzeuge als Übungsfahrzeuge angelegt (keine Auswahl mehr nötig).
- **Übungsfahrzeuge-Liste:** zeigt nur Fahrzeuge, die in einem Einsatz sind, angefordert oder alarmiert wurden (einmal benutzt bleibt sichtbar). „alle zeigen“ blendet alle ein.
- **Sonderlage:** Fahrzeuge in der kompakten Ansicht nach Aufträgen gruppiert (Priolage, Priorität, Status – wie in der Ansicht Aufträge), dann „Ohne Auftrag · Bereitstellung“ und „Weitere Fahrzeuge“.

### Neu in 5.124

- **Alarmmonitor bei Sonderlage:** Mit einem eigenen Fahrzeug im Einsatz zeigen Adresse, Karte und Navigations-QR den **Auftrag** des Fahrzeugs. Mit mehreren eigenen Fahrzeugen erscheint eine **große Karte** mit allen Fahrzeugen und ihren Aufträgen (Linie Fahrzeug → Auftrag) und rechts die Fahrzeugliste; der Rest wird ausgeblendet.

### Neu in 5.123

- **Einsatz-Uhren (Anzeige):** Ist nur ein Einsatz bzw. eine Sonderlage offen, entfällt der Kopf mit Stichwort und Nummer. Bei mehreren Einsätzen bleibt er zur Unterscheidung.

### Neu in 5.122

- **Einsatz-Uhren (Anzeige):** Bei einer Sonderlage zeigt die Kachel statt „Atemschutz“ die **alarmierten Wehren** – Anzahl groß, darunter die Namen der Ortswehren mit Fahrzeugen im Einsatz.

### Neu in 5.121

- **Fenster und Bildschirme → Einsatz-Uhren:** Die Aufträge stehen in Spalten wie im Board (Neu · 🔍 Erkunden (nur wenn aktiv) · In Dispo · Disponiert · In Arbeit), mit Erkunden / + Fahrzeug; antippen öffnet den Auftrag.
- **Board-Karte:** Der Ort steht nur noch in der Überschrift (keine doppelte Zeile mehr).

### Neu in 5.120

- **Zurückgenommen:** Die Änderung aus 5.119 an der Einsatz-Übersicht ist wieder entfernt (Uhren und Aufträge dort wie vorher).
- **Fenster und Bildschirme → Einsatz-Uhren:** Einsatzdauer, Lagemeldung, Stärke F/M/G und Atemschutz stehen in einer Zeile in gleich großen Kacheln, danach Aggregat und Timer. Die Ziffern passen sich der Kachelbreite an.
- Die **Aufträge** darunter sehen aus wie im Reiter Aufträge (Erkunden, + Fahrzeug, antippen öffnet den Auftrag).

### Neu in 5.119

- **Übersicht → Einsatz-Uhren:** Einsatzdauer, Lagemeldung, Stärke F/M/G und Atemschutz stehen als gleich große Kacheln in einer Zeile, danach Aggregate und Timer.
- **Aufträge in der Übersicht** werden darunter genauso dargestellt wie im Reiter Aufträge (inkl. Erkunden / + Fahrzeug).

### Neu in 5.118

- **Reiter Objekte:** Objekte erscheinen als Liste wie die Ansprechpartner, nach Kategorie (Art) gruppiert mit Anzahl je Gruppe. Innerhalb der Gruppe gilt die gewählte Sortierung (Name / Entfernung).

### Neu in 5.117

- **Einheitliche Überschrift bei Aufträgen:** überall „Auftrag Nr · Kategorie · 📍 Ort · 🚒 Fahrzeuge“. Fenster hängen ihre Aktion an, z. B. „– Bearbeiten“, „– Fahrzeug disponieren“, „– 🔍 Erkunder wählen“, „– Erkundet“. Im Board steht die Nummer groß davor.

### Neu in 5.116

- **Aufträge:** Der Ort (📍) steht jetzt in allen Ansichten mit in der Überschrift – Board-Karte, Auftragsübersicht neben der Uhr, Meine Ansicht, Disponier-/Erkunder-/Bearbeiten-Fenster, Auswahl „Auftrag wählen“ und ELW-App.

### Neu in 5.115

- **Einsatz anlegen / bearbeiten:** Wird als Führungsstelle **ÖEL** gewählt, ist die Sonderlage (Großschadenslage) immer angehakt.

### Neu in 5.114

- **Auftragsfenster:** Die Überschrift zeigt jetzt auch den Ort (📍 Adresse) und bleibt beim Scrollen oben stehen.

### Neu in 5.113

- **Anforderung:** Die Liste zeigt alle Fahrzeuge – auch die im Einsatz. Diese sind mit „🚒 in diesem Einsatz“ bzw. „⚠ im Einsatz“ gekennzeichnet.

### Neu in 5.112

- **Anforderung → „Was wird angefordert?“** ist jetzt ein Auswahlfeld wie Melder/Empfänger: beim Tippen (z. B. „14-“) klappt eine Liste aller freien Fahrzeuge und Funktionen (GemBM, OrtsBM …) auf, darunter Einheiten wie Löschzug, THW, Polizei. Pfeiltasten + Enter oder antippen übernimmt.

### Neu in 5.111

- **Anforderung → „Was wird angefordert?“:** Unter dem Feld stehen alle freien Fahrzeuge (nicht in diesem oder einem anderen laufenden Einsatz, kein Einsatzstatus). Tippen filtert nach Rufzeichen, Typ oder Ortswehr.

### Neu in 5.110

- **Neue Auftragskategorie „🔥 Feuer“** (wird auch bei eigenen Kategorien vorne ergänzt).
- **Board „In Dispo“** zwischen Neu und Disponiert: erkundete Aufträge und Aufträge, von denen alle Fahrzeuge abgezogen wurden (auch aus „In Arbeit“).
- **Spalte „🔍 Erkunden“** erscheint nur, solange ein Fahrzeug erkundet. Filter: Neu · Erkunden · In Dispo · Disponiert …
- **Auftragstagebuch:** Wechsel Eingang ↔ Ausgang tauscht Von und An – das Fahrzeug springt mit.

### Neu in 5.109

- **Board „Neu“:** Das Kennzeichen „⚡ PRIOLAGE“ in der Spalte Neu zählt nur noch Aufträge, die wirklich neu sind. Ist eine Priolage schon disponiert oder in Arbeit, steht der Schriftzug nicht mehr in der Spalte Neu.
- **Anforderung → „Was wird angefordert?“:** Suche nach Rufzeichen (z. B. „41-12“, Leerzeichen und Striche egal), Fahrzeugtyp oder Ortswehr. Passende freie Fahrzeuge erscheinen als Vorschläge zum Antippen.

### Neu in 5.108
- **Übungsleitstelle nur für den, der sie gestartet hat:** Während eine Übung läuft, öffnet und bedient nur der Benutzer die Übungsleitstelle, der die Übung gestartet hat. Andere sehen „Die Übungsleitstelle wird von … bedient“. Der Superadmin kann im Notfall übernehmen bzw. die Übung beenden.
- **Mehrfachauswahl:**
  - **Disposition eines Auftrags:** Fahrzeuge antippen markiert sie (rot mit ✓), „Zuweisen (n)“ bzw. „Zum Erkunden schicken (n)“ schickt alle auf einmal.
  - **Neuer Einsatz:** unten „Fahrzeuge alarmieren (mehrere möglich)“ mit Filter – beim Eröffnen werden alle markierten Fahrzeuge alarmiert (Status A).
  - **Einsatz → Fahrzeuge:** wie bisher Kästchen vor jedem Fahrzeug bzw. „alle“, dann Status, Abschnitt, Auftrag, Nachricht, Umsetzen oder Entlassen für alle markierten.
  - **Übungsleitstelle:** Kästchen an jeder Fahrzeugkarte; für alle markierten Status 1/2/3/4/6 setzen oder „Anfahrt simulieren“.
- **Priorität der Aufträge:** statt P1/P2/P3 jetzt **Sofort** (rot), **Dringend** (gelb) und **Kann warten** (grün) – in Listen, Disposition, Übersicht und Tagebuch (Bezeichnung ab 5.155).
- **Meine Ansicht → Mein Platz:** Ist ein Einsatz geöffnet, wird nur der Platz der Führungsstelle dieses Einsatzes (ELW oder ÖEL) zur Auswahl angezeigt; der andere bleibt gespeichert.

### Neu in 5.107
- Einsatz → Übersicht → **📄 Ausgaben → „📱 ELW-App (QR-Code)“**: zeigt die Adresse der ELW-Info-App (…/elw) als QR-Code zum Scannen mit dem Tablet im ELW, mit Kopieren und Drucken. Die Adresse gilt im Netz des Pi bzw. über das VPN.

### Neu in 5.106 – Übungsleitstelle
- **Fahrzeuge wieder aus dem Übungseinsatz nehmen:** In der Einsatzkarte stehen unter „Im Einsatz“ alle Fahrzeuge mit ihrer **Ortswehr** und einem ✕. Nach Rückfrage wird das Fahrzeug aus dem Einsatz genommen (wieder frei, Status 2, Vermerk im Tagebuch).
- Die Fahrzeugkarten zeigen neben dem Typ die **Ortswehr**.
- **Filter** über den Fahrzeuglisten (Alarmieren, Nachalarmieren, „Weitere Fahrzeuge zur Übung hinzufügen“ und die Übungsfahrzeuge): Funkrufname, Typ oder Ortswehr eintippen.
- **2. Bildschirm:** „↗ 2. Bildschirm“ bei den Übungsfahrzeugen öffnet ein eigenes Fenster nur mit Posteingang und allen Übungsfahrzeugen (mehrspaltig) – z. B. für einen zweiten Monitor oder ein Tablet für den „Fahrzeugspieler“. Adresse: …/uebleitstelle/?ansicht=fahrzeuge.

### Neu in 5.105
- **Träger-App-Zugangsblatt:** Link und QR-Code enthalten immer die Internetadresse (nicht mehr die Adresse, über die der Atemschutzgerätewart gerade angemeldet ist).
- **Berichtswesen und Jahresauswertung** ordnen Einsätze unter PA auch der „Ortswehr des Trägers“ aus der ASÜ zu (für Träger ohne Eintrag in der Atemschutz-Datenbank).
- **Berichtswesen:** neuer Bericht **„😷 Atemschutz – Inbetriebnahmen“** (Datum, Ortswehr, Gerät, LA, Flasche, Maske, vier Prüfpunkte, Druck, Ergebnis, Prüfer, wo erfasst, eingesetzt am, Einsatz/Übung, Druck passt) mit Filter, Sortierung, PDF und Excel.
- **Gerätenachweis „Wer mit welchem Gerät“:** neue Spalten Ortswehr des Trägers, Druck passt und Inbetriebnahme (Datum, Prüfer, Druck); auch im CSV.
- **ASÜ-Protokoll (PDF):** Gerätetabelle mit Ortswehr des Trägers und Druck (mit „passt“, wenn angehakt). Ortswehr, Inbetriebnahme und „Druck passt“ gehen auch bei eigenständiger ASÜ in die Dokumentation.
- **Berichtswesen im gleichen Aussehen wie die Datenbanken:** Wappen, Schrift, Uhr, rote Knöpfe, gleiche Felder und Tabellen.

### Neu in 5.104
- Atemschutz-Datenbank aufgeräumt: Reiter **Personen** (darin 👤 Personen · 📋 Einsatznachweis) und **Atemschutzgeräte** (darin 🧯 Geräte · 🔧 Gerätepflege · ✅ Inbetriebnahme). Die Zahl der offenen Gerätepflege steht am Reiter Atemschutzgeräte. Daneben bleiben 📅 Kalender, 📊 Jahresauswertung, QR-Codes und ⚙ Verwaltung.

### Neu in 5.103
- **ASÜ – Ortswehr des Trägers:** Unter jeder Person steht „🏠 Ortswehr“. Wird der Personen-QR-Code oder die 4-stellige Nummer eingelesen, setzt die ASÜ die Ortswehr automatisch aus der Atemschutz-Datenbank. Bei Personen, die nicht in der Datenbank stehen, wird sie aus einer Liste gewählt („Ortswehr des Trägers – bitte wählen“).
- Der Einsatznachweis, die Gerätepflege und die Auswertung einer Person ordnen sich jetzt dieser Ortswehr zu – auch wenn eine andere Feuerwehr überwacht hat. So sieht der Zugang der Ortswehr des Trägers dessen Einsätze und Übungen.
- **Atemschutz-Datenbank:** Der Reiter „Einsatzbereitschaft“ entfällt. Die Leiste „Personen · einsatzbereit · nicht einsatzbereit · läuft in 28 Tagen ab“ steht jetzt oben auf jeder Seite (außer ⚙ Verwaltung). Die Datenbank öffnet mit dem Reiter „Personen“.

### Neu in 5.102
- **Admin-Recht für Zugänge der Gerätewarte und Atemschutzgerätewarte:** In ⚙ Verwaltung → Zugang bearbeiten „⚙ Admin-Recht“ anhaken. Der Zugang sieht dann den Reiter ⚙ Verwaltung **seines Bereichs** (Zugänge, Leitung, Links; in der Atemschutz-Datenbank auch ASÜ-Zugänge, Wehr-Schlüssel, ASÜ-Adresse und Online-Schulung) – nicht den anderen Bereich. Den eigenen Zugang kann man nicht löschen, sperren oder sich das Admin-Recht entziehen.
- **Kalender in der Atemschutz-Datenbank:** neuer Reiter „📅 Kalender“ je Ortswehr mit den Prüfterminen der Atemschutzgeräte, ablaufenden Nachweisen der Personen (G 26, Belastungsübung, Unterweisung, Übung/Einsatz, CSA) und den Terminen aus der Träger-App (Übungsstrecke, G 26). Wie bei der Gerätedatenbank als Abo für Apple-, Google- oder Outlook-Kalender oder als .ics.
- **Leitung je Ortswehr getrennt nach Bereich:** Die Leitung der Atemschutz-Datenbank verwaltet unter 👤 → „👥 Atemschutzgerätewarte“ nur noch Atemschutz-Zugänge ihrer Ortswehr und legt dort weitere Atemschutzgerätewarte an; die Gerätewarte sind dort nicht mehr sichtbar (und umgekehrt in der Gerätedatenbank). Die Leitung wird je Bereich festgelegt.
- **Träger-App nur über die Internetadresse:** Wird /traeger über die Adresse des Pi im Feuerwehr-WLAN aufgerufen, leitet der Pi auf die Internetadresse um; Anmeldung und Daten gehen nur über die Internetadresse.

### Neu in 5.101 – Inbetriebnahme der Atemschutzgeräte nach dem Tausch
- Kommen Geräte von der FTZ zurück, werden sie **in Betrieb genommen**: alle Komponentennummern (Gerät, Lungenautomat, Flasche, Maske – die 4-stellige Nummer vom Etikett reicht, LA und Flasche werden aus der Atemschutz-Datenbank ergänzt), **Kurz- und Sichtprüfung** mit den Punkten Hochdruckdichtprüfung, Warnsignal, Flaschendruck und Sichtprüfung (je i. O. / nicht i. O.), der **Flaschendruck** in bar, Ortswehr, Name des Prüfers und Zeitstempel.
- Erfassen geht an drei Stellen: **ASÜ** → Tausch / Prüfung → „✅ Inbetriebnahme nach Tausch“ (mit QR-Einlesen), **Träger-App** → „🔧 Gerät in Betrieb nehmen“ und **Atemschutz-Datenbank** → neuer Reiter **„✅ Inbetriebnahme“**.
- Gespeichert wird in der Atemschutz-Datenbank. Bis zum nächsten Einsatz steht die Inbetriebnahme in der Liste der Ortswehr („Noch nicht eingesetzt“). Kommt das Gerät in der ASÜ zum Einsatz oder zur Übung, wird sie automatisch mit dieser Überwachung verknüpft („Eingesetzt“ mit Datum, Einsatzstelle, Trupp, Träger und Druck).
- **Im Einsatz:** Steht in der ASÜ ein Gerät mit Inbetriebnahme, erscheint unter der Person „🔧 In Betrieb genommen … (Name)“ und das Kästchen **„Druck passt (… bar)“**. Angehakt wird der Druck aus der Inbetriebnahme übernommen, sonst den aktuellen Druck eintragen. Ob „Druck passt“ angehakt war, wird mitgespeichert.
- Eine Inbetriebnahme mit einem Punkt „nicht i. O.“ wird rot angezeigt („Gerät nicht einsetzen“); der Atemschutzgerätewart wird benachrichtigt. Geräte, die nach einer Benutzung zur FTZ gemeldet und seitdem nicht wieder in Betrieb genommen wurden, zeigt die ASÜ mit „⚠ Gerät ist zur Prüfung (FTZ) gemeldet“.
- Behoben: Der Reiter „Tausch / Prüfung“ der ASÜ meldete „Fehler 400“, wenn ein Atemschutzgerät eine reine Zahl als Nummer hatte.

### Neu in 5.100 – ASÜ, Gerätewarte und Schulung aus der Einsatzverwaltung herausgelöst
- In der Einsatzverwaltung entfallen die Reiter **„ASÜ-Zugänge“** und **„Gerätewarte“**. Stattdessen gibt es unter Verwaltung → Personen & Zugänge den Reiter **„Apps & Zugänge“** mit den Links der Apps und dem Hinweis, wo was gepflegt wird.
- **Atemschutz-Datenbank → ⚙ Verwaltung** (Anmeldung mit dem Superadmin) enthält jetzt zusätzlich:
  - **ASÜ-Zugänge der Ortswehren:** anlegen, bearbeiten, löschen, neues Kennwort bzw. Startcode (einzeln oder für eine Auswahl), Zugangszettel mit QR-Code drucken.
  - **🔑 Wehr-Schlüssel an ASÜ übergeben** (QR-Code und Einrichtungslink).
  - **ASÜ auf den Tablets:** Internetadresse des Pi für unterwegs, eigenständige ASÜ für andere Feuerwehren (GitHub: Einstellungen, Jetzt veröffentlichen, ZIP) und Umzugshinweis.
  - **🎓 Online-Schulung (Unterweisung):** hochladen, ansehen, aktivieren, deaktivieren, löschen.
- **Gerätedatenbank → ⚙ Verwaltung:** solange die Gerätedatenbank noch nicht aktiv ist, steht dort „Ausrüstungslisten übernehmen und Datenbank aktivieren“.
- Der Wehr-Schlüssel selbst wird weiter in der Einsatzverwaltung unter Einstellungen → Schnittstellen gepflegt.

### Neu in 5.99 – Aufräumen nach der Aufteilung
- **ASÜ und Gerätedatenbank sind jetzt auch im Programm getrennt.** Bisher enthielten beide Seiten noch den kompletten Programmteil des jeweils anderen Bereichs. Die ASÜ/Atemschutz-Datenbank (`asue/index.html`) enthält jetzt keinen Code der Gerätedatenbank mehr, die Gerätedatenbank (`asue/geraete.html`) keinen Code der ASÜ und der Atemschutz-Datenbank. Beide laden dadurch rund ein Viertel bzw. ein Drittel weniger. An der Bedienung ändert sich nichts.
- **Alte OBM-Adressen entfallen.** Der Einsatzbericht geht nur noch an die E-Mail-Adressen der Berichtswesen-Zugänge. Beim ersten Start von 5.99 werden alte Eintragungen einmalig in vorhandene Zugänge ohne E-Mail der jeweiligen Ortswehr übernommen. Ortswehren ohne Zugang zeigt die Einsatzverwaltung (Verwaltung → E-Mail) gelb mit „⚠ keine Adresse“ und der bisherigen Adresse an – beim „Aus der Einsatzverwaltung übernehmen“ im Berichtswesen wird diese Adresse in den neuen Zugang übernommen.

### Neu in 5.98
- **E-Mail-Adressen der Ortsbrandmeister** werden nicht mehr in der Einsatzverwaltung gepflegt, sondern im **Berichtswesen** (/berichte → ⚙ Verwaltung → Zugang → E-Mail). Der automatische Einsatzbericht geht an die E-Mail der Ortsbrandmeister-Zugänge dieser Ortswehr (Gemeindebrandmeister mit „alle“ bekommen ihn nicht automatisch).
- In der Einsatzverwaltung (Verwaltung → E-Mail → „Einsatzbericht an die Ortsbrandmeister“) steht nur noch zur Kontrolle, an wen der Bericht geht. Solange für eine Ortswehr im Berichtswesen noch keine Adresse hinterlegt ist, gilt die alte Eintragung weiter (gelb markiert). Beim „Aus der Einsatzverwaltung übernehmen“ wird die alte Adresse automatisch in den neuen Zugang übernommen.

### Neu in 5.97 – Berichtswesen (Bereich 4)
- **Neue App „Berichtswesen“** unter `/berichte` (ASÜ-Adresse, z. B. `https://…ts.net:8443/berichte`) für **Ortsbrandmeister und Gemeindebrandmeister**. Jeder sieht **nur die Daten seiner eigenen Ortswehr** – Gemeindebrandmeister (Ortswehren „alle“) die ganze Gemeinde.
- **Berichte aus drei Bereichen:** 🚒 Einsätze (aus dem Archiv: Nr., Datum, Stichwort, Ort, Dauer, eigene Fahrzeuge, Stärke F/M/G, AGT) · 😷 Atemschutz (Geräteträger mit Status und Fristen; Einsätze/Übungen unter PA) · 🧰 Gerätewarte (Geräte mit Zustand und Prüfterminen; Schadensmeldungen).
- **In der App filtern und sortieren:** Zeitraum (mit Schnellwahl dieses Jahr / Vorjahr / Monat / 12 Monate), Suche in allen Spalten, beliebig viele Filter (enthält, gleich, nicht, größer/kleiner, leer), Sortieren per Spaltenkopf (Umschalttaste = weitere Sortierung), Spalten ein-/ausblenden, **Gruppieren** mit Anzahl je Gruppe.
- **Ausgabe:** 🖨 PDF/Drucken (mit Titel, Zugang, Ortswehr, Filterbeschreibung und Stand; ab 8 Spalten quer) und 📊 Excel (.xlsx).
- **Berichtsformen speichern:** „💾 Als Berichtsform speichern“ merkt sich Bereich, Zeitraum, Filter, Sortierung, Spalten und Gruppierung je Zugang – später mit einem Tipp wieder aufrufen.
- **Zugänge:** Reiter **„⚙ Verwaltung“** in der App, nur für den Admin (Superadmin). **„⇩ Aus der Einsatzverwaltung übernehmen“** legt für alle EV-Benutzer mit Rolle Ortsbrandmeister/Gemeindebrandmeister einen Zugang an (gleicher Benutzername, Ortswehr wie in der EV, Gemeindebrandmeister = alle) und zeigt die Startkennwörter einmal an – mit Zugangsblättern zum Drucken. Dazu: Zugänge anlegen, bearbeiten, sperren, löschen; Link der App.
- Jeder Abruf eines Berichts wird im Systemprotokoll vermerkt.

### Neu in 5.96 – Bereiche entkoppelt
- **Drei getrennte Bereiche:** (1) ASÜ + Atemschutz-Datenbank (Atemschutzgerätewarte, Träger-App), (2) Gerätedatenbank (Gerätewarte), (3) Einsatzverwaltung. Die Gerätedatenbank hat jetzt eine **eigene Programmdatei** (`asue/geraete.html`) – Änderungen an einem Bereich wirken sich nicht mehr auf den anderen aus. Jede Seite zeigt nur ihren Bereich.
- **Getrennte Zugänge:** Neue Zugänge gelten immer nur für eine Datenbank. Alte Zugänge „für beide Datenbanken“ werden in der Einsatzverwaltung (Verwaltung → Gerätewarte) und im neuen Reiter Verwaltung als Warnung gezeigt und lassen sich mit **„Aufteilen“** trennen: der bisherige Benutzer gilt dann für die Atemschutz-Datenbank, für die Gerätedatenbank entsteht „…-gw“ mit demselben Kennwort.
- **Neuer Reiter „⚙ Verwaltung“** in der Atemschutz-Datenbank und in der Gerätedatenbank – **nur für den Admin** (Anmeldung mit dem Superadmin der Einsatzverwaltung). Dort: Zugänge dieses Bereichs anlegen, bearbeiten, sperren, Startkennwort, löschen; Leitung je Ortswehr; **Links für die Apps** mit Kopieren und QR-Code (Atemschutz: Atemschutz-DB, ASÜ, Träger-App, Sammel-App; Geräte: Gerätedatenbank, Hinweis auf die Fahrzeug-App-Links je Fahrzeug).
- Wehr-Schlüssel und ASÜ-Anmeldungen der Ortswehren bleiben in der Einsatzverwaltung (Verwaltung → ASÜ-Zugänge).

### Neu in 5.95
- Fehler aus 5.84 behoben: Die aufgeräumte Handyansicht der ASÜ wirkte versehentlich auch auf die **Gerätedatenbank und Atemschutz-Datenbank** – Kopfzeile zeigte „ASÜ“, Feedback- und Benutzerknopf waren verschoben, das Benutzermenü ragte links aus dem Bild. Die Datenbank-Seiten sehen wieder aus wie vorher.

### Neu in 5.94
- Atemschutz-Datenbank → Einsatznachweis → **„+ Übung/Einsatz eintragen“**: Der Atemschutzgerätewart trägt Übungen oder Einsätze von Hand ein, die nicht über die ASÜ liefen – Art, Datum, Uhrzeit, Dauer unter Atemschutz, Einsatzstelle/Thema, Einsatz-Nr., CSA, dazu beliebig viele Personen (mit Suche) und je Person optional die Gerätenummer. Der Eintrag zählt wie ein ASÜ-Eintrag für „Übung oder Einsatz unter Atemschutz“, erscheint im Einsatz- und Gerätenachweis und in der Träger-App. Falsche Einträge lassen sich wie bisher in der Personenansicht ausblenden.

### Neu in 5.93
- **Online-Schulung importieren:** Verwaltung → Gerätewarte → Abschnitt **„🎓 Online-Schulung (Unterweisung)“**. Titel und Jahr eintragen, Datei wählen (**ZIP mit index.html** samt Bildern/Videos oder **einzelne HTML-Datei**), „Hochladen“. Mit „gleich aktivieren“ erscheint sie sofort in der Träger-App. Jedes Jahr eine neue hochladen – die älteren bleiben in der Liste (Ansehen, Aktivieren, Deaktivieren, Löschen). Es ist immer genau eine Schulung aktiv; beim Versuch wird der Titel der Schulung mitgespeichert. Bereits eingetragene Unterweisungen bleiben beim Löschen erhalten.

### Neu in 5.92 – Träger-App „Mein Atemschutz“
- **Eigene App für jeden Atemschutzgeräteträger** unter `/traeger` (ASÜ-Adresse, z. B. `https://…ts.net:8443/traeger`), am Handy „Zum Home-Bildschirm“.
- **Zugang anlegen:** Atemschutz-Datenbank → Person öffnen → **„📱 Träger-App“** → „Zugang anlegen“. Benutzer = 4-stellige Nummer der Person, Startpasswort wird einmal angezeigt (mit QR-Code und „Zugangsblatt drucken“). Beim ersten Anmelden legt der Träger ein eigenes Passwort fest. Dort auch: neues Startpasswort, Zugang sperren/entsperren.
- **In der App sieht der Träger:** einsatzbereit ja/nein, alle Nachweise mit „gültig bis“, die letzten Einsätze/Übungen unter Atemschutz.
- **Termine eintragen:** nächster Termin Übungsstrecke und G 26-Untersuchung – der Gerätewart sieht sie im Fenster „Träger-App“.
- **Benachrichtigungen:** „Benachrichtigungen einschalten“ → Erinnerung 4 Wochen vor Ablauf und bei Ablauf eines Nachweises sowie am Vortag der eingetragenen Termine (iPhone: erst zum Home-Bildschirm hinzufügen).
- **Online-Schulung = theoretische Unterweisung:** bestanden → Unterweisung wird mit dem heutigen Datum eingetragen. Nicht bestanden → die Schulung ist gesperrt, der Atemschutzgerätewart bekommt eine Benachrichtigung und gibt sie nach der Nachschulung im Fenster „Träger-App“ mit **„Schulung freigeben“** wieder frei. Die Schulung selbst wird als `asue/schulung/index.html` eingespielt (Schnittstelle siehe SCHULUNG_SCHNITTSTELLE.md); bis dahin zeigt die App „noch nicht eingerichtet“.
- Der Atemschutzgerätewart kann die Unterweisung **weiterhin selbst im Personenblatt eintragen** (z. B. nach einer Unterweisung vor Ort, auch ohne Internet).

### Neu in 5.91
- ASÜ: **Einsatzende nur am führenden Gerät.** Die anderen verbundenen Geräte sehen unter Einsatzdaten → „Einsatz abschließen“ statt des Knopfs den Hinweis „🔒 Den Einsatz beendet nur das führende Gerät (…)“. Sie können sich unter „Mehrere Geräte“ vom Einsatz trennen. Ohne Geräteverbund (einzelnes Gerät) bleibt alles wie bisher.

### Neu in 5.91
- ASÜ: **Einsatz beenden** geht im Geräteverbund nur am **führenden Gerät**; die anderen Geräte sehen „🔒 Den Einsatz beendet nur das führende Gerät“.
- Atemschutz-Datenbank → Einsatznachweis → neue Ansicht **„🧯 Wer mit welchem Gerät“**: je Einsatz/Übung und Person Beginn, Ende, Trupp, Funktion, **Gerät, Lungenautomat, Flasche, Maske** und Flaschendruck (Beginn → Ende). Mit Jahr-, Art- und Namensfilter, Drucken und CSV (CSV jetzt auch mit LA, Flasche, Maske und Drücken). Lungenautomat, Flasche, Maske und Drücke werden jetzt auch bei eigenständiger ASÜ (ohne Geräteverbund) mitgespeichert.
- Aufbewahrung: Der Nachweis wird dauerhaft im Atemschutz-Nachweis gespeichert – also mindestens so lange wie die ASÜ-Einsatzdaten (Einstellung „Aufbewahrung beendeter ASÜ-Einsätze“); bei ausgeschiedenen Personen greift die Löschfrist (Anonymisierung), die Gerätenummern bleiben erhalten.

### Neu in 5.90
- ASÜ: Die Leiste „Überwachung der … · führt: …“ wird am **führenden Gerät** nicht mehr angezeigt (und ohne Geräteverbund auch nicht). Die anderen Geräte sehen sie weiter, damit klar ist, wessen Überwachung sie anzeigen.

### Neu in 5.89
- ASÜ → **Führung übergeben** (am führenden Gerät, ohne Passwort): Das gewählte Gerät bekommt eine Abfrage **„Führung übernehmen? – Annehmen / Ablehnen“** (mit Ton und Vibration). Erst mit „Annehmen“ wechselt die Führung. Das führende Gerät zeigt bis dahin „⏳ Übergabe angeboten – wartet auf Annahme“ mit „Zurückziehen“; bei Ablehnung kommt ein Hinweis. Das Angebot verfällt nach 10 Minuten.
- **Führung übernehmen** (an einem anderen Gerät, z. B. wenn das führende ausgefallen ist): nur noch mit **Benutzer und Passwort des führenden Geräts** (der ASÜ-Anmeldung der Wehr, z. B. „aerzen“) oder einem Admin-Zugang. Ein beliebiger anderer Wehr-Zugang reicht nicht. Jede Übergabe/Übernahme steht im Systemprotokoll.

### Neu in 5.88
- ASÜ: Reiter **„DB“ entfernt**. Die Datenbanken laufen über ihre eigenen Seiten /atemschutz und /geraete.
- Trupps (Handy): Tauglichkeitswarnung steht jetzt **in der Karte der betroffenen Person** (vorher zwischen den Karten, wirkte wie zur nächsten Person gehörig); Kamera- und ✕-Knopf auf gleicher Höhe.
- **Einzelne Person einem bestehenden Trupp zuweisen:** Person unter „Einzelne Geräteträger“ öffnen (✎) → „Einem bestehenden Trupp zuweisen“ → Trupp wählen → Zuweisen (nur Trupps mit weniger als 3 Personen; Rückfrage, wenn der Trupp schon unter Atemschutz ist).
- **Tauglichkeit sicherer:** Personen, die nicht (mehr) in der Atemschutz-Datenbank stehen, bekommen auch in den Listen die Warnung „Nicht in der Atemschutz-Datenbank – Tauglichkeit unbekannt“. Ruhend gemeldete oder ausgeschiedene Personen gelten als nicht einsatzbereit. Konnte die ASÜ die Datenbank länger als 15 Minuten nicht erreichen, steht der Stand dabei.

### Neu in 5.87
- **Wehr-Schlüssel ohne Abtippen:** Verwaltung → ASÜ-Zugänge → „🔑 Wehr-Schlüssel an ASÜ übergeben (QR / Link)“ zeigt neben dem QR-Code jetzt einen **Einrichtungslink** (im Netz der Feuerwehr / von außen) zum Kopieren oder Öffnen. Öffnet man ihn auf dem Tablet/Handy, übernimmt die ASÜ Wehr-Schlüssel und Adresse sofort. iPhone/iPad: Link in Safari öffnen, bevor die ASÜ zum Home-Bildschirm hinzugefügt wird. Der Schlüssel selbst wird weiter unter Einstellungen → Schnittstellen gepflegt.
- ASÜ → Kamera: startet jetzt **direkt mit „QR live scannen“** – ein Knopf für Personen- und Geräte-QR. „QR-Foto“, „Namensschild“ und „Etikett / Text“ bleiben als Ausweg (z. B. alte Etiketten ohne QR).
- ASÜ Handy: Seite ließ sich bei langer Serveradresse seitlich verschieben (Einsatz → Mehrere Geräte) – behoben.

### Neu in 5.86
- ASÜ → Trupps (Geräteerfassung): Darstellungsfehler auf dem Handy behoben – die erste Personenkarte wurde neben dem Knopf „QR-Übergabe“ zu schmal gezeichnet.
- **Löschen direkt in der Liste:** 🗑 neben „QR-Übergabe“ löscht den ganzen Trupp, ✕ an jeder Personenkarte löscht die Person aus dem Trupp (mit Rückfrage; Warnung, wenn schon Zeiten erfasst sind; ist es die letzte Person, wird der Trupp mit gelöscht; fällt der Truppführer weg, rückt der Nächste nach). Einzelpersonen löscht man wie bisher über „Person entfernen“ im Personenfenster, Trupps auch über „Trupp löschen“ im Bearbeiten-Fenster.

### Neu in 5.85
- ASÜ: Geht eine Person im selben Einsatz **zum 2. (oder weiteren) Mal unter Atemschutz**, erscheint beim „Beginn“ ein Hinweis mit den vorherigen Trupps und Endzeiten (bzw. „läuft noch!“) und der Erinnerung an Erholungszeit, Einsatzbereitschaft und Flaschenfüllung. Mit „OK“ geht es weiter, mit „Abbrechen“ wird nicht begonnen. Erkannt wird die Person über den QR-Code/die 4-stellige Nummer oder gleichen Namen.

### Neu in 5.84
- **Abgleich mit der Atemschutz-Datenbank:** Die ASÜ holt die Tauglichkeitsdaten jetzt jede Minute (statt alle 5 Minuten), zusätzlich sofort beim Zurückkehren in die App und beim Öffnen eines Trupps. Änderungen erscheinen ohne Neuladen in der Übersicht.
- **Handyansicht aufgeräumt:** Reiterleiste unten mit Symbolen und vollständig lesbaren Bezeichnungen, Kopfzeile „ASÜ“ statt abgeschnittenem Titel, Knöpfe gleichmäßig zweispaltig, Protokolltabelle seitlich scrollbar statt abgeschnitten, Gerätetausch-Zeile neu angeordnet (Kamera-Symbol statt fehlerhaftem Bildzeichen). In den Trupplisten erscheinen nur echte Warnungen (nicht einsatzbereit), die ausführlichen Hinweise im Bearbeiten-Fenster.

### Neu in 5.83
- ASÜ → Trupp → **Kamera → „QR live scannen“**: QR-Codes der Atemschutz-Datenbank (Person oder Atemschutzgerät) werden direkt mit der Kamera erkannt, ohne Foto. „QR-Foto“ bleibt als Ausweg.
- Die QR-Erkennung für iPad/iPhone liefert jetzt der Pi selbst aus (holt sie einmal aus dem Internet und speichert sie) – Scannen klappt damit auch, wenn das Tablet selbst kein Internet hat.
- **4-stellige Nummer:** Jede Person und jedes Atemschutzgerät bekommt eine eindeutige 4-stellige Nummer. Sie steht groß auf dem QR-Etikett. Wird sie in der ASÜ ins Feld Nachname getippt, setzt die ASÜ Name und Vorname aus der Atemschutz-Datenbank ein und meldet die Tauglichkeit.
- Tauglichkeitsprüfung zeigt jetzt immer ein Ergebnis unter der Person: „✓ einsatzbereit“, „⚠ Nicht einsatzbereit …“, „Nicht in der Atemschutz-Datenbank gefunden“ oder „Atemschutz-Datenbank nicht verbunden“ (dann ist die ASÜ nicht mit dem Pi verbunden – Wehr-Schlüssel prüfen).
- **Bitte QR-Etiketten neu drucken**, damit die 4-stellige Nummer darauf steht.

### Neu in 5.82
- ASÜ → Trupp → Scannen: Wird der **Personen-QR-Code** aus der Atemschutz-Datenbank eingelesen, prüft die ASÜ sofort die Tauglichkeit und meldet „✅ einsatzbereit“, „⛔ NICHT einsatzbereit: …“ (mit Vibration) oder „nicht in der Atemschutz-Datenbank gefunden“. Beim Übernehmen kommt bei nicht einsatzbereiten Personen weiterhin die deutliche Warnung.
- **Geräte-QR-Code** eines Atemschutzgeräts enthält jetzt Gerät, Lungenautomat und Flasche: ein Scan füllt alle drei Nummern. Die **Maske** hat weiter ihren eigenen QR-Code und wird einzeln gescannt.
- QR-Etiketten der Atemschutzgeräte zeigen unter der Gerätenummer „LA … · Fl. …“. **Wichtig:** Etiketten, die vor 5.82 gedruckt wurden, enthalten nur die Gerätenummer – für Geräte mit LA/Flasche bitte neu drucken.

### Neu in 5.81
- Atemschutz-Datenbank → Atemschutzgeräte neu aufgebaut: Ein Atemschutzgerät besteht aus **Nummer Gerät, Nummer Lungenautomat und Nummer Flasche** (ein Eintrag, gleiches Prüfdatum). Das Feld Typ/Hersteller entfällt; die Liste zeigt die drei Nummern in eigenen Spalten. (Die Auswahlfelder aus 5.80 sind dadurch ersetzt.)
- **Prüftermine eintragen** (Geräteliste): Die zwei halbjährlichen Termine der Atemschutzwerkstatt werden einmal für alle Geräte eingetragen – für eine oder alle eigenen Ortswehren. Im Gerät selbst gibt es keine Terminfelder mehr; neue Geräte übernehmen die zuletzt eingetragenen Termine automatisch.

### Neu in 5.80
- Atemschutz-Datenbank → Atemschutzgeräte: Einem Pressluftatmer lassen sich jetzt ein Lungenautomat und eine Atemluftflasche derselben Ortswehr zuordnen (im Gerät unter „Bearbeiten“). In der Geräteliste steht beim Pressluftatmer „LA … · Fl. …“, beim Lungenautomaten bzw. bei der Flasche „an PA …“. Ein Teil gehört immer nur zu einem Pressluftatmer – wird es einem anderen zugeordnet, wird es beim bisherigen automatisch ausgetragen.

### Neu in 5.79
- Verwaltung → Gerätewarte: neuer Abschnitt „👑 Leitung je Ortswehr“. Für jede Ortswehr wählt der Admin aus den aktiven Zugängen dieser Ortswehr, wer die Leitung hat. Die Leitung sieht in der Gerätedatenbank unter 👤 den Punkt „Gerätewarte“ und darf dort Zugänge ihrer Ortswehr anlegen, sperren und Kennwörter zurücksetzen. Ist niemand gewählt, gilt wie bisher der zuerst angelegte Zugang.

### Neu in 5.78
- Gerätedatenbank auf dem Handy: Der „⋯“-Knopf an den Fahrzeugkarten sitzt auch auf Android-Geräten mittig in der Karte; das Benutzermenü wird am rechten Rand nicht mehr abgeschnitten.

### Neu in 5.77
- Einheiten → Detailansicht eines Fahrzeugs, das seinen Status über PowerAlarm bekommt: Das FMS-Raster entfällt. Neben „Ausrüstung“ steht nur noch der Knopf „A Alarmiert“; darunter der zuletzt gelesene PowerAlarm-Status.

### Neu in 5.76
- Gerätedatenbank am PC: Die Überschrift „Gerätedatenbank“ unter der Leiste ist entfernt; „Feedback“ und das Benutzermenü stehen jetzt rechts oben in der Reiterleiste.

### Neu in 5.75
- Übersicht Fahrzeuge und Material: Der Zusatz „für den Gemeindebrandmeister · Stand …“ in der Kopfzeile ist entfernt.

### Neu in 5.74
- Gerätedatenbank: Der überflüssige Reiter „Datenbank“ oben ist entfernt – die Bereich-Buttons stehen direkt in der Leiste.

### Neu in 5.73
- Gerätedatenbank am PC: Die Bereich-Buttons und die Geräteanzahl stehen jetzt oben in der Reiterleiste neben „Datenbank“. Auf Handy und Tablet bleibt alles wie bisher.

### Neu in 5.72 – Gerätedatenbank am PC: ein Knopf „Prüfen“

- Am PC stehen „Prüfung im Stapel“ und „Prüfen am Fahrzeug“ hinter einem Knopf **✅ Prüfen ▾**. Er öffnet eine kleine Auswahl; ein Klick daneben schließt sie wieder. Auf Handy und Tablet bleibt „Prüfen“ unten in der Leiste.

### Neu in 5.71 – Gerätedatenbank: „aus Foto“ entfernt, am PC alles in einer Reihe

- Der Knopf **„🖼 aus Foto“** ist entfallen. Zum Öffnen eines Geräts dienen „📷 Scannen“ oder die normale Handy-Kamera (Link im Etikett).
- **Am PC** gibt es keinen „⋯ Mehr“-Knopf mehr. Alle Funktionen stehen in einer Reihe über der Liste: Gerät, Scannen, Prüfung im Stapel, Prüfen am Fahrzeug, Wo ist …?, Diesen Monat fällig, Monatsliste, Begriffe/Vorlagen/Listen und Excel.
- Auf Handy und Tablet bleibt „Mehr“ unten in der Leiste, ohne die Prüf-Einträge, die schon unter „Prüfen“ stehen.

### Neu in 5.70 – Gerätedatenbank auf Handy und Tablet

- **Untere Leiste**: ＋ Gerät · 📷 Scannen · ✅ Prüfen · ⋯ **Mehr**. „Mehr“ öffnet wie „Prüfen“ ein Menü mit allen weiteren Funktionen. Tippt man daneben ins Bild, gehen beide Menüs wieder zu.
- **Druckansichten** (z. B. „Diesen Monat fällig“) öffnen auf Handy und Tablet in einem Fenster im Programm, mit **🖨 Drucken** und **Schließen**. So kommt man immer zurück.
- **Ein Fenster „⚙ Begriffe, Vorlagen & Listen“** mit drei Reitern: Einheitliche Begriffe, Gerätevorlagen sowie Listen & Prüfarten. Auf dem Handy sind die Tabellen als Karten untereinander dargestellt und vollständig bearbeitbar.
- Der Knopf **„Etiketten“** ist entfallen; das Etikett gibt es bei jedem Gerät.
- **Wochenüberblick und Jahresbericht** stehen im Bereich **🏛 Übersicht**.

### Neu in 5.69 – Status über PowerAlarm, feste Leisten in der Verwaltung

- **Fahrzeuge mit Status über PowerAlarm** (oder per E-Mail): Die Detailansicht zeigt nur noch den **aktuellen Status** und den Knopf **A (Alarmiert)**. Dazu kommt ein Hinweis, welcher Status zuletzt gelesen wurde und wann.
- **A gedrückt**: Das Fahrzeug bleibt auf „A“, bis über PowerAlarm **Status 3** (oder 4) kommt. Andere Meldungen (1, 2, 6) ändern daran nichts.
- **Einsatz beendet, Fahrzeug noch auf „A“**: Das Fahrzeug geht auf den **zuletzt gelesenen Status** zurück, z. B. 6 oder 2. Fahrzeuge, die 3/4 gemeldet hatten, gehen wie gewohnt auf 2.
- **Verwaltung**: Die beiden Reiterleisten oben (Fahrzeuge & Geräte, Personen & Zugänge, … System und darunter Fahrzeuge, Gerätewarte, …) bleiben beim Scrollen stehen.

### Neu in 5.68 – Gerätedatenbank: feste Leiste unten auf Handy und Tablet

- Auf Handy und Tablet liegen **＋ Gerät**, **📷 Scannen** und **✅ Prüfen** als feste Reiter am unteren Rand. Sie sind immer erreichbar, auch beim Scrollen durch lange Gerätelisten.
- **Prüfen** öffnet eine kleine Auswahl: „Prüfung im Stapel“ oder „Prüfen am Fahrzeug“.
- Am PC bleiben die Knöpfe wie gewohnt über der Liste.

### Neu in 5.67 – Fensterüberschrift bleibt stehen

- In allen Fenstern (Popups) der Einsatzverwaltung bleiben die Überschrift und das ✕ zum Schließen beim Scrollen oben stehen. So sieht man immer, in welchem Fenster man gerade ist.
- Dasselbe gilt in der Fahrzeug-App, z. B. für Schaden melden, Verbrauch, Fahrzeug-Check, Beladung prüfen, Lagemeldung und Feedback. In der Gerätedatenbank und der Atemschutzüberwachung waren die Fensterköpfe schon fest.

### Neu in 5.66 – Ablaufplan übersichtlicher

- **Kopfzeile**: Plan, Führungsstelle und „x von y Plätzen besetzt“ auf einen Blick. Rechts stehen die Auswahl ELW/ÖEL, die Umschaltung **▤ Ein Platz / ▦ Alle Plätze** sowie Erklärung, Mein Platz und Bearbeiten.
- **Besetzungsleiste**: Alle Plätze stehen als kleine Kacheln mit Name, „besetzt durch“ (oder *frei*) und Fortschritt. Der grüne Rand zeigt besetzte Plätze, 🪑 den eigenen Platz und 🎯 Plätze, die Feuerwehren betreuen. Ein Tipp auf eine Kachel öffnet den Platz.
- **Ein Platz**: Der gewählte Platz (vorgegeben: der eigene) steht groß mit Erklärung, Besetzung/Übergeben und allen Schritten.
- **Alle Plätze**: Alle Plätze nebeneinander, kompakt ohne Erklärung.
- **Rechte Spalte**: Knopf „🎯 Meine Feuerwehren“ (bei Plätzen mit 🎯), „Was macht das Team?“ und die Hilfsmittel EL ↔ Führung. Auf Tablet und Handy steht die Spalte darunter.

### Neu in 5.65 – Objekt-Eingabe überarbeitet

- Die Seite „Objekt anlegen/bearbeiten“ ist in Abschnitte gegliedert:
  - **🏷 Grunddaten**
  - **📍 Lage**: Adresse, Koordinate, Ort
  - **🚒 Für den Einsatz**: Merkmale, Hinweise, Ansprechpartner, Suchbegriffe
  - **📄 Pläne und Dokumente**
- **Art per Antippen**: Alle Arten stehen mit ihrem Kartensymbol als Kacheln da. Darunter lässt sich bei Bedarf eine eigene Art eintragen.
- **Merkmale als Schaltflächen**: antippen = an (blau). Die bisherigen, verrutschten Ankreuzkästchen sind weg. Weitere Merkmale lassen sich mit Komma getrennt ergänzen.
- **Speichern, Abbrechen und Löschen** bleiben beim Scrollen unten sichtbar. Auf dem Handy stehen die Art-Kacheln zweispaltig.

### Neu in 5.64 – Objekte und Ansprechpartner: Symbole und Filter

**Objekte**
- **Sprechende Symbole je Art**, in der Liste, im Einsatz und **auf der Lagekarte** als farbige Nadel:
  - 🏭 Industrie
  - 🏫 Schule/Kita
  - 🏥 Pflegeheim/Krankenhaus
  - 🏟 Versammlungsstätte
  - 🚜 Landwirtschaft
  - ☣️ Gefahrstoffe
  - 🏘 Wohnanlage
  - 🏨 Hotel
  - ⛪ Kirche/Denkmal
  - 🏛 Behörde
  - ⛽ Tankstelle/Energie
  - 💧 Wasser/Abwasser
  - 🚆 Verkehr/Bahn/Tunnel
  - 🛒 Handel
  - 📍 Sonstiges

  Das Symbol ergibt sich aus der „Art“; frei eingetragene Arten werden über Stichworte erkannt (z. B. „Biogasanlage“ → 🚜).
- **Merkmale je Objekt** (ankreuzen, eigene möglich): Feuerwehrplan, Laufkarten, BMA, Schlüsseldepot, Feuerwehrzufahrt, Löschwasser vor Ort, Gefahrstoffe, Personen mit Hilfebedarf, Tiere, PV-Anlage, Sprinkler.
- **Filter** über der Liste: nach Art (mit Anzahl), „mit Plänen“, „mit Hinweisen“, „bis 1,5 km vom Einsatz“, „ohne Koordinate“ und jedes Merkmal. Sortieren nach Name, Art oder Entfernung zum Einsatzort.
- Der **Art-Filter gilt auch für die Lagekarte**: Wer z. B. nur 🏥 und 🏫 auswählt, sieht auf der Karte nur diese Objekte.

**Ansprechpartner**
- **Kategorie** mit Symbol: 👤 Person, 🛠 Dienstleistung, 🚜 Gerät/Material, 🏛 Behörde/Versorger.
- Neue Felder:
  - **Was kann er/sie?**: Stichworte, z. B. Bagger, Radlader, Tierarzt, Dolmetscher, Kran, Sandsäcke; mit Vorschlagsliste.
  - **Ort**
  - **⏰ 24 h erreichbar**
- **Filter** nach Kategorie, Ort, „24 h erreichbar“ und Stichworten, beim Pflegen (Objekte → Ansprechpartner) und auch **im Einsatz** bei „Ansprechpartner suchen“. Damit findet man z. B. schnell „🚜 Gerät + Bagger + 24 h“.
- Der CSV-Export/-Import enthält zusätzlich die Spalten Kategorie, Stichworte, Ort und 24h.

### Neu in 5.63 – Fahrzeugkarten aufgeräumt

- In der Fahrzeugübersicht (Einheiten) steht der Status-Hinweis jetzt in der Mitte der Karte, z. B. „6 Außer Dienst“, „A Alarmiert 2026-095“ oder „4 Am Einsatzort“. Links bleiben Funkrufname, Funktion und Ortswehr, rechts der Status-Knopf. Die Karten werden dadurch niedriger, und es passen mehr auf den Bildschirm.
- Auf dem Handy rutscht der Hinweis unter den Namen.
- Korrektur zu 5.62: Die neuen Gestaltungsregeln (einheitliche Knöpfe, Nachtmodus der neuen Ansichten, Ladeanzeige, „Rückgängig“-Hinweis) wirken jetzt wirklich in der App.

### Neu in 5.62 – Aussehen und Bedienung

- **Einheitliche Knöpfe**: gleiche Rundungen und Mindesthöhen, ein deutlicher Fokusrahmen bei Tastaturbedienung und eine kurze Rückmeldung beim Antippen.
- **Nachtmodus**: Ablaufplan, Editor, Meine Feuerwehren und ELW-Info sind auf den Nachtmodus abgestimmt (gedämpftes Rot, keine hellen Flächen).
- **Statusfarben gleich**: In Ablaufplan, Meine Feuerwehren und ELW-Info stehen die Status jetzt in denselben Farben wie überall:
  - 1/2 grün
  - A orange
  - 3 hellblau
  - 4 blau
  - 6 grau
- **Rückgängig statt Rückfrage**: Im Editor der Ablaufpläne gibt es keine „Wirklich?“-Fenster mehr für Platz löschen, Schritt löschen und Vorgabe. Stattdessen erscheint 10 Sekunden lang „↶ Rückgängig“. Dasselbe gilt, wenn im Ablaufplan ein Haken entfernt wird.
- **Wischen**: In der Einsatzansicht und in der ELW-Info wechselt Wischen nach links oder rechts zum nächsten bzw. vorigen Reiter. Auf Karten, in Eingabefeldern und in den Reiterleisten selbst ist das Wischen aus.
- **Direkt zum eigenen Platz**: Unter 👁 Meine Ansicht bzw. „🪑 Mein Platz“ gibt es „Beim Öffnen eines Einsatzes direkt zu meinem Platz“. Danach öffnet sich der Einsatz gleich im Ablaufplan, bei Plätzen mit 🎯 in „Meine Feuerwehren“.
- **Ladeanzeige**: Beim Verbinden dreht sich eine Ladeanzeige unter dem Wappen.
- **Eindeutigere Symbole**: In der ELW-Info heißt der Reiter „Lage“ jetzt 📢 statt 📋. Die Fahrzeugdaten in der Gerätedatenbank haben 🚒 statt 📋.

### Neu in 5.61 – ELW-Info offline, Großanzeige, Ablöse, Meldungen der betreuten Wehren

- **ELW-Info: Verbindung weg.** Reißt das VPN ab, bleibt der letzte Stand stehen. Ein oranger Hinweis zeigt dann „Verbindung zum Pi unterbrochen – Stand von hh:mm Uhr“. Die App verbindet sich von selbst neu.
- **ELW-Info: neue Reiter.**
  - 📌 **Aufträge** erscheint nur bei Sonderlagen und zeigt die offenen Aufträge zuerst.
  - 🧑‍🚒 **Atemschutz** erscheint, sobald eine Atemschutzüberwachung angeschlossen ist. Er zeigt die Trupps im Einsatz, bereit und waren im Einsatz, je ASÜ mit der letzten Meldung.
  - Die Restzeiten der einzelnen Trupps bleiben auf dem ASÜ-Tablet.
- **Großanzeige (Monitor).**
  - Mit **/elw?monitor=1** oder unter ⚙ „Großanzeige“ werden die Reiter ausgeblendet und die Schrift größer.
  - Lagekarte, Abschnitte, Lage, Feuerwehren, Aufträge und Atemschutz wechseln automatisch, vorgegeben alle 20 Sekunden (einstellbar).
- **Meine Feuerwehren.** Der Reiter zeigt die Zahl der ungelesenen Nachrichten der betreuten Feuerwehren. Kommt eine neue Nachricht, gibt es einen kurzen Signalton und einen Hinweis.
- **Platz übergeben (Pausenablöse).** Im Ablaufplan hat jeder besetzte Platz den Knopf **⇄ Übergeben**. Ins Tagebuch kommt dann z. B. „ÖEL Platz 3: übergeben von A an B (Ablöse)“.
- **Fahrzeug-App-Schalter jetzt auch am Pi gesperrt.** Ausgeschaltete Meldungen (Schaden, Verbrauch, Beladung, Check) lehnt der Pi ab, auch wenn noch eine alte App-Version offen ist.
- **Gerätedatenbank: Einstellungen übernehmen.** Im Reiter 📱 Fahrzeug-App gibt es „Einstellungen übernehmen von …“. Damit kopiert man Schalter und Check-Punkte eines anderen Fahrzeugs; gleiche Fahrzeugtypen stehen oben. Danach noch Speichern.

### Neu in 5.60 – neues App-Icon für die Einsatzverwaltung

- Die Einsatzverwaltung hat ein eigenes Icon: eine weiße Einsatzstellen-Nadel mit Flamme auf feuerwehrrotem Grund mit Kartenraster. Es gilt für den Home-Bildschirm (iPhone/iPad und Android), den Browser-Tab und die ELW-Info-App.
- Damit ist es klar vom Gerätewart-Icon (blau, Klemmbrett) und von der Atemschutzüberwachung (gelb) zu unterscheiden.
- **Auf den Home-Bildschirm legen**:
  - iPhone/iPad: Safari → Teilen → „Zum Home-Bildschirm“.
  - Android: Chrome → ⋮ → „Zum Startbildschirm hinzufügen“ bzw. „App installieren“.
- Ein schon vorhandenes Symbol einmal entfernen und neu hinzufügen, sonst bleibt das alte Icon.

### Neu in 5.59 – eigenes App-Icon für die Gerätedatenbank

- Die Gerätedatenbank (Gerätewart) hat ein eigenes Icon: Klemmbrett mit Prüfhaken und Schraubenschlüssel auf blauem Grund. Bisher war es das Atemschutz-Icon mit „GW“-Schild.
- Das Icon erscheint auf dem Startbildschirm, im Browser-Tab und bei Push-Mitteilungen.
- Wer die App schon auf dem Startbildschirm hat, muss sie dafür einmal entfernen und neu hinzufügen. iOS übernimmt ein neues Icon sonst nicht.

### Neu in 5.58 – ELW-Info-App (nur Ansicht)

- Eigene App fürs Tablet im ELW (Vorgabe **14-11-10**), erreichbar über das VPN unter **http://‹Pi-Adresse›:8080/elw**. Die Anmeldung läuft wie in der Einsatzverwaltung; am besten legt man dafür einen Benutzer mit der Rolle **Betrachter** an. Die App zeigt nur an, bearbeitet wird weiter in der Einsatzverwaltung.
- **Welcher Einsatz**: Gezeigt wird automatisch der Einsatz, in dem das eigene Fahrzeug aktiv ist, sonst der neueste laufende. Laufen mehrere Einsätze, kann man oben umschalten. Das Fahrzeug stellt man unter ⚙ ein; die Einstellung gilt nur auf diesem Tablet.
- **Kopfzeile**: Stichwort, Nummer, Einsatzort, Zahl der Fahrzeuge, Stärke, Einsatzdauer und Uhr.
- **Reiter**:
  - 🗺 **Lagekarte** mit Einsatzort, Zeichen, Abschnittsflächen und Fahrzeugpositionen; Zoom mit ＋/－ und ⤢ für „alles zeigen“.
  - ♟ **Taktik**: die Einsatztaktik-Karte.
  - 📋 **Lage**: Einsatzdaten, die letzte Lagemeldung, Kräfte, Nachforderungen und die letzten Tagebucheinträge.
  - 🚒 **Feuerwehren**: eingesetzte Fahrzeuge nach Ortswehr, mit Status, Stärke und Abschnitt.
  - 🧩 **Abschnitte** mit Leiter, Kanal, Auftrag und Fahrzeugen.
  - 📞 **Ansprechpartner**: Telefonnummern zum Antippen.
  - ☣️ **Gefahrstoffe** mit Warntafel (Gefahrnummer/UN-Nummer) und Klasse.
- Alles aktualisiert sich live, wenn in der Einsatzverwaltung etwas geändert wird.

### Neu in 5.57 – Platz automatisch besetzt, Ansicht „Meine Feuerwehren“

- **Name automatisch**: Wer einen Platz als „Mein Platz“ gewählt hat, wird beim Öffnen des Ablaufplans dort automatisch unter „besetzt durch“ eingetragen, mit Vermerk im Tagebuch. Ist der Platz schon besetzt, wird nichts überschrieben; der Name lässt sich jederzeit ändern.
- **Neue Einsatz-Karte 🎯 Meine Feuerwehren**: Sie erscheint, wenn der eigene Platz 🎯 hat (im ÖEL z. B. Platz 2 und 3).
  - Oben stehen die betreuten Feuerwehren (aufklappbar zum Ändern), die Zahl der Fahrzeuge, die Stärke und die offenen Aufträge.
  - Darunter folgen drei Spalten: **📌 Aufträge** dieser Feuerwehren, **🚒 Fahrzeuge** (Status, Stärke, Auftrag, ✉ einzeln anschreiben) und **💬 Nachrichten** von und an diese Fahrzeuge. Ungelesene Nachrichten sind rot markiert und haben die Knöpfe „✓ Gelesen“ und „↩ Antworten“.
  - Dazu gibt es die Knöpfe „Nachricht an diese Fahrzeuge“, „Lagemeldung“ und „Nachforderung an Platz 1“.
  - Auf dem Tablet stehen die Spalten zu zweit, auf dem Handy untereinander.
- Im Ablaufplan führt der Knopf „🎯 Meine Feuerwehren öffnen“ direkt in diese Ansicht.

### Neu in 5.56 – Editor für die Ablaufpläne neu gestaltet

- Oben stehen die Umschaltung ELW / ÖEL, Titel und Erklärung des Plans und „↺ Vorgabe“ (mit Rückfrage).
- **Links die Plätze**: Antippen wählt einen Platz aus, mit ▲▼ lässt sich die Reihenfolge ändern, und „＋ Platz hinzufügen“ legt einen neuen an.
- **Rechts der gewählte Platz** mit Name, Wer, Erklärung und 🎯 „nur bestimmte Feuerwehren betreuen“.
- **Schritte als einzelne Zeilen**: Jede Zeile hat ein eigenes Feld und daneben diese Knöpfe:
  - **Ü** macht die Zeile zur Zwischenüberschrift.
  - **⇥** rückt die Zeile ein.
  - **▲▼** verschiebt die Zeile.
  - **✕** löscht die Zeile.

  Enter im Feld legt direkt darunter einen neuen Schritt an. Dazu gibt es „＋ Schritt“, „＋ Überschrift“ und „🗑 Platz löschen“ (mit Rückfrage).
- Gerätedatenbank → Fahrzeugdaten → **📱 Fahrzeug-App** ist neu gestaltet: Jede Funktion steht in einer eigenen Zeile mit kurzer Beschreibung und einem Schalter (grün = an). Die eigenen Check-Punkte stehen darunter in einem eigenen Feld.
- Speichern und Abbrechen bleiben beim Scrollen unten sichtbar. Auf dem Handy stehen Plätze und Platz untereinander.

### Neu in 5.55 – Erklärungen im Ablaufplan

- **Ganzer Plan**: Oben in der Karte 🪑 Ablaufplan steht „ℹ Was macht das Team ELW/ÖEL?“, eine kurze Erklärung des gewählten Plans, die man aufklappen kann. Der Knopf **ℹ Erklärung** zeigt alle Plätze mit Erklärung und Schritten und kann sie drucken.
- **Gewählter Platz**: Wer über „Mein Platz“ einen Platz gewählt hat, sieht dessen Erklärung oben im Kasten „🪑 Dein Platz“. Das ℹ an jeder Platz-Kachel öffnet die Erklärung nur für diesen Platz; von dort geht es mit „Alle Plätze“ weiter zum ganzen Plan.
- Im Editor (✏ Bearbeiten) lassen sich die Erklärung des Plans und jedes Platzes anpassen. „Vorgabe wiederherstellen“ setzt auch die Erklärungen zurück.

### Neu in 5.54 – Fahrzeug-App je Fahrzeug einstellen

- Gerätedatenbank → Fahrzeug → ⋯ → Fahrzeugdaten → neuer Reiter **📱 Fahrzeug-App**. Dort legt der Gerätewart je Fahrzeug fest, was die Besatzung in der Fahrzeug-App sieht und melden kann:
  - 🔧 Schaden melden
  - 📦 Verbrauch nachfüllen
  - ✅ Fahrzeug-Check
  - ✅ Check-Hinweis nach dem Einsatz
  - 🔍 Beladung prüfen
  - 🚦 Geräte-Ampel auf der Startseite
  - ⏰ Fahrzeug-Fristen im Fahrtenbuch
- **Eigene Check-Punkte je Fahrzeug**: eine Zeile je Punkt. Bleibt das Feld leer, gilt die Checkliste der Ortswehr.
- Was ausgeschaltet ist, verschwindet aus dem Menü der Fahrzeug-App. Sind Schaden, Verbrauch, Check und Beladung alle aus, entfällt der 🔧-Knopf ganz.
- Die Grundeinstellung ist „alles an“, für bestehende Fahrzeuge ändert sich also nichts.

### Neu in 5.53 – Ablaufpläne Team ELW / ÖEL

- Neue Einsatz-Karte **🪑 Ablaufplan**. Sie zeigt automatisch den passenden Plan zur Führungsstelle des Einsatzes (ELW oder ÖEL). Über die Auswahl oben kann man auf den anderen Plan umschalten.
- Jeder Platz ist eine Kachel mit Wer, „besetzt durch …“, Fortschritt und abhakbaren Schritten. Besetzung und jeder abgehakte Schritt stehen mit Uhrzeit im Einsatztagebuch.
- **Mein Platz**: über 👁 Meine Ansicht oder den Knopf „🪑 Mein Platz“ wählt jede/r seinen Platz für ELW und ÖEL (nur für sich, auf diesem Gerät). Der eigene Platz steht vorn und ist rot umrandet; „nur mein Platz“ blendet die anderen aus.
- **Hilfsmittel EL ↔ Führung**: Felder für Einsatzabschnitte/Führungsstruktur, Kommunikationsstruktur, Einsatzschwerpunkt und Nachforderungen, gespeichert je Einsatz.
- **🎯 Meine Feuerwehren** (ÖEL, Plätze 2 und 3): Wer einen Platz mit 🎯 als „Mein Platz“ hat, wählt oben die betreuten Ortswehren. Angezeigt werden nur deren Fahrzeuge mit Status, Stärke und Auftrag sowie die zugehörigen Aufträge. Dazu gibt es die Knöpfe „Nachricht an diese Fahrzeuge“, „Lagemeldung ins Tagebuch“ und „Nachforderung an Platz 1“. Eine Nachforderung landet im Tagebuch und bei den Hilfsmitteln.
- **✏ Bearbeiten** (Admin, Einsatzleiter, GBM): Titel, Plätze, Beschreibung und Schritte anpassen. Plätze lassen sich hinzufügen, löschen und verschieben, und 🎯 „nur bestimmte Feuerwehren“ kann man je Platz ein- und ausschalten. „Vorgabe wiederherstellen“ setzt den Plan auf den Stand der PDF-Ablaufpläne (ELW v1.0, ÖEL v1.4) zurück. Schritte stehen eine Zeile je Schritt; eine Zeile mit „:“ am Ende ist eine Zwischenüberschrift, Leerzeichen am Anfang rücken ein.

### Neu in 5.52: Nur Klarnamen von Personen überspringen

Das Kästchen unter „Fahrzeugstatus von außen“ heißt jetzt **„Keine Personen auswerten“**. Übersprungen werden nur noch Kontakte mit **Klarnamen** (nur Buchstaben, keine Ziffern, keine OPTA-Kennung – z. B. „Max Mustermann“). **Funktionen wie OrtsBM, StvOBM, GemBM** (z. B. „FL HM 14-03-31“ / „NIFW HM 14 03 ORTSBM 31“) werden wieder ganz normal ausgewertet. (Ersetzt die Regel aus 5.51.)

### Neu in 5.51: Nur Fahrzeuge aus PowerAlarm auswerten

Unter Verwaltung → ⚙️ System → Einstellungen → „Fahrzeugstatus von außen“ gibt es das Kästchen **„Nur Fahrzeuge auswerten“** (Vorgabe: an). Dann werden Statusmeldungen von Personen und Funktionen übersprungen – erkannt an der Bezeichnung/OPTA aus PowerAlarm (z. B. „ORTSBM“, „STVOBM“, „GEMBM“, Pressewart …) bzw. am Fahrzeugtyp in der Einsatzverwaltung (OrtsBM, GemBM, Pressewart, Feuerwehrhaus, ohne Fahrzeugtyp). Gilt für den Websocket und den HTTP-Kontakt. Übersprungene Meldungen erscheinen nicht im Protokoll und nicht in der Zuordnungsliste.

### Neu in 5.50: „⋯ Mehr“ / „▴ Weniger“

In der Geräte-/Atemschutzdatenbank zeigt der Knopf „⋯ Mehr“ nach dem Aufklappen „▴ Weniger“ – antippen klappt das Menü wieder zu.

### Neu in 5.49: „Alarmiert“ bleibt bis Status 3, automatisches Beenden

- **Alarmiert bleibt stehen:** Ein Fahrzeug bzw. eine Einheit, die bei einer Alarmierung auf **A (alarmiert)** gesetzt wurde, bleibt auf A, bis **Status 3** (oder 4) kommt oder der Einsatz beendet wird. Statusmeldungen von außen (PowerAlarm-Websocket, HTTP-Kontakt, E-Mail „Status Änderung …“) mit 1, 2 oder 6 werden in dieser Zeit ignoriert (Protokoll: „ignoriert: … bleibt alarmiert bis Status 3“). Von Hand in der Einsatzverwaltung kann der Status weiterhin jederzeit geändert werden.
- **Automatische Beendigung:** Bei automatisch angelegten Einsätzen zählen jetzt nur noch Fahrzeuge, die **mindestens in Status 3** waren: Sind diese alle wieder auf 1/2 (10 Minuten Ruhe), wird der Einsatz beendet. Fahrzeuge, die nur alarmiert wurden und nie ausgerückt sind, halten den Einsatz nicht mehr offen. Ist gar kein Fahrzeug ausgerückt, gilt wie bisher die eingestellte Zeit.

### Neu in 5.48: Fahrzeuge aus PowerAlarm automatisch erkennen

PowerAlarm schickt je Fahrzeug z. B. `{"bezeichnung":"FL HM 14-03-31","kennung":"00000000","opta":"NIFW HM 14 03 ORTSBM 31","status":"2"}`. Bisher wurde die leere Kennung „00000000“ genommen – daher „Fahrzeug unbekannt“. Jetzt:
- Kennungen aus lauter Nullen werden ignoriert; genommen werden **Bezeichnung**, dann **OPTA**, Name, Kennung, ISSI.
- Der **Funkrufname wird in der Bezeichnung gesucht** („FL HM 14-03-31“ → Fahrzeug 14-03-31).
- Direkt nach dem Verbinden schickt PowerAlarm den Stand aller Fahrzeuge – die Status werden übernommen. Ist der Status schon gleich, passiert nichts (kein Eintrag im Protokoll).
- Fahrzeuge, die es in der Einsatzverwaltung nicht gibt, stehen weiter unter „Zuordnung“ mit ihrer Bezeichnung und können dort einem Fahrzeug zugeordnet werden.

### Neu in 5.47: Fahrzeugstatus über den PowerAlarm-Websocket (PA-Monitor-Key)

PowerAlarm bietet eine Websocket-Schnittstelle (Anleitung PowerAlarm, Kapitel 10: `wss://www.poweralarm.de:8001`, Anmeldung mit dem API-Key). Darüber liefert PowerAlarm Rückmeldungen, Alarme, den **Status der Kontakte/Fahrzeuge** und News.

**Einrichten:** Verwaltung → Einstellungen → **PowerAlarm** → „PA-Monitor API-Key (Websocket – Fahrzeugstatus empfangen)“ eintragen und speichern. Der Pi baut die Verbindung sofort auf, hält sie dauerhaft offen und verbindet sich bei Unterbrechung selbst neu (5 s, dann länger, höchstens alle 5 min). Keine Portfreigabe nötig – der Pi baut die Verbindung nach außen auf.

**Was passiert:** Statusänderungen von Fahrzeugen werden wie beim HTTP-Kontakt („Fahrzeugstatus von außen“) übernommen – gleiche Fahrzeug-Zuordnung, gleiches Protokoll „Zuletzt empfangen“ (Quelle „PowerAlarm (Websocket)“). Unter Verwaltung → **Fahrzeugstatus von außen** steht, ob der Websocket verbunden ist, die Status-Übersicht laut PowerAlarm und die letzten Nachrichten (auch nicht ausgewertete). Rückmeldungen und News werden ignoriert; Alarme kommen weiter über den bisherigen Weg.

Hinweis: Die Anleitung zeigt für den Fahrzeugstatus nur die Zusammenfassung (Anzahl je Status). Einzelne Fahrzeugmeldungen werden automatisch erkannt (Funkrufname/Kennung + Status). Falls PowerAlarm sie anders schickt, erscheinen sie unter „Letzte Websocket-Nachrichten“ als „nicht ausgewertet“ – dann eine solche Zeile schicken, die Auswertung wird angepasst.

### Neu in 5.46: Statusmeldungen per E-Mail/PowerAlarm lösen keinen Alarm aus

Enthält eine Alarm-E-Mail oder ein PowerAlarm-Alarm eine Zeile **„Status Änderung X => Y“** (z. B. „Gruppe für Testalarme FL HM 14-19-10 / Status Änderung 6 => 2“), wird **kein Einsatz angelegt**. Stattdessen sucht die Einsatzverwaltung den genannten Funkrufnamen (hier 14-19-10) und setzt das Fahrzeug auf den neuen Status (hier 2). Im Mail-Protokoll steht „Statusmeldung: 14-19-10 Status 6 → 2 (kein Alarm)“; wird kein Fahrzeug gefunden, wird die Meldung nur protokolliert.

### Neu in 5.45: Bereiche als Menü in der Handy-Ansicht

In der Handy-Ansicht der Geräte-/Atemschutzdatenbank ist die Zeile mit den Bereichen (Gerätedatenbank, Kalender, Lager, Übersicht …) entfallen. Stattdessen steht oben links ein aufklappbares Menü **„☰ Gerätedatenbank ▾“**, das den aktuellen Bereich zeigt; antippen und den gewünschten Bereich wählen. Auf Tablet und PC bleibt die Zeile wie bisher.

### Neu in 5.44: Feuerwehrhäuser eindeutig je Gemeinde/Stadt

- Jedes Feuerwehrhaus gehört zu einer **Gemeinde/Stadt** (neues Feld, aus der Fahrzeugliste) und einer Ortswehr. Je Gemeinde/Stadt und Ortswehr gibt es **nur ein** Feuerwehrhaus – beim Anlegen, beim Abgleich, beim Import aus OpenStreetMap und beim Speichern auf dem Pi wird das geprüft (Doppelte werden zusammengeführt, das mit Koordinate bzw. „geprüft“ bleibt).
- **Führend ist die Gemeinde/Stadt:** Einträge wie „Kreisfeuerwehr …“, „Kreisfeuerwehrbereitschaft KatS“, THW, DRK, DLRG usw. in der Spalte Stadt gelten nicht als eigene Gemeinde – z. B. „Groß Berkel“ ist nur einmal (Aerzen) angelegt, auch wenn ein Kreisfahrzeug dort steht.
- Gleichnamige Orte in verschiedenen Gemeinden (z. B. Rohrsen in Hameln und Bad Münder) bekommen je ein eigenes Haus.

### Neu in 5.43: Alarmmonitor schlanker

Auf dem Alarmmonitor entfallen die Bereiche **„Kräfte, Fahrzeug & Mittel laut Stichwort“** und **„Weitere Kräfte laut Alarmierung“**. Stichwort, Einsatzort, Karte, alarmierte Ortsfeuerwehren und Fahrzeuge, Fahrzeuge der eigenen Ortswehr, Hydranten/Rettungspunkt und Navigation bleiben.

Außerdem: Meldet sich der **Superadmin** in der Einsatzverwaltung oder der Datenbank der Gerätewarte an, kommt **kein Sicherheitshinweis** mehr (Mail/Push). Die Anmeldung steht weiterhin im Anmeldeprotokoll.

### Neu in 5.42: Feuerwehrhäuser abgleichen, Leitung der Gerätewarte je Ortswehr

**Verwaltung → Feuerwehrhäuser → „🔄 Mit Fahrzeugliste abgleichen“:** Für jede Ortswehr, zu der Fahrzeuge eingepflegt sind, gibt es danach genau ein Feuerwehrhaus. Bekannte Standorte bleiben erhalten (bei doppelten Einträgen der mit Koordinate); für neue Häuser wird – wenn vorhanden – die GPS-Position des Fahrzeugs „Feuerwehrhaus“ der Ortswehr übernommen. Alle anderen Einträge (Ortswehren ohne Fahrzeuge, Doppelte) werden gelöscht. Vorher zeigt ein Fenster, was bleibt, neu angelegt und gelöscht wird. Neue Häuser ohne Koordinate danach mit „Bearbeiten“ oder „🛰 Aus OpenStreetMap ergänzen“ vervollständigen.
*Fehlerbehebung:* Fehlende Koordinaten wurden bisher beim Speichern als 0,0 abgelegt – das wird beim Start automatisch repariert.

**Gerätewarte: Leitung je Ortswehr.** Der zuerst angelegte Gerätewart einer Ortswehr hat die **Leitung** (👑). Er findet unter 👤 → **„👥 Gerätewarte …“**:
- **Neuen Gerätewart anlegen** (Name, Benutzername, E-Mail, Startkennwort, Bereiche Atemschutz/Geräte – nur für die eigene Ortswehr),
- **🔑 Kennwort** (neues Startkennwort), **Sperren / Entsperren**, **🗑 Löschen**,
- **👑 Leitung übergeben** an einen anderen Gerätewart der Ortswehr.
Zugänge, die auch zu anderen Ortswehren gehören, bleiben beim Administrator der Einsatzverwaltung. Dort steht in Verwaltung → Gerätewarte, wer die Leitung hat. Alle Änderungen stehen im Protokoll.

### Neu in 5.41: E-Mail-Adresse selbst pflegen

Gerätewarte tragen ihre E-Mail-Adresse jetzt selbst ein oder ändern sie: Gerätedatenbank (bzw. Atemschutz-Datenbank) → 👤 → **🔔 Benachrichtigungen** → „Ihre E-Mail-Adresse für Erinnerungen“ → **E-Mail speichern**. Leer speichern entfernt die Adresse. Die Adresse wird auf Gültigkeit geprüft; die Änderung steht im Protokoll. Der Administrator kann sie weiterhin unter Verwaltung → Gerätewarte ändern.

### Neu in 5.40: Vorlaufzeiten der Erinnerungen einstellbar

Gerätedatenbank → 👤 → **🔔 Benachrichtigungen**: unter „Vorlaufzeit – wie viele Wochen vorher?“ stellt jeder Gerätewart für seinen Zugang getrennt für **📱 App** und **✉️ E-Mail** ein, wie viele Wochen vorher er erinnert wird (0–26 Wochen; 0 = erst am Fälligkeitstag):
- **Geräteprüfungen** (Gerätedatenbank) – Vorgabe 1 Woche
- **Fahrzeugfristen** (HU, SP, UVV, Wartung …) – Vorgabe 4 Wochen

Abgelaufene Fristen werden immer gemeldet. Jede Erinnerung kommt je Kanal einmal. Mit „Auswahl speichern“ übernehmen.

### Neu in 5.39: Standort und Benachrichtigungen oben in der Fahrzeug-App

- Oben rechts in der Fahrzeug-App gibt es neben 🔧 (Schaden melden) und 💬 (Feedback) jetzt **📍 Standort** und **🔔 Benachrichtigungen**. Sie öffnen sich als Fenster; „Schließen“ führt zurück. Auf der Startseite stehen beide nicht mehr („⋯ Mehr“ enthält nur noch das Fahrtenbuch).
- Auf dem Handy wird oben die Uhr ausgeblendet, damit Funkrufname und Zeichen Platz haben.
- **Tablet, Reiter Nachrichten:** Spalten getauscht – links der Verlauf, rechts „Nachricht senden“.

### Neu in 5.38: Nachrichten auf dem Tablet zweispaltig

In der Fahrzeug-App ist auf Tablets auch der Reiter **Nachrichten** zweispaltig: links „Nachricht senden“ (bleibt beim Blättern stehen), rechts der Verlauf. Auf dem Handy bleibt alles untereinander.

### Neu in 5.37: Fahrzeug-App für Tablets

- **Tablet-Ansicht:** Ab Tablet-Breite (ca. 820 Pixel, hoch oder quer) nutzt die Fahrzeug-App die ganze Breite: links Einsatz, Lagemeldung, Ampel sowie Standort, Fahrtenbuch und Benachrichtigungen; rechts Einsatzbereitschaft und Stärke. Fenster (Schaden melden, Feedback …) erscheinen mittig. Auf dem Handy bleibt alles wie bisher.
- **Fahrzeug bearbeiten (Einsatzverwaltung):** Das Feld „PowerAlarm-Kennung“ ist entfernt – aus der Einsatzverwaltung wird kein Status an PowerAlarm gesendet (Status kommt weiter von PowerAlarm herein).
- Die Anzeige **„📦 Verbrauchsmaterial“ auf der Startseite** ist entfallen; das Material steht weiter unter 🔧 → „Verbrauch nachfüllen“.

### Neu in 5.36: Verbrauchsliste nur aus der Gerätedatenbank

In der Fahrzeug-App unter 🔧 → „📦 Verbrauch nachfüllen“ stehen nur noch die Positionen aus **Gerätedatenbank → Fahrzeug „⋯“ → 📦 Verbrauchsmaterial** (plus Schaummittel, wenn es in der Beladung eingetragen ist). Die allgemeine Liste der Ortswehr wird dort nicht mehr angezeigt. Ist für ein Fahrzeug nichts hinterlegt, erscheint ein Hinweis; Material kann dann unten frei eingetragen werden.

### Neu in 5.35: Beleuchtung ohne „ja“, Beladung beim Schaden melden

- **Einsatzverwaltung, Fahrzeugansicht:** Bei der Ausrüstung steht nur noch „Beleuchtung intern“ bzw. „Beleuchtung extern“ (ohne „: ja“).
- **Fahrzeug-App → Schaden melden:** Unter „Was ist betroffen?“ stehen jetzt auch B-, C- und D-Schläuche und AGT-Geräte (mit Anzahl) sowie Beleuchtung intern/extern aus der Beladung.
- **Schaummittel** aus der Beladung steht in der Fahrzeug-App beim **Verbrauchsmaterial** (mit Litern) und oben in der Liste „Verbrauch nachfüllen“.

### Neu in 5.34: Schaden melden in der Fahrzeug-App vereinfacht

Im Fenster „🔧 Schaden melden“ der Fahrzeug-App gibt es keine vorgefertigten Texte mehr. Direkt unter „Was ist betroffen?“ steht das Freitextfeld **„Was ist kaputt?“**, danach Zustand, Foto und „Schaden melden“.

### Neu in 5.33: Beladeplan mit Fach-Nr. und Sortierung

- **Geräte:** Der Knopf „Öffnen“ ist entfallen – die Gerätezeile antippen öffnet das Gerät. Neues Feld **Fach-Nr.** in den Stammdaten des Geräts (neben Geräteraum); in der Liste steht z. B. „G1 · Fach 3“.
- **🖨 Beladeplan drucken:** Vor dem Drucken wählen: nach Geräteraum gruppieren (ja/nein), bis zu drei Sortierfelder (Geräteraum, Fach-Nr., Gerät, Inventar-Nr., Kategorie, Nächste Prüfung, Zustand) und die Spalten (Fach-Nr., Anzahl, Inv.-Nr., Kategorie, Nächste Prüfung, Hersteller/Typ, Serien-Nr.). Die Auswahl wird gemerkt; leere Felder stehen beim Sortieren am Ende.
- **Einsatzverwaltung → Fahrzeug bearbeiten:** Baujahr, Hersteller Fahrgestell und Aufbauhersteller sind dort entfernt – sie werden nur noch in der Gerätedatenbank unter „📋 Fahrzeugdaten“ gepflegt (bleiben beim Speichern in der Einsatzverwaltung erhalten).

### Neu in 5.32: Fahrzeugdaten zusammengefasst, Fahrtenbuch mit Filtern

**Gerätedatenbank → Fahrzeug „⋯“** enthält jetzt: 📋 Fahrzeugdaten · Beladung · Fristen, 🖨 Beladeplan drucken, 📦 Verbrauchsmaterial, 🚗 Fahrtenbuch, ✅ Prüfen am Fahrzeug, Fahrzeug außer Dienst.

- **📋 Fahrzeugdaten** zeigt oben den QR-Code des Fahrzeugs (antippen = groß / drucken), Ampel und fällige Fristen. Drei Reiter: **Daten** (Hersteller, Aufbau, Baujahr, Kennzeichen), **Beladung** (Schläuche, Wasser, Schaum, AGT, Stromaggregat, Beleuchtung), **Fristen** (HU, Wartung … und Wartung nach km). Ein „Speichern“ sichert alles. Unten: Fahrtenbuch und Beladeplan.
- Die einzelnen Einträge „Beladung · Strom · Licht“ und „QR-Code fürs Fahrzeug“ sind entfallen (stecken in den Fahrzeugdaten).
- **🖨 Beladeplan drucken** – jetzt mit Verbrauchsmaterial und Hersteller.
- **🚗 Fahrtenbuch** – eigenes Fenster, filterbar nach **Jahr, Monat, Fahrer, Zweck und Ziel**; Summe, CSV und Druck richten sich nach dem Filter.

**Einsatzverwaltung → Fahrzeug bearbeiten:** Ist die Gerätedatenbank aktiv, sind Beladung und Ausrüstung dort ausgeblendet (Hinweis auf die Gerätedatenbank).

**Gleich hohe Eingabefelder:** In allen Fenstern der Gerätedatenbank sind Text-, Datums- und Auswahlfelder gleich hoch und stehen in einer Linie.

### Neu in 5.31: Gerätedatenbank aufgeräumt, Verbrauchsmaterial, Fahrzeugdaten

**Gerätefenster einfacher (Reiter „⚠ Zustand · Mangel“):** Oben steht der aktuelle Zustand. Darunter: 1. „Was ist los?“ kurz eintragen, 2. den neuen Zustand mit einer der vier großen Kacheln antippen – **✅ In Ordnung**, **⚠️ Defekt**, **📦 Fehlt**, **🔧 In Reparatur** (öffnet Werkstatt und „zurück bis“). Foto und Frist zum Mangel sowie „anderer Zustand / nur Notiz“ stehen eingeklappt darunter. Unten nur noch „▦ QR-Etikett“ und „⋯ Mehr“ (Lebenslauf, Prüfnachweis, Aussondern, Löschen).

**Handy-Ansicht:** Kopf deutlich kleiner – Feedback 💬 und Konto 👤 (Benachrichtigungen, Kennwort, Abmelden) als kleine Knöpfe, die Bereiche (Gerätedatenbank, Kalender, Lager, Übersicht) und „Heute zu tun“ als wischbare Zeile. Unter der Suche nur „+ Gerät“, „📷 Scannen“ und „⋯ Mehr“ (dort Prüfung im Stapel, Prüfen am Fahrzeug, Wo ist …?). Das „⋯“ der Fahrzeuge steht rechts oben in der Fahrzeugzeile.

**Fahrzeug-Menü „⋯“:**
- **📋 Fahrzeugdaten · QR-Code** – Hersteller Fahrgestell, Aufbauhersteller, Baujahr, Kennzeichen (gleiche Daten wie in den Fahrzeugstammdaten der Einsatzverwaltung) und der QR-Code fürs Fahrzeug.
- **📦 Verbrauchsmaterial** – Liste, was auf dem Fahrzeug sein soll (Material, Menge, Einheit, Fach). Sie erscheint in der **Fahrzeug-App** auf der Startseite unter „📦 Verbrauchsmaterial“; beim Melden „Verbrauch nachfüllen“ stehen diese Positionen oben.

**Stromaggregat als Gerät:** Wird bei der Beladung ein Stromaggregat (kVA) eingetragen, legt die Gerätedatenbank automatisch ein Gerät „Stromerzeuger“ mit Prüfung nach DGUV 305-002 (jährlich) an – oder übernimmt einen schon angelegten Stromerzeuger des Fahrzeugs. In der Einsatzverwaltung steht es trotzdem nur **einmal** („Stromaggregat (kVA): …“). Ist das Gerät defekt oder ausgeliehen, steht das Stromaggregat dort als nicht verfügbar. Wird das Aggregat aus der Beladung genommen, wird das Gerät gelöscht bzw. (wenn es schon Prüfungen hat) ausgesondert.

**Lagerplatz:** Im Lager (Verbrauchsmaterial der Ortswehr) gibt es die Spalte **Lagerplatz** (z. B. „Keller, Regal 2“). Geräte ohne Fahrzeug haben statt „Geräteraum“ das Feld **Lagerplatz**.

**Live-Aktualisierung:** Die Gerätedatenbank prüft alle 15 Sekunden, ob sich etwas geändert hat (Einsatzverwaltung, Fahrzeug-App, andere Gerätewarte), und lädt dann selbst neu – nicht während ein Fenster offen ist oder getippt wird (dann direkt danach).

**Fahrzeug-App:** Defekte und fehlende Geräte bei „Beladung prüfen“ sind im dunklen Modus wieder gut lesbar.

**Feedback:** 💬 oben rechts in der Gerätedatenbank – geht wie in der Einsatzverwaltung an die Entwicklung.

### Neu in 5.30: Vorhandene Bezeichnungen beim Anlegen

- **Gerätedatenbank → „+ Gerät“:** Unter der Bezeichnung stehen alle schon eingepflegten Bezeichnungen (einheitliche Begriffe blau umrandet, dahinter die Anzahl vorhandener Geräte). Beim Tippen wird die Liste gefiltert – auch ohne Umlaute und Bindestriche („waermebild“ findet „Wärmebildkamera“). Antippen übernimmt die Schreibweise. Gibt es die Bezeichnung schon in anderer Schreibweise, erscheint ein gelber Hinweis mit „übernehmen“.
- **Fahrzeugstammdaten (ohne Gerätedatenbank):** Unter dem Feld „Ausrüstung“ stehen alle schon bei Fahrzeugen eingetragenen Gegenstände; antippen fügt sie in derselben Schreibweise hinzu.

### Neu in 5.29: Stromaggregat und Beleuchtung in der Beladung

In den Fahrzeugstammdaten (bzw. in der Gerätedatenbank beim Fahrzeug unter „🧯 Beladung · Strom · Licht“) gibt es neben Schläuchen, Wasser, Schaummittel und AGT-Geräten jetzt:

- **Stromaggregat** – Leistung in **kVA** (Kommazahl möglich, z. B. 13,5).
- **Beleuchtung intern** und **Beleuchtung extern** – je ein Kästchen „vorhanden“ (intern = fest am Fahrzeug, z. B. Lichtmast; extern = absetzbar, z. B. Stative/Flutlicht).

Bei der Ausrüstungssuche funktioniert es wie bei Wasser und Schläuchen: Suche nach „Strom“, „Aggregat“ oder „kVA“ zeigt einmal „⚡ Stromaggregat“ mit Gesamtleistung und am Fahrzeug die kVA; „Licht“ oder „Beleuchtung“ zeigt, welche Fahrzeuge interne bzw. externe Beleuchtung haben.

### Neu in 5.28.1: Korrekturen

- Auftrag anlegen: Das Kästchen „⚡ Priolage“ wird wieder richtig mit Beschriftung angezeigt.
- Auftragsfenster: Titel, Ort und Priorität bleiben beim Scrollen oben stehen.
- Gerätedatenbank: Ein Gerät öffnet sich schon beim Antippen der Zeile – „Öffnen“ ist nicht mehr nötig.

### Neu in 5.28: Aufträge erkunden

In der Auftragsübersicht (Einsatz → Aufträge) gibt es eine neue Spalte **„🔍 Erkunden“** zwischen „Neu“ und „Disponiert“.

1. Bei einem neuen Auftrag auf **🔍** tippen (oder im Auftragsfenster „🔍 Erkunden“) und ein Fahrzeug als Erkunder wählen. Der Auftrag wandert in die Spalte „Erkunden“, das Fahrzeug bekommt den Auftrag mit dem Hinweis „ERKUNDEN – bitte Lage feststellen und zurückmelden“ in die Fahrzeug-App.
2. Alle Nachrichten, Lagemeldungen und Fotos des Erkunders werden **automatisch im Tagebuch dieses Auftrags** gespeichert (zusätzlich wie gewohnt im Einsatztagebuch).
3. Ist die Lage klar, auf **„✓ Erkundet“** tippen. Das Ergebnis ist mit den letzten Meldungen des Erkunders vorbelegt; die Priorität kann gleich mit festgelegt werden. Der Erkunder wird frei (bleibt in der Lage).
4. Der Auftrag steht wieder unter **„Neu“** – mit dem grünen Vermerk **„✅ Erkundet … durch … – wartet auf Disposition“**, bis ein Fahrzeug disponiert wird. Danach steht das Ergebnis weiterhin im Auftragsfenster.

Wird der Erkunder vorher frei (Status 1/2) oder abgezogen, geht der Auftrag ohne Vermerk zurück nach „Neu“. Ein Erkunder kann auch direkt per „+“ disponiert werden – dann wird der Auftrag sofort „Disponiert“.

### Neu in 5.27: Nachbesprechung, BMA-Fehlalarme, Ablöseplanung, Unwetter-Liste, Navigation und Lagemeldung in der Fahrzeug-App, AGT-Tauglichkeit, Rollen für Orts- und Gemeindebrandmeister, Datenschutz

**🗣 Nachbesprechung:** Archiv → Einsatz öffnen → „🗣 Nachbesprechung“. Ergebnis des Einsatzes (Einsatz, Fehlalarm BMA – technischer Defekt / Täuschungsalarm / Bedienfehler, böswilliger oder blinder Alarm), Hinweis zur Brandmeldeanlage (Melder, Ursache), Teilnehmer, „Was lief gut?“, „Was können wir besser machen?“, fehlendes oder defektes Material, fehlendes Personal, Sonstiges und **Maßnahmen** mit „wer kümmert sich“ und Haken für erledigt. Die Nachbesprechung steht im Einsatzbericht; im Archiv zeigen „Fehlalarm“ und „🗣 ✓“ den Stand. Die Jahresauswertung zählt Fehlalarme und Nachbesprechungen.

**🔔 BMA-Fehlalarme:** Archiv → „🔔 BMA-Fehlalarme“: je Objekt (aus der Objektdatenbank) bzw. Adresse die Zahl der Fehlalarme im Jahr mit Einsatz-Nr., Datum, Art und Hinweis – zum Drucken für das Gespräch mit dem Betreiber.

**🏛 Ortswehren:** Archiv → „🏛 Ortswehren“: je Ortswehr Einsätze, Fahrzeug- und Personalstunden, Fehlalarme und Einsätze ohne Nachbesprechung, dazu offene Maßnahmen – für Gemeinde- und Ortsbrandmeister, druckbar.

**🔄 Ablöseplanung:** In der Einsatz-Übersicht ab einer Stunde Einsatzdauer: alle Fahrzeuge im Einsatz nach Dauer mit Stärke. Über der Grenze (Einstellungen → Einsatz → Plausibilitätsprüfung und Ablösung, Vorgabe 3 h) rot markiert und automatisch aufgeklappt; „Ablösung anfordern“ trägt es ins Einsatztagebuch ein.

**⛈ Unwetter-Liste:** In der Einsatz-Übersicht neben „Einsatz beenden“. Adresse und Stichwort eintippen, Enter – fertig. Jede Zeile ist ein Auftrag des Einsatzes (Lagekarte, Reiter Aufträge, Fahrzeug-App). Fahrzeug aus der Liste wählen = disponieren (freie Fahrzeuge werden alarmiert), „in Arbeit“ und „✓ erledigt“ direkt in der Zeile.

**Fahrzeug-App:**
- **🧭 Navigation:** Im Einsatz öffnet der Knopf Apple Karten (iPhone/iPad) bzw. Google Maps mit dem Ziel – Auftrag oder Einsatzort. Das Ziel wird nur übertragen, wenn die Karte für die Fahrzeug-App eingeschaltet ist (wie bisher beim Auftrag).
- **🗣 Lagemeldung:** Sprechen (🎤, Spracherkennung des Geräts) oder tippen; die Meldung kommt als „LAGEMELDUNG“ ins Einsatztagebuch und unter Lagemeldungen der Einsatzleitung. Ohne Spracherkennung im Browser hilft das 🎤 der Tastatur.

**🫁 Tauglichkeit der Atemschutzgeräteträger:** In der Atemschutz-Karte des Einsatzes und in der ELW-Besatzung erscheint bei Personen aus der Atemschutz-Datenbank ein roter Hinweis „nicht einsatzbereit“ (z. B. G 26.3 abgelaufen, Unterweisung oder Übung fehlt) bzw. gelb „läuft bald ab“. Die ASÜ warnt wie bisher schon beim Zuteilen zum Trupp.

**👥 Rollen für Orts- und Gemeindebrandmeister:** Verwaltung → Benutzer → Rolle:
- **Gemeindebrandmeister** – Rechte wie Einsatzleitung, alle Ortswehren, Übersichten und Auswertungen; keine Verwaltung (Fahrzeuge, Benutzer, Schnittstellen).
- **Ortsbrandmeister** – Rechte wie Einsatzleitung, mit Auswahl der Ortswehr(en). Archiv, Jahresauswertung, Ortswehr-Übersicht und Nachbesprechung zeigen nur Einsätze mit Fahrzeugen der eigenen Ortswehr (auch auf dem Server gesperrt); „Einheiten“ und „Ausrüstung“ starten mit der eigenen Ortswehr. Laufende Einsätze sind für die Zusammenarbeit weiter sichtbar.

**🔒 Datenschutz:** Verwaltung → Einstellungen → Betrieb → „Personendaten im Archiv schwärzen nach … Monaten“. Danach werden in archivierten Einsätzen Namen (im Text und in Feldern), Rufnummern, E-Mail-Adressen, Kfz-Kennzeichen, Ansprechpartner, Meldende, Fahrer/Halter beim VU, Namen in der Atemschutzüberwachung und Fotos automatisch geschwärzt (zweimal täglich). Stichwort, Ort, Zeiten, Fahrzeuge und Stärke bleiben – Statistik und Jahresauswertung stimmen weiter. Der Atemschutz-Nachweis ist nicht betroffen. Im Archiv zeigt 🔒 geschwärzte Einsätze; Admins sehen den Stand und können fällige Einsätze sofort schwärzen. **Nicht rückgängig zu machen.**

### Neu in 5.26: Umzugshinweis auf der alten GitHub-Seite

Wer die ASÜ noch über die **alte GitHub-Adresse** öffnet, sieht oben einen **roten Hinweis** „Die ASÜ ist umgezogen“ mit Link zur neuen Adresse des Pi. Beim Öffnen (einmal am Tag, nicht während Trupps unter Atemschutz sind) kommt zusätzlich ein Fenster mit Schritt-für-Schritt-Anleitung, **QR-Code** und Knopf „Zur neuen Adresse“; der Benutzername wird gleich mitgegeben. Auch die Anmeldeseite zeigt den Hinweis. Sonst läuft die alte Seite wie gewohnt weiter – eine laufende Überwachung wird nicht unterbrochen.

Einrichten: Verwaltung → ASÜ-Zugänge → „Alte GitHub-Seite: Hinweis auf die neue Adresse“. Voraussetzung ist die eingetragene Internetadresse des Pi („Unterwegs“).
- **„⬆ Hinweis auf … veröffentlichen“** – wenn für die alte Seite noch der Zugriffsschlüssel auf dem Pi liegt (aus der früheren automatischen Veröffentlichung), lädt der Pi die Dateien selbst hoch.
- sonst **„⬇ Als ZIP zum Hochladen von Hand“**: entpacken und alle Dateien im bisherigen Repository ersetzen.

Die Tablets bekommen den Hinweis beim nächsten Öffnen mit Internet. Sind alle umgestellt, das alte Repository löschen.

### Neu in 5.25: ASÜ direkt vom Pi – GitHub nur noch für die eigenständige ASÜ

**Die ASÜ kommt direkt vom Pi.** GitHub wird für eure Ortswehren nicht mehr gebraucht. Neue Versionen kommen mit „Programm aktualisieren“ automatisch auf alle Tablets (beim nächsten Öffnen der App).
- **Im Feuerwehr-WLAN:** Adresse des Pi mit Port 8082, z. B. `http://192.168.178.50:8082/`.
- **Unterwegs (Mobilfunk):** die Tailscale-Funnel-Adresse des Pi ohne „/api“, z. B. `https://name.tailXXXX.ts.net:8443/`. Einzutragen unter Verwaltung → Personen & Zugänge → ASÜ-Zugänge → „Unterwegs – Internetadresse des Pi“.
- Die **Zugangszettel** (Startcode) enthalten jetzt die Adresse des Pi als QR-Code.
- **Tablet umstellen:** laufende Überwachung mit „Einsatzende“ abschließen, die Adresse des Pi im Browser öffnen, anmelden, „Zum Home-Bildschirm“, altes GitHub-Symbol löschen. Daten der alten GitHub-App werden nicht übernommen.

**Eigenständige ASÜ für andere Feuerwehren:** Unter Verwaltung → ASÜ-Zugänge → „Eigenständige ASÜ für andere Feuerwehren (GitHub)“. Diese Ausgabe ist **nur die Überwachung** – ohne Server, ohne Anmeldung, ohne Datenbank und ohne Gerätetausch:
- Beim ersten Start trägt jede Feuerwehr **Namen, Zusatz und Wappen** selbst ein (später unter Einstellungen → „Feuerwehr, Name und Wappen“, dort auch Name der App und ein zweites Wappen fürs Protokoll). Weitere Geräte gleich einrichten über „Einstellungen als Datei sichern / laden“.
- Alle Daten bleiben auf dem Gerät. Trupps gehen per **QR-Code** von Gerät zu Gerät, ganze Einsätze per **„Sicherung als Datei / Sicherung laden“** (Einsatzdaten). Einsatzende speichert das PDF und löscht die Daten.
- Keine Reiter „Tausch / Prüfung“ und „Datenbank“, keine Übergabe an eine Einsatzverwaltung, keine Sammel-App.
- **„⬇ Eigenständige ASÜ als ZIP“** zum Hochladen von Hand – oder Repository und Zugriffsschlüssel eintragen und **„Jetzt auf GitHub veröffentlichen“**, auf Wunsch automatisch nach jedem Update. Bitte ein **neues Repository** verwenden (z. B. `atemschutzueberwachung`), nicht das bisherige der ASÜ – die frühere automatische Veröffentlichung ist abgeschaltet und muss neu eingerichtet werden.
- Im Repository liegt eine README mit Anleitung für die anderen Feuerwehren.

### Neu in 5.24: Einheitliche Begriffe in der Gerätedatenbank, Mengen in der Ausrüstung

**🔤 Einheitliche Begriffe:** Alle Ortswehren verwenden für Geräte dieselben Bezeichnungen – so steht in der Einsatzverwaltung überall das Gleiche (z. B. immer „Wärmebildkamera“, nie „WBK“ oder „Wärmebild“). Mitgeliefert sind rund 80 übliche Begriffe mit gängigen anderen Schreibweisen.
- Beim **Anlegen** zeigt das Feld „Bezeichnung“ die Begriffe zur Auswahl. Eine bekannte andere Schreibweise wird automatisch angeglichen (z. B. „WBK“ → „Wärmebildkamera“, „C Schlauch 15m“ → „C-Druckschlauch 15 m“). Bei einem unbekannten Begriff schlägt das Programm den passenden vor; erst wenn es das Gerät wirklich noch nicht gibt, kann man ihn als neuen Begriff für alle aufnehmen.
- Auch der **Excel-Import** gleicht bekannte Schreibweisen an.
- ⋯ Mehr → **„🔤 Einheitliche Begriffe“**: oben die **abweichenden Bezeichnungen** vorhandener Geräte (mit Vorschlag) – Begriff wählen, „Umstellen“, fertig; die alte Schreibweise wird gemerkt und künftig automatisch angeglichen. Darunter die Liste aller Begriffe mit ihren anderen Schreibweisen (bearbeitbar), neue Begriffe aufnehmen, löschen. Änderungen gelten für die ganze Gemeinde.

**Ausrüstung: Wasser, Schaummittel, Schläuche und AGT einmal – mit Menge am Fahrzeug:** In der Einsatzverwaltung unter „Ausrüstung“ erscheinen B-, C-, D-Schläuche, Wasser, Schaummittel und AGT-Geräte in der Ausrüstungsauswahl jeweils **einmal**. Wer danach sucht (z. B. „Wasser“, „Tank“, „AGT“, „Atemschutz“, „C-Schlauch“) oder es auswählt, sieht oben die **Summe** („gesamt 23.500 l auf 13 Fahrzeugen“) und darunter jedes Fahrzeug mit seiner **Menge**, nach Menge sortiert; die Fahrzeugkarten zeigen die Menge ebenfalls. Antippen öffnet das Fahrzeug. Die Ortswehr-Kacheln filtern wie gewohnt.

### Neu in 5.23: Gerätedatenbank – Monatsliste, Prüfen am Fahrzeug, Haltbarkeit, Prüfnachweis, Reparaturstufen, Fahrzeug-QR, Vorlagen, „Wo ist …?“, Jahresbericht

**🗓 Monatsliste „Diesen Monat fällig“:** Am 1. jedes Monats ab 7 Uhr bekommt jeder Gerätewart eine Mail mit allen Prüfungen und Haltbarkeiten bis Monatsende (Überfälliges rot), je Ortswehr sortiert nach Fahrzeug und Geräteraum, mit Kästchen zum Abhaken – die Mail lässt sich direkt drucken. Abschaltbar unter 🔔 Benachrichtigungen („Monatsliste“). Jederzeit: ⋯ Mehr → „🗓 Diesen Monat fällig“ (Druck/PDF) oder „📧 Monatsliste an mich“.

**🚒 Prüfen am Fahrzeug:** Knopf in der Leiste oder ⋯ am Fahrzeug. Fahrzeug wählen, dann Geräteraum (G1, G3, Kabine … oder „alle Räume“) und Gerät für Gerät „✓ i. O.“ oder „⚠ Mangel“ (mit kurzer Beschreibung) antippen. „✓ alle sichtbaren i. O.“ hakt den ganzen Raum ab. Gespeichert werden nur angetippte Geräte – mit Sammelprotokoll wie bei der Stapelprüfung. Ideal für die Beladungskontrolle, ganz ohne Scannen.

**🧴 Haltbar bis:** Neues Feld in den Stammdaten für Verbandkästen, Schaummittel, Batterien, Atemschutzfilter usw. Abgelaufen → Ampel **rot**, in den nächsten 30 Tagen → **gelb**. Erscheint in „Heute zu tun“, im Kalender (🧴), im Wochenüberblick und in der Monatsliste.

**📄 Prüfnachweis:** Im Gerät unten „📄 Prüfnachweis“ – alle Prüfungen mit Datum, Ergebnis, Prüfer und Protokoll-Nr. auf einer Seite mit Unterschriftsfeld, z. B. für Leitern und Hebekissen oder die Unfallkasse.

**🔧 Reparatur mit Stufen:** Im Gerät unter „⚠ Mangel · Zustand“ → Reparatur: Stufe (Reparatur gemeldet · in der Werkstatt · Ersatzteil bestellt), Werkstatt/Firma und „zurück bis“. Die Stufe steht in der Liste; im Kalender erscheint „Zurück aus Werkstatt“. Ist das Datum überschritten oder ein Gerät ohne Datum länger als 4 Wochen weg, gibt es den Hinweis „zu lange in Reparatur“ (Heute zu tun, Wochenüberblick). „🔧 Repariert – einsatzbereit“ schließt die Reparatur ab.

**▦ QR-Code fürs Fahrzeug:** ⋯ am Fahrzeug → „QR-Code fürs Fahrzeug“, ausdrucken und ins Fahrzeug kleben. Mit der Handykamera gescannt öffnet sich (nach der Anmeldung) direkt die Geräteliste dieses Fahrzeugs mit Ampel.

**★ Gerätevorlagen:** Bei „+ Gerät“ oben „Aus Vorlage“ wählen – Bezeichnung, Kategorie, Prüfart, Intervall, Ausstattung und Haltbarkeit sind ausgefüllt; nur noch Inventar-Nr. und Fahrzeug ergänzen. Mitgeliefert sind u. a. Feuerwehrleine, Haltegurt, Handlampe, Steckleiter, B-/C-Schlauch, Verbandkasten, Schaummittel, Stromerzeuger, Motorkettensäge, Wärmebildkamera, Hebekissen. Eigene Vorlage: Gerät öffnen → Stammdaten → „★ Als Vorlage speichern“. Verwalten unter ⋯ Mehr → „★ Gerätevorlagen“.

**📍 Wo ist …?:** Bezeichnung, Inventar- oder Serien-Nr. eingeben – angezeigt werden Fahrzeug und Geräteraum, Lager, Ausleihe, Werkstatt oder Aussonderung über alle eigenen Ortswehren. Antippen öffnet das Gerät.

**📊 Jahresbericht:** ⋯ Mehr oder Reiter „Übersicht“ → „📊 Jahresbericht“, Jahr eingeben. Je Ortswehr (und gesamt): Geräte, Neuzugänge, Prüfungen (davon mit Mangel), Prüfquote, Mängel, abgeschlossene Reparaturen, Meldungen aus der Fahrzeug-App, Ausleihen, Aussonderungen mit Grund, Mängel nach Kategorie – als PDF für die Dienstversammlung.

### Neu in 5.22: Ampel in der Fahrzeug-App

Im Reiter „Einsatz“ der Fahrzeug-App steht unter der Einsatzzeile die **Ampel aus der Gerätedatenbank** – vor dem Losfahren sieht die Besatzung sofort, ob alles passt:
- 🟢 **Fahrzeug einsatzbereit** – alles in Ordnung.
- 🟡 **Einsatzbereit mit Hinweisen** – z. B. Prüfung fällig oder überfällig, Gerät in Prüfung, TÜV/Wartung bald fällig.
- 🔴 **Nicht vollständig einsatzbereit** – Gerät defekt oder fehlt, Mangel-Frist überschritten, Status 6 oder Fahrzeug außer Dienst, Frist abgelaufen.

Antippen zeigt die Gründe; bei Rot ist die Liste gleich aufgeklappt. Die Ampel aktualisiert sich von selbst, sobald der Gerätewart etwas ändert. Sie erscheint, sobald die Gerätedatenbank Geräte enthält.

### Neu in 5.21: Einfachere Bedienung – Meine Ansicht, Ausgaben-Menü, Verwaltung in Gruppen, Gerätedatenbank aufgeräumt, großer Einsatz-Bildschirm in der Fahrzeug-App

**👁 Meine Ansicht (Einsatzverwaltung):** In der Reiterleiste des Einsatzes rechts das Auge antippen. Jede/r legt dort für sich selbst fest, was angezeigt wird – **Karten im Einsatz** (z. B. Abschnitte, VU, Zeitstrahl), **Ausgaben** der Übersicht (Funkskizze, Pressetext …) und **Hauptreiter** (Ausrüstung, Objekte, Gefahrstoffdatenbank …). „✨ Einfache Ansicht“ setzt einen schlanken Vorschlag, „Alles zeigen“ stellt alles wieder her. Die Einstellung gilt pro Benutzer auf diesem Gerät; es gehen keine Daten verloren. Ein ausgeblendeter Reiter, der gerade offen ist, bleibt sichtbar, bis man wechselt.

**Einsatz-Karten mit Text:** Auf Tablet und PC zeigen die Karten Symbol **und** Namen (bei Platzmangel etwas kleiner und zweizeilig). Nur auf dem Handy bleiben es reine Symbole.

**📄 Ausgaben ▾:** In der Einsatz-Übersicht stecken Einsatzbericht, E-Mail, Funkskizze, Pressetext, Lagebesprechung, FeWIS, Waldbrandkarte und Mappe in einem Knopf „📄 Ausgaben ▾“. Sichtbar bleiben nur **„Einsatz beenden“** – und bei Wald-/Vegetationsbränden die **🌲 Waldbrandkarte**.

**Verwaltung in 5 Gruppen:** Oben stehen „🚒 Fahrzeuge & Geräte“, „👥 Personen & Zugänge“, „📨 Alarmierung & Schnittstellen“, „🖥 Anzeige & Monitore“ und „⚙️ System“; darunter nur die Unterpunkte der gewählten Gruppe.

**Einheitliche Druckansicht:** Alle Ausdrucke der Einsatzverwaltung und der Gerätedatenbank haben oben Wappen, Feuerwehr und Titel und unten Druckdatum und „Seite x von y“ (Karten und Plakate mit eigenem Format ausgenommen).

**Gerätedatenbank:**
- **📌 Heute zu tun** ganz oben: überfällige und bald fällige Prüfungen, Mängel mit Frist, nicht einsatzbereite Geräte, überfällige Ausleihen, offene Meldungen. Antippen filtert die Liste.
- **Meldungen aus der Fahrzeug-App** sind einklappbar; gleiche Meldungen zum gleichen Gerät (z. B. „Handlampe defekt“ von mehreren Fahrzeugen) stehen zusammen mit „×Anzahl“, jede einzeln erledigbar.
- **Gerätedialog in Reitern:** ✅ Prüfen · ⚠ Mangel · Zustand · ⇄ Standort · Verleih · 📋 Stammdaten · 🕘 Verlauf. Der zuletzt benutzte Reiter bleibt gemerkt.
- **⚙ Filter (n):** Fahrzeug, Zustand, Ausstattung und „nur fällig“ stecken hinter einem Knopf; die Zahl zeigt aktive Filter, „✕ Filter zurücksetzen“ hebt alle auf.
- **Knopfleiste:** + Gerät, ✅ Prüfung im Stapel, 📷 Etikett scannen – alles andere unter „⋯ Mehr“.
- **Fahrzeuge einklappbar:** Jede Zeile zeigt Ampel, Funkrufname, Anzahl Geräte und Auffälligkeiten (nicht bereit, Prüfung fällig). Antippen klappt auf; geöffnete Fahrzeuge bleiben gemerkt. Bei Suche oder Filter ist alles offen.
- **⋯ am Fahrzeug:** Beladeplan, Schläuche · Wasser · AGT, Fahrtenbuch & Fristen und „außer Dienst“ sind im Menü rechts.
- **Dubletten-Warnung:** Gibt es eine Inventar-Nr. in der Ortswehr schon, fragt das Programm vor dem Speichern nach.

**Fahrzeug-App – großer Einsatz-Bildschirm:** Sobald das Fahrzeug in einem Einsatz ist, zeigt die App nur noch groß: Einsatz, **Im Einsatz / Verfügbar** und **Stärke**. Standort, Fahrtenbuch und Benachrichtigungen liegen unter „⋯ Mehr“. Außerhalb von Einsätzen bleibt alles wie gewohnt.

### Neu in 5.20: Gerätedatenbank – Stapelprüfung, Beladeplan, Ampel, Lager, Lebenslauf, Aussonderung, Offline, Übersicht für den Gemeindebrandmeister

**✅ Prüfung im Stapel** (Gerätedatenbank → „Prüfung im Stapel“): Datum, Prüfart und Prüfer eintragen, dann Etikett für Etikett scannen oder die Inventar-Nr. + Enter eingeben. Jedes Gerät kommt mit „i. O.“ in die Liste; Mängel umstellen und kurz beschreiben. „Alle … Prüfungen speichern“ trägt alle Prüfungen ein (nächste Prüfung nach Intervall) und öffnet ein **Sammelprotokoll** zum Drucken bzw. als PDF. Im Verlauf jedes Geräts führt „📄 Sammelprotokoll“ wieder dorthin.

**Weitere Prüflisten** für das Prüfprotokoll mit Unterschrift: Feuerwehrleinen, Druckschläuche, Hydraulische Rettungsgeräte, Tragkraftspritze, Sprungpolster, Absturzsicherung, Motorkettensäge, Wärmebildkamera (zusätzlich zu Leitern, Hebekissen, Stromerzeuger, Elektrisch, Allgemein). Die passende Liste wird nach Bezeichnung/Kategorie vorgeschlagen.

**Mängel mit Foto und Frist:** Im Gerät unter „Zustand und Standort“ den Mangel beschreiben, optional **„Mangel beheben bis“** und **📷 Foto zum Mangel** (bis 3), dann „⚠ Mangel melden“. Die Frist steht in der Liste (⏰), im Kalender („⚠ Mangel beheben“), im Wochenüberblick und färbt die Ampel rot, wenn sie überschritten ist. Fotos stehen im Verlauf und im Lebenslauf. „🔧 Repariert“ hebt die Frist auf.

**🗺 Beladeplan nach Geräteraum:** In den Stammdaten jedes Geräts den **Geräteraum** eintragen (G1–G6, GR, Kabine, Dach, Heck …). In der Liste stehen die Geräte danach sortiert; beim Fahrzeug druckt **„🗺 Beladeplan“** eine Abhakliste je Geräteraum – mit Schläuchen, Wasser, Schaum und AGT-Geräten oben.

**📦 Fehlteile aus der Fahrzeug-App:** In der Fahrzeug-App gibt es beim Schaden melden die dritte Wahl **„📦 Fehlt / verbraucht“**. Das Gerät bekommt den Zustand „fehlt – nachbestücken“, ist in der Einsatzverwaltung nicht mehr als Ausrüstung verfügbar und steht im Wochenüberblick unter „Fehlt – nachbestücken“. Auch der Gerätewart kann „📦 Fehlt“ setzen.

**Ampel je Fahrzeug** (vor dem Funkrufnamen, Hinweise beim Darüberfahren): 🔴 Gerät defekt/fehlt, Fahrzeug außer Dienst bzw. Status 6, Fahrzeugfrist oder Mangel-Frist überschritten · 🟡 Prüfung überfällig oder in 7 Tagen, Fahrzeugfrist in 14 Tagen · 🟢 alles in Ordnung.

**📦 Lager** (eigener Reiter, je Ortswehr): Verbrauchsmaterial mit Einheit, Bestand und Mindestbestand – nur Mengen, keine Preise. Mit − und + buchen. Unter dem Mindestbestand: rote Zeile, Hinweis „nachbestellen“, Wochenüberblick und Übersicht.

**📄 Gerätelebenslauf:** Im Gerät „📄 Lebenslauf“ – Stammdaten, kompletter Verlauf mit Fotos, Prüfprotokolle und alle Meldungen aus der Fahrzeug-App; zum Drucken bzw. als PDF (z. B. für Unfallkasse, FTZ oder bei Aussonderung).

**🗄 Aussonderung:** Grund im Textfeld eintragen, „🗄 Aussondern“. Das Gerät verschwindet aus allen Listen, Fahrzeugen, Kalender und Erinnerungen und bleibt im Archiv: Zustand-Auswahl „🗄 ausgesondert (n)“. „↩ Wieder aufnehmen“ macht es rückgängig.

**📴 Offline-Prüfung:** Ist der Pi nicht erreichbar (Halle ohne WLAN), zeigt die Gerätedatenbank den zuletzt geladenen Stand. Prüfungen und Stapelprüfungen werden auf dem Gerät gespeichert („📴 … gespeichert“) und automatisch nachgesendet, sobald die Verbindung wieder da ist (oder mit „Jetzt senden“). Voraussetzung: die Datenbank wurde auf dem Gerät vorher einmal mit Verbindung geöffnet.

**Baujahr (Fahrzeuge):** Verwaltung → Fahrzeuge → Bearbeiten → „Baujahr“; erscheint in der Fahrzeugkarte (mit Alter), in der Gerätedatenbank, im Beladeplan, in der Übersicht und in der Fahrzeug-Excel-Liste.

**🏛 Übersicht Fahrzeuge und Material** (Reiter „Übersicht“, gedacht für den Gemeindebrandmeister – zeigt alle Ortswehren des Zugangs): Kennzahlen der Gemeinde (Fahrzeuge 🔴/🟡, Geräte, nicht einsatzbereit, Prüfungen überfällig / in 30 Tagen, Summe Schläuche, Wasser, Schaum, AGT) und je Ortswehr eine Tabelle aller Fahrzeuge mit Ampel, Baujahr und Alter, nächster Frist, Beladung und Hinweisen, darunter Material (Zusatz/Standard/Lager, nicht einsatzbereit, fehlt, ausgeliehen, dieses Jahr ausgesondert) und Lager unter Mindestbestand. „🖨 Drucken / PDF“ für die Sitzung. Ein Zugang für den Gemeindebrandmeister: Verwaltung → Gerätewarte → Gerätewart mit allen Ortswehren.

### Neu in 5.19: Kalender in der Gerätedatenbank (je Ortswehr, mit Abo für Apple und Google)

In der Gerätedatenbank gibt es neben „🧰 Gerätedatenbank“ den Reiter **„📅 Kalender“**. Er zeigt für die gewählte Ortswehr (Auswahl oben, wenn der Zugang mehrere hat) alle Fristen und Termine:

- **🧰 Geräteprüfungen** – jedes Gerät mit nächster Prüfung (Prüfart, Fahrzeug bzw. Lager, Inventar-Nr.); antippen öffnet das Gerät,
- **🚒 Fahrzeugfristen** aus „Fahrtenbuch & Fristen“ (HU, SP, UVV, Wartung, Pumpenprüfung …),
- **📌 eigene Fristen** (auch wiederkehrende),
- **🔧 Außer Dienst** – geplante Rückkehr eines außer Dienst gestellten Fahrzeugs.

Überfällige stehen rot ganz oben, darunter alles nach Monaten (bis 2 Jahre voraus); „alle Arten“ filtert.

**In den eigenen Kalender übernehmen** (aufklappen „📲 In Apple- oder Google-Kalender übernehmen“):

- **🍎 Apple-Kalender abonnieren** – auf iPhone, iPad oder Mac antippen → „Abonnieren“.
- **📅 Google Kalender** – öffnet calendar.google.com → „Hinzufügen“ (alternativ dort Einstellungen → Kalender hinzufügen → Per URL → Link einfügen).
- **🔗 Link kopieren** – z. B. für Outlook (Kalender hinzufügen → Aus dem Internet).
- **⬇ .ics herunterladen** – einmaliger Import ohne automatische Aktualisierung.
- **Neuer Link** – macht den alten Link ungültig (wenn er weitergegeben wurde).

Abonnierte Kalender aktualisieren sich von selbst und erinnern 7 Tage vor jedem Termin. Für Google und für Handys außerhalb des Feuerwehr-WLANs braucht der Pi eine öffentliche https-Adresse (Externe Adresse der Fahrzeug-App, z. B. Tailscale Funnel); sonst funktioniert das Abo nur im eigenen Netz.

### Neu in 5.18: Beladung mit Anzahl, Standard- oder Zusatzausstattung, Einsatzbericht an den Ortsbrandmeister

**Beladung mit Anzahl (Gerätedatenbank, ab 5.18.2):** In der **Gerätedatenbank** beim Fahrzeug auf **„🧯 Schläuche · Wasser · AGT“** tippen („(fehlt)“ = noch nicht erfasst): **B-, C- und D-Schläuche** (Stück), **Wasser im Tank** (Liter), **Schaummittel** (Liter) und **AGT-Geräte** (Stück). Die Werte erscheinen beim Fahrzeug als Ausrüstung („Wasser (Liter): 2000“), werden beim Stichwort-Abgleich („2.400 l Wasser“), im Pendelverkehr und in der Ausrüstungssuche benutzt und müssen **nicht mehr** als Geräte in der Gerätedatenbank stehen. In der Einsatzverwaltung (Verwaltung → Fahrzeuge) stehen die Werte nur noch zur Ansicht – ohne aktive Gerätedatenbank können sie dort eingetragen werden. Vorhandene Angaben („Wasser (Liter): 2000“ usw.) wurden beim Update einmalig übernommen; solche Einträge in der Gerätedatenbank erscheinen nicht mehr doppelt und können dort gelöscht werden.

**Standard- oder Zusatzausstattung (Gerätedatenbank):** Beim Gerät unter „Stammdaten“ wählen: **Standardausrüstung** (z. B. Feuerwehrleinen, Handlampen) bleibt nur in der Gerätedatenbank (Prüfungen, Mängel). **Zusatzausstattung** kann im Einsatz gebraucht werden und erscheint in der Einsatzverwaltung als Ausrüstung des Fahrzeugs. Vorhandene Geräte gelten als Zusatzausstattung. In der Liste filtert die Auswahl „nur Standardausrüstung / nur Zusatzausstattung“; Excel-Spalte „Ausstattung (Standard / Zusatz)“.

**Keine Mail mehr bei erfolgreicher Anmeldung:** Anmeldungen von neuen Geräten, des Superadmins und „erfolgreich nach Fehlversuchen“ stehen nur noch in der Hinweis-Zentrale. Fehlgeschlagene Anmeldungen und Sperren werden weiter gemeldet.

**Schadensmeldungen bis 3 Stunden nach dem Einsatz:** Meldet die Besatzung in der Fahrzeug-App bis 3 Stunden nach dem Freimelden bzw. Einsatzende einen Schaden, gehört er noch zu diesem Einsatz (Tagebuch, Sammelmail an den Gerätewart, Einsatzbericht an den Ortsbrandmeister).

**Automatisch angelegte Einsätze schließen sich selbst:** Ein Einsatz aus Leitstellen-Mail oder PowerAlarm, in den **niemand direkt in der Einsatzverwaltung** etwas eingetragen hat (Nachrichten und Schadensmeldungen der Fahrzeuge zählen nicht), wird geschlossen, sobald **alle alarmierten Fahrzeuge wieder Status 1/2** haben (nach 10 Minuten Ruhe). Ist kein Fahrzeug ausgerückt, nach der eingestellten Zeit (Verwaltung → Einstellungen → „Automatisch angelegte Einsätze selbst schließen“, Vorgabe 60 Minuten, 0 = aus). Ein Tagebucheintrag, ein Status von Hand, eine Lagemeldung oder Zeichnen auf der Lagekarte zählen als Bearbeitung – dann bleibt der Einsatz offen.

**Einsatzbericht an den Ortsbrandmeister:** Nach jedem Einsatzende (nicht bei Übungen und Testalarmen) geht ein Einsatzbericht per E-Mail an den Ortsbrandmeister der Ortswehr, in deren Bereich der Einsatz war (aus der Einsatzadresse, sonst nächstes Feuerwehrhaus). Inhalt: eingesetztes Personal (Stärke, Atemschutzgeräteträger aus der ASÜ), Fahrzeuge mit Zeiten, Schadensmeldungen, Lagemeldungen – bei automatisch geschlossenen Einsätzen zusätzlich alle Nachrichten der Fahrzeuge an die Einsatzleitung. Der Bericht wird **erst nach Ablauf der Frist für Schadensmeldungen** verschickt (3 Stunden nach Einsatzende) – so sind auch die Schäden enthalten, die nach dem Einsatz gemeldet wurden. Mit Chromium auf dem Pi hängt der Bericht zusätzlich als PDF an. Adressen: Verwaltung → Einstellungen → Alarmierung & E-Mail → „Einsatzbericht an die Ortsbrandmeister“ (je Ortswehr eine oder mehrere Adressen).

**Erinnerungen:** Es stehen höchstens drei fällige Erinnerungen („Lagemeldung fällig“ …) übereinander; der Rest ist mit einem Knopf in der Hinweis-Zentrale.

### Neu in 5.17.3: Darstellung auf PC, Tablet und Handy geprüft

Alle Programme wurden auf PC, Tablet und Handy geprüft (rund 200 Bildschirme). Behoben: breite Tabellen verbreiterten am Handy die Seite (untere Leiste verschwand), Lagekarte am Handy jetzt oben, Einsatztitel am Handy, Kopfzeile am Tablet (Kachel „AGT“) und PC (Titel), Erinnerungs-Leiste „Lagemeldung fällig“ unter statt über der Kopfzeile, ASÜ-Reiter am Handy in einer Zeile und am Tablet vollständig, Fahrzeug-App-Hinweise unter der Kopfzeile, Datenbank-Apps am Handy ohne leere Reiterleiste, Alarmmonitor passt die linke Spalte automatisch an. Dazu gibt es die **bebilderte Anleitung** (PDF).

### Neu in 5.17.2: Bedienung

- Verwaltung → Einstellungen: Die linke Leiste (Suche und Gruppen) bleibt beim Scrollen fest unter den Reitern stehen.
- Handy: Die untere Reiterleiste bleibt beim Scrollen fest am unteren Rand.

### Neu in 5.17: System-Mails der Einsatzverwaltung je Empfänger auswählbar

**Fahrzeug-App (ab 5.17.1):** Hier gibt es bewusst **keine** Auswahl – eingeschaltete Benachrichtigungen kommen immer für alles: Nachrichten der Einsatzleitung, neue Aufträge, Umsetzen in einen anderen Einsatz und die Fahrtenbuch-Erinnerung.

**Einsatzverwaltung (E-Mail):** Verwaltung → Einstellungen → E-Mail → **„Wer bekommt welche Systemmeldung?“**. Für jede Adresse aus „Empfänger Systemmeldungen“ eine Spalte mit Haken je Art: Sicherheitsereignisse, Datensicherung fehlgeschlagen, rote Pi-Warnungen, E-Mail-Alarmierung wieder in Ordnung, Fahrzeug-App von außen wieder erreichbar, ASÜ-Veröffentlichung auf GitHub fehlgeschlagen, täglicher Selbsttest, Hydrant mit Mangel, Schadensmeldungen (wenn kein Gerätewart zuständig ist). Danach „E-Mail-Einstellungen speichern“. Neue Adressen bekommen zunächst alles. Einsatzbericht und Lagemeldungen haben weiterhin eigene Empfängerlisten.

ASÜ (Wehr-Tablets), Alarmmonitor und der Link für Atemschutzgeräteträger verschicken keine Benachrichtigungen – dort gibt es nichts einzustellen.

### Neu in 5.16: Benachrichtigungen auswählbar

In der Atemschutz-Datenbank und der Gerätedatenbank oben auf **🔔 Benachrichtigungen** tippen. Unter **„Wofür möchten Sie benachrichtigt werden?“** steht eine Tabelle mit allen Anlässen, die für den eigenen Zugang in Frage kommen, je mit einem Haken für **📱 App** (Push aufs Handy) und **✉️ E-Mail**:

| Anlass | App | E-Mail |
|---|---|---|
| Fällige Prüfungen, Nachweise und Fahrzeugfristen | ✔ | ✔ |
| Schadensmeldungen aus der Fahrzeug-App (nur Gerätedatenbank) | ✔ | ✔ |
| Wochenüberblick montags (nur Gerätedatenbank) | ✔ | ✔ |
| Neue Atemschutz-Nutzungen aus Einsatz/Übung (nur Atemschutz) | ✔ | – |
| Gerätetausch / zur FTZ aus der ASÜ (nur Atemschutz) | ✔ | – |
| Kennwort läuft ab | ✔ | ✔ |
| Sicherheitshinweise (nur Superadmin) | ✔ | – |

Haken entfernen → **Auswahl speichern**. Die Auswahl gilt für den Zugang auf **allen** Geräten. Ohne hinterlegte E-Mail-Adresse ist die Mail-Spalte ausgegraut (Adresse trägt der Administrator unter Verwaltung → Gerätewarte ein). Vorgabe: alles eingeschaltet – wie bisher.

### Neu in 5.15: Gerätetausch in der ASÜ

- Tausch / Prüfung: Gerät scannen oder Nummer eingeben → Benutzung aus Einsatz/Übung (wer, wann, wie lange) → „Zur FTZ – Gerät tauschen“ oder „Nur Elemente tauschen“; Tauschgerät vorhanden oder neu anlegen mit QR-Etikett, Zuweisung an die tauschende oder eine andere Ortswehr der Gemeinde.

### Neu in 5.14: Ein Einsatz je PowerAlarm-Alarm, PowerAlarm + E-Mail zusammengeführt

- Nur Alarm-Gruppen erzeugen einen Einsatz; mehrere Gruppen mit demselben Text = ein Einsatz; Ortswehren der Gruppen als „Alarmierte Feuerwehren“.
- PowerAlarm-Alarm und Leitstellen-Mail zum selben Einsatz werden zusammengeführt (Leitstellen-Nummer bzw. Stichwort + Adresse/Koordinate), die Mail ergänzt Fahrzeuge und Daten.
- Nachalarmierung: zusätzlich einzelne Fahrzeuge und Funktionen der Gemeinde wählbar.

### Neu in 5.13: Checklisten als Excel, Alarmmonitor, Hydranten, Feuerwehrhäuser

- Checklisten als Excel exportieren und importieren (ein Tabellenblatt je Checkliste, Blattname = Name).
- Alarmmonitor zeigt im Alarm die alarmierten Ortsfeuerwehren.
- Hydrantenverwaltung nur für die eigene Gemeinde; Feuerwehrhäuser nach Gemeinde/Stadt geordnet.
- PowerAlarm-Gruppen im Nachalarmierungs-Dialog nach Ortswehr.

### Neu in 5.12: PowerAlarm-Anbindung

- Nachalarmierung von Gruppen direkt aus dem Einsatz (mit Einsatzort), Lage-Info an alarmierte Gruppen, Probealarm, Alarme aus PowerAlarm als Hinweis oder Einsatz, Fahrzeugstatus an PowerAlarm senden. API-Key unter Schnittstellen & Schlüssel → PowerAlarm.

### Neu in 5.11: Excel-Import und -Export der Datenbanken

- Gerätedatenbank und Atemschutz-Datenbank (Personen, Atemschutzgeräte): Export als Excel-Datei je Ortswehr, leere Vorlage, Import mit Prüfung vor dem Einspielen.
- Persönlicher Link der Atemschutzgeräteträger: öffentlich über die externe Adresse der Fahrzeug-App, eigenes Passwort beim ersten Öffnen, „angemeldet bleiben“, Zurücksetzen durch den Atemschutzgerätewart.

### Neu in 5.10.4: Gesamttest und Fehlerbehebung

- Gesamttest aller Programmteile (153 Testschritte, `docs/TESTBERICHT-5.10.4.md`). Behoben: In den Datenbank-Apps meldete „Kennwort ändern“ → „Abbrechen“ den Benutzer ab.
- Anleitungen und Demo auf den Stand 5.10.4 gebracht.

### Neu in 5.10.3: Fahrtenbuch-Erinnerung, Fahrzeugfristen auf dem Alarmmonitor

- Zurück auf Status 2 → Benachrichtigung an die Fahrzeug-App, das Fahrtenbuch öffnet sich von selbst (Abzeichen „km“). Einstellung „Fahrtenbuch: Erinnerung bei Status 2“.
- Fahrzeugfristen (HU, SP, UVV, Wartung, Pumpenprüfung) unter „Termine“ auf dem Alarmmonitor und im Kalender-Abo; überfällige mit „⚠ überfällig“.

### Neu in 5.10.2: Abfahrt und Ankunft aus dem Status, Fahrer merken

- Abfahrt/Ankunft werden aus dem FMS-Status gesetzt (Status 2 → anderer Status = Abfahrt, zurück auf 2 = Ankunft) und sind änderbar.
- Fahrerliste aus den letzten Einträgen; zuletzt gewählter Fahrer bleibt vorbelegt. Zeiten in der Gerätedatenbank und im CSV.

### Neu in 5.10.1: Fahrtenbuch vereinfacht

- Nur noch der km-Stand wird eingegeben; Zweck und Ziel als Auswahllisten (vorgegebene Ziele: Feuerwehrtechnische Zentrale, Ortsgebiet, Aerzen); Einsatznummer automatisch.

### Neu in 5.10: Hydrantenfotos, Löschwasser-Abdeckung, Fahrtenbuch

- Bis zu zwei Fotos je Hydrantenprüfung (hängen an der Mängel-Mail).
- Kartenebene „Löschwasser-Abdeckung“ (Umkreis je Entnahmestelle, Vorgabe 300 m) und Auswertung „Objekte ohne Löschwasser“.
- Fahrtenbuch, Tanken und Betriebsstunden in der Fahrzeug-App; Fahrzeugfristen mit Erinnerung an die Gerätewarte; Abschnitt „Fahrleistung“ im Jahresbericht. Keine Kosten.

### Neu in 5.9: Hydrantenprüfung

- Hydranten mit der Fahrzeug-App prüfen: sechs Prüfpunkte, Druck, Bemerkung, „außer Betrieb“, fehlende Hydranten melden, „Hydranten in der Nähe“.
- Zustand in Lagekarte, Fahrzeug-App und Alarmmonitor; Verwaltung → Hydranten mit Übersicht je Ortswehr, „behoben“, CSV; Mängel-Mail an den Wasserversorger.

### Neu in 5.8: Jahresbericht, Notfallmappe, ASÜ automatisch auf GitHub, Betriebshandbuch

- Verwaltung → **Berichte & Notfall**: Jahresbericht auf Knopfdruck und Notfallmappe für den Ausfall der Einsatzverwaltung (mit leeren Vordrucken nach FwDV 100 und FwDV 7).
- ASÜ direkt auf GitHub veröffentlichen, auf Wunsch automatisch nach jedem Update.
- Neues **Betriebshandbuch** (`docs/BETRIEBSHANDBUCH.md`): Update, Sicherung zurückspielen, Pi tauschen, Schlüsselumschlag, Störungen. Neue Kurzanleitungen für Gerätewarte, Atemschutzgerätewarte und Geräteträger.

### Neu in 5.7: Vorschriften und Datenschutz

- ASÜ: Rückfrage bzw. Warnung bei Trupps mit weniger als 2 Personen (FwDV 7).
- Gerätedatenbank: Prüfarten als Auswahl mit Intervall (gemeindeweit bearbeitbar).
- „Eignungsuntersuchung Atemschutz (G 26.3)“ als Bezeichnung.
- Datenschutzhinweise in allen Apps, Schriften vom Pi statt von Google, neue Punkte im Sicherheits-Check.

### Neu in 5.6: Sicherheit, Gerätewarte, Atemschutz, Datenschutz

- Angemeldet bleiben (30 Tage) in den Datenbank-Apps, Fern-Abmeldung durch den Admin.
- Sicherheitsübersicht mit Anmeldungen aller Apps und angemeldeten Geräten; Sicherheitshinweise als Benachrichtigung an den Superadmin.
- Gerätedatenbank: QR-Etiketten mit Link, Live-Scan, Prüfprotokoll mit Unterschrift, Wochenüberblick.
- Atemschutz: Benachrichtigung bei neuen Nutzungen, Jahresauswertung, persönlicher Link für Geräteträger, „ausgeschieden am“ mit Löschfrist.

### Neu in 5.5: Datenbanken als App mit Benachrichtigungen

- Gerätedatenbank und Atemschutz-Datenbank als eigene installierbare Apps mit Benachrichtigungen zu Terminen, Schäden, Gerätepflege und Kennwortablauf.

### Neu in 5.4: Superadmin

- Ein Admin als Superadmin mit einem Kennwort für Einsatzverwaltung, ASÜ und beide Datenbanken.

### Neu in 5.3: Gerätetausch und Prüfung aus der ASÜ

- Reiter „Tausch / Prüfung“ in der ASÜ für jede Feuerwehr, Einträge landen in der Gerätepflege der Atemschutz-Datenbank.

### Neu in 5.2: Gerätewart und Atemschutzgerätewart getrennt anlegen

- Verwaltung → **Gerätewarte**: zwei Knöpfe „+ Gerätewart anlegen“ und „+ Atemschutzgerätewart anlegen“ – gleiche Eingaben (Name, Benutzer, Ortswehren, E-Mail, Startkennwort), getrennte Listen. Der Gerätewart bekommt die Gerätedatenbank, der Atemschutzgerätewart die Atemschutz-Datenbank.
- Der ausgedruckte Zugangszettel nennt die passende Datenbank und deren Link (von außen und im Netz des Pi).
- Ältere Zugänge mit beiden Bereichen stehen unter „Zugänge für beide Datenbanken“ und funktionieren weiter.

### Neu in 5.1: Kennwort der Gerätewarte alle 4 Monate

- Zugänge für Atemschutz- und Gerätedatenbank (auch von außen über die Internetadresse der ASÜ, Port 8443): Kennwort mind. 8 Zeichen, **alle 4 Monate** neu (statt 4 Wochen); Mail eine Woche vor Ablauf, Hinweis in der Datenbank 14 Tage vorher. Die letzten Kennwörter dürfen nicht wiederverwendet werden.

### Neu in 5.0: Eigene Seiten für Gerätedatenbank und Atemschutz-Datenbank

- Eigene Links `/geraete` und `/atemschutz` (ASÜ-Port, auch von außen), Links unter Verwaltung → Gerätewarte.
- Atemschutz-Nachweis als Reiter „Einsatznachweis“ in der Atemschutz-Datenbank.
- Außer Dienst (Fahrzeuge und Geräte) und Prüffristen werden in der Gerätedatenbank gepflegt; bisherige Einträge aus der Alarmmonitor-Verwaltung übernommen.

### Neu in 4.9: Verbrauch, Fahrzeug-Check, Beladungsprüfung, Ausleihen

- Fahrzeug-App 🔧-Menü: Schaden (mit Schnell-Knöpfen), Verbrauch nachfüllen, Fahrzeug-Check nach dem Einsatz (mit Erinnerung), Beladung prüfen.
- Gesammelte Mail an den Gerätewart nach dem Einsatz; Rückmeldung des Gerätewarts an die Besatzung.
- Gerätedatenbank: Ausleihen an andere Wehren, Listen je Ortswehr, „Beladung geprüft am …“.

### Neu in 4.8: Schäden aus der Fahrzeug-App melden

- 🔧 in der Fahrzeug-App: Gerät, Zustand (außer Betrieb / funktioniert noch), Beschreibung, Fotos.
- Im Einsatz ins Einsatztagebuch, sonst Mail an den Gerätewart; immer in der Gerätedatenbank unter „Schadensmeldungen“.

### Neu in 4.7: Gerätedatenbank für Gerätewarte

- Alle Geräte der Fahrzeuge und im Lager mit Zustand, Prüffristen, Prüf- und Schadensverlauf, Umsetzen, QR-Etiketten; Mail eine Woche vor der Prüfung.
- Ersetzt nach der einmaligen Übernahme die Ausrüstungsliste: im Einsatz zählen nur einsatzbereite Geräte, nicht verfügbare sind am Fahrzeug markiert.
- Zugänge der Gerätewarte mit Bereichen (Atemschutz, Geräte); Reiter in der ASÜ heißt jetzt „Datenbank“, in der Verwaltung „Gerätewarte“.

### Neu in 4.6: Alarmmonitor – außer Dienst und Nachtmodus

- Fahrzeuge (Status 6 oder eingetragen) und Geräte außer Dienst mit Grund und „voraussichtlich bis“; Atemschutzgeräte bei der FTZ.
- Nachtmodus: Bildschirm schwarz in einstellbarer Zeit, bei Alarm sofort wieder an.

### Neu in 4.5: Alarmmonitor mit Status-1-Karte, Kalender und Prüffristen

- Ruhezustand: Karte mit den Fahrzeugen im Status 1, Termine aus Google-/Apple-Kalendern (iCal) und Prüffristen.
- Verwaltung → Alarmmonitor: eigene Prüffristen (wiederkehrend), Kalender-Abo der Prüffristen für Google/Apple/Outlook.
- Selbsttest prüft die eingebundenen Kalender.

### Neu in 4.4: Prüftermine der Geräte mit Mail

- Zwei Prüftermine je Gerät und Jahr, von Hand oder für alle Geräte einer Wehr auf einmal („📅 Prüftermine setzen“).
- Mail an die Atemschutzgerätewarte eine Woche vor jedem Termin (statt bisher 4 Wochen vor „Prüfung fällig“).

### Neu in 4.3: Gerätepflege, Gerätetausch und Formblatt

- Atemschutz-Datenbank, Reiter **Gerätepflege**: Benutzungen aus Übungen und Einsätzen automatisch, Haken „FTZ“, Tauschgerät, selbst gepflegt, Mängel, Rückkehr von der FTZ.
- Vorausgefülltes **Formblatt** je Einsatz/Übung zum Drucken.
- Reiter Geräte: Nutzung (Anzahl, Zeit, zuletzt) und Zustand je Gerät.
- Die ASÜ übermittelt jetzt auch Flasche, LA, Maske und Drücke an den Nachweis.

### Neu in 4.2: Einsatzbereitschaft auf einen Blick, Selbsttest

- ASÜ, Atemschutz-Datenbank: neuer Reiter **Einsatzbereitschaft** – je Ortswehr einsatzbereite Träger, mögliche Trupps, Gründe, bald Ablaufendes; Warnung unter 2 Trupps.
- Verwaltung → Zustand des Pi: **Selbsttest** jeden Morgen mit Mail an die System-Empfänger (Speicher, Pi, Daten, Sicherungen, Mail, Fahrzeug-App, PowerAlarm, Atemschutz, Feuerwehrhäuser).

### Neu in 4.1.1: Einlesen mit getrenntem Nach- und Vornamen

- ASÜ, Trupp einlesen (QR-Code, Namensschild, Etikett): Nachname und Vorname sind eigene Felder. Ein erkannter Name („Max Mustermann“ oder „Mustermann, Max“) wird automatisch aufgeteilt.

### Neu in 4.1: Feuerwehrhäuser und Anfahrtszeiten

- Verwaltung → **Feuerwehrhäuser**: Standorte der 13 Ortswehren (Startwerte, bitte prüfen), Nachbarwehren per Hand oder aus OpenStreetMap, Regeln für die Anfahrtsschätzung, Test per Adresse.
- Übungsgenerator: „🚒 Nächste Wehren eintragen“, automatisch beim Zufallsgenerator, erwartete Zeit in der Auswertung.
- Übungsleitstelle: Fahrzeuge starten am Feuerwehrhaus, nächste Wehren im Alarmformular, Automatik mit Ausrückzeit und Tempo „realistisch“.

### Neu in 4.0.1: Atemschutz-Datenbank nur für die Gemeinde

- In der Atemschutz-Datenbank werden nur noch die Ortswehren der Gemeinde Aerzen geführt.

### Neu in 4.0: Atemschutz-Datenbank, QR-Codes, Sammel-App, Geräte-Abgleich neu

- **Atemschutz-Datenbank auf dem Pi:** Atemschutzgerätewarte pflegen Personen, Prüf- und Leistungsnachweise nach FwDV 7 und Geräte ihrer Ortswehr – im neuen ASÜ-Reiter „Atemschutz-DB“, auch von außen. Eigene Zugänge, Kennwort mindestens 8 Zeichen, alle 28 Tage neu.
- **QR-Codes** für Personen (mit versteckter Kennung) und Geräte, Flaschen, Lungenautomaten und Masken; Etiketten drucken.
- **Einsatzbereitschaft in der ASÜ:** Hinweis, wenn eine nicht einsatzbereite Person eingescannt oder ausgewählt wird.
- **Erinnerung per E-Mail** an den Gerätewart 4 Wochen vor Ablauf und bei Ablauf.
- **Einsätze und Übungen** aus der ASÜ landen automatisch im Nachweis der Person.
- **Sammel-App** fürs Handy: nur Personen und Trupps erfassen, Übergabe ausschließlich per QR-Code.
- **Mehrere Geräte** neu geordnet, Gerätename Pflicht, Anzeige „verbunden mit … – führt …“, Wehr-Schlüssel per QR.

### Neu in 3.99: Übungsleitstelle mit Sonderlage, Automatik und Übungsgenerator

- **Sonderlage üben:** Alarm als Sonderlage (Großschadenslage) mit Bereitstellungsraum; Aufträge der Leitstelle mit Ort auf der Karte und ⚡ Priolage; „🎲 Aufträge würfeln“ sofort oder über einen Zeitraum; Übersicht der offenen Aufträge und Aufträge auf der Karte.
- **Fahrzeuge in der Sonderlage:** zugewiesener Auftrag in der Fahrzeugkarte mit „Zum Auftrag fahren“, „Im Einsatz“ und „✓ Auftrag erledigt“; „📌 Einsatzstelle melden“ wie in der Fahrzeug-App.
- **🤖 Automatik:** Übungsfahrzeuge rücken selbst aus, fahren an, melden Status 4 und Stärke und arbeiten disponierte Aufträge in der eingestellten Zeit ab.
- **Übungsgenerator eingebunden:** Szenarien (dieses Gerät und Pi) direkt in der Übungsleitstelle abspielen – der Pi verschickt nach Zeitplan, nur an Übungsfahrzeuge. „🎲 Neu würfeln“ in der Übungsleitstelle, „🎛 In der Übungsleitstelle abspielen“ im Übungsgenerator.
- Karte der Übungsleitstelle bleibt beim Scrollen stehen; die Startseite verliert beim Tippen keine Eingaben mehr.

### Neu in 3.98: Übungsleitstelle – eine Person spielt Fahrzeuge und Leitstelle

Aufruf: Reiter Einsatz → „🎛 Übungsleitstelle“ (ohne laufenden Einsatz) oder direkt `http://<Pi>:8080/uebleitstelle/` – Anmeldung mit Benutzer und PIN der Einsatzverwaltung (Einsatzleitung oder Admin).

**Grundsatz:** Für die Übung werden **Übungsfahrzeuge** angelegt – Kopien der gewählten Fahrzeuge mit gleichem Funkrufnamen. Alarm, Status, Stärke, Position und Nachrichten gehören nur zu diesen virtuellen Fahrzeugen. **Echte Fahrzeuge, echte Fahrzeug-Apps, Push-Meldungen, Alarmmonitor und „Wer kommt?“ bleiben unberührt**; Mails und Lagemeldungen nach außen gibt es bei Übungen nicht. In einen Übungseinsatz können keine echten Fahrzeuge, in einen echten Einsatz keine Übungsfahrzeuge – ein echter Alarm während der Übung läuft ganz normal.

**Ablauf**
1. **Übung starten:** Namen eintragen, mitspielende Fahrzeuge ankreuzen (Filter nach Funkrufname, Typ, Ortswehr), „Übung starten“.
2. **Leitstelle:** Stichwort, Meldebild, Einsatzort (Adresse suchen oder 📍 auf der Karte) und Fahrzeuge wählen → „Alarmieren“. Der Einsatz erscheint in der Einsatzverwaltung mit „ÜBUNG:“ und einem lila Hinweisbalken. Je Einsatz: **Nachalarmieren**, **Meldung Leitstelle** (ins Einsatztagebuch), **Auftrag (Sonderlage)**; Kräfteanforderungen der Einsatzleitung werden angezeigt.
3. **Fahrzeuge:** je Fahrzeug Status 1, 2, 3, 4, 6, A sowie 5 (Sprechwunsch) und 0 (Notruf), **Nachricht an ELW** (mit Vorlagen), **Stärke melden**, **Anfahrt simulieren** (fährt mit der gewählten Geschwindigkeit zum Einsatzort, Status 4 bei Ankunft), **Fahren nach …** und **Standort** auf der Karte.
4. **Posteingang:** Nachrichten und Aufträge der Einsatzleitung an die Übungsfahrzeuge – mit Ton, „✓ Verstanden“ und „↩ Antworten“.
5. **Übung beenden:** Übungseinsätze werden beendet (bleiben als Übung im Archiv), die Übungsfahrzeuge mit allen Daten gelöscht.

### Neu in 3.97: Gefahrstoffdatenbank aus ADR 2025 und ERG 2024 – auf Deutsch

- **Reiter „Gefahrstoffdatenbank“** (vorher „Gefahrstoffe“).
- **Daten aus den Originalen:** alle 2.347 UN-Nummern des ADR 2025 (Tabelle A) mit deutscher Benennung, Klasse, Klassifizierungscode, Verpackungsgruppe, Gefahrzetteln, Tunnelbeschränkungscode und **Gefahrnummer**. Für **jeden** Stoff Einsatzleitfaden und Absperrabstände nach ERG 2024; Tabelle 1 und 3 mit den **metrischen Originalwerten**, Tabelle 2 (giftige Gase bei Kontakt mit Wasser).
- Mehrere Benennungen derselben UN-Nummer (z. B. 1993 mit verschiedenen Verpackungsgruppen) werden im Kopf mit VG und Gefahrnummer aufgeführt.
- Alles auf Deutsch; die Benennungen sind aus dem englischen ADR übersetzt (nicht amtlicher Wortlaut).
- **Gefahrstoff im Einsatz eintragen** (Übersicht → ☣ Gefahrstoff eintragen): Suche und Nummer greifen auf die Datenbank zu, Name, Gefahrnummer und Klasse werden übernommen, darunter eine Kurzinfo (Leitfaden, giftig, Sofortabsperrung).
- **Einsatz-Reiter „Gefahrstoff“** zwischen Atemschutz und VU – erscheint, sobald ein Gefahrstoff eingetragen ist. Zeigt für jeden Stoff das komplette Einsatzblatt (Absperrung, Gefahrnummer, Klasse, Leitfaden, Stoffwerte) mit „Absperrbereich auf die Lagekarte“ und „Aus dem Einsatz entfernen“. Der Knopf „Einsatzblatt“ in der Übersicht springt dorthin.
- **Lagekarte ⌂:** zeigt jetzt 1 km um das Gerätehaus (52.05477, 9.23712). Mittelpunkt und Umkreis sind unter Verwaltung → Einstellungen änderbar.

### Neu in 3.96: Gefahrstoff-Datenbank mit Einsatzblatt und Absperrbereich

**Reiter Gefahrstoffe**
- **Suche** nach UN-Nummer oder Name (deutsch oder englisch, z. B. „1017“, „Chlor“, „Salzsäure“, „Diesel“) – mit Pfeiltasten und Enter wählbar. Die Warntafel-Eingabe bleibt.
- **Datenbank:** rund 2.350 gültige UN-Nummern. Benennung englisch (Liste nach US-DOT, Wikipedia) und deutsch (maschinell übersetzt, *nicht amtlich*). Für 52 häufige Stoffe gepflegte deutsche Benennung mit Gefahrnummer nach ADR.
- **Einsatzblatt** je Stoff:
  - Kopf mit Warntafel, Klasse, ERG-Leitfaden und Warnung „giftig beim Einatmen“.
  - **Absperrung:** Sofortabsperrung, Evakuierung bei großem Austritt und bei Brand nach Leitfaden; bei giftigen Gasen/Dämpfen **ERG-Tabelle 1** (kleiner/großer Austritt, Tag/Nacht) und **Tabelle 3** (nach Behälter und Windstärke).
  - **Einsatzleitfaden** (alle 62 ERG-2024-Leitfäden ins Deutsche übersetzt): Gesundheits-, Brand- und Explosionsgefahr, Erstmaßnahmen, Schutzkleidung, Evakuierung, Brandbekämpfung, Leckage, Erste Hilfe – mit Link zum englischen Original.
  - **Stoffwerte** für 113 häufige Stoffe: schwerer/leichter als Luft, Dichte (schwimmt/sinkt), Siedepunkt, Flammpunkt, Explosionsgrenzen, Wasserlöslichkeit, Reaktion mit Wasser, CAS-Nr. (NOAA CAMEO Chemicals).
  - Links zu GESTIS, ERI-Cards und CAMEO.
- **☣ In den Einsatz übernehmen:** Stoff kommt an den laufenden Einsatz (Übersicht, Bericht) mit Tagebuch-Eintrag.
- **↔ Absperrbereich auf die Lagekarte:** Lage (kleiner/großer Austritt, Brand), Tag/Nacht (automatisch nach Sonnenstand), Behälter, Wind (Richtung und Stärke, „Aktuellen Wind abrufen“). Gezeichnet werden ein Absperrkreis und – wenn vorhanden – der Schutzbereich als Kegel in Windrichtung; dazu ein Tagebuch-Eintrag. Auch aus dem Gefahrstoff-Block im Einsatz erreichbar („↔ Absperrbereich“).

**Wichtig:** Erstinformation für die Feuerwehr – Lage durch Fachberater / TUIS bestätigen lassen. Maßgeblich sind Beförderungspapier, schriftliche Weisungen und die Warntafel. Leitfäden und Tabelle-1-Werte stammen aus dem ERG 2024 (US/Kanada/Mexiko), Abstände von ft/mi in m/km umgerechnet. Eine Stichprobenprüfung gegen die Quellen liegt in docs/GEFAHRSTOFFE_PRUEFBERICHT.md.

### Neu in 3.95: Vollbild nur mit Karte

- Im Vollbild der Lagekarte erscheinen nur noch Karte, Werkzeuge, Lagekarte/Einsatztaktik, „Vollbild beenden“ und „← Zurück“. Die Reiterleiste des Einsatzes ist im Vollbild ausgeblendet.

### Neu in 3.94: Lagekarte gehört zum Einsatz

- Über der Lagekarte sieht die Reiterleiste genauso aus wie in den anderen Bereichen – mit den Zahlen (Tagebuch, Fahrzeuge, Checklisten …) und dem ⧉-Knopf für ein eigenes Fenster.
- Der Hauptreiter „Lagekarte“ in der oberen Reihe ist entfallen. Die Karte erreicht ihr über Einsatz → Lagekarte; ohne laufenden Einsatz über den Knopf „🗺 Lagekarte“ im Reiter Einsatz. Auch die Suche (Strg+F) springt weiterhin in die Karte.

### Neu in 3.93: Tagebuch-Eingabe fest oben, Lagekarte im gewohnten Rahmen

- **Tagebuch:** Der Eingabebereich bleibt beim Scrollen unter der Reiterleiste stehen – ältere Einträge lesen und gleichzeitig weiterschreiben. Der Diktierknopf 🎤 sitzt rechts neben dem Inhaltsfeld (⏹ = Diktat beenden).
- **Lagekarte aus dem Einsatz:** Die Ansicht bleibt wie im Einsatz – Hauptreiter „Einsatz“ bleibt markiert, die Reiterleiste steht an derselben Stelle. Lagekarte/Einsatztaktik und Vollbild stehen darunter. „← Zurück“ erscheint nur noch im Vollbild (verlässt das Vollbild und geht zurück).
- **Aufträge** erscheinen als Reiter nur noch bei einer Sonderlage (Großschadenslage bzw. sobald Aufträge vorhanden sind).

### Neu in 3.92: Posterdruck mit Blattanzahl und Vorschau, Funkskizze mit Unterabschnitten

- **Posterdruck** (Lagekarte → 📷 Ausschnitt / Poster → 🖨 Posterdruck):
  - *Auf mehrere Blätter:* Blattformat (A4/A3) und **Anzahl Blätter** (1 bis 36) wählen. Die beste Anordnung (Spalten × Reihen, Blatt hoch/quer) wird passend zum Bereich ausgesucht; unter „Anordnung“ lässt sich eine andere wählen.
  - *Eine große Seite:* A4 bis A0 für Plotter, Copyshop oder PDF.
  - Die **Vorschau** zeigt das Poster mit Karte, Überschrift, Blattgrenzen, Blattnummern und den roten Klebekanten. Darunter stehen Postergröße in cm und Maßstab.
  - Im Druckdialog „Tatsächliche Größe“ bzw. 100 % wählen, nicht „An Seite anpassen“.
- **Funkskizze:** Unterabschnitte hängen unter ihrem Abschnitt (mit „↳“, Verbindungslinie und eigenem Kanal) – der Funkweg läuft erkennbar über den Abschnitt. In der Tabelle steht „↳ Name (UA von …)“.
- **Übersicht:** Die Knöpfe „Lagekarte“ und „Einsatztaktik“ sind entfallen – die Lagekarte ist ein eigener Reiter, die Einsatztaktik wird dort oben umgeschaltet.

### Neu in 3.91: Kompakter Kopf, feste Reiterleiste, neue Reihenfolge

- **Kopfbereich kompakter:** Wappen, Knöpfe, Uhr und Hauptreiter sind kleiner, damit mehr Platz für den Inhalt bleibt. Bei schmalen Fenstern entfällt der Schriftzug neben dem Wappen.
- **Reiterleiste bleibt stehen:** Die Reiter im Einsatz und in der Verwaltung bleiben beim Scrollen fest unter dem Kopfbereich.
- **Reihenfolge im Einsatz:** Übersicht · Tagebuch · Aufträge · Fahrzeuge · Abschnitte · Lagekarte · Nachrichten · Atemschutz · VU · Checklisten · Nachbereitung · Zeitstrahl. Die Lagekarte steht ohne Symbol in der Reihe.
- **Nachrichten und Fotos zusammen:** Unter „Nachrichten“ gibt es die Unterreiter 💬 Nachrichten (öffnet zuerst) und 📷 Fotos.
- **Kompakte Leiste:** Passt die Reiterleiste nicht in eine Zeile, zeigt sie nur noch Symbole; beim Drüberfahren mit der Maus erscheint der Name. Zähler (z. B. ungelesene Nachrichten) bleiben sichtbar.

### Neu in 3.90: Abschnitte übersichtlicher

- **Unterabschnitte hängen sichtbar am Hauptabschnitt:** Sie stehen direkt unter ihrem Hauptabschnitt, sind mit einer Linie in dessen Farbe verbunden und tragen dieselbe Farbe.
- **Bereitstellungsraum als schmale Leiste rechts:** Im Reiter Abschnitte steht jeder Bereitstellungsraum kompakt am rechten Rand – nur Funkrufname und Fahrzeug bzw. Funktion. Antippen klappt ihn auf (Adresse, Stärke, Link/QR, Auflösen …), „⟩ zu“ klappt ihn wieder ein. Fahrzeuge lassen sich auch aus der schmalen Ansicht am Griff ⠿ herausziehen. Auf schmalen Bildschirmen steht die Leiste unter den Abschnitten.

### Neu in 3.89: Unterabschnitte, Diktieren und freie Gesprächspartner

- **Lagekarte-Suche:** Eine Koordinate (z. B. `52.04, 9.26`) oder eine what3words-Adresse (`///wort.wort.wort`) springt direkt zur Stelle in der Lagekarte – auch über die Schnellsuche (Strg+F), dort erscheint als erster Treffer „🗺 … in der Lagekarte zeigen“. what3words braucht einen hinterlegten Schlüssel.
- **Unterabschnitte:** Bei jedem Abschnitt gibt es „+ UA“. Im Abschnitt-Dialog legt „Gehört zu“ den übergeordneten Abschnitt fest (eine Ebene). Unterabschnitte erscheinen eingerückt mit „↳“, in Listen als „Abschnitt › Unterabschnitt“. Wird ein Abschnitt gelöscht, werden seine Unterabschnitte eigenständig; Fahrzeuge wandern in den übergeordneten Abschnitt.
- **ASÜ:** Hinweise „fehlender Wehr-Schlüssel“ erscheinen nicht mehr, alte offene Meldungen dieser Art werden beim Start automatisch quittiert. Ein *falscher* Schlüssel wird weiterhin gemeldet.
- **🎤 Diktieren:** Im Einsatztagebuch und in der Fahrzeug-App (Nachrichten) kann Text per Sprache eingegeben werden. Funktioniert in Chrome, Edge und Safari (meist mit Internetverbindung), das Mikrofon muss erlaubt werden. In Firefox wird der Knopf nicht angezeigt.
- **Tagebuch Von/An:** Freie Texteingabe – die Liste filtert beim Tippen. Nicht aufgeführte Gesprächspartner (z. B. „Bauhof Herr Meier“) einfach eintragen; sie stehen danach für diesen Einsatz in der Vorauswahl unter „In diesem Einsatz eingetragen“. Der Knopf **⇄** tauscht Sender und Empfänger.

### Neu in 3.88: Lagekarte, Timer, Alarmmonitor und vieles mehr

- **Funkrufname der Führungsstelle:** Führt die **ÖEL**, ist der Funkrufname **14-09-10** (ELW: 14-11-10). Er steht als Absender in der Fahrzeug-App („ÖEL 14-09-10“), im Einsatzkopf und in der Funkskizze. Ändern: Verwaltung → Einstellungen (Funkrufname ELW / ÖEL).
- **Eigene Timer:** In der Übersicht bei den Einsatz-Uhren **„+ Timer“**: Name, Zeit (Dauer oder Uhrzeit) und Zweck eingeben. Ist er abgelaufen, meldet er sich wie die anderen Uhren (Ton, Hinweis) – „erledigt“, „+10 min“ oder löschen. Alles steht im Tagebuch.
- **Lagekarte:** Fahrzeuge und Marker **wachsen und schrumpfen mit dem Zoom** (Zoomstufe 17 = Originalgröße).
- **Schlauchleitungen verlängern:** Leitung antippen → **„➕ Am Ende verlängern“** bzw. **„Am Anfang verlängern (Wasserentnahme)“** und die Verlängerung zeichnen – sie wird an die Leitung angehängt (eine Förderberechnung wird dann neu gemacht). Die **Saugleitung** gibt es als Werkzeug nicht mehr (alte bleiben sichtbar).
- **Lagekarte als Reiter im Einsatz:** In der Einsatzansicht gibt es den Reiter **„🗺 Lagekarte“**. Kommt man aus der Einsatzansicht zur Karte (Reiter, „In der Lagekarte zeigen“ usw.), bleiben die Reiter des Einsatzes über der Karte stehen – ein Tipp führt zurück.
- **Fahrzeugdetails:** Statt „In OpenStreetMap anzeigen“ jetzt **„🗺 In der Lagekarte zeigen“**.
- **Fahrzeug-App:** Auch bei **„Verfügbar“** wird der Standort weiter gesendet (nicht mehr bei Status 2/6, außer „immer senden“). Auf der Karte gibt es **💧 Hydranten und Wasserentnahmestellen** (ab Zoomstufe 14, antippen zeigt Art und DN) – mit 💧 ein- und ausblendbar.
- **Nachrichten aus einem Auftrag:** Schickt ein Fahrzeug im Auftrag eine Nachricht, ist sie in Einsatz → Nachrichten mit „📋 Auftrag …“ markiert. Mit **„Bericht“** kommt sie zusätzlich ins **Tagebuch des Auftrags** (✓).
- **ELW-Besatzungs-App:** Die Karte hängt beim Zoomen nicht mehr (nicht mehr benötigte Kacheln werden abgebrochen, Mausrad/Touchpad gebremst, Zwei-Finger-Zoom ohne Sprung).
- **Alarmmonitor:** In den Monitor-Einstellungen wählbar: im Alarm **Fahrzeuge der Ortswehr mit Status** und **alle im Einsatz geführten Kräfte** (auch anderer Wehren und die laut Alarmierung mitalarmierten Kräfte) anzeigen.
- **Mail-Anhänge** öffnen jetzt direkt in der Einsatzverwaltung (PDF, Bilder, Text) bzw. werden heruntergeladen – auch in der installierten App und auf dem iPad. Gespeichert werden die Anhänge aller abgelegten Mails.

### Neu in 3.87: Neue Symbole in der ELW-Besatzungs-App

Auf der Karte „Standort ELW“ ist die **Einsatzstelle jetzt eine Flamme 🔥** und der **ELW ein Fahrzeug 🚒** mit Funkrufname darunter. Die Knöpfe rechts an der Karte (🚒 = zum ELW, 🔥 = zur Einsatzstelle) passen dazu.

### Neu in 3.86: Fahrzeug-App nur auf einem Endgerät

Je Fahrzeug läuft die Fahrzeug-App nur noch auf **einem Endgerät**:
- Das **erste Gerät**, das den Link öffnet, wird gebunden. Innerhalb von 30 Minuten darf **dasselbe Handy** noch einmal übernehmen (z. B. iPhone: erst Safari, dann die App vom Home-Bildschirm) – danach nicht mehr.
- Jedes **andere Gerät** sieht „📵 Dieses Fahrzeug ist bereits auf einem anderen Gerät angemeldet“ mit einem **Code** und kann **„Freigabe bei der Einsatzleitung anfragen“**.
- In der Einsatzverwaltung (Fahrzeug → Fahrzeug-App-Link → Zugang) steht, an welches Gerät die App gebunden ist (z. B. „iPhone · Safari, Code 52CA“). Bei einer Anfrage: Code vergleichen und **„✓ Auf … wechseln“** – das bisherige Gerät ist dann abgemeldet. Oder **„Gerät freigeben“**: das nächste Gerät wird gebunden. Anfragen erscheinen auch in der Hinweis-Zentrale (🔔), abgewiesene Zugriffe bei Admins als Sicherheitshinweis.
- **„Neuer Link“** löst die Bindung ebenfalls.
- **Mehrere Endgeräte erlauben:** Verwaltung → Fahrzeuge → Fahrzeug bearbeiten → „Fahrzeug-App auf mehreren Endgeräten erlauben“.
- Die Begleit-App für den Standort bei gesperrtem Handy ist davon nicht betroffen.

### Neu in 3.85: Andere Fahrzeuge auf der Karte der Fahrzeug-App

Im Reiter **Karte** der Fahrzeug-App erscheinen die anderen Fahrzeuge **desselben Einsatzes** mit Funkrufname und Status (rot = Standort aktuell, grau = älter als 15 min; gezeigt wird höchstens 1 Stunde alter Standort). Antippen zeigt Fahrzeug, Status, Uhrzeit des Standorts und Koordinate (mit Navigation).
- **Abwählbar** mit dem Knopf **„FZ“** rechts an der Karte (durchgestrichen = aus). Die App merkt sich die Einstellung.
- Voraussetzung: Die anderen Fahrzeuge senden ihren Standort aus der Fahrzeug-App; Karte in der Fahrzeug-App nicht „aus“.

### Neu in 3.84: Fahrzeug-App mit drei Reitern

Die Reiter **Stärke** und **Standort** sind entfallen. Unten stehen nur noch **Einsatz · Nachrichten · Karte** (bei Sonderlage zusätzlich Melden).
- **Stärke** steht unverändert im Reiter **Einsatz** unter „Einsatzbereitschaft“ (Führer, Mannschaft, davon AGT, „Stärke melden“).
- **📍 Standort** und **🔔 Benachrichtigungen** sind im Reiter Einsatz **aufklappbar**. Zugeklappt zeigt die Zeile den aktuellen Stand (z. B. „Gesendet 14:32 · ±8 m“ bzw. „eingeschaltet“); ein ⚠ erscheint, wenn der Standort nicht gesendet werden kann. Die App merkt sich, was aufgeklappt ist.

### Neu in 3.83: Fahrzeug an Fahrzeug, ASÜ eigenständig oder angeschlossen

**Fahrzeug-App – Nachrichten an andere Fahrzeuge:** Ist das Fahrzeug im Einsatz, steht über dem Eingabefeld **„An:“** mit 🏢 Einsatzleitung und allen anderen Fahrzeugen dieses Einsatzes (🚒 …, „alle Fahrzeuge“). Mehrfachauswahl ist möglich – z. B. Einsatzleitung und ein Fahrzeug gleichzeitig.
- Das empfangende Fahrzeug bekommt eine Meldung („Nachricht von …“); die Nachricht steht violett im Verlauf, ohne „Verstanden“.
- In der Einsatzverwaltung erscheint sie unter **Einsatz → Nachrichten** violett mit **„Fahrzeug ⇄ Fahrzeug“** – **ohne Ton, ohne Hinweis, nicht als ungelesen**. Filter „Fahrzeug ⇄ Fahrzeug“; per Häkchen auch in den Einsatzbericht.

**Atemschutzüberwachung – Einsatz anschließen?** Beginnt man an der ASÜ einen Einsatz (z. B. „Leeren Einsatz beginnen“) und läuft in der Einsatzverwaltung ein Einsatz, fragt die ASÜ: **„Möchtest du dich dem Einsatz … anschließen?“** (bei mehreren Einsätzen: Auswahl).
- **Ja:** Truppstatus erscheint beim Einsatz und im Tagebuch (wie bisher).
- **Nein, eigenständig überwachen:** Die Überwachung erscheint **nicht** in der Einsatzverwaltung. Die Atemschutzzeiten (Beginn, Ende, Personen, Trupp) gehen trotzdem in den **Atemschutz-Nachweis** (Verwaltung → Atemschutz-Nachweis).
- „Später“ fragt nach 3 Minuten erneut. Ändern geht jederzeit unter Einsatzdaten → „Einsatz der Einsatzverwaltung“.
- Neu: Die Zeiten gehen auch bei angeschlossenen ASÜ (ohne gemeinsamen Einsatz) automatisch in den Atemschutz-Nachweis.

### Neu in 3.82: Fahrzeuge hinzufügen und aus dem Einsatz nehmen

**Fahrzeug hinzufügen** (Einsatz → Fahrzeuge bzw. Übersicht): Das Fenster zeigt sofort alle freien Fahrzeuge aus der Fahrzeugliste, nach Ortswehr gruppiert – zuerst die eigene Gemeinde, umschaltbar auf „Alle Gemeinden“, optional „nur einsatzbereit (Status 1/2)“.
- Die **erste Zeile ist ein Filter** (Funkrufname, Typ, Ortswehr, Gemeinde, Kennzeichen; mehrere Wörter möglich). Mit Filtertext wird in allen Gemeinden gesucht; Enter wählt den einzigen Treffer.
- **Mehrere Fahrzeuge** anhaken, Status (3 oder 4) wählen → „… Fahrzeuge hinzufügen“. Fahrzeuge in einem anderen Einsatz sind ausgegraut.
- Steht das Fahrzeug nicht in der Liste, öffnet sich unten „Neu anlegen“ mit dem Filtertext als Funkrufname.

**Aus dem Einsatz nehmen über die Fahrzeugansicht:** Fahrzeug öffnen → **„✕ Aus Einsatz … entfernen“**. Dann wählen:
- **Aus dem Einsatz entlassen** (Status 2) – bleibt in Tagebuch, Stärke und Bericht (normaler Weg).
- **Ganz entfernen** – z. B. versehentlich zugeordnet: wird entlassen und erscheint nicht mehr in Fahrzeugliste, Stärke und Bericht (Grund optional, Vermerk im Tagebuch).
Bei bereits entlassenen Fahrzeugen gibt es nur „Ganz entfernen“.

### Neu in 3.81: Fahrzeug-App – Reiter Nachrichten neu geordnet

- **Oben** steht immer die Eingabe „Nachricht an die Einsatzleitung“.
- Darunter **„Neu – bitte bestätigen“**: Nachrichten der Einsatzleitung, die noch nicht mit „Verstanden“ bestätigt sind.
- Ganz unten der **Verlauf**: gesendete und bestätigte Nachrichten gemeinsam nach Zeit (neueste oben) – ⬆ gesendet (grün, mit „gelesen“/„noch nicht gelesen“), ⬇ empfangen (blau, mit „verstanden“).
- **Anklickbar** in allen Nachrichten (Fahrzeug-App und Einsatzverwaltung): Links (auch ohne https, z. B. www.…), ///what3words und Koordinaten (auch „52.05123 9.26111“ ohne Komma). In der Fahrzeug-App auch Ort und Text des Auftrags im Reiter Einsatz.

### Neu in 3.80: Crash Recovery bei VU, ÖEL, Aufräumen und Komfort

**🚗 Crash Recovery System bei VU:** Im Reiter VU hat jedes Unfallfahrzeug den Bereich **„Rettungsdaten“**:
1. **„🚗 CRS öffnen“** startet das Crash Recovery System auf diesem Gerät (muss installiert und freigeschaltet sein). Deutsche Kennzeichen kann das CRS nicht abfragen – dort Hersteller, Modell und Baujahr wählen. Bei ausländischen Kennzeichen (NL, BE, AT, CH, DK, …) Land wählen – dann sucht das CRS das Kennzeichen direkt.
2. Unter **„📋 Erfassen“** das Rettungsblatt als **Bildschirmfoto** übernehmen (🖥 Bildschirmfoto, 📷 Bild wählen oder Windows + Umschalt + S und Strg + V; ✂ = Ausschnitt), Baujahr, Lage der 12-V-Batterie, die wichtigsten Punkte (Airbags, Gurtstraffer, Hochvolt, Trennstelle, Verstärkungen, Tank) und Hinweise eintragen.
3. **„Speichern und an Fahrzeuge senden“** öffnet die Nachricht an die Fahrzeuge mit Text und Bildern (vorgewählt: Fahrzeuge mit Status 4). Die Bilder kommen auf Wunsch in die Fotodokumentation, die Rettungsdaten stehen im Tagebuch und im Einsatzbericht.

**Führungsstelle ELW / ÖEL:** Beim Anlegen oder Bearbeiten eines Einsatzes wählbar. Vorschlag: Sonderlage = **ÖEL**, sonst **ELW**. Überall (Tagebuch, Nachrichten an die Fahrzeuge, Aufträge, Einsatzkopf) steht dann die gewählte Führungsstelle.

**Einsatzuhr bei Sonderlage:** In der großen Anzeige „Einsatz-Uhren“ stehen die offenen Aufträge mit Priolage/Priorität, Ort, Fahrzeug und Wartezeit (antippen = Auftrag öffnen).

**Fahrzeug-App – Nachrichten:** Wird ein Fahrzeug zu einem Auftrag disponiert (oder bekommt im Einsatz einen Auftrag als Text), steht der Auftrag **zusätzlich im Reiter Nachrichten** – mit Ort als anklickbarer Koordinate.

**Status 2 löscht „Im Einsatz“/„Verfügbar“** der Fahrzeug-App.

**Fahrzeuge aus dem Einsatz entfernen:** In der Übersicht unter „Aus dem Einsatz entlassen“ → **✕ Entfernen** (optional mit Grund). Das Fahrzeug erscheint dann nicht mehr in Fahrzeugliste, Stärke und Bericht; der Vorgang steht im Tagebuch.

**Letzte GPS-Position:** In Einsatz → Fahrzeuge steht unter jedem Fahrzeug „📍 GPS hh:mm · vor …“ (grün = aktuell, orange = älter, grau = noch kein GPS).

**Anhänge im E-Mail-Postfach öffnen:** Anhänge gesendeter und empfangener Mails (freigegebene Absender) lassen sich anklicken – PDF, Bilder und Text öffnen im Browser, alles andere wird heruntergeladen (⬇). Gilt für Mails ab dieser Version; Aufbewahrung wie die Mail (90 Tage).

**Beim Schließen abmelden:** Wer das letzte Fenster der Einsatzverwaltung schließt, ist abgemeldet (Neuladen bleibt angemeldet). Abschaltbar: Verwaltung → Einstellungen → Betrieb → „Beim Schließen der Einsatzverwaltung abmelden“.

**Automatisch angelegte Einsätze:** Einsätze aus E-Mail/Leitstelle, an denen niemand etwas macht (kein Eintrag, kein Fahrzeugstatus 3/4, keine ASÜ), werden nach **1 Stunde** automatisch beendet und im Archiv gespeichert. Der Einsatzkopf zeigt das solange an. Zeit einstellbar (0 = aus): Verwaltung → Einstellungen → Betrieb.

### Neu in 3.79: Kommunikation mit den Fahrzeugen

**Lange Wegstrecke direkt an die Fahrzeuge:** In der B-Leitung → „Pumpen berechnen“ die Fahrzeuge den Pumpen zuteilen und **„📤 An die Fahrzeuge senden“** tippen. Es entsteht ein Kartenbild der Förderstrecke, in dem jede Pumpe (P, VP 1, VP 2 …) mit dem **zugeteilten Fahrzeug** und der Verteiler eingezeichnet sind. Jedes Fahrzeug bekommt eine eigene Nachricht mit **seinem Standort als ///what3words und Koordinate**, dem Ausgangsdruck und der Übersicht aller Pumpen – plus das Bild. Optional geht die Übersicht auch an weitere Fahrzeuge im Einsatz. Ein Vermerk kommt ins Tagebuch.

**Links und Koordinaten anklickbar – überall:** In Nachrichten (Einsatzverwaltung und Fahrzeug-App) sind Internet-Links, **///what3words** und Koordinaten (z. B. „52.05123, 9.26111“) anklickbar. ///what3words und Koordinaten springen direkt in die Karte (Einsatzverwaltung: Lagekarte, Fahrzeug-App: Reiter Karte). Ohne Karte öffnet sich what3words.com bzw. OpenStreetMap.

**what3words immer mit ///:** Wer in einer Nachricht „//wort.wort.wort“ oder „w3w: wort.wort.wort“ schreibt, bekommt beim Senden automatisch die richtige Schreibweise ///wort.wort.wort.

**Bereitstellungsraum-Link:** „📤 An Fahrzeug“ schickt jetzt den Link mit – in der Fahrzeug-App direkt antippbar.

**Bild an Fahrzeuge – Bildschirmfoto und Ausschnitt:** Im Fenster „Nachricht an Fahrzeuge“: **🖥 Bildschirmfoto** (Bildschirm/Fenster wählen), **🗺 Kartenausschnitt** (Bereich in der Lagekarte aufziehen → „In die Nachricht übernehmen“) oder ein mit **Windows + Umschalt + S** aufgenommenes Bild mit **Strg + V** einfügen. Mit **✂** an einem Bild wählt man einen Ausschnitt.

**Koordinate an Fahrzeug:** Im Koordinaten-Fenster (Tippen auf die Karte) gibt es **„✉ An Fahrzeug senden“** – mit ///what3words und Koordinate.

**Fahrzeug-App:**
- **Alle empfangenen Nachrichten** der letzten 24 Stunden stehen im Reiter Nachrichten (neueste oben), auch nach „Verstanden“ – ebenso alle gesendeten.
- Die **Karte füllt den ganzen Bildschirm**; Suche oben, Infos unten (mit × schließbar). **⛶** blendet zusätzlich die Kopfzeile aus.
- **Gemeldete Aufträge kann das meldende Fahrzeug nicht mehr selbst übernehmen** – das Häkchen „Wir übernehmen selbst“ ist entfallen. Wer den Auftrag bekommt, entscheidet die Einsatzleitung in der Disposition.

### Neu in 3.78: ASÜ über GitHub an die Ortswehren verteilen – Anmeldung über den Pi

Die ASÜ lässt sich jetzt über eine feste Internetadresse an alle Ortswehren verteilen, z. B. **GitHub Pages** (kostenlos) oder einen anderen https-Webspace. Angemeldet wird **über den Pi**, mit denselben Zugängen wie unter Verwaltung → ASÜ-Zugänge. Bei neuen Versionen bleiben die Kennwörter gleich.

**Einrichten (Verwaltung → ASÜ-Zugänge → „ASÜ über GitHub an die Ortswehren verteilen“):**
1. Die **Adresse der Seite** eintragen, z. B. `https://feuerwehr-aerzen.github.io/asue/`.
2. Die **Internetadresse des Pi für die ASÜ** eintragen: die Tailscale-Funnel-Adresse mit `:8443/api`, z. B. `https://raspberrypi.tailXXXX.ts.net:8443/api`. Vorgeschlagen wird sie aus der externen Adresse der Fahrzeug-App.
3. **„⬇ Paket für GitHub erzeugen (ZIP)“** (mit PIN). Die Seite wird dabei automatisch für den Zugriff auf den Pi freigegeben (Einstellung „Erlaubte Herkunft der ASÜ-App“).
4. Das ZIP entpacken und **alle Dateien samt Ordner `wappen`** im GitHub-Repository hochladen. Die Kurzanleitung steht unter „So geht's“ und in `LIESMICH.txt`.

**Was das Paket enthält:**
- Die ASÜ-App mit Wappen.
- `asue-config.js` mit den Adressen des Pi.
- Eine **leere** Zugangsliste. Im Internet liegen also **keine** Kennwort-Prüfwerte, die Zugänge bleiben nur auf dem Pi.

**Anmelden in der ASÜ (Ortswehr):**
- Die **erste Anmeldung auf einem Gerät** geht über den Pi und braucht deshalb Internet. Der Pi prüft das Kennwort, ein Startcode funktioniert genauso (danach eigenes Kennwort festlegen, siehe 3.77). Das Gerät merkt sich den Zugang seiner Feuerwehr und **den Wehr-Schlüssel** – er muss nicht mehr von Hand eingetragen werden.
- **Danach geht die Anmeldung auch ohne Verbindung** mit dem gemerkten Zugang.
- **Mit Verbindung entscheidet immer der Pi.** Ändert die Feuerwehr ihr Kennwort an einem Gerät oder setzt der Admin es neu, gilt das sofort an allen Geräten, sobald sie online sind.
- **Neue Version:** Ein neues Paket erzeugen und alle Dateien auf GitHub ersetzen. Die Tablets laden die neue Version beim nächsten Öffnen, bleiben angemeldet und behalten ihren Zugang.
- Auf dem Ausdruck mit Startcode bzw. Kennwort stehen jetzt auch **Adresse und QR-Code** der Seite. Der Benutzer ist darin schon eingetragen (`?u=reher`).
- Auf der Anmeldeseite gibt es unter „Adresse des Pi“ eine Möglichkeit, die Adresse von Hand zu ändern. Sie ist nur nötig, wenn sich die Adresse des Pi ändert, bevor ein neues Paket hochgeladen ist.

**Wichtig:** Von GitHub aus erreicht die App den Pi **nur über https** (Tailscale Funnel, Port 8443). Der **Wehr-Schlüssel** sollte gesetzt sein (Einstellungen → Schnittstellen). Die Seite zeigt dazu einen Hinweis. Die ASÜ direkt vom Pi (Port 8082 im Gerätehaus) funktioniert weiter wie bisher.

### Neu in 3.77: Kennwort legt die Feuerwehr selbst fest (Startcode)

Unter **Verwaltung → ASÜ-Zugänge** können Sie einen Zugang so anlegen oder zurücksetzen, dass die Feuerwehr **bei der ersten Anmeldung ihr eigenes Kennwort festlegt**. Das ist jetzt die Vorgabe.

**In der Einsatzverwaltung (Admin):**
- „+ Zugang anlegen“, „🔑 Neues Kennwort“ und „Neue Kennwörter für ausgewählte“ bieten **Startcode** (vorausgewählt) oder ein fertiges Kennwort an. Bei „Neues Kennwort“ gibt es zusätzlich ein eigenes.
- Der **Startcode** sieht aus wie `QWYZ-3KZL` und gilt **14 Tage**. Er erscheint einmalig zum Drucken oder Kopieren. Der Ausdruck enthält je Feuerwehr Benutzer, Startcode, Gültigkeit und eine kurze Anleitung.
- In der Liste steht „⏳ wartet auf Erstanmeldung (gültig bis …)“ bzw. „⌛ Startcode abgelaufen“. Hat die Feuerwehr ihr Kennwort gesetzt, steht dort „✓ gesetzt · neu … · Ortsfeuerwehr … (selbst)“.

**In der ASÜ (Feuerwehr):**
1. Mit Benutzer und **Startcode** anmelden. Das Feld heißt jetzt „Passwort bzw. Startcode“.
2. Es erscheint **„Eigenes Kennwort festlegen“**: neues Kennwort mit mindestens 8 Zeichen, zweimal eingeben. Mit „Kennwort speichern und anmelden“ ist man angemeldet.
3. Das Kennwort gilt danach für **alle Geräte dieser Feuerwehr**, der Startcode verfällt sofort.
- Dafür muss das Gerät **mit dem Pi verbunden** sein (Gerätehaus-WLAN oder Internetadresse der ASÜ), denn der Pi speichert das Kennwort. Ohne Verbindung kommt ein entsprechender Hinweis.
- Ist der Startcode abgelaufen, kommt der Hinweis, beim Administrator einen neuen anzufordern.
- Wird ein Zugang mit Startcode zurückgesetzt, meldet sich ein noch angemeldetes Tablet dieser Feuerwehr beim nächsten Öffnen ab: „Der Zugang wurde vom Administrator zurückgesetzt …“.

**Eigenes Kennwort ändern:** In der ASÜ unter **Einstellungen → Benutzer → „Eigenes Kennwort ändern“** (bisheriges Kennwort, zweimal das neue) kann jede Feuerwehr ihr Kennwort jederzeit selbst ändern. Auch das geht nur mit Verbindung zum Pi.

**Schutz:** Nach 5 Fehlversuchen je Zugang ist 10 Minuten Pause (insgesamt höchstens 30 Versuche in 10 Minuten). Ab 3 Fehlversuchen erscheint ein Hinweis unter „Sicherheit“. Jede Änderung steht im Protokoll, der vorherige Stand wird gesichert.

Hinweis: Das funktioniert, wenn die ASÜ **vom Pi** geöffnet wird. Das ist der Normalfall: Port 8082 im Gerätehaus bzw. die Internetadresse mit `:8443`. Eine ASÜ, die von GitHub geladen wird, liest ihre Zugangsliste von dort.

### Neu in 3.76: ASÜ-Zugänge verwalten

**Verwaltung → ASÜ-Zugänge** (nur Admins, Änderungen mit PIN) zeigt alle Zugänge der Atemschutzüberwachung: Feuerwehr mit Wappen, Benutzername, Gemeinde, und ob ein Kennwort gesetzt ist. Bei jedem Zugang steht, wann und von wem das Kennwort zuletzt geändert wurde.

- **Kennwörter lassen sich nicht anzeigen.** Sie sind nur verschlüsselt gespeichert (PBKDF2, wie bisher). Ein vergessenes Kennwort wird **neu gesetzt**.
- **🔑 Neues Kennwort** gibt es je Zugang auf zwei Arten:
  - **Vorschlag:** vier Teile, z. B. „Linde-Hafen-Specht-47“. Gut zu merken und schwer zu erraten.
  - **Eigenes Kennwort:** mindestens 8 Zeichen, besser 12.
- **Mehrere auf einmal:** Zugänge anhaken, dann „Neue Kennwörter für ausgewählte“.
- Die neuen Kennwörter erscheinen **genau einmal**. Dort gibt es **„Drucken / PDF“** (je Feuerwehr ein Abschnitt zum Ausschneiden), **„Kopieren“** und **„Fertig“**. Danach sind sie nicht mehr abrufbar. Das bisherige Kennwort gilt ab sofort nicht mehr.
- **+ Zugang anlegen:** Name, Ort, Benutzername (wird aus dem Ort vorgeschlagen), Gemeinde, Wappen und Art (Feuerwehr oder Administrator). Das Kennwort wird dabei vorgeschlagen und einmal angezeigt.
- **Bearbeiten:** Name, Ort, Gemeinde und Wappen ändern oder den Zugang **löschen**. Der letzte Administrator-Zugang lässt sich nicht löschen.
- Geändert wird direkt die Datei `asue/benutzer.js` auf dem Pi, ohne Terminal. Vorher wird der alte Stand unter `backups/asue-zugaenge/` gesichert, die letzten 15 Stände bleiben erhalten. Jede Änderung steht im **Protokoll** (ohne Kennwort). Updates lassen die Zugänge wie bisher unverändert.
- **ASÜ-Tablets:** Die neue Zugangsliste kommt beim nächsten Öffnen der ASÜ mit Verbindung zum Pi an. Danach gilt das neue Kennwort auch offline. Ein schon angemeldetes Tablet bleibt angemeldet.

### Neu in 3.75: Verbindung von außen prüfen und reparieren

**Verwaltung → Zustand des Pi → „Verbindung von außen“** (nur Admins). Die Prüfung startet beim Öffnen von selbst, „Verbindung jetzt prüfen“ wiederholt sie. Geprüft wird Schritt für Schritt, jeweils mit ✓, ⚠ oder ✗ und einem Hinweis, was zu tun ist:

1. **Programm auf dem Pi:** Antworten die Fahrzeug-App (Port 8081) und die ASÜ (8082)?
2. **Internet am Pi:** Kommt der Pi ins Internet?
3. **Tailscale:** Läuft es, ist der Pi online, wann läuft der Schlüssel ab? Ab 14 Tagen vor Ablauf kommt eine Warnung mit dem Hinweis „Disable key expiry“.
4. **Funnel:** Zeigt Port 443 auf die Fahrzeug-App und 8443 auf die ASÜ, jeweils mit dem richtigen Protokoll (http oder https)?
5. **Externe Adresse:** Passt sie zum Tailscale-Namen des Pi? Wenn nicht, gibt es den Knopf „Adresse übernehmen“.
6. **Fahrzeug-App von außen / ASÜ von außen:** Das ist der **echte Weg über das Internet**. Der Pi fragt öffentliche DNS-Server (1.1.1.1, 8.8.8.8) nach der Adresse und ruft sich über den Funnel-Eingang von Tailscale selbst auf, genau wie ein Handy im Mobilfunk.

**Reparieren** (jeweils mit PIN-Bestätigung, mit Eintrag im Protokoll):
- **🌐 Funnel neu einrichten:** setzt die Freigabe zurück und richtet Port 443 → Fahrzeug-App und 8443 → ASÜ neu ein, passend zu http/https.
- **🔁 Tailscale neu starten:** startet den Dienst `tailscaled` neu (etwa 15 Sekunden).
- **🔄 Programm neu starten**
- **⏻ Pi neu starten:** nur als letzter Schritt.

Bei Fehlern steht die empfohlene Aktion direkt an der Zeile und oben als „Empfohlen: …“.

**Überwachung:** Der Pi prüft den Weg von außen alle 10 Minuten selbst. Schlagen zwei Prüfungen hintereinander fehl, erscheint oben **⛔ Pi** mit „Fahrzeug-App von außen nicht erreichbar (seit …)“. Ist eine System-Mailadresse eingerichtet, kommt außerdem eine Mail. Eine Entwarnung kommt, sobald es wieder geht. Optional gibt es **„Automatisch reparieren“**: Nach zwei Fehlprüfungen richtet der Pi den Funnel neu ein bzw. startet Tailscale neu, höchstens einmal pro Stunde.

**Erlaubnis für die Reparatur:** Für „Tailscale neu starten“, „Funnel neu einrichten“ und „Pi neu starten“ braucht das Programm die Erlaubnis für genau diese Befehle. Bei Neuinstallationen richtet `install.sh` das ein. Auf einem bestehenden Pi zeigt die Seite beim ersten Versuch den Befehl dazu an („Befehl kopieren“). Diesen einmalig im Terminal des Pi einfügen:

```
echo "pi ALL=(root) NOPASSWD: /usr/bin/systemctl restart tailscaled, /usr/bin/tailscale, /usr/sbin/reboot" | sudo tee /etc/sudoers.d/einsatzverwaltung && sudo chmod 440 /etc/sudoers.d/einsatzverwaltung
```

Hat der Benutzer auf dem Pi ohnehin sudo ohne Passwort (Standard bei Raspberry Pi OS), geht es auch ohne diesen Schritt.

### Neu in 3.74: Pendelverkehr im Kreisverkehr (zwei Wegstrecken)

Wo der Pendelverkehr gebraucht wird, sind die Wege oft eng, z. B. im Wald oder an Feldwegen. Dann ist ein **Kreisverkehr** besser: beladen über den einen Weg zur Einsatzstelle, leer über einen zweiten Weg zurück zur Füllstelle. So begegnen sich die Fahrzeuge nicht.

- Im Fenster der Pendelstrecke wählen Sie unter **Betriebsart**: **⇄ Gegenverkehr** (hin und zurück auf derselben Strecke) oder **↻ Kreisverkehr**.
- **↩ Rückweg einzeichnen:** Das Fenster schließt sich. Ziehen Sie den Rückweg von **A** (Einsatzstelle) über die zweite Strecke zurück nach **F** (Füllstelle). Haben Sie ihn falsch herum gezogen, dreht das Programm ihn selbst um. Die Enden werden an A und F angeschlossen. Danach öffnet sich das Fenster wieder. Der Rückweg erscheint grau gepunktet mit seiner Länge. Abbrechen geht mit dem Knopf „Rückweg ziehen … (abbrechen)“ in der Werkzeugleiste.
- **Hinweg** und **Rückweg** haben eigene Längen, vorbelegt mit der gezeichneten Länge. Ohne gezeichneten Rückweg können Sie die Länge auch nur eintragen.
- **Enge Wege – Zeitverlust je Begegnung (min):** Im Gegenverkehr begegnet jedes Fahrzeug jedem anderen zweimal pro Umlauf. Bei 4 Fahrzeugen sind das 6 Begegnungen je Fahrzeug und Umlauf. Tragen Sie ein, was eine Begegnung an Zeit kostet, z. B. 1–2 min für Ausweichstelle oder Rangieren. Die Tabelle zeigt dann eine Spalte „Begegnungen“.
- **Vergleich:** Das Ergebnis nennt immer die andere Betriebsart mit, z. B. „Im Kreisverkehr (Rückweg gleich lang) wären es 665 l/min“ oder „Im Gegenverkehr auf dem Hinweg wären es 444 l/min (6 Begegnungen, je 1,5 min)“.
- **Richtung umkehren** tauscht im Kreisverkehr F und A und dabei auch Hin- und Rückweg. Beim Verschieben der Strecke wandert der Rückweg mit.
- An der Linie steht „Kreisverkehr hin 3,3 km · 636/800 l/min“. Einsatztagebuch und Einsatzbericht nennen die Betriebsart und beide Längen.
- Neu ist außerdem ein Hinweis bei einem Engpass an der Füll- oder Abgabestelle: Weitere Fahrzeuge helfen erst, wenn der Engpass behoben ist.

### Neu in 3.73: Pendelverkehr einzeichnen und berechnen

**Lagekarte → Werkzeuge → Lage und Taktik → „⇄ Pendelverkehr“**, dann die Strecke auf der Karte ziehen. Starten Sie an der **Wasserentnahme (Füllstelle)**, folgen Sie der Fahrstrecke und enden Sie an der **Einsatzstelle (Abgabe in den Pufferbehälter)**. Die Strecke erscheint als türkis gestrichelte Linie. Die Füllstelle ist mit **F** markiert, die Abgabe mit **A**. Das Rechenfenster öffnet sich danach von selbst. Später öffnet ein Tipp auf die Linie es wieder.

**Eingaben** (vorbelegt, alle änderbar):
- Wasserbedarf an der Einsatzstelle (200 bis 2.400 l/min)
- Fahrstrecke für die einfache Fahrt. Vorbelegt ist die gezeichnete Länge. Bei Umwegen anpassen.
- Ø Geschwindigkeit beladen und leer, Füll- und Abgabeleistung, Rüstzeiten
- Anzahl der Füllstellen und Abgabestellen, die gleichzeitig arbeiten
- **Pendelfahrzeuge:**
  - Die Fahrzeuge des Einsatzes mit Wassertank stehen in der Liste, TLF sind vorausgewählt.
  - Den Tankinhalt liest das Programm aus der Ausrüstung („Wasser (Liter): 3000“). Fehlt die Angabe, nimmt es einen Typwert nach der Fahrzeugbezeichnung (z. B. TLF 3000 → 3.000 l, LF 10/6 → 600 l, HLF 20 → 1.600 l). Der Wert ist änderbar.
  - Über „+ weiteres Fahrzeug mit Wassertank“ lassen sich Fahrzeuge hinzunehmen, die nicht im Einsatz sind.
- **Planung:** zusätzliche Fahrzeuge mit Anzahl und Liter, z. B. angeforderte TLF der Kreisbereitschaft.

**Ergebnis** (wird sofort neu gerechnet):
- Liefermenge in l/min, Deckung des Bedarfs in %, Takt (alle wie viele Minuten ein Fahrzeug ankommt) und die empfohlene Größe des Pufferbehälters
- Eine Tabelle je Fahrzeug: Füllen, Fahrt voll, Abgabe, Fahrt leer, Umlaufzeit und Liefermenge
- Reicht die Menge nicht, steht dort, **wie viele Fahrzeuge fehlen**, gerechnet mit der Tankgröße unter „Nachforderung rechnen mit“. Außerdem steht dort, nach wie vielen Minuten ein voller Pufferbehälter leer ist.
- Warnung, wenn die **Füllstelle oder die Abgabestelle der Engpass** ist, also Fahrzeuge dort warten würden
- Die nächste Wasserstelle an F wird angezeigt, wenn die Ebene Wasser geladen ist. Ebenso die Faltbehälter, die die Fahrzeuge in der Lage mitführen.

**Knöpfe:**
- „Speichern“: Das Ergebnis erscheint an der Linie, z. B. „⇄ Pendel 3,4 km · 679/1.200 l/min“, grün wenn die Menge reicht, rot wenn nicht.
- „Ins Einsatztagebuch“ übernimmt eine Kurzfassung.
- „⇄ Richtung umkehren“ tauscht F und A.

Das Ergebnis steht auch im **Einsatzbericht**. Die Faustwerte stellen Sie unter **Verwaltung → Einstellungen → Lagekarte → „Pendelverkehr“** ein. Vorgabe: 35 km/h beladen, 45 km/h leer, Füllen 1.200 l/min, Abgabe 1.500 l/min, Rüstzeit 2 und 1,5 min.

So rechnet das Programm: Umlauf = Tankinhalt ÷ Füllleistung + Rüstzeit + Fahrt voll + Tankinhalt ÷ Abgabeleistung + Rüstzeit + Fahrt leer. Die Liefermenge je Fahrzeug ist Tankinhalt ÷ Umlauf. Der Puffer ist der größte Tank plus der Verbrauch bis zum nächsten Fahrzeug, plus 20 % Reserve.

### Neu in 3.72: Atemschutz zeigt nur die eigenen Überwachungen

Unter **Einsatz → Atemschutz** erscheinen nur noch die Atemschutzüberwachungen, die **diesem Einsatz zugewiesen** sind. Das gilt für die Truppstatus-Kacheln, die Liste der meldenden ASÜ und die Trupp-Details. Nicht mehr angezeigt werden:
- Überwachungen ohne Zuordnung (bisher „keinem Einsatz zugeordnet“ bzw. „Nicht zugeordnete Überwachungen“) und
- Überwachungen, die einem anderen Einsatz zugeordnet sind.

Damit eine Überwachung hier erscheint, wählen Sie in der ASÜ unter **Einsatzdaten → „Einsatz der Einsatzverwaltung“** den passenden Einsatz. Meldet sich eine ASÜ ohne Zuordnung länger nicht, steht sie weiterhin in der Hinweis-Zentrale und kann dort entfernt werden.

### Neu in 3.71: Priorität vergibt die Einsatzleitung – Priolage der Leitstelle

**Die Priorität wird jetzt ausschließlich in der Einsatzverwaltung vergeben.** Sie ist nirgends mehr fest vorgegeben:

- **Fahrzeug-App (Melden):** Die Auswahl „Wie dringend?“ ist entfallen. Gemeldete Aufträge kommen mit **„P–“ (Priorität offen)** an. Vergibt die Einsatzleitung eine Priorität, sieht das Fahrzeug sie in „Von uns gemeldet“ und auf der Auftragskarte.
- **E-Mail der Leitstelle:** Aus der Mail wird keine Priorität mehr übernommen.
- **„+ Auftrag“:** Keine Priorität vorgewählt. Man kann sie gleich setzen oder offen lassen (nochmal antippen = wieder offen).
- **Übungsplaner:** Statt „Priorität“ gibt es „Leitstelle meldet Priolage“.

**In der Disposition bleibt die Priorität erhalten und wird dort gesetzt:**

- Im **Auftragsfenster** unter „Priorität“ gibt es die Schnellknöpfe **P1 · P2 · P3 · ⚡ Priolage**. Ein Tipp setzt die Priorität, ein zweiter Tipp auf denselben Knopf setzt sie wieder auf „offen“. Jede Änderung steht im Auftragstagebuch.
- Das Fenster **„Fahrzeug für Auftrag …“** (Disponieren) hat oben dieselben Knöpfe. Dort steht in Rot „(noch offen)“, solange keine Priorität vergeben ist.
- Aufträge ohne Priorität tragen überall das gestrichelte Kennzeichen **P–**. In der Spalte „Neu“ zeigt der Kopf, wie viele noch offen sind (z. B. „2× P–“).

**Priolage (Leitstelle):** Meldet die Leitstelle eine Priolage, wird der Auftrag deutlich markiert:

- In der Leitstellen-Mail wird sie erkannt an einer Zeile `Priolage: ja`, `Prio: 1`/`hoch`/`sofort` oder an „Priolage“, „Prio-Lage“, „PRIO“, „Priorität 1/hoch“ im Betreff oder Text. Von Hand: im Auftragsformular den Haken „⚡ Priolage“ setzen oder im Auftragsfenster den Knopf „⚡ Priolage“ antippen.
- Gekennzeichnet wird sie mit einem **blinkenden roten Schild „⚡ PRIOLAGE“** und einem roten Rahmen. Das gilt in der Auftragsliste, in der Übersicht neben der Einsatzuhr, auf dem Board (Neu/Disponiert/In Arbeit), im Auftragsfenster, im Disponierfenster, beim Drucken und im CSV (Spalte „Priolage“). Auf der **Lagekarte** blinkt der Marker mit gelbem Rand.
- Priolagen stehen in allen Listen **ganz oben**. Die Reihenfolge ist: Priolage → P1 → Prio offen → P2 → P3.
- Kommt eine Priolage herein, ertönt ein **doppelter Ton** und der Hinweis „⚡ PRIOLAGE (Leitstelle): Auftrag …“ erscheint. Die Push-Nachricht ans Fahrzeug beginnt mit „⚡ PRIOLAGE“.

### Neu in 3.70: Aufträge aus der Fahrzeug-App melden (Sonderlage)

**Fahrzeug-App → Reiter „📝 Melden“** – erscheint nur, solange eine **Sonderlage** (Großschadenslage mit Aufträgen) läuft: für Fahrzeuge in dieser Lage, und wenn genau eine Sonderlage läuft, auch für Fahrzeuge ohne Einsatz (z. B. auf dem Weg zum Gerätehaus). Nach Einsatzende verschwindet der Reiter wieder.

So wird gemeldet:
1. **Was?** – Kategorie antippen (dieselben Kategorien wie in der Einsatzverwaltung, z. B. Baum/Ast, Wasser/Keller, Dach/Gebäude).
2. **Wie dringend?** – 1 sofort · 2 dringend · 3 kann warten.
3. **Wo?** – beim Öffnen holt die App den eigenen Standort per GPS (mit Genauigkeit), „📍 Mein Standort“ erneut, oder „🗺️ Punkt aus der Karte“ (vorher im Reiter Karte auf die Stelle tippen). Zusätzlich oder statt GPS eine Adresse/Ortsbeschreibung.
4. **Beschreibung**, optional Ansprechpartner/Rückruf vor Ort.
5. **Fotos** – bis zu 3 (Kamera oder Galerie, werden verkleinert).
6. Optional **„Wir übernehmen den Auftrag selbst“** – das Fahrzeug wird gleich zugeordnet, der Auftrag steht auf „in Arbeit“.
7. **„Auftrag senden“**.

Darunter zeigt **„Von uns gemeldet“** die eigenen Meldungen mit Nummer und Stand (offen, disponiert, in Arbeit, erledigt). Ein angefangener Text bleibt erhalten, falls das Senden nicht klappt.

In der **Einsatzverwaltung**:
- Der Auftrag erscheint sofort unter Einsatz → Aufträge (Meldender = Funkrufname, Eingang „Fahrzeug-App“), in der Liste mit **🚒 Funkrufname** und **📷 Anzahl Fotos** gekennzeichnet. Mit Koordinate steht er auch auf der Lagekarte.
- Im Auftragsfenster: Block „Gemeldet aus der Fahrzeug-App“ (mit GPS-Genauigkeit) und die **Fotos** (antippen = groß, speichern).
- Einsatzleitung und Admins hören einen kurzen Ton und sehen den Hinweis „🚒 14-46-1 meldet Auftrag 7: Baum/Ast“ (die Priorität vergibt ab 3.71 die Einsatzleitung).
- Eintrag im Einsatztagebuch („14-46-1 meldet Auftrag 7: … [mit Foto]“), die Fotos kommen außerdem in die Fotodokumentation des Einsatzes und werden dauerhaft aufbewahrt.

### Neu in 3.69: Alarmmonitor fürs Gerätehaus

**Verwaltung → Alarmmonitor** (nur Admin): Monitore anlegen, Link/QR, Probealarm, Bearbeiten, Neuer Link, Sperren, Löschen. Die Liste zeigt, ob ein Monitor gerade verbunden ist („● online“).

Einstellungen je Monitor:
- **Name** (unten links am Bildschirm) und **Ortswehr**: Alarme, an denen ein Fahrzeug dieser Ortswehr beteiligt ist (ab der Alarmierung dieser Fahrzeuge, auch bei Nachalarmierung); „alle Einsätze der Gemeinde“ für die Hauptwache.
- **Standort des Gerätehauses**: Karte mit Gerätehaus 🏠 und Einsatzort 🔥, Entfernung und Richtung („1,3 km Luftlinie Richtung Nordosten“).
- **Alarmanzeige … Minuten** (Vorgabe 60), danach wieder Ruhezustand mit „Laufende Einsätze“.
- **Gong bei Alarm**, **„Wer kommt?“ mit Namen** (Besatzungs-App des ELW, nur für dessen Gerätehaus sinnvoll), **Information** für den Ruhezustand (z. B. Dienstabend).

Anzeige im **Ruhezustand**: große Uhr mit Datum, Information, Unwetterwarnungen für den Landkreis, laufende Einsätze, Fahrzeuge der Ortswehr mit FMS-Status. Der Inhalt verschiebt sich jede Minute um wenige Pixel (Schutz vor Einbrennen).

Anzeige bei **Alarm** (rote Kopfzeile, blinkt kurz, Gong):
- Stichwort groß, Meldebild, Bedeutung des Stichworts, Einsatznummer, Zeit seit Alarm (läuft mit).
- Einsatzort groß mit Koordinate; Objekt (falls hinterlegt) gelb hervorgehoben.
- **Kräfte, Fahrzeug & Mittel laut Stichwortliste**, **alarmierte Fahrzeuge** mit Status (eigene Ortswehr zuerst).
- **In der Nähe:** bis zu 4 Hydranten/Wasserentnahmestellen im Umkreis von 600 m und der nächste Rettungspunkt.
- **Karte**, **„Wer kommt?“** (Anzahl, Namen, Ankunft „in 5 min“ / „da“) und **QR-Code „Navigation“** – mit dem Handy scannen, die Navigation startet zum Einsatzort.
- Bei einem **Probealarm** ist die Kopfzeile gelb und mit „PROBEALARM“ beschriftet.

Unten rechts: „● verbunden · 19:48“ bzw. rot „Keine Verbindung zum Pi seit …“ und der Ton-Zustand („🔔 Ton bereit“ oder „🔇 Ton aus – einmal klicken“). Einrichtung der Hardware: ANLEITUNG, Schritt 17.

### Neu in 3.68: Checklisten und Jahresauswertung nach den neuen Stichworten

**Checklisten** (Einsatz → Checklisten) werden jetzt nach Einsatzart, Ergänzung und Zusatz der landeseinheitlichen Stichworte zugeordnet:

| Stichwort (Beispiel) | Checklisten |
|---|---|
| B1 AY, B3, F2 | Brand |
| B1 BMA | Brandmeldeanlage (neu) |
| B2 VEG | Wald- und Vegetationsbrand (neu) |
| H1 VU Y, H KLEMM 1Y, TH VU | Verkehrsunfall |
| B2 VU Y (Fahrzeug brennt, Person eingeklemmt) | Brand + Verkehrsunfall |
| H2 X, ABC2 | Gefahrgut |
| B2 X | Brand + Gefahrgut |
| H1 W | Technische Hilfe + Einsatz auf Gewässer (neu) |
| H0 mit Meldebild „Sturmschaden“, „Wasser im Keller“ | Technische Hilfe + Unwetter |
| H1, H0 TÜR, TH1 | Technische Hilfe |
| Sicherheitswache, B BSW | nur „Allgemein“ |

- Regel: Passt eine Ergänzung (VU, BMA, VEG …), entfällt die allgemeine Liste derselben Einsatzart; Zusätze (X, W, Y) und Meldebilder kommen immer dazu. „Allgemein“ gilt weiter für jeden Einsatz.
- **Neue Vorgabe-Listen:** Brandmeldeanlage, Wald- und Vegetationsbrand, Einsatz auf Gewässer. Wer die Checklisten unter Verwaltung → Einstellungen → Einsatz schon selbst geändert hat, behält seine Fassung – die alten Muster (TH VU, B, F, BMA …) passen weiter auf die neuen Stichworte. Die neuen Listen bekommt man dort mit „Vorgabe wiederherstellen“ (eigene Änderungen vorher sichern) oder durch Einfügen von Hand.
- In den Mustern gehen jetzt auch `VU`, `BMA`, `VEG`, `LKW`, `BAHN`, `EIN`, `TÜR` …, `X`, `W`, `Y` sowie `B3`/`H2` für eine bestimmte Stufe (Hilfetext in den Einstellungen).

**Jahresauswertung** (Archiv → Jahresauswertung)
- **Einsätze nach Art** neu eingeteilt: Gefahrstoff (X) · Brandmeldeanlage (BMA) · Wald-/Vegetationsbrand (VEG) · Verkehrsunfall (VU) · Gewässer (W) · Unwetter / Wasser im Keller · Brand (B) · Hilfeleistung (H) · Sicherheitswache · Sonstige. Ein Einsatz zählt genau einmal, nach dieser Reihenfolge (B2 X = Gefahrstoff, B1 BMA = Brandmeldeanlage). Alte Einsätze (F, TH, ABC, H KLEMM …) werden umgerechnet.
- Neu: **Einsätze nach Einsatzart und Stufe** (B0 … B4, H0 … H4).
- CSV-Export mit den zusätzlichen Spalten „Stichwort (landeseinheitlich)“, „Einsatzart“ und „Stufe“.

**Alarm-Mail der Leitstelle:** Stichworte mit mehreren Teilen („H1 VU Y: …“, „B2 LKW AY: …“, „H0 TÜR: …“) werden jetzt vollständig erkannt, auch im Betreff. Bisher wurde bei mehr als einer Ergänzung die Stichwortzeile nicht gelesen.

**Außerdem:** Der Knopf „🌲 Waldbrandkarte“ ist bei VEG-Stichworten hervorgehoben; der Expositionsnachweis schlägt bei X „Gefahrstoff“ vor.

### Neu in 3.67: Stichwort mit Kräften und Meldebildern, Rettungspunkte in der Fahrzeug-App

**Einsatz → Übersicht: Block „Stichwort“** (landeseinheitliche Einsatzstichwörter der KRL Weserbergland ab 31.07.2026)
- Unter dem Einsatzkopf steht das Stichwort mit seiner Bedeutung, z. B. **B1 AY** = Brandbekämpfung · Stufe 1 (1 Gruppe) · außerorts · Menschenleben in Gefahr, dazu das bisherige Stichwort (F1AY).
- **Kräfte, Fahrzeug & Mittel (Soll)** laut Stichwortliste mit Abgleich gegen die Fahrzeuge im Einsatz: ✓ vorhanden (z. B. „1 DLK ✓ 14-30-1“), **!** fehlt noch (z. B. „2 Gruppen ≈ 18 Kräfte · Ist 12“, „3.200 l Wasser · Ist 2.000 l“), ○ nur bei Bedarf/optional bzw. nicht prüfbar, ✚ Rettungsdienst/THW (über die Leitstelle). Wasser zählt aus der Fahrzeugausrüstung („Wasser (Liter)“), Stärke aus den Stärkemeldungen. Nur ein Anhalt – maßgeblich ist die Alarmierung der Leitstelle.
- **Meldebilder** des Stichworts; das Meldebild des Einsatzes ist hervorgehoben.
- Alte Stichworte (F2, ABC1, H KLEMM 1Y, TH1 …) werden dem neuen zugeordnet. Steht ein Stichwort nicht in der Liste (z. B. „B2 XW“), zeigt der Block das nächstpassende (B2 X) und die Bedeutung aller Zusätze.
- Der Block lässt sich zuklappen (▾); das merkt sich das Gerät.
- **Neuer Einsatz / Bearbeiten:** Die Auswahl beim Stichwort enthält die neuen Stichworte; beim Meldebild erscheinen die Meldebilder des gewählten Stichworts. Erst Meldebild eintippen (z. B. „Wohnung“) → „Passendes Stichwort: B2 · B2 BMA …“ zum Antippen. Darunter stehen die Kräfte des Stichworts.

**Fahrzeug-App: Rettungspunkte Forst auf der Karte**
- Im Reiter **Karte** erscheinen die Rettungspunkte als grüne Schilder mit Nummer (wie in der Lagekarte, gleiche Daten vom Pi). Der Knopf **✚** rechts blendet sie aus und wieder ein; das merkt sich das Handy.
- Antippen zeigt Nummer, Beschreibung, Koordinate sowie **Kopieren**, **An Einsatzleitung** (z. B. „Rettungspunkt HM-1018: 52.07100, 9.24000“) und **Navigation**.
- Suche nach der Nummer im Suchfeld der Karte („HM-1018“).
- Geladen wird nur der sichtbare Ausschnitt (ab etwa 10 km Kartenbreite). Mit „Karte in der Fahrzeug-App: aus“ gibt es auch keine Rettungspunkte.

### Neu in 3.66: App-Symbole, Feedback, Excel mit Ausrüstungsspalten, Rettungspunkte, Standort im Hintergrund

**Eigene Symbole je App** – auf dem Home-Bildschirm sofort zu unterscheiden:
- Einsatzverwaltung: rot mit Lagetafel („EINSATZ“) · Fahrzeug-App: Löschfahrzeug auf Weiß („FAHRZEUG“) · Atemschutzüberwachung: gelb mit Maske und Uhr („ATEMSCHUTZ“) · Besatzungs-App: grün mit Personen („BESATZUNG“) · Bereitstellungsraum: blau „BR“ · Stärkemeldung: grau „1/8/9“.
- Bereits angelegte Symbole auf iPhone/iPad ändern sich erst, wenn die App einmal vom Home-Bildschirm entfernt und neu hinzugefügt wird; Android übernimmt sie meist von selbst nach einigen Tagen (sonst ebenso neu anlegen).

**Feedback-Modus**
- Oben in der Kopfzeile der Knopf **💬** (alle Benutzer, auch Betrachter) und in der Fahrzeug-App oben rechts. Art wählen (🐞 Fehler, 💡 Wunsch, 👍 Lob, ❓ Frage, ✏️ Sonstiges), beschreiben, optional Rückrufnummer und bis zu 3 Bilder. In der Einsatzverwaltung kann zusätzlich ein **Bildschirmfoto der aktuellen Ansicht** mitgehen (Haken, Vorgabe aus – es kann Einsatzdaten zeigen).
- Mitgeschickt werden Ansicht, Version, Gerät/Browser, Bildschirmgröße und Benutzer bzw. Fahrzeug.
- Versand per E-Mail an **joern-preuss@web.de** über den E-Mail-Zugang der Einsatzverwaltung. Ist er nicht eingerichtet oder klappt der Versand nicht, bleibt das Feedback auf dem Pi und wird alle 15 Minuten erneut versucht.
- Verwaltung → Einstellungen → Sicherung & System → **Feedback**: Liste der letzten Rückmeldungen mit Stand (✅ gesendet / ⏳ wartet), „Wartendes Feedback jetzt senden“. Unter Schnittstellen → Betrieb: **„Feedback-Modus“** (an/aus) und **„Feedback geht an“**.

**Fahrzeuge in Excel: jede Ausrüstung eine eigene Spalte**
- Verwaltung → Fahrzeuge → „Fahrzeuge exportieren (Excel)“: Nach den festen Spalten (ID bis AGT) folgt **je Ausrüstung eine Spalte**; **„x“** = auf dem Fahrzeug vorhanden. Ausrüstung mit Menge oder Größe hat eine Spalte mit dem **Wert** in der Zelle, z. B. „Wasser (Liter)“ = 2500, „Strom/Beleuchtung (kVA)“ = 14KVA (mehrere Werte mit „;“). Filter in der Kopfzeile, zweites Blatt „Hinweise“.
- **Neue Ausrüstung:** rechts eine Spalte anfügen, Namen oben eintragen, bei den Fahrzeugen „x“ setzen, dann „Fahrzeuge importieren (Excel)“. Die Rückfrage nennt die neue Ausrüstung. Daten, die nicht in der Liste stehen (z. B. Kennzeichnung „nachgemeldet“), bleiben bei gleicher ID erhalten. Alte Listen mit der Spalte „Ausruestung“ lassen sich weiter einlesen.
- **Entfallen:** „Stammdaten sichern (JSON)“ und „Stammdaten laden (JSON)“. Fahrzeuge über Excel, alles andere über die Datensicherung des Pi.

**Betrachter:** Die Reiter **Archiv** und **Verwaltung** sind für Betrachter ausgeblendet (wie schon E-Mail); auch der Pi gibt das Archiv nur noch an Einsatzleitung und Admins heraus.

**Lagekarte: Rettungspunkte Forst**
- Neue Ebene **„Rettungspunkte Forst“** (Ebenen-Auswahl der Lagekarte, Vorgabe an): grüne Schilder mit ✚ und Nummer, z. B. „HM-1018“ – ab einer Kartenbreite von etwa 10 km als kleine Punkte, näher mit Nummer.
- Antippen: Nummer, Beschreibung, Entfernung zum Einsatzort, Koordinaten in allen Formaten, „Als Marker ‚Sammelstelle‘ übernehmen“ (z. B. als Treffpunkt mit dem Rettungsdienst).
- **Suche** in der Lagekarte nach der Nummer: „HM-1018“, „hm 1018“ oder „RP 1018“. Das Koordinatenfenster zeigt die **zwei nächsten Rettungspunkte** mit Entfernung.
- Daten: Verwaltung → Einstellungen → Lagekarte → **„Rettungspunkte Forst“**. Am genauesten ist die Datei des KWF – auf rettungspunkteforst.de als **GPX oder KML** herunterladen (kostenlos, Lizenz CC BY-ND 4.0) und mit „KWF-Datei einlesen“ übernehmen; der Pi behält nur die Punkte im Umkreis (wie bei den Wasserentnahmestellen, 50 km). Ohne Datei lädt er sie automatisch aus OpenStreetMap (alle 30 Tage neu). Quelle und Stand stehen im Info-Fenster.

**Fahrzeug-App: Standort auch bei gesperrtem Handy (Begleit-App)**
- Eine Web-App darf bei gesperrtem Handy keinen Standort senden. Dafür gibt es jetzt den Weg über die kostenlose Begleit-App **Traccar Client** (Android und iPhone, ohne Konto) oder **OwnTracks**.
- Einrichten in der Fahrzeug-App unter **Standort → „Standort bei gesperrtem Handy“ → Einrichten**: App installieren, die angezeigte **Server-URL** kopieren und in Traccar eintragen (Gerätekennung beliebig), Genauigkeit hoch, Intervall 60 s, Distanz 50 m, Standort „Immer erlauben“, Dienst einschalten.
- **Zeitlich begrenzt:** Der Pi nimmt diese Standorte nur **3 Stunden** ab Alarm, Zuordnung zum Einsatz bzw. „Im Einsatz“ an (erneut „Im Einsatz“ verlängert) und nur, solange das Fahrzeug nicht in Status 2/6 bzw. „Verfügbar“ ist. Alles andere verwirft er sofort, es wird nichts gespeichert. Die Begleit-App darf deshalb dauerhaft laufen.
- Die Karte in der Fahrzeug-App zeigt an, ob gerade angenommen wird („bis 18:45 Uhr“) und wann zuletzt ein Standort der Begleit-App kam. In der Einsatzverwaltung erscheinen diese Standorte wie gewohnt (Quelle „Begleit-App“).
- Einstellung: Verwaltung → Einstellungen → Fahrzeug-App → **„Standort im Hintergrund (Begleit-App): Stunden“** (Vorgabe 3, 0 = aus). „Neuer Link“ macht auch die Adresse der Begleit-App ungültig.

### Neu in 3.65: Sicherungsstick ohne Terminal, Benachrichtigungen in der Fahrzeug-App

**Sicherungsstick**
- Verwaltung → Einstellungen → **Sicherung & System** zeigt jetzt, ob der Stick steckt: **🟢 Stick erkannt** (mit „kann gefahrlos abgezogen werden“ bzw. „eingehängt“), **🔴 Stick nicht erkannt** oder **🟠 Stick erkannt, aber nicht eingehängt**. Die Anzeige ändert sich innerhalb von 15 Sekunden nach dem Einstecken oder Abziehen.
- Wird ein Stick eingesteckt, **sichert der Pi sofort** – kein „sudo mount“ mehr nötig. Voraussetzung ist die einmalige Einrichtung mit `sudo bash ~/einsatzverwaltung/docs/stick-einrichten.sh` (ANLEITUNG, Schritt 15); bei älterer Einrichtung zeigt die Verwaltung genau diesen Befehl an.
- Der Pi hängt den Stick nach einer Minute ohne Zugriff selbst aus. Zwei Sticks mit dem Namen FWBACKUP können im Wechsel benutzt werden.
- War die letzte Sicherung auf einem inzwischen abgezogenen Stick weniger als 26 Stunden alt, gilt sie weiter als aktuell (keine Warnung „Keine aktuelle externe Sicherung“).

**Fahrzeug-App: Benachrichtigungen bei gesperrtem Handy**
- Im Reiter **Einsatz** der Fahrzeug-App gibt es den Bereich **„Benachrichtigungen“** mit **„🔔 Benachrichtigungen einschalten“**. Danach kommen auch bei geschlossener App bzw. gesperrtem Handy:
  - **Nachrichten der Einsatzleitung** (Text, 📷 bei Bildern),
  - **neue Aufträge** in der Großschadenslage (Nummer, Priorität, Art; die Adresse nur bei „Karte in der Fahrzeug-App: an“),
  - das **Umsetzen in einen anderen Einsatz**.
- Antippen der Benachrichtigung öffnet die Fahrzeug-App. Nachrichten und Aufträge bleiben stehen, bis sie angetippt oder weggewischt werden. Bestätigt („Verstanden“) wird weiter in der App.
- **„Test senden“** prüft die Verbindung, **„Ausschalten“** beendet sie für dieses Gerät. Je Fahrzeug bis zu 5 Geräte.
- Geht nur über die **https-Adresse** der Fahrzeug-App; auf iPhone/iPad nur als App vom Home-Bildschirm (ab iOS 16.4). Die App zeigt an, was fehlt.
- Einstellung **Verwaltung → Einstellungen → Fahrzeug-App → „Benachrichtigungen (Push)“**: `an` (mit Text), `kurz` (auf dem Sperrbildschirm nur „Neue Nachricht“ / „Neuer Auftrag“ ohne Inhalt) oder `aus`.
- **Verwaltung → Fahrzeug-App** zeigt in der Spalte 🔔, wie viele Geräte je Fahrzeug Benachrichtigungen eingeschaltet haben. **„Neuer Link“ oder „Sperren“ beendet auch die Benachrichtigungen** dieses Fahrzeugs.
- Datenschutz: Der Inhalt geht Ende-zu-Ende-verschlüsselt über den Push-Dienst des Handys (Google, Apple, Mozilla); der Dienst sieht nur, dass eine Nachricht kommt. Alarmiert wird weiter über Melder bzw. PowerAlarm.

### Neu in 3.64: Anleitungen aktualisiert, kleine Korrekturen

- **Bedienungsanleitung und Kurzfassung** (PDF) sind auf dem Stand 3.63/3.64 – mit neuen Bildschirmfotos aus der Demo-Version. Neue Funktionen seit 3.30 sind dort mit „NEU“ markiert.
- **Tastaturkürzel (?):** Die Übersicht nennt jetzt richtig „Umschalt + 1 … 9“ für die Reiter (5 = Besatzung, 9 = E-Mail).
- **Demo-Version:** Der Reiter Besatzung zeigt den ELW der Demo (77-11-10); vorher stand dort „ELW ohne Einsatz“.

### Neu in 3.63: Einheitliche Such- und Filterzeile

- Im Reiter **Ausrüstung** haben Statusauswahl, Suchfeld und „Ausrüstung“ jetzt dieselbe Höhe, Rahmen und Schrift. Auf dem Handy steht der Status oben, Suchfeld und „Ausrüstung“ stehen darunter nebeneinander.
- Die Auswahlfelder (auch unter **Einheiten**) sehen auf iPad/iPhone (Safari) jetzt genauso aus wie am PC: flach mit Pfeil statt grauem Verlauf.
- Für Vorführungen gibt es eine neue **Demo-Version** auf dem Stand 3.63.

### Neu in 3.62: Hängende ASÜ-Meldung „keine Meldung seit …“ entfernen

Eine Atemschutzüberwachung, die zuletzt „Trupp im Einsatz“ gemeldet hat und sich danach nicht mehr meldet, blieb bisher dauerhaft in den Hinweisen stehen. Das passiert zum Beispiel nach einem Test oder wenn ein Tablet einfach ausgeschaltet wurde. Jetzt gilt:

- **Hinweise (🔔):** Der Hinweis hat einen Knopf **„Entfernen“** (Einsatzleitung/Admin) und, wenn die ASÜ einem Einsatz zugeordnet ist, den Knopf **„Atemschutz“**. Vor dem Entfernen kommt eine Rückfrage. Bitte nur entfernen, wenn sicher kein Trupp mehr unter Atemschutz ist. Das Entfernen wird im Einsatztagebuch bzw. im Systemprotokoll vermerkt. Meldet sich die ASÜ wieder, erscheint sie erneut.
- **Einsatz → Atemschutz:** Veraltete oder nicht zugeordnete Meldungen haben dort ebenfalls „Entfernen“.
- **Automatisch:** Meldungen ohne Lebenszeichen seit 12 Stunden erscheinen nicht mehr als Hinweis. Der Pi löscht Meldungen nach 24 Stunden ohne Lebenszeichen und Meldungen zu Einsätzen, die nicht mehr laufen.

### Neu in 3.61: Symbol Dekon-Platz, E-Mail-Seite repariert

- **Dekon-Platz:** In der Lagekarte und in der Einsatztaktik gibt es unter den Lage-Symbolen (nach „Sammelstelle“) das neue Symbol **Dekon-Platz**, ein violettes Schild mit Brause und „DEKON“. Die Vorlage „Gefahrstoff: Gefahren- und Absperrbereich“ setzt den Dekon-Platz jetzt automatisch neben die ASÜ. Bei den Standard-Symbolen für das Einsatztagebuch ist er ebenfalls dabei.
- **E-Mail → Neue E-Mail:** Der Kasten „Mitsenden“ war seit 3.52 übereinandergeschoben und ist wieder normal lesbar.

### Neu in 3.60: Fahrzeug in einen anderen Einsatz verschieben, Stärkemeldung bei den Fahrzeugen

- **Stärkemeldung:** Der Knopf ist aus der Übersicht verschwunden und steht jetzt im Reiter **Einsatz → Fahrzeuge** oben neben „＋ Fahrzeug hinzufügen“. Dort gibt es weiterhin die Summe, „📱 Per Handy sammeln“ und „📷 Ergebnis vom Handy einlesen“. Die Stärke je Fahrzeug trägst du wie bisher direkt in der Tabelle ein.
- **Verschieben in einen anderen Einsatz:** Wenn mehrere Einsätze laufen, klickst du unter **Fahrzeuge** oder **Abschnitte** auf ein Fahrzeug. Im Feld **Einsatz** wählst du dann den Zieleinsatz (⇄) und bestätigst. Status und Stärke bleiben erhalten. Im neuen Einsatz steht das Fahrzeug zuerst unter „Frei“. Beide Tagebücher bekommen einen Vermerk, und der Schritt lässt sich rückgängig machen.
- Verschoben wird **nur aus dem geöffneten Einsatz heraus**. Ein Fahrzeug, das zu einem anderen Einsatz gehört, lässt sich von hier nicht hereinholen; dafür öffnest du dessen Einsatz. Das gilt auch für „⇄ In anderen Einsatz“ im Status-Fenster.
- **Fahrzeuge-Tabelle:** Das Häkchen „nur 〈Einsatznummer〉“ ist jetzt standardmäßig gesetzt. Wenn du es abschaltest, merkt sich das Gerät die Einstellung.

### Neu in 3.59: Auftragsübersicht an der Einsatzuhr, Treffer anderer Ortswehren in der Ausrüstung

**Auftragsübersicht (Sonderlage/Großschadenslage):** In der Einsatz-Übersicht steht neben den Einsatz-Uhren jetzt eine Übersicht aller offenen und laufenden Aufträge. Die Uhren werden dafür kleiner und schmaler dargestellt.

- Jede Zeile zeigt die **Priorität** (P1 rot, P2 gelb, P3 grau), die **Kategorie** mit Symbol und Kurztext (was ist es?), den **Ort** und den Status. Sind Fahrzeuge zugeteilt, stehen sie unter dem Ort.
- Sortiert nach Priorität, dann offen → disponiert → in Arbeit, dann nach Eingang. P1-Aufträge stehen also immer oben.
- Darüber steht eine Zählzeile (offen / disponiert / in Arbeit / erledigt).
- Ein Klick auf eine Zeile öffnet den Auftrag, „Alle Aufträge ›“ springt zum Reiter Aufträge.
- Die Übersicht aktualisiert sich live, auch wenn Fahrzeuge in der Fahrzeug-App „Im Einsatz“ oder „Verfügbar (Auftrag erledigt)“ melden.
- Bei normalen Einsätzen ohne Aufträge bleibt alles wie bisher.

**Ausrüstung suchen:** Im Reiter Ausrüstung gibt es ein Suchfeld „🔍 Ausrüstung suchen“. Gesucht wird in der Ausrüstung, im Funkrufnamen, im Fahrzeugtyp und in der Funktion. Die Ausrüstungs-Auswahl, die Kategorien und der Statusfilter funktionieren wie bisher und lassen sich kombinieren.

- Während einer Suche zeigt jede Ortswehr-Kachel die Anzahl ihrer Treffer. Kacheln ohne Treffer werden blass.
- Ist eine einzelne Ortswehr ausgewählt, werden andere Ortswehren (und Werkfeuerwehren) mit Treffern **gelb mit ★ hervorgehoben**.
- Über der Ergebnisliste steht „Auch zu finden in: …“ mit Trefferzahl. Ein Klick darauf wechselt zur jeweiligen Ortswehr, die Suche bleibt erhalten.

### Neu in 3.58: „Im Einsatz“ / „Verfügbar (Auftrag erledigt)“ steuern die Aufträge der Großschadenslage

- Ist das Fahrzeug in einer **Großschadenslage einem Auftrag zugewiesen**, zeigt die Fahrzeug-App oben eine **Auftragskarte**: Nummer, Stand, Kategorie, Priorität – und bei der Einstellung „Karte in der Fahrzeug-App: an“ auch Adresse und Beschreibung. Ein neuer Auftrag wird als Meldung angezeigt.
- **🚒 Im Einsatz** („Auftrag … übernehmen“): Der Auftrag geht auf **„in Arbeit“**; Eintrag im Auftrags- und im Einsatztagebuch („Besatzung meldet: im Einsatz – Auftrag 12 übernommen“).
- **✅ Verfügbar (Auftrag erledigt)**: Nach einer Rückfrage wird das Fahrzeug **vom Auftrag frei** und steht in der Lage für den nächsten Auftrag bereit. Ist es das letzte Fahrzeug am Auftrag, wird der Auftrag **„erledigt“** und sein Tagebuch ins Einsatztagebuch übernommen; sonst bleibt er „in Arbeit“. Ein **Ergebnis** (z. B. „Baum beseitigt“) kann vorher in das Feld unter den Knöpfen geschrieben werden und steht dann am Auftrag.
- Ohne Auftrag (normaler Einsatz) wirken die Knöpfe wie in 3.57: Meldung an die Einsatzleitung und Standort senden/pausieren. Der FMS-Status wird in keinem Fall verändert (PowerAlarm).

### Neu in 3.57: Fahrzeug-App ohne Statusmeldung – „Im Einsatz“ und „Verfügbar“

- In der **Fahrzeug-App** gibt es **keine FMS-Statusknöpfe (1, 2, 3, 4, 6) und keinen Sprechwunsch** mehr. Der FMS-Status kommt über **PowerAlarm** (Fahrzeugstatus von außen) oder wird in der Einsatzverwaltung gesetzt; die App zeigt ihn nur noch an („FMS-Status (PowerAlarm / Einsatzleitung): 3 – Einsatz übern.“).
- Stattdessen zwei große Knöpfe unter **„Einsatzbereitschaft“**:
  - **🚒 Im Einsatz** – die Besatzung meldet, dass sie im Einsatz ist; der **Standort wird gesendet** (wenn „Standort alle 2 Minuten senden“ an ist).
  - **✅ Verfügbar** – die Besatzung meldet sich verfügbar; der **Standort pausiert**.
  - Ohne Meldung gilt wie bisher der FMS-Status (Standort bei A, 1, 3, 4). Der Schalter „auch wenn Verfügbar (immer senden)“ sendet immer.
- Die Meldung ändert **keinen FMS-Status**. In der Einsatzverwaltung erscheint sie als Schild **„🚒 im Einsatz“** bzw. **„✅ verfügbar“** am Fahrzeug (Einheiten, Fahrzeuge im Einsatz, Abschnitte; gilt 12 Stunden). Ist das Fahrzeug in einem Einsatz, steht „Besatzung meldet: im Einsatz / verfügbar“ im Einsatztagebuch, sonst im Systemprotokoll.
- Ältere, noch zwischengespeicherte Fahrzeug-Apps können keinen Status mehr senden (der Pi lehnt ab); beim nächsten Öffnen lädt die App neu.

### Neu in 3.56: Waldbrandeinsatzkarte Niedersachsen

- Die **Waldbrandeinsatzkarten** des Landes (LGLN, Mapbender-Anwendung mit Anmeldung, Zugang für BOS über den Träger der Feuerwehr) lassen sich nicht in die Lagekarte einbetten – es gibt keinen offenen Kartendienst. Sie sind deshalb **wie FeWIS** eingebunden.
- **Im Einsatz:** Übersicht → **„🌲 Waldbrandkarte“** (rot hervorgehoben bei Stichwort/Meldebild mit Wald, Vegetation, Fläche, Moor oder Heide; auch über Strg+F „Waldbrand“). Fenster mit „Waldbrandkarte öffnen ↗“, Zugangsdaten (nur Einsatzleitung und Admins, verdeckt, anzeigen/kopieren, im Systemprotokoll), Kurzanleitung und **„Einsatzort zum Suchen in der Karte“** (Koordinate dezimal, UTM Zone 32 und UTMREF zum Kopieren); „Ins Tagebuch: Karte genutzt“.
- **Einrichten (Admin):** Verwaltung → Einstellungen → Einsatz → **„Waldbrandeinsatzkarte Niedersachsen (LGLN)“** – Adresse (Vorgabe `https://maps.lgln.niedersachsen.de/wbek/mapbender/application/Waldbrandeinsatzkarte`), Benutzer, Passwort, Kurzanleitung. Speichern mit PIN.

### Neu in 3.55: FeWIS (Feuerwehr-Wetter-Informationssystem des DWD)

- **Im Einsatz:** Übersicht → **„🌦 FeWIS“** (auch über Strg+F „FeWIS“). Das Fenster zeigt:
  - **„FeWIS öffnen ↗“** – öffnet FeWIS in einem neuen Fenster; angemeldet wird dort.
  - **Zugangsdaten** (Benutzer und Passwort) – **nur für Einsatzleitung und Admins**, zunächst verdeckt; „anzeigen“ (verbirgt sich nach 30 Sekunden wieder) und „kopieren“. Betrachter sehen diesen Bereich nicht, und der Pi gibt ihnen die Daten auch nicht heraus. Jedes Anzeigen/Kopieren steht im Systemprotokoll.
  - **Kurzanleitung** – von den Admins hinterlegt, für alle sichtbar; Adressen darin sind anklickbar.
  - **Angaben für die Meldung** mit „kopieren“: Einsatz, Uhrzeit, Einsatzort, Koordinate (dezimal, UTM, UTMREF) und das letzte Wetter vom Einsatzort – zum Einfügen in FeWIS.
  - **„Ins Tagebuch: Prognose angefordert“** (Einsatzleitung) – Eintrag „Ausbreitungsprognose (Rauch/Schadstoffe) über FeWIS angefordert“.
- **Einrichten (Admin):** Verwaltung → Einstellungen → Einsatz → **„FeWIS“**: Adresse (Vorgabe `https://fewis.dwd.de` – bitte mit eurem Zugang prüfen), Benutzername, Passwort (leer lassen = unverändert, „Passwort löschen“) und Kurzanleitung. Speichern fragt nach der eigenen PIN. **Keine Zugangsdaten in die Anleitung schreiben** – die sehen auch Betrachter.
- Die Daten liegen nur auf dem Pi in der Datei `portale.json` (bis 3.55 `fewis.json`, wird automatisch übernommen) (nur für den Dienst lesbar), nicht in `data.json` und nicht in der Datensicherung – nach einer Neuinstallation neu eintragen. Ein Programm-Update lässt sie unverändert.

### Neu in 3.54: Bereitstellungsräume im Reiter Abschnitte, Fahrzeug hinzufügen unter Fahrzeuge

- **Bereitstellungsräume stehen jetzt im Reiter Abschnitte** und sehen aus wie ein Abschnitt (orange Kopfleiste, Kennzeichen „Bereitstellungsraum“). In der Übersicht gibt es keinen Bereitstellungsraum mehr (weder Feld noch Block noch Knopf).
- **Anlegen:** Abschnitte → „🅿 + Bereitstellungsraum“ (Name, Adresse mit Suche, Koordinate). Bearbeiten über ✎, „🗑 Auflösen“ auf der Karte – die Fahrzeuge darin stehen danach unter „Frei“.
- **Link versenden:** Auf der Karte des Raums „📱 Link / QR“ (QR-Code, kopieren, teilen, neuer Link) und „📤 Link an Fahrzeug“ (Fahrzeug-App bekommt den Knopf „🅿 Bereitstellungsraum öffnen“). „Zurück“ führt wieder zu den Abschnitten.
- **Fahrzeuge:** Die Karte zeigt die Fahrzeuge im Raum mit „im Raum seit“, Stärke und AGT. Fahrzeuge am Griff ⠿ in einen Bereitstellungsraum ziehen (Status 4, Eintrag im Tagebuch) – oder aus dem Raum in einen Abschnitt bzw. nach „Frei“ (verlässt den Raum). Fahrzeuge im Raum zählen oben als „im Bereitstellungsraum“, nicht als frei.
- **Fahrzeug hinzufügen** (auch unbekannte Fahrzeuge) ist von der Übersicht in den Bereich **Fahrzeuge** des Einsatzes gewandert: Knopf „＋ Fahrzeug hinzufügen“. Für neue Fahrzeuge zusätzlich **Gemeinde/Stadt** und **Kennzeichen**. Das Fahrzeug wird **dauerhaft in der Fahrzeugliste gespeichert** und ist bei späteren Einsätzen über die Suche zu finden; in der Fahrzeugverwaltung trägt es „🆕 nachgemeldet“, bis ein Admin es geprüft und gespeichert hat.

### Neu in 3.53: Atemschutzüberwachung – Personen einzeln erfassen und zu Trupps zusammenstellen

- **„+ Person“** (Überwachung und Trupps & Geräte): Nachname, Vorname, Geräte-, LA-, Flaschen- und Masken-Nr. und Flaschendruck einer einzelnen Person erfassen – wie im Trupp auch mit Kamera (QR-Code, Namensschild, Etikett). „Speichern & nächste Person“ erfasst mehrere nacheinander.
- Die Personen stehen oben unter **„Einzelne Geräteträger“**. Zwei oder drei antippen (Haken), dann **„Trupp bilden“**.
- **Truppführer festlegen:** Im nächsten Fenster muss der Truppführer angetippt werden – vorher geht es nicht weiter. Die anderen werden Truppmann bzw. Truppmann 2. Danach wie gewohnt Rufgruppe, Auftrag, Sicherheitstrupp/CSA eintragen und anlegen; die Personen verschwinden aus der Liste.
- **Truppführer wechseln:** Im Fenster eines Trupps bei jeder anderen Person „Zum Truppführer“ – bereits erfasste Drücke wandern mit der Person mit.
- **Trupp auflösen:** Solange ein Trupp noch nicht unter Atemschutz gegangen ist, stellt „Trupp auflösen“ seine Personen wieder einzeln in die Liste.
- Die Liste der einzelnen Personen liegt auf dem Gerät, auf dem sie erfasst wurden (nicht im Abgleich mit anderen Geräten). An einem Gerät ohne Führung wird aus „Trupp bilden“ wie bisher ein Vorschlag.

### Neu in 3.52

- **Stärke ohne Unterführer:** Überall gilt jetzt Führer / Mannschaft / Gesamt (F/M/G), z. B. 1/8/9 – in der Einsatzverwaltung, der Fahrzeug-App, der Besatzungs-App, der Sammelseite, im Bereitstellungsraum, im Bericht und in der Jahresauswertung (CSV ohne Spalte „Unterführer“). Bereits gemeldete Unterführer zählen beim Update zur Mannschaft; die Gesamtzahl bleibt gleich. Fahrzeuglisten (Excel) mit Spalte „Unterführer“ werden weiter gelesen und ebenfalls zur Mannschaft gezählt.
- **Status 2 setzt die Stärke zurück:** Meldet ein Fahrzeug Status 2 (einsatzbereit auf der Wache), wird seine Stärke gelöscht. Beim nächsten Alarm gilt wieder die Vorgabe-Stärke aus der Fahrzeugliste. Die zuletzt gemeldete Stärke bleibt im Einsatz gespeichert und erscheint im Einsatzbericht. „Rückgängig“ stellt auch die Stärke wieder her.
- **Mehrere Einsätze – Status 2 verlässt den Einsatz:** Laufen mehrere Einsätze, verlässt ein Fahrzeug mit Status 2 seinen Einsatz immer – auch eine Großschadenslage. Läuft nur eine Großschadenslage, bleibt es wie bisher mit Status 1 oder 2 frei für den nächsten Auftrag.
- **Fahrzeug in einen anderen Einsatz umsetzen:** Im Fenster eines Fahrzeugs (Status-Knopf) „⇄ In anderen Einsatz“ und den Ziel-Einsatz wählen – oder in der Fahrzeugliste des Einsatzes mehrere Fahrzeuge anhaken und „⇄ In anderen Einsatz …“ wählen. Status und Stärke bleiben, im neuen Einsatz steht das Fahrzeug unter „Nicht zugeteilt“; ein Bereitstellungsraum oder Auftrag im alten Einsatz wird verlassen. Beide Einsatztagebücher bekommen einen Vermerk; Strg+Z macht es rückgängig.
- **Objekte mit Ort:** Im Objekt-Formular „Ort“ aus den Ortsfeuerwehren der Gemeinde wählen (wird beim Suchen der Adresse vorgeschlagen; leer = aus der Adresse erkennen). Der Ort steht in der Objektliste, im Objekt-Fenster und wird bei der Suche gefunden; über der Liste filtert „Alle Orte“ nach Ort.
- **Ausrüstung mit Werkfeuerwehren:** Im Reiter Ausrüstung stehen die Werkfeuerwehren **Aerzener Maschinenfabrik** und **Lenze** mit eigenen Kacheln; „Gemeinde Aerzen“ schließt ihre Fahrzeuge und Ausrüstung mit ein.
- **E-Mail gelesen für alle:** Im Posteingang sind ungelesene Mails mit rotem Punkt und fett markiert. Öffnet jemand eine Mail, gilt sie für **alle Benutzer** als gelesen (mit Zeit und Name). „✓ Alle als gelesen“, Filter „Ungelesen“ und in der Mail „als ungelesen markieren“. Die Zahl am Reiter E-Mail zählt ungelesene Mails (ohne ignorierte). Beim Update gelten alle vorhandenen Mails als gelesen.
- **Suche nach Ausrüstung:** Strg+F findet auch Ausrüstung, z. B. „Kettensäge“, „Wärmebild“ oder „Kettensäge Grießem“ – Fahrzeuge der eigenen Gemeinde und der Werkfeuerwehren zuerst, mit Status und Einsatz.
