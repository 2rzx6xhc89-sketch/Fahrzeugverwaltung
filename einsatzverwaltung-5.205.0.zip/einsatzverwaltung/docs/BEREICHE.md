# Bereiche der Einsatzverwaltung (ab 5.96, Bereich 4 ab 5.97)

Arbeitsregel: **Änderungen in einem Bereich nur, wenn sie vorher ausdrücklich besprochen wurden.** Keine Nebenwirkungen auf andere Bereiche.

| Bereich | Nutzer | Programmdatei(en) | Adresse |
|---|---|---|---|
| 1. ASÜ + Träger-App | Atemschutzüberwachung, Geräteträger | `asue/index.html` (ASÜ), `asue/traeger.html`, `asue/sammeln.html` | ASÜ-Port: `/`, `/traeger` |
| 2. Datenbank (ab 5.188: Gerätedatenbank + Atemschutz-Datenbank) | Gerätewarte, Atemschutzgerätewarte | `asue/datenbank.html` | ASÜ-Port: `/datenbank` (`/geraete`, `/atemschutz` leiten weiter) |
| 3. Einsatzverwaltung (inkl. Fahrzeug-App, ELW-Info) | Einsatzleitung, Admin | `public/index.html`, `melde/index.html` | Port 8080 (intern), Meldeserver |
| 4. Berichtswesen (ab 5.97) | Ortsbrandmeister, Gemeindebrandmeister | `asue/berichte.html` | ASÜ-Port: `/berichte` |

- Gemeinsam bleibt nur der Server (`server.js`) und der Datenbestand.
- Zugänge: je Bereich eigene Zugänge (kein Zugang mehr für beide Datenbanken).
- Verwaltung der Zugänge und App-Links: Reiter **„⚙ Verwaltung“** in der jeweiligen Datenbank-App, nur für den Admin (Superadmin). Wehr-Schlüssel und ASÜ-Anmeldungen der Ortswehren: Einsatzverwaltung → Verwaltung → ASÜ-Zugänge.
- Ab 5.188: Rechte in der Datenbank-App – Atemschutzgerätewart: Personen, Nachweise, Atemschutzgeräte, Kalender, Auswertung, QR, Lager. Gerätewart: Gerätedatenbank, Kalender, Lager, Digitalfunk, Übersicht, Atemschutzgeräte (sehen und bearbeiten). Serverseitig `agwRecht(k, res, 'agtGeraete' | 'lager')`.
- `asue/index.html` enthält noch den alten Datenbank-Programmteil (wird nicht mehr aufgerufen; die ASÜ öffnet `/datenbank`).
