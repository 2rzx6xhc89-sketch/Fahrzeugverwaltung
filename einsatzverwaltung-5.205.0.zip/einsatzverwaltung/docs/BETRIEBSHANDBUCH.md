# Einsatzverwaltung – Betriebshandbuch für Admins

Stand: Version 5.10.4 (11.10.2026)

Dieses Handbuch beschreibt, wie der Pi im Alltag betreut wird und was im Störfall zu tun ist. Einrichtung und Installation stehen in `ANLEITUNG.md`, die Bedienung in `docs/BEDIENUNG.md`.

**Kurzfassung für den Ernstfall:** Im Einsatz geht der Einsatz vor – auf Papier weiterführen (Notfallmappe). Den Pi erst danach reparieren. Daten gehen bei einem Neustart nicht verloren.

---

## 1. Was läuft wo?

| Teil | Adresse | Erreichbar |
|---|---|---|
| Einsatzverwaltung | `http://<Pi-IP>:8080` | nur im Netz des Feuerwehrhauses / ELW – **nie** aus dem Internet freigeben |
| Fahrzeug-App | Port 8081, von außen über HTTPS (Tailscale Funnel) | Handys der Fahrzeuge |
| ASÜ, Datenbank für Gerätewarte und Atemschutzgerätewarte (`/datenbank`) | Port 8082, von außen über HTTPS (Tailscale Funnel, Port 8443) | Tablets, Gerätewarte |
| ASÜ für die Ortswehren | GitHub Pages (z. B. `https://konto.github.io/asue/`) | überall, Anmeldung über den Pi |

**Wichtige Dateien im Ordner `~/einsatzverwaltung`:**

| Datei / Ordner | Inhalt | Auf dem Sicherungs-Stick? |
|---|---|---|
| `data.json` | alle Daten (Einsätze, Fahrzeuge, Benutzer, Atemschutz, Geräte) | ja (verschlüsselt, wenn Passwort gesetzt) |
| `backups/` | stündliche und tägliche Stände, frühere Programmversionen | nein (liegt auf dem Pi) |
| `objekte/`, `berichtbilder/`, `protokoll/` | Pläne, Bilder, Änderungsprotokoll | ja |
| `asue/benutzer.js` | Zugänge der ASÜ | ja |
| `einstellungen.json` | Schnittstellen, Kennwörter von Postfach und Portalen, Wehr-Schlüssel, Sicherungs-Passwort | **nein** – getrennt aufbewahren (Kapitel 7) |
| `push-vapid.json` | Schlüssel für Benachrichtigungen | **nein** – getrennt aufbewahren |
| `tiles/`, `schrift/`, `hoehe/` | Karten, Schriften, Höhendaten (Zwischenspeicher) | nein (lädt der Pi neu) |

---

## 2. Regelmäßige Aufgaben

| Wann | Was | Wo |
|---|---|---|
| täglich (automatisch) | Selbsttest-Mail kommt an – bleibt sie aus, Pi prüfen | Postfach der System-Empfänger |
| wöchentlich | Hinweis-Zentrale 🔔 und **Verwaltung → Sicherheit** ansehen: Sicherheits-Check, Auffälligkeiten, Anmeldungen | Einsatzverwaltung |
| monatlich | Sicherung auf dem Stick prüfen (grün), Zweit-Stick tauschen, falls im Wechsel genutzt | Verwaltung → Einstellungen → Sicherung & System |
| nach jedem Update | Probestart abwarten, danach kurz Einsatz, ASÜ und Fahrzeug-App öffnen; ASÜ auf GitHub aktuell? | Atemschutz-Datenbank → ⚙ Verwaltung |
| monatlich | **Verwaltung → Hydranten**: offene Mängel und „außer Betrieb“ an den Wasserversorger weitergeben, erledigte als „behoben“ eintragen; Fahrzeugfristen (HU, SP, UVV) in der Gerätedatenbank im Blick | Verwaltung → Hydranten, Gerätedatenbank |
| halbjährlich | Benutzer und Zugänge durchsehen: ausgeschiedene Personen sperren, „ausgeschieden am“ in der Atemschutz-Datenbank eintragen | Verwaltung → Benutzer, Gerätewarte, ASÜ-Zugänge |
| jährlich | **Wiederherstellungsprobe** (Kapitel 5) · Notfallmappe neu drucken · Hydranten-Prüfrunde mit der Fahrzeug-App abschließen (Prüfintervall 12 Monate) · Fahrtenbuch je Fahrzeug als CSV sichern (Gerätedatenbank) · Verzeichnis der Verarbeitungstätigkeiten prüfen · GitHub-Schlüssel und Zertifikat auf Ablauf prüfen | – |

---

## 3. Programm aktualisieren

1. Neue Version als ZIP auf den PC laden.
2. Einsatzverwaltung → **Verwaltung → Einstellungen → Sicherung & System → „Programm aktualisieren“** (Admin, PIN).
3. ZIP auswählen → **„Paket prüfen“**. Der Pi startet die neue Version zur Probe auf Testports (ohne eure Daten). Es werden Versionen, Neuerungen und Hinweise angezeigt – z. B. wenn ein Einsatz läuft.
4. **„Jetzt einspielen und neu starten“**. Vorher sichert der Pi die Daten und legt das bisherige Programm in `backups/programm/` ab (die letzten 3). Nach etwa 10 Sekunden lädt die Seite neu.
5. Bei „ASÜ automatisch auf GitHub“ veröffentlicht der Pi die neue ASÜ etwa 90 Sekunden später selbst. Sonst unter Verwaltung → ASÜ-Zugänge „Jetzt auf GitHub veröffentlichen“ bzw. ZIP erzeugen und hochladen.

**Nicht während eines laufenden Einsatzes aktualisieren.**

**Zurück zur vorherigen Version:** Verwaltung → Einstellungen → Sicherung & System → „Frühere Programmversionen“ → „Zurück zu …“. Startet der Pi nach einem Update gar nicht mehr (Kapitel 6): per SSH `bash ~/einsatzverwaltung/backups/programm/<Ordner>/zuruecksetzen.sh`.

Für die Erstinstallation oder wenn eine Version es ausdrücklich verlangt: `bash install.sh` im entpackten Ordner (siehe ANLEITUNG).

---

## 4. Datensicherung

- Der Pi sichert **stündlich und täglich** auf seine Speicherkarte und auf den **USB-Stick „FWBACKUP“** bzw. ein Netzlaufwerk – außerdem nach jedem Einsatzende.
- Mit **Sicherungs-Passwort** (Einstellungen → Betrieb) ist alles auf dem Stick verschlüsselt. Das Passwort steht im Schlüsselumschlag (Kapitel 7). Ohne Passwort sind die Sicherungen nicht lesbar.
- **Sicherung herunterladen:** Verwaltung → Einstellungen → Sicherung & System → „Sicherung herunterladen“ (PIN) – ein vollständiger Stand als Datei, z. B. vor größeren Änderungen.
- Zwei Sticks im Wechsel, einer außer Haus, schützen auch gegen Brand oder Diebstahl im Feuerwehrhaus.

---

## 5. Sicherung zurückspielen

Auf demselben Pi (z. B. nach versehentlichem Löschen) oder auf einem neu installierten Pi:

1. Dienst anhalten: `sudo systemctl stop einsatzverwaltung`
2. Stick einstecken und einhängen (`sudo mount /mnt/fwbackup`, bei Raspberry Pi OS mit Desktop unter `/media/…`).
3. **Verschlüsselte Sicherung entschlüsseln** (fragt nach dem Sicherungs-Passwort):
   ```bash
   cd ~/einsatzverwaltung
   node sicherung-entschluesseln.js /mnt/fwbackup/einsatzverwaltung-sicherung ~/wiederherstellung
   ```
   Unverschlüsselte Sicherung: direkt aus `/mnt/fwbackup/einsatzverwaltung-sicherung` nehmen.
4. Den gewünschten Tagesstand zurückkopieren (aktuellste Datei nehmen, Datum im Namen):
   ```bash
   cp ~/einsatzverwaltung/data.json ~/einsatzverwaltung/data.json.vor-wiederherstellung   # falls vorhanden
   cp ~/wiederherstellung/data-JJJJ-MM-TT.json ~/einsatzverwaltung/data.json
   cp -r ~/wiederherstellung/objekte ~/wiederherstellung/berichtbilder ~/einsatzverwaltung/ 2>/dev/null
   cp ~/wiederherstellung/asue/benutzer.js ~/einsatzverwaltung/asue/
   ```
5. `einstellungen.json` und `push-vapid.json` aus dem Schlüsselumschlag zurücklegen (Kapitel 7), Rechte setzen: `chmod 600 ~/einsatzverwaltung/einstellungen.json ~/einsatzverwaltung/push-vapid.json`
6. Dienst starten: `sudo systemctl start einsatzverwaltung` – nach etwa einer Minute anmelden und prüfen: letzter Einsatz im Archiv, Fahrzeuge, Benutzer, Sicherheits-Check.
7. Die stündlichen Stände auf dem Pi selbst (`backups/`) sind unverschlüsselt und lassen sich genauso zurückkopieren, wenn nur ein paar Stunden fehlen.

**Wiederherstellungsprobe (jährlich):** Schritte 3 und 4 auf einem zweiten Rechner oder Ersatz-Pi durchspielen. Nur so ist sicher, dass Stick und Passwort im Ernstfall funktionieren.

---

## 6. Störungen und was zu tun ist

| Störung | Was tun |
|---|---|
| Einsatzverwaltung lädt nicht, im ELW und im Feuerwehrhaus | Pi neu starten (Stecker 10 Sekunden ziehen). Nach etwa 2 Minuten erneut versuchen. In der Zwischenzeit: Notfallmappe. |
| Lädt weiterhin nicht | Per SSH anmelden: `sudo systemctl status einsatzverwaltung` und `journalctl -u einsatzverwaltung -n 50`. Fehlermeldung notieren. |
| Nach einem Update kaputt | Zurück zur vorherigen Version (Kapitel 3). |
| Anmeldung zeigt keine Benutzer mehr / Daten scheinen weg | Daten nicht verloren: per SSH Programm anhalten (`sudo systemctl stop einsatzverwaltung`), im Programmordner die neueste große Sicherung prüfen (`data.json.vor-update-…` oder `backups/stuendlich/…`), nach `data.json` kopieren, starten. Ab 5.151.2 erledigt das Programm das beim Start selbst. |
| Pi startet gar nicht (keine Lämpchen, Speicherkarte defekt) | **Pi tauschen** (Kapitel 8). |
| Fahrzeug-App / Datenbanken von außen nicht erreichbar | Verwaltung → Zustand des Pi → „Verbindung von außen“ (zeigt Ursache, hat Knöpfe zum Reparieren). Im Einsatz: Funk. |
| ASÜ-Tablets „Server nicht erreichbar“ | Die ASÜ läuft offline weiter und überträgt später. Nichts tun, nach dem Einsatz prüfen. |
| Keine Selbsttest-Mail | Pi aus, ohne Internet oder Mailversand gestört – Zustand des Pi ansehen. |
| Sicherheitshinweis (Mail / Push an Superadmin) | Verwaltung → Sicherheit → Auffälligkeiten und Anmeldungen. Unklare Anmeldung von außen: betroffenes Gerät abmelden und Kennwort des Zugangs ändern. |
| Handy eines Gerätewarts verloren | Verwaltung → Sicherheit → Angemeldete Geräte → „Abmelden“. Kennwort neu vergeben lassen. |
| Fahrzeug-Handy verloren | Verwaltung → Fahrzeug-App → Zugang des Fahrzeugs erneuern (alter Link wird ungültig). |

---

## 7. Schlüsselumschlag

Diese Dinge liegen bewusst **nicht** auf dem Sicherungs-Stick. Sie gehören in einen versiegelten Umschlag (z. B. beim Gemeindebrandmeister und bei der Gemeinde), am besten zusätzlich auf einem zweiten, verschlüsselten Stick:

- Sicherungs-Passwort
- `einstellungen.json` (Kopie; enthält Postfach-Kennwort, Portalzugänge, Wehr-Schlüssel)
- `push-vapid.json` (sonst müssen nach einem Pi-Tausch alle Benachrichtigungen auf den Geräten neu eingeschaltet werden)
- Kennwort des Superadmins und des Pi-Benutzers (SSH)
- Zugang zum Tailscale-Konto und zum GitHub-Konto der Feuerwehr

Nach jeder Änderung an Schlüsseln oder Kennwörtern den Umschlag erneuern.

---

## 8. Pi tauschen (Ersatz-Pi oder neue Speicherkarte)

**Vorbereitung (einmalig, am besten jetzt):** Eine zweite Speicherkarte bzw. einen Ersatz-Pi mit derselben Version der Einsatzverwaltung einrichten (ANLEITUNG, Schnellinstallation) und beschriftet im Feuerwehrhaus lagern. Ein Ersatz-Pi im ELW mit eigener FRITZ!Box kann im Ernstfall direkt übernehmen.

**Im Ernstfall:**

1. Alten Pi vom Strom nehmen, Ersatz-Pi an denselben Platz (gleiches Netzwerkkabel, damit die FRITZ!Box ihm dieselbe IP gibt – sonst in der FRITZ!Box die feste IP auf den neuen Pi legen, ANLEITUNG Schritt 6).
2. Ist die Version auf dem Ersatz-Pi älter: neueste ZIP über `bash install.sh` einspielen.
3. **Sicherung zurückspielen** (Kapitel 5), einschließlich Schlüsselumschlag.
4. Tailscale auf dem neuen Pi anmelden (`sudo tailscale up`) und den Funnel einschalten (ANLEITUNG Schritt 8 und 13), damit Fahrzeug-App, ASÜ und Datenbanken von außen wieder gehen.
5. USB-Stick „FWBACKUP“ einrichten: `sudo bash ~/einsatzverwaltung/docs/stick-einrichten.sh`
6. Prüfen: Anmeldung, Sicherheits-Check, „Verbindung von außen“, Testalarm-Mail, eine Fahrzeug-App, eine ASÜ.

---

## 9. Zertifikat und Zugriff von außen

- Die HTTPS-Adressen kommen über **Tailscale Funnel**; das Zertifikat erneuert Tailscale selbst. Prüfung: Verwaltung → Zustand des Pi → „Verbindung von außen“.
- Port 8080 (Einsatzverwaltung) wird **nie** im Router freigegeben.
- Eigenes Zertifikat für das interne Netz (optional): Verwaltung → Einstellungen → Ports und Zertifikate → Zertifikat und Schlüssel eintragen, danach Neustart. Ablaufdatum notieren und rechtzeitig erneuern.

---

## 10. Zugänge und Rollen

| Wer | Zugang | Anlegen unter |
|---|---|---|
| Einsatzleitung, Admins, Betrachter | Benutzer mit PIN | Verwaltung → Benutzer |
| Superadmin (ein Kennwort für alles) | Admin mit Haken „Superadmin“ | Verwaltung → Benutzer |
| Ortswehren in der ASÜ | ASÜ-Zugang mit Startcode | Atemschutz-Datenbank → ⚙ Verwaltung → ASÜ-Zugänge (ab 5.100) |
| Gerätewart / Atemschutzgerätewart | Zugang zur Datenbank (Kennwort alle 4 Monate) | Atemschutz- bzw. Gerätedatenbank → ⚙ Verwaltung (ab 5.100) |
| Fahrzeuge | Link je Fahrzeug (ein Gerät) | Verwaltung → Fahrzeug-App |
| Atemschutzgeräteträger | persönlicher Link (nur Lesen) | Atemschutz-Datenbank → Person → „Persönlicher Link“ |

Beim **Austritt** eines Mitglieds: Zugänge sperren bzw. löschen, Geräte abmelden, in der Atemschutz-Datenbank „ausgeschieden am“ eintragen (die Löschfrist anonymisiert die Person später automatisch).

---

## 11. Berichte und Notfallmappe

- **Jahresbericht:** Verwaltung → Berichte & Notfall → Jahr wählen → „Jahresbericht öffnen“ → drucken oder als PDF speichern.
- **Notfallmappe:** Verwaltung → Berichte & Notfall → „Notfallmappe öffnen“ → drucken. Ansprechpartner vorher unter Einstellungen → Betrieb eintragen. Ein Exemplar in den ELW, eines ins Feuerwehrhaus.
