# Cyber Resilience Act (CRA) – Stand der Umsetzung

Verordnung (EU) 2024/2847. Gilt allgemein ab 11.12.2027; Meldepflichten (Art. 14) ab 11.09.2026. *Keine Rechtsberatung.*

## Anwendungsbereich
Der CRA gilt für Produkte mit digitalen Elementen, die **im Rahmen einer Geschäftstätigkeit** auf dem EU-Markt bereitgestellt werden (Erwägungsgrund 15). Die Einsatzverwaltung ist eine Eigenentwicklung für die Gemeindefeuerwehr Aerzen ohne Verkauf und ohne Gewinnerzielungsabsicht – nach dieser Lesart fällt sie derzeit **nicht** unter die Herstellerpflichten. Das ändert sich, wenn sie anderen Feuerwehren oder Kommunen **gegen Entgelt** (Lizenz, bezahlter Support über den Kosten) bereitgestellt wird. Dann wäre sie voraussichtlich ein Produkt der Standardklasse (keine „wichtige“/„kritische“ Kategorie nach Anhang III/IV) mit Selbstbewertung (Modul A), CE-Kennzeichnung und EU-Konformitätserklärung.

Die Umsetzung orientiert sich trotzdem an Anhang I – als gute Praxis und Vorbereitung.

## Anhang I Teil I – Sicherheitsanforderungen
| Anforderung | Stand |
|---|---|
| Keine bekannten ausnutzbaren Schwachstellen bei Bereitstellung | Prüfung 10/2026 durchgeführt, Funde behoben (siehe unten); Server-Bibliotheken express 4.21.2, ws 8.21.3 ohne bekannte offene Lücken |
| Sichere Standardkonfiguration | PIN mindestens 6 Zeichen für alle Rollen, kürzere und die Standard-PIN müssen bei der Anmeldung geändert werden; Superadmin ≥ 12 Zeichen; ASÜ von außen nur mit Schlüssel; Port 8080 nur intern |
| Sicherheitsupdates, möglichst automatisch, mit Hinweis | Update-Paket mit Ed25519-Signatur, Prüfung, Probestart, Rückfall auf Vorversion, SHA-256 |
| Schutz vor unbefugtem Zugriff | Anmeldung, Rollen, Sperre nach Fehlversuchen, Sicherheitshinweise |
| Vertraulichkeit | TLS über Tailscale/eigenes Zertifikat, verschlüsselte Sicherungen; Daten auf dem Pi unverschlüsselt (Datenträgerverschlüsselung empfohlen) |
| Integrität | Server-seitige Prüfung aller Eingaben, Protokoll aller Änderungen |
| Datenminimierung | Löschfristen, Namen in Berichten kürzbar/ausblendbar |
| Verfügbarkeit / Resilienz | Ausfallsichere Speicherung, tägliche Sicherung mit wöchentlicher Wiederherstellungsprobe, Selbstüberwachung des Pi (Temperatur, Spannung, Speicher, Uhrzeit, Schreibfähigkeit, Neustarts), Offline-Puffer auf den Tablets, Pi-Tausch-Anleitung |
| Angriffsfläche minimieren | Nur benötigte Ports, Sicherheits-Header, Browser-Bibliotheken lokal (html2canvas, SheetJS im Paket; ZXing, Tesseract vom Pi zwischengespeichert mit Prüfsumme) |
| Protokollierung | Systemprotokoll, Anmeldeprotokoll, Sicherheitshinweise |
| Löschen von Daten | Löschfristen, Benutzer/Zugänge löschbar |

## Anhang I Teil II – Umgang mit Schwachstellen
| Anforderung | Stand |
|---|---|
| Stückliste (SBOM) | `docs/sbom.cdx.json` (CycloneDX 1.5) |
| Schwachstellen zügig beheben, Updates kostenlos | über Update-Paket |
| Regelmäßige Tests | Darstellungs- und Sicherheitsprüfung 10/2026 |
| Offenlegung behobener Lücken | in den Versionshinweisen (BEDIENUNG.md, „Neu in …“) |
| Richtlinie zur koordinierten Offenlegung, Kontaktstelle | `SECURITY.md` |
| Sichere Verteilung der Updates | Ed25519-Signatur über alle Dateien (`SIGNATUR.json`, Werkzeug `docs/update-signieren.js`), Paket-Prüfung, SHA-256; nicht signierte Pakete nur durch den Superadmin nach ausdrücklicher Bestätigung |

## Offene Punkte
Erledigt in 5.131: Update-Signatur, Browser-Bibliotheken lokal, PIN-Mindestlänge 6 für alle Rollen.
1. Datenträgerverschlüsselung des Pi bzw. verschlüsselte data.json.
2. Content-Security-Policy für die Hauptseiten (erst sinnvoll, wenn eingebettete Skripte ausgelagert sind).
3. Privaten Signaturschlüssel getrennt sichern (zweite Kopie offline, z. B. versiegelter USB-Stick); bei Verlust neues Schlüsselpaar und einmalig ein nicht signiertes Übergangspaket.
4. Bei Weitergabe gegen Entgelt: technische Dokumentation, Konformitätserklärung, Meldeweg an ENISA/BSI (Art. 14) einrichten.
