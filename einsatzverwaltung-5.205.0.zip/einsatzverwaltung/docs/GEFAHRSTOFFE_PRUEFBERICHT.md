# Prüfbericht Stichprobe Gefahrstoff-Datenbank (Stand 2026-10-10)

Quellen per WebFetch geprüft: ERG-2024-Leitfäden (cameochemicals.noaa.gov/erg_guides/en/Guide_NNN.pdf), CAMEO-Datenblätter, CAMEO UNNA-Seiten (ERG Tabelle 1), Wikipedia „List of UN numbers …“.

**Ergebnis:** 56 Prüfpunkte (8 Bullets, 5 Abstandssätze, 10 Datenblätter, 8 Zeilen aus Tabelle 1, 25 UN-Einträge), davon 54 OK, 2 Abweichungen (beide inhaltlich, keine Zahlendreher). Dazu 5 Hinweise (nicht als Fehler gezählt).

## 1. Leitfaden-Bullets (EN-Wortlaut + DE-Übersetzung)

| Guide | Abschnitt | EN im Original | DE-Übersetzung | Status |
|---|---|---|---|---|
| 132 | gesundheit | wörtlich vorhanden (HEALTH) | treu | OK |
| 173 | gesundheit | wörtlich vorhanden (HEALTH) | treu | OK |
| 120 | schutzkleidung | wörtlich vorhanden | treu | OK |
| 137 | brand_explosion | wörtlich vorhanden | treu | OK |
| 153 | leckage | wörtlich vorhanden | treu | OK |
| 114 | schutzkleidung | wörtlich vorhanden | treu | OK |
| 115 | leckage | wörtlich vorhanden | treu | OK |
| 164 | brand_explosion | wörtlich vorhanden | „without **risk of** content loss“ → „ohne dass Inhalt … verloren geht“: das Wort „Gefahr/Risiko“ fehlt, aus einer Risikoaussage wird eine Tatsachenaussage | ABWEICHUNG (geringfügig) |

Vorschlag 164: „Verpackungen können vollständig verbrennen, ohne dass die Gefahr eines Inhaltsverlusts aus der versiegelten Quellkapsel besteht.“

## 1b. Abstände

| Guide | sofort_m | gross_leck_m | brand_m | Status |
|---|---|---|---|---|
| 115 | 100 ✓ | 800 ✓ | 1600 ✓ | OK |
| 124 | 100 ✓ | null ✓ (nur Verweis auf Tabelle 1) | 800 ✓ | OK |
| 128 | 50 ✓ | 300 ✓ | 800 ✓ | OK |
| 132 | 50 ✓ | null ✓ (kein Abstand im Großleck-Abschnitt) | 800 ✓ | OK |
| 140 | 50 ✓ (Flüssigkeiten) | 100 ✓ | 800 ✓ | OK (Hinweis H1) |

Alle Zitate (sofort_text_en, brand_text_en) stimmen mit dem Original überein.

## 2. Werte aus CAMEO-Datenblättern

| UN | Stoff | VD | SG | Kp °C (aus °F) | Fp °C | UEG/OEG | ERG | Status |
|---|---|---|---|---|---|---|---|---|
| 1593 | Dichlormethan | 2.93 ✓ | 1.322 ✓ | 39.8 ✓ (103.6 °F) | null ✓ | 12/19 ✓ | 160 ✓ | OK |
| 2014 | H2O2 20–60 % | null ✓ | 1.11 ✓ | 150.2 ✓ (302.4 °F) | null ✓ | null ✓ | 140 ✓ | OK |
| 1017 | Chlor | 2.49 ✓ | 1.424 ✓ | -34.6 ✓ (-30.3 °F) | null ✓ | null ✓ | 124 ✓ | OK |
| 1942 | Ammoniumnitrat | null ✓ | 1.72 ✓ | null ✓ | null ✓ | null ✓ | 140 ✓ | OK (Hinweis H2) |
| 1170 | Ethanol | 1.59 ✓ | 0.79 ✓ | 78.5 ✓ (173.3 °F) | 12.8 ✓ (55 °F) | 3.3/19 ✓ | 127 ✓ | OK |
| 1016 | Kohlenmonoxid | 0.97 ✓ | 0.791 ✓ | -191.5 ✓ (-312.7 °F) | null ✓ | 12/75 ✓ | 119 ✓ | OK |
| 1075 | Flüssiggas (LPG) | null ✗ | null ✗ | null ✗ | null ✗ | null ✗ | 115 ✓ | **ABWEICHUNG** |
| 1013 | Kohlendioxid | 1.53 ✓ | 1.56 ✓ | null ✓ („Sublimes“) | null ✓ | null ✓ | 120 ✓ | OK |
| 1402 | Calciumcarbid | null ✓ | 2.22 ✓ | null ✓ | null ✓ | null ✓ | 138 ✓ | OK |
| 1838 | Titantetrachlorid | null ✓ | 1.726 ✓ | 136.4 ✓ (277.5 °F) | null ✓ | null ✓ | 137 ✓ | OK |

**ABWEICHUNG UN 1075:** Das Datenblatt enthält Werte als Bereiche bzw. pro Komponente, die Datenbank hat alles auf null gesetzt: VD 1.45–2.00; SG 0.51–0.58 (bei -58 °F); Kp > -40 °F (> -40 °C); Fp Propan -156 °F (-104 °C), Butan -76 °F (-60 °C); UEG Propan 2.2 % / Butan 1.8 %; OEG Propan 9.5 % / Butan 8.4 %. Vermutlich verwirft der Parser alles, was keine einzelne Zahl ist. Das ist gefährlich, weil „keine Angabe“ bei einem hochentzündbaren Gas als „nicht entzündbar“ missverstanden werden kann.

## 3. ERG Tabelle 1 (Originalwerte ft/mi und Umrechnung)

| UN | Name | Original klein | Original groß | Umrechnung | Status |
|---|---|---|---|---|---|
| 1005 | Ammonia, anhydrous | 100 ft/0.1/0.1 ✓ | Tabelle 3 ✓ | 30 m/0.2/0.2 km ✓ | OK |
| 1005 | Anhydrous ammonia | ✓ | ✓ | ✓ | OK |
| 1053 | Hydrogen sulfide | 100 ft/0.1/0.3 ✓ | 1250 ft/1.5/4.0 ✓ | 30 m/0.2/0.5; 381 m/2.4/6.4 ✓ | OK |
| 1053 | Hydrogen sulphide | ✓ | ✓ | ✓ | OK |
| 1079 | Sulfur dioxide | 300 ft/0.4/1.6 ✓ | Tabelle 3 ✓ | 91 m/0.6/2.6 ✓ | OK |
| 1079 | Sulphur dioxide | ✓ | ✓ | ✓ | OK |
| 1076 | Phosgene | 300 ft/0.4/1.6 ✓ | 1500 ft/1.9/5.9 ✓ | 91 m/0.6/2.6; 457 m/3.1/9.5 ✓ | OK |
| 1050 | Hydrogen chloride, anhydrous | 100 ft/0.1/0.2 ✓ | Tabelle 3 ✓ | 30 m/0.2/0.3 ✓ | OK |

## 4. UN-Liste (Wikipedia), 25 Einträge

Alle 25 Einträge stimmen in UN-Nummer, Klasse und Name mit der passenden Wikipedia-Seite überein: 1212, 2027, 2790, 1278, 3418, 1134, 3547, 2234, 3503, 1463, 1055, 3548, 1496, 2525, 1027, 3449, 0391, 3520, 0378, 1603, 3235, 3381, 2837, 2258, 3095 → **25 × OK** (Hinweis H4).

## Hinweise (nicht als Abweichung gezählt)

- **H1 – Guide 140:** sofort_m speichert nur 50 m (Flüssigkeiten). Die 25 m für Feststoffe stehen nur im Textfeld. Wer nur das Zahlenfeld anzeigt, sieht die Feststoff-Angabe nicht.
- **H2 – UN 1942:** Das CAMEO-Datenblatt verweist zusätzlich auf ERG Guide 112 (Ammoniumnitrat als Explosivstoff). Gespeichert ist nur 140.
- **H3 – Datentyp erg_guide uneinheitlich:** bei 1017, 1016 und 1013 als Zahl (124, 119, 120), sonst als String. Bei striktem Vergleich oder Lookup kann das zu Fehlern führen.
- **H3b – Metrik Tabelle 1:** Die Meterwerte sind rechnerisch korrekt aus ft/mi umgerechnet (auf eine Nachkommastelle in km gerundet). Sie sind aber **nicht** die offiziellen Werte der metrischen ERG-Ausgabe, die eigene, gerundete Abstände verwendet. Das sollte in der App gekennzeichnet werden („umgerechnet aus US-Ausgabe“). Ein Abgleich mit der metrischen Ausgabe war nicht Teil dieser Stichprobe.
- **H4 – UN 3381:** Der Name enthält LaTeX-Reste aus Wikipedia („200ml/m^{3}“, „500 LC_{50}“). Sie sollten vor der Anzeige bereinigt werden (z. B. „200 ml/m³“, „500 LC50“).

## Prüfung Version 3.97 (Originaldateien ERG 2024 und ADR 2025)

- ERG 2024, gelbe Seiten: 1.983 Nummern maschinell ausgelesen; Abgleich mit dem Seitentext vollständig (keine fehlende Nummer). Leitfadennummern der 113 CAMEO-Stoffe stimmen alle überein.
- ERG 2024, Tabelle 1: 537 Zeilen / 272 UN-Nummern mit metrischen Originalwerten; Abgleich mit den bisherigen (umgerechneten) CAMEO-Werten: keine Abweichung über Rundungsgrenzen. Verbundene Tabellenzellen (z. B. 1340, 1744, 1754) einzeln geprüft.
- ERG 2024, Leitfäden: alle 2.575 englischen Sätze der Übersetzungsvorlage im PDF-Text wiedergefunden (Abweichungen nur bei Zwischenüberschriften wie „Small Fire:“).
- ADR 2025 Tabelle A: 2.939 Einträge / 2.347 UN-Nummern; Gefahrnummern und Klasse/Klassifizierungscode gegen den Seitentext gegengeprüft (Abweichungen nur durch Textlayout, z. B. „See SP 671“).
- Deutsche Benennungen: Stichprobe von 40 – alle sinngetreu, 4 kleine Abweichungen in Schreibweise (Masse-%, Bindestriche, Komma).
