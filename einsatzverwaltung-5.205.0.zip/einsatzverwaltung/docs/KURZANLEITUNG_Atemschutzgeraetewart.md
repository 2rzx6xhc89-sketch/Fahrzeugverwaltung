# Kurzanleitung Atemschutzgerätewart – Atemschutz-Datenbank

Stand: Version 5.170 (20.10.2026)

Die Atemschutz-Datenbank führt die Atemschutzgeräteträger eurer Ortswehr mit ihren Nachweisen nach FwDV 7, die Atemschutzgeräte und die Gerätepflege nach Einsätzen und Übungen. Ob jemand einsatzbereit ist, sieht die ASÜ beim Einlesen des QR-Codes sofort.

## Erste Anmeldung

1. Link vom Zugangszettel öffnen (`…/atemschutz`), Benutzer und Startkennwort eingeben.
2. Eigenes Kennwort festlegen (mindestens 8 Zeichen), Wechsel **alle 4 Monate** – eine Woche vorher kommt eine Erinnerung.
3. Auf dem eigenen Handy: Haken **„Angemeldet bleiben“** (30 Tage).

## Als App installieren und Benachrichtigungen einschalten

- **Android / Chrome / Edge:** „📲 Als App installieren“. **iPhone / iPad:** Safari → „Teilen“ → „Zum Home-Bildschirm“.
- **„🔔 Benachrichtigungen“** → „Auf diesem Gerät einschalten“ → „Test senden“.
- Ihr bekommt: ablaufende Nachweise (4 Wochen vorher und bei Ablauf), Prüftermine der Atemschutzgeräte, neue Atemschutz-Nutzungen aus dem Einsatz (Geräte zur Pflege), Gerätetausch und Prüfung aus der ASÜ, die Kennwort-Erinnerung.

## Personen und Nachweise

| Aufgabe | So geht's |
|---|---|
| Person anlegen | „+ Person“ oder Reiter **QR-Codes** → Name eintragen → QR-Code drucken (für den Helm bzw. die Karte) |
| Nachweis eintragen | Person öffnen → Datum eintragen: Lehrgang, Eignungsuntersuchung Atemschutz (G 26.3) mit „gültig bis“, Belastungsübung, Unterweisung, CSA-Übung |
| Einsatzbereitschaft | Reiter **Einsatzbereitschaft** – wer ist bereit, wer bald fällig, wer nicht |
| Übung / Einsatz unter Atemschutz | wird aus der ASÜ automatisch übernommen (QR-Code beim Trupp einlesen) |
| Person ausgeschieden | Person öffnen → „Ausgeschieden am“ eintragen. Nach der Löschfrist wird sie automatisch anonymisiert. |
| Persönlicher Link | Person öffnen → „🔗 Persönlicher Link“ → als QR-Code zeigen oder per Messenger schicken. Der Geräteträger sieht damit seine eigenen Fristen. |
| Link-Passwort vergessen | Person öffnen → „🔗 Persönlicher Link“ → „Passwort zurücksetzen“ – der Geräteträger legt beim nächsten Öffnen ein neues fest |
| Jahresauswertung | Reiter **📊 Jahresauswertung** → Jahr wählen → drucken (z. B. für die Jahreshauptversammlung) |
| Excel | Reiter **Personen** oder **Atemschutzgeräte** → „📊 Excel“ → Ortswehr wählen → Export, leere Vorlage oder Import (erst „Datei prüfen“, dann „Jetzt einspielen“; ID-Spalte nicht ändern; nur Datumsangaben, keine Befunde) |

**Gesundheitsdaten:** Von der Eignungsuntersuchung werden nur Datum und „gültig bis“ eingetragen – **nie** ein Befund.

## Geräte und Pflege

- Reiter **Gerätepflege:** jede Benutzung aus Einsatz und Übung mit Gerätenummern. Haken „FTZ“, wenn der Gerätesatz zur Prüfung geht, „zurück“, wenn er wiederkommt. „📄 Formblatt“ druckt den Übergabezettel.
- Andere Feuerwehren können Tausch und Prüfung auch selbst in der ASÜ melden (Reiter „Tausch / Prüfung“) – das erscheint hier und als Benachrichtigung.
- Reiter **Atemschutzgeräte:** Nummern, Typ, zwei Prüftermine im Jahr (die Fristen gibt die Atemschutzwerkstatt des Kreises vor).

## Datenschutz: wer sieht Namen?

- **Ihr** und der **Ortsbrandmeister** eurer Ortswehr seht die Namen eurer Geräteträger.
- Der **Gemeindebrandmeister** sieht in der Atemschutz-Datenbank und im Berichtswesen **keine Namen und keine Kontaktdaten** – nur eine feste Kennung wie „Person 17“ – und kann hier nichts ändern.
- Damit Einsätze aus der ASÜ der richtigen Person zugeordnet werden: bei der ASÜ immer den **QR-Code** des Geräteträgers einlesen; sonst zählt nur der gleiche Nach- und Vorname.
- Scheidet jemand aus: hier das **Ausscheidedatum** eintragen (der Admin entfernt den Zugang mit „Mitglied ausgeschieden“).
- Für FeuerON gibt es unter „📊 Excel“ den **FeuerON-Export** (Personalnummer und Geburtsdatum nur dafür).

## Wichtig

- Ihr seht nur Personen und Geräte eurer eigenen Ortswehr(en).
- Handy verloren: dem Admin Bescheid geben, er meldet das Gerät ab.
