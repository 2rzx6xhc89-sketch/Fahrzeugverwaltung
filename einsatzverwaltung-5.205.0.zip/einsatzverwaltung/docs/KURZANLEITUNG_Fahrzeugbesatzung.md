# Kurzanleitung Fahrzeug-App – für Fahrzeugbesatzungen, Orts- und Gemeindebrandmeister

Stand: Version 5.170 (20.10.2026)

Jedes Fahrzeug (und jede Funktion wie OrtsBM oder GemBM) hat eine eigene **Fahrzeug-App** fürs Handy. Kein Benutzername, kein Kennwort – der Zugang steckt im Link bzw. QR-Code.

## Einrichten

1. QR-Code vom Zettel im Fahrzeug scannen (oder vom Admin: Fahrzeug → „Stärke …“ → „Fahrzeug-App für dieses Fahrzeug“).
2. Auf den Home-Bildschirm legen (iPhone: Safari → Teilen → „Zum Home-Bildschirm“, Android: ⋮ → „App installieren“).
3. **🔔 Benachrichtigungen** einschalten – dann kommen Alarm, Nachrichten und Aufträge auch bei geschlossener App.
4. Ein Fahrzeug = ein Handy. Ein zweites Gerät sieht einen **Code** und fragt die Freigabe bei der Einsatzleitung an.

## Im Einsatz

| Reiter / Knopf | So geht's |
|---|---|
| 🚒 Einsatz | Stichwort, Einsatzort, **🧭 Navigation**; **Im Einsatz** / **Verfügbar** melden; **Stärke melden** (Führer, Mannschaft, AGT); **🗣 Lagemeldung** sprechen oder tippen |
| Ampel | 🟢 einsatzbereit · 🟡 mit Hinweisen · 🔴 nicht vollständig einsatzbereit (antippen = Gründe) |
| ✉️ Nachrichten | an Einsatzleitung oder andere Fahrzeuge, mit Fotos; Nachrichten der Einsatzleitung mit **„Verstanden“** bestätigen |
| 🗺️ Karte | Einsatzort, andere Fahrzeuge, ///what3words, eigener Standort, Hydranten |
| 📝 Melden | bei einer Sonderlage: weitere Schadensstelle melden |
| 🔧 | Schaden melden, Verbrauch nachfüllen, Fahrzeug-Check, Beladung prüfen |

Den **FMS-Status** sendet die App nicht – er kommt über PowerAlarm bzw. die Einsatzleitung.

## Fahrtenbuch (nach jeder Fahrt)

1. Zurück auf **Status 2** → die App erinnert („bitte den km-Stand eintragen“). Sonst: 🚒 Einsatz → **Fahrtenbuch**.
2. **km-Stand** eintippen – Abfahrt, Ankunft und Einsatznummer stehen schon drin; bei Bedarf Zweck, Ziel und Fahrer wählen → **Speichern**.
3. ⛽ **Getankt** (Liter, AdBlue, km) und ⏱ **Betriebsstunden** im selben Bereich. Es werden keine Kosten erfasst.

## Hydrantenprüfung

🗺️ Karte → **💧 Hydranten** → Hydrant antippen → sechs Punkte ✓/✗ oder „Alles in Ordnung“ → **Speichern**. Mängel gehen automatisch an den Wasserversorger. Fehlt ein Hydrant: an der Stelle tippen → „Hydranten hier melden und prüfen“.

## Für Orts- und Gemeindebrandmeister

Ist euch ein Eintrag zugewiesen (z. B. **OrtsBM**, **GemBM**), kommen über diese App auch Benachrichtigungen aus dem **Berichtswesen** (Anforderungen, Lager Gemeinde). Was genau, stellt ihr selbst im Berichtswesen unter **🔔 Benachrichtigungen** ein – auch, welche Meldungen der Fahrzeug-App ihr bekommen wollt.

## Wichtig

- Link nicht weitergeben. Handy verloren? Einsatzleitung bzw. Admin erzeugt einen **neuen Link** – der alte ist sofort ungültig.
- Datenschutzhinweise: Link unten in der App.
