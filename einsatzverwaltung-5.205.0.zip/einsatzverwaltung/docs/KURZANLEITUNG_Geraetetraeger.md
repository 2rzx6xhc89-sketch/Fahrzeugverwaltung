# Mein Atemschutz – Kurzanleitung für Atemschutzgeräteträger

Stand: Version 5.170 (20.10.2026)

Mit deinem persönlichen Link siehst du auf dem Handy jederzeit, ob du als Atemschutzgeräteträger einsatzbereit bist und wann deine Nachweise ablaufen.

## So bekommst du den Link

Dein Atemschutzgerätewart erzeugt ihn in der Atemschutz-Datenbank und zeigt dir einen QR-Code oder schickt dir den Link. QR-Code mit der Handy-Kamera scannen und die Seite öffnen – das geht auch von unterwegs über das Mobilfunknetz.

## Beim ersten Öffnen: Passwort festlegen

1. Ein eigenes **Passwort** (mindestens 6 Zeichen) zweimal eingeben – es schützt deine Seite, falls der Link mal in falsche Hände gerät.
2. Haken **„Auf diesem Handy angemeldet bleiben“** lassen – dann musst du es auf deinem Handy 90 Tage lang nicht mehr eingeben. Auf einem fremden Gerät den Haken weglassen.
3. Tipp: Seite als Lesezeichen oder auf dem Home-Bildschirm ablegen.

**Passwort vergessen?** Sag deinem Atemschutzgerätewart Bescheid – er setzt es in der Atemschutz-Datenbank zurück, und du legst beim nächsten Öffnen ein neues fest. Unten auf der Seite kannst du dich auf einem Gerät auch wieder abmelden.

## Was du siehst

- **Ganz oben:** ✓ Einsatzbereit, ✓ Einsatzbereit – bald fällig, oder ✗ Zurzeit nicht einsatzbereit (mit Grund).
- **Meine Nachweise (FwDV 7):** Lehrgang, Eignungsuntersuchung Atemschutz (G 26.3), Belastungsübung, Unterweisung, Übung oder Einsatz unter Atemschutz, ggf. CSA-Übung – jeweils mit Datum und „gültig bis“.
  - Grün: gültig · Gelb: läuft in den nächsten 4 Wochen ab · Rot: fehlt oder abgelaufen.
- **Unter Atemschutz in diesem Jahr:** Anzahl der Einsätze und Übungen, Minuten und die letzten Einsätze.

## Gut zu wissen

- Die Seite ist **nur zum Ansehen**. Stimmt etwas nicht, sag deinem Atemschutzgerätewart Bescheid.
- **Gib Link und Passwort nicht weiter.** Hast du ihn verloren oder weitergegeben, lässt du ihn sperren und bekommst einen neuen.
- Gespeichert sind nur Termine und Einsatzzeiten, keine Untersuchungsergebnisse.
- Deinen Namen sehen nur dein Atemschutzgerätewart und dein Ortsbrandmeister. In Auswertungen für die Gemeinde (Gemeindebrandmeister) erscheinst du nur als Kennung, z. B. „Person 17“.
- Damit Übungen und Einsätze mitzählen, beim Anlegen des Atemschutzes immer deinen QR-Code in der ASÜ einlesen lassen.
- Datenschutzhinweise: Link unten auf der Seite.
