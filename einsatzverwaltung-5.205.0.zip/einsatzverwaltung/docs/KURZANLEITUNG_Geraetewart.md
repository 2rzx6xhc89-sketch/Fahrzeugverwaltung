# Kurzanleitung Gerätewart – Gerätedatenbank

Stand: Version 5.170 (20.10.2026)

Die Gerätedatenbank zeigt alle Geräte eurer Ortswehr auf den Fahrzeugen und im Lager – mit Zustand, Prüffristen, Schadensmeldungen und Fahrzeugen außer Dienst. Was ihr hier eintragt, sieht die Einsatzleitung sofort in der Einsatzverwaltung.

## Erste Anmeldung

1. Link vom Zugangszettel öffnen (`…/geraete`), Benutzer und Startkennwort eingeben.
2. Eigenes Kennwort festlegen (mindestens 8 Zeichen). Es muss **alle 4 Monate** erneuert werden – eine Woche vorher kommt eine Erinnerung.
3. Auf dem eigenen Handy: Haken **„Angemeldet bleiben“** (30 Tage). Nicht an fremden Geräten.

## Als App installieren und Benachrichtigungen einschalten

- **Android / Chrome / Edge:** oben „📲 Als App installieren“.
- **iPhone / iPad:** in Safari „Teilen“ → „Zum Home-Bildschirm“, dann die App vom Home-Bildschirm öffnen.
- In der App **„🔔 Benachrichtigungen“** → „Auf diesem Gerät einschalten“ → „Test senden“.
- Ihr bekommt: Geräteprüfungen eine Woche vorher, sofort jede Schadensmeldung aus der Fahrzeug-App, montags den Wochenüberblick, die Erinnerung an das Kennwort.

## Im Alltag

| Aufgabe | So geht's |
|---|---|
| Gerät finden | Suche oben, Filter nach Fahrzeug oder Zustand – oder **📷 Etikett scannen** (QR-Code am Gerät) |
| Prüfung eintragen | Gerät öffnen → Datum, Ergebnis → „✅ Prüfung speichern“. Die nächste Prüfung wird nach dem Intervall berechnet. |
| Prüfung mit Protokoll | Gerät öffnen → „📝 Mit Prüfprotokoll + Unterschrift“ → Prüfpunkte abhaken, unterschreiben → drucken oder als PDF speichern |
| Mangel melden | Gerät öffnen → Text eintragen → „⚠ Mangel melden“. Das Gerät erscheint am Fahrzeug als nicht verfügbar. |
| Repariert | „🔧 Repariert – einsatzbereit“ |
| Umsetzen / ausleihen | Fahrzeug wählen → „⇄ Umsetzen“ bzw. „Ausleihen an …“ und später „Zurück“ |
| Fahrzeug außer Dienst | beim Fahrzeug „Fahrzeug außer Dienst …“, später „Wieder im Dienst“ (erscheint auf dem Alarmmonitor) |
| Schadensmeldung erledigen | Block „Schadensmeldungen aus der Fahrzeug-App“ → „✓ Erledigt …“ mit kurzer Antwort (geht an die Fahrzeug-App zurück) |
| QR-Etiketten drucken | „🖨 Etiketten“ – Etikett ans Gerät kleben |
| Excel | „📊 Excel“ → Ortswehr wählen → Export, leere Vorlage oder Import (erst „Datei prüfen“, dann „Jetzt einspielen“; ID-Spalte nicht ändern) |
| Prüfart wählen | Gerät → Stammdaten → Prüfart aus der Liste; das Intervall wird übernommen |
| Fahrzeugfristen (HU, SP, UVV, Wartung, Pumpenprüfung) | beim Fahrzeug „🚗 Fahrtenbuch & Fristen“ → Daten eintragen → „Fristen speichern“. Erinnerung 28 Tage vorher per Mail und Push; steht auch auf dem Alarmmonitor. |
| Fahrtenbuch ansehen | gleicher Dialog: Fahrten, km, Tanken, Betriebsstunden je Jahr; „⬇ CSV“ für Excel; falsche Einträge mit Grund als „falsch“ markieren |

## Lager

| Aufgabe | So geht's |
|---|---|
| Verbrauchsmaterial der Ortswehr | Reiter **Lager** → „+ Material“ (Bezeichnung, Einheit, Lagerplatz, Bestand, Mindestbestand). Mit − / + entnehmen bzw. einbuchen. Unter Mindestbestand wird die Zeile rot und steht im Wochenüberblick. |
| Wer hat was gebucht? | Material → „Bearbeiten“ → **📜 Bewegungen**: jede Entnahme, Einbuchung und Korrektur mit Zeit und Name |
| **Lager Gemeinde** ansehen | Auswahl oben → **🏛 Lager Gemeinde**: Ihr seht die **öffentlichen** Artikel der Gemeinde mit Bestand und Lagerplatz – nur ansehen |
| Aus dem Lager Gemeinde anfordern | beim Artikel **📝 Anfordern** → Menge und Begründung. Daraus wird eine Anforderung im Berichtswesen, die der Gemeindebrandmeister bearbeitet. |
| Gemeindegerätewart | Mit einem Zugang für **alle Ortswehren** pflegt ihr (zusammen mit dem Gemeindebrandmeister) das Lager Gemeinde: Artikel anlegen, „🌐 Öffentlicher Artikel“ ankreuzen, entnehmen, einbuchen. Fällt ein Artikel unter den Mindestbestand, kommt eine Mail. |

**Wochenüberblick:** „📋 Wochenüberblick“ zeigt jederzeit offene Schäden, Fahrzeuge außer Dienst, nicht einsatzbereite Geräte und die Prüfungen der nächsten 4 Wochen.

## Wichtig

- Ihr seht nur Geräte und Fahrzeuge eurer eigenen Ortswehr(en) – im Lager Gemeinde nur die öffentlichen Artikel.
- Fahrzeug oder Funktion: Einträge ohne Fahrzeugtyp (und Funktionen wie OrtsBM, Fachberater, Feuerwehrhaus) zählen nicht als Fahrzeug.
- Das Fahrtenbuch füllt die Besatzung in der Fahrzeug-App (nur km-Stand); Abfahrt und Ankunft kommen aus dem FMS-Status.
- Handy verloren oder neues Handy: dem Admin Bescheid geben, er meldet das alte Gerät ab.
- Datenschutzhinweise: Link unten auf der Anmeldeseite.
