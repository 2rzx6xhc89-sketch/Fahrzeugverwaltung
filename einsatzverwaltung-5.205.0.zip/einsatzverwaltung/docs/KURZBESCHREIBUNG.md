# Einsatzverwaltung – Kurzbeschreibung

Stand: Version 5.10.4 (11.10.2026)

Die Einsatzverwaltung ist ein digitaler Führungsassistent für die Gemeindefeuerwehr. Sie läuft auf einem eigenen kleinen Server (Raspberry Pi) im Feuerwehrhaus – ohne Cloud – und verbindet ELW, Fahrzeuge, Atemschutzüberwachung und die Gerätewarte.

## Was sie leistet

| Bereich | Leistung |
|---|---|
| Einsatzführung | Einsatztagebuch nach FwDV 100 (nur ergänzbar), Lagekarte mit taktischen Zeichen, Abschnitte, Kräfteanforderung, Lagemeldung, Uhren, Checklisten, Einsatzbericht als PDF |
| Fahrzeuge | Status über PowerAlarm, Stärke (Führer / Mannschaft / Atemschutzgeräteträger), Position, Nachrichten und Aufträge über die Fahrzeug-App auf dem Handy; Fahrtenbuch (nur km-Stand, Zeiten aus dem Status), Tanken, Betriebsstunden; Fahrzeugfristen HU/SP/UVV/Wartung mit Erinnerung |
| Atemschutz | Atemschutzüberwachung auf dem Tablet nach FwDV 7 (Druckabfragen, Rückzug, Sicherheitstrupp, Notfall, CSA), läuft auch offline; Nachweis je Geräteträger |
| Atemschutz-Datenbank | Nachweise der Geräteträger (Lehrgang, Eignungsuntersuchung nur mit Datum, Belastungsübung, Unterweisung), Einsatzbereitschaft auf einen Blick, Gerätepflege, Jahresauswertung, persönlicher Link für jeden Geräteträger |
| Gerätedatenbank | alle Geräte auf den Fahrzeugen mit Prüffristen, Prüfprotokoll mit Unterschrift, QR-Etiketten, Schadensmeldungen aus den Fahrzeugen, Wochenüberblick |
| Information | Gefahrstoffdatenbank, Objekte mit Plänen, Unwetterwarnungen, Wasserentnahmestellen, Anfahrtszeiten der Ortswehren |
| Hydranten | Hydrantenprüfung mit der Fahrzeug-App (Prüfpunkte, Fotos, „außer Betrieb“), Mängel-Mail an den Wasserversorger, Zustand in der Lagekarte, Löschwasser-Abdeckung, Übersicht je Ortswehr mit CSV-Export |
| Gerätehaus | Alarmmonitor mit Karte, Terminen, Prüffristen und Fahrzeugen außer Dienst |
| Ausbildung | Übungsgenerator, Übungsleitstelle, Demo-Version auf USB-Stick |
| Verwaltung | Jahresbericht auf Knopfdruck (mit Fahrleistung), Notfallmappe mit Papiervordrucken für den Ausfall |

## Apps

- **Einsatzverwaltung** – im ELW und im Feuerwehrhaus (nur internes Netz).
- **Fahrzeug-App** – ein Link je Fahrzeug, auf dem Handy der Besatzung.
- **Atemschutzüberwachung (ASÜ)** – Tablet je Ortswehr, verteilt über GitHub Pages, automatisch aktuell.
- **Gerätedatenbank** und **Atemschutz-Datenbank** – als App auf dem Handy der Gerätewarte, mit Benachrichtigungen.

## Sicherheit und Datenschutz

- **Daten bleiben bei der Feuerwehr:** eigener Server, keine Cloud, kein Auftragsverarbeiter. Karten und Schriften liefert der Server selbst aus.
- **Zugriff von außen nur verschlüsselt (HTTPS)** und nur für Fahrzeug-App, ASÜ und Datenbanken. Die Einsatzverwaltung selbst ist aus dem Internet nicht erreichbar.
- **Persönliche Zugänge** mit Rollen (Admin, Einsatzleitung, Betrachter), PIN-Bestätigung vor kritischen Aktionen, Kennwortwechsel alle 4 Monate für Zugänge von außen, Sperre nach Fehlversuchen.
- **Nachvollziehbar:** Änderungsprotokoll, Anmeldejournal, Sicherheits-Check mit Hinweisen per Mail.
- **Datensicherung** stündlich und täglich, verschlüsselt auf USB-Stick oder Netzlaufwerk; Notfallmappe und Betriebshandbuch für den Ausfall.
- **Datenschutz:** Datenschutzhinweise in allen Apps, einstellbare Löschfristen, Anonymisierung ausgeschiedener Geräteträger, keine Gesundheitsbefunde; Entwurf des Verzeichnisses der Verarbeitungstätigkeiten liegt vor.

## Vorschriften

FwDV 100 (Einsatztagebuch, Führung), FwDV 7 (Atemschutzüberwachung, Nachweise, Trupp aus mindestens 2 Personen), FwDV 3 (Stärke, in vereinfachter Form ohne Unterführer), DGUV Grundsatz 305-002 (Prüfarten der Gerätedatenbank), DSGVO und NDSG (Datenschutz). Die Prüffristen der Atemschutzgeräte gibt die Atemschutzwerkstatt des Kreises vor.

## Betrieb

- Hardware: Raspberry Pi mit USB-Stick für die Sicherung; optional Ersatz-Pi im ELW.
- Updates über die Oberfläche (Probestart, automatische Sicherung, Rückkehr zur Vorversion möglich).
- Dokumentation: Bedienungsanleitung, Einrichtungsanleitung, Betriebshandbuch, Kurzanleitungen für Gerätewarte, Atemschutzgerätewarte, Geräteträger und Fahrzeugbesatzungen.
- Keine Kosten- oder Gebührenfunktionen – die Software bildet nur den Einsatz- und Gerätebetrieb ab.
