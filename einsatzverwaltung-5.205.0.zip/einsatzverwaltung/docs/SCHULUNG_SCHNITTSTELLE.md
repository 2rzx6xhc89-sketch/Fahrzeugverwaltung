# Schnittstelle Online-Schulung ↔ Träger-App (ab 5.92)

**Ablage (ab 5.93):** Die Schulung wird als **ZIP-Datei mit `index.html`** (alle Bilder, Videos, CSS/JS mit relativen Pfaden im selben ZIP) oder als **einzelne HTML-Datei** in der Einsatzverwaltung unter Verwaltung → Gerätewarte → „🎓 Online-Schulung“ hochgeladen und aktiviert. Die aktive Schulung ist dann unter `https://<ASÜ-Adresse>/schulung/` erreichbar. Jedes Jahr kann eine neue hochgeladen werden; Größe bis 80 MB.

**Aufruf:** Die Träger-App (`/traeger`) öffnet die Schulung im Vollbild-Rahmen (iframe, gleiche Adresse), wenn der Geräteträger „Schulung starten“ tippt. Der Knopf erscheint nur, wenn `asue/schulung/index.html` vorhanden ist und die Schulung nicht gesperrt ist.

**Ergebnis melden** – am Ende der Schulung genau einmal:
```js
window.parent.postMessage({
  typ: 'asue-schulung',
  bestanden: true,      // true = bestanden, false = nicht bestanden
  punkte: 18,           // erreichte Punkte (optional)
  max: 20,              // mögliche Punkte (optional)
  version: '2026-1',    // Version/Stand der Schulung (optional, max. 40 Zeichen)
  schliessen: true      // optional, false = Rahmen bleibt offen (z. B. für eine Abschlussseite)
}, '*');
```

**Wirkung:**
- `bestanden: true` → In der Atemschutz-Datenbank wird **„Unterweisung“ mit dem heutigen Datum** eingetragen (Quelle „Online-Schulung“), gültig 12 Monate.
- `bestanden: false` → Die Schulung wird **gesperrt**. Der Atemschutzgerätewart der Ortswehr bekommt eine Benachrichtigung und muss sie in der Atemschutz-Datenbank (Person → „📱 Träger-App“ → „Schulung freigeben“) wieder freigeben.
- Jeder Versuch wird mit Datum, Punkten und Version gespeichert (die letzten 20).

**Hinweise für die Schulung:**
- Keine eigene Anmeldung nötig – die Träger-App ist bereits angemeldet und meldet das Ergebnis an den Pi.
- Keine Daten nach außen senden; Inhalte (Texte, Bilder, Videos) lokal im Ordner `asue/schulung/` ablegen.
- Läuft nur über die Träger-App sinnvoll (direkt geöffnet passiert beim postMessage nichts).
