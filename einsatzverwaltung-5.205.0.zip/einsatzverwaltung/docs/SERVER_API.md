# Einsatzverwaltung – Schnittstelle der Atemschutzüberwachung

Stand: 27.09.2026 · Version 3.4 · eingebaut in `server.js` der Einsatzverwaltung (Node.js, Raspberry Pi)

Die Atemschutzüberwachung (ASÜ) ist eine eigene App auf eigenem Port (Standard 8082,
`ASUE_PORT`) und spricht dieselbe Adresse unter `/api` an. Alles landet in **derselben `data.json`** wie die Einsatzverwaltung.

| Schlüssel in `data.json` | Inhalt | für die Einsatzverwaltung sichtbar |
|---|---|---|
| `opta3.asueStatus` | letzte Truppstatus-Meldung je Feuerwehr + Einsatz (nur Zahlen, mit `evId` = Einsatz der Einsatzverwaltung) | ja, live per WebSocket |
| `opta3.log` | Einsatztagebuch, Einträge „ASÜ“ bei jeder Änderung der Zahlen | ja |
| `asue.einsaetze` | vollständige ASÜ-Einsätze (Trupps, Namen, Geräte, Zeiten, Drücke) | nur lesend über `GET /api/asue/einsaetze` (Karte „Atemschutz“, ab 3.9) – nie per WebSocket verteilt, von der Einsatzverwaltung nicht änderbar |

## Anmeldung

- Ohne Umgebungsvariable `ASUE_KEY`: keine Anmeldung (nur im eigenen Netz betreiben).
- Mit `ASUE_KEY`: jede Anfrage außer `/health` braucht `Authorization: Bearer <ASUE_KEY>`, sonst `401`.
  In der ASÜ unter Einsatzdaten → Mehrere Geräte → „Wehr-Schlüssel“ eintragen.
- CORS nur, wenn `ASUE_ORIGIN` gesetzt ist (z. B. ASÜ weiterhin auch von GitHub).

## Endpunkte

| Methode | Pfad | Zweck |
|---|---|---|
| GET | `/api/health` | Lebenszeichen; `{"ok":true,"name":"Einsatzverwaltung","schluessel":false}` – daran erkennt die ASÜ, dass sie auf dem Pi läuft |
| POST | `/api/status` | Truppstatus (Schema `asue.status/1`, siehe DATENMODELL.md) → `204` |
| GET | `/api/status` | alle gespeicherten Meldungen |
| GET | `/api/ev/einsaetze` | laufende Einsätze der Einsatzverwaltung (Nummer, Stichwort, Meldebild, Adresse, Alarmzeit, Einsatzleiter) – daraus übernimmt die ASÜ den Einsatz |
| GET | `/api/einsaetze/{code}?since={rev}` | Änderungen eines geteilten Einsatzes seit Revision `rev` |
| PUT | `/api/einsaetze/{code}/einsatz` | Einsatzdaten speichern |
| PUT | `/api/einsaetze/{code}/trupps/{id}` | einen Trupp speichern (vollständiges Objekt, Grabstein `{"_gone":…}` beim Löschen) |
| POST | `/api/einsaetze/{code}/fuehrung` | `{"an":"<geraet>"}` Übergabe durch das führende Gerät · `{"uebernahme":true,"benutzer":"admin","passwort":"…"}` Übernahme mit Admin-Zugang aus `asue/benutzer.js` |

### Führendes Gerät (ab 3.4)

Jede Anfrage trägt `X-ASUE-Geraet` (Geräte-ID, `A-Za-z0-9_-`, 6–40 Zeichen) und `X-ASUE-Name`
(URL-kodiert, max. 60 Zeichen).

- Das erste Gerät, das einen Einsatz schreibt, wird führend (`fuehrung = {id, name, seit, wie}`).
- `PUT …/einsatz` nur vom führenden Gerät, sonst `403 {"error":"nur_fuehrung","fuehrung":…}`.
- `PUT …/trupps/{id}` von anderen Geräten nur mit `"vorschlag":true` und nur für neue IDs oder
  den eigenen, noch offenen Vorschlag. Der Server speichert dazu `vorschlag = {von, name, t}`.
  Das führende Gerät bestätigt, indem es den Trupp ohne `vorschlag` speichert, und lehnt ab
  mit `{"_gone":…}`. Eigene Vorschläge zieht der Vorschlagende mit `{"_gone":…,"vorschlag":true}` zurück.
- `GET …/einsaetze/{code}` liefert zusätzlich `fuehrung` und `geraete` (in den letzten 3 Minuten aktiv).
- Übernahme: 5 Fehlversuche je Gerät bzw. 30 insgesamt in 10 Minuten, danach `429`.
  Übergabe und Übernahme werden im Protokoll der Einsatzverwaltung vermerkt.
- `POST /api/status`: im gemeinsamen Einsatz meldet nur das führende Gerät, als Einsatz-ID
  `sync-<code>`; `einsatz.ersetzt` entfernt die vorige Meldung desselben Geräts.

`{code}`: 4–12 Zeichen `A-Z0-9`. `{id}`: `A-Za-z0-9_-`. Unbekannter Code → `{"rev":0,"einsatz":null,"trupps":[]}`.
Die Konfliktlösung (je Feld gewinnt der neuere Zeitstempel in `_m`) macht die App; der Server
speichert nur, zählt `rev` hoch und liefert seit `since` Geändertes.

## Automatisch auf dem Pi

- Die ASÜ trägt nichts ein: Status-Adresse und Abgleich-Server sind automatisch der Pi.
- Sobald der erste Trupp angelegt ist, wird der Einsatz mit einem Einsatz-Code geteilt und auf dem Pi gesichert
  („Trennen“ unter Einsatzdaten schaltet das für diesen Einsatz ab).
- Aufräumen: ASÜ-Einsätze nach `ASUE_AUFBEWAHRUNG_TAGE` (Standard 90) ohne Änderung, Statusmeldungen nach 24 h.

## Umgebungsvariablen

| Variable | Standard | Bedeutung |
|---|---|---|
| `PORT` | 8080 | App Einsatzverwaltung |
| `ASUE_PORT` | PORT+2 | App Atemschutzüberwachung + ihre Schnittstelle |
| `MELDE_PORT` | PORT+1 | isolierter Meldeserver für Fahrzeugbesatzungen |
| `ASUE_KEY` | – | Wehr-Schlüssel für die ASÜ-Schnittstelle |
| `ASUE_ORIGIN` | – | erlaubte fremde Herkunft(en) für CORS, z. B. `https://NAME.github.io` (mehrere mit Komma) |
| `ASUE_AUFBEWAHRUNG_TAGE` | 90 | Aufbewahrung der ASÜ-Einsätze auf dem Pi |
| `TLS_CERT`, `TLS_KEY` | – | Zertifikat + Schlüssel → Server läuft mit HTTPS |
| `BACKUP_RETENTION_DAYS` | 30 | tägliche Sicherungen von `data.json` |
| `OBJEKT_MAX_MB` | 40 | höchste Dateigröße für Objektpläne |
| `OVERPASS_URL` | overpass-api.de | Quelle der Wasserentnahmestellen (OpenStreetMap) |
| `WASSER_RADIUS_KM` | 50 | Umkreis um den Heimatort für Wasserentnahmestellen |
| `GEOCODE_ORT` | 31855 Aerzen | Adresssuche ohne PLZ/Komma zuerst in diesem Ort |
| `W3W_KEY` | – | what3words-API-Schlüssel; aktiviert `///wort.wort.wort` in allen Adresssuchen und die Anzeige im Koordinatenfenster |

## Einsatzverwaltung (Port 8080)

Seit Version 3 führt der Server alle Änderungen an Einsätzen selbst aus (Datei `einsatz.js`). Die Geräte schicken dazu per WebSocket `{"type":"op","id":1,"op":"…","args":{…},"user":"…"}` und bekommen `{"type":"opResult","id":1,"ok":true,"data":…}` zurück; alle Geräte erhalten die geänderten Schlüssel als `update` bzw. `delete`.

| Aktion | Zweck |
|---|---|
| `einsatz.neu`, `einsatz.aendern`, `einsatz.ende` | Einsatz eröffnen, ändern, beenden (archivieren); u. a. `gsl`, `bereitstellung`, `brLat`, `brLon`, `objektId` |
| `fz.status` | FMS-Status 1, 2, A, 3, 4, 6 setzen (ordnet bei A/3/4 dem Einsatz zu) |
| `fz.ruf` | Sprechwunsch (5) / Notruf (0) melden oder quittieren |
| `fz.zuordnen`, `fz.abschnitt` | Fahrzeug einem Einsatz bzw. Abschnitt zuordnen; `fz.abschnitt` nimmt auch `auftrag` (Freitext) |
| `staerke` | Stärke F/M + AGT je Fahrzeug (ab 3.52 ohne Unterführer; `uf` wird zur Mannschaft gezählt und als 0 gespeichert) |
| `abschnitt`, `anforderung`, `lage` | Abschnitte, Kräfteanforderungen, Lagemeldungen (`von` = Melder, `an` = Empfänger) |
| `abschnitt` (Zusatz) | `auftrag` (Abschnitts-Auftrag), `nurAuftrag:true` ändert nur den Auftrag; `nurFlaeche:true` + `flaeche:[[lat,lon],…]` (3–400 Punkte, `null` entfernt) setzt den Bereich auf der Lagekarte; `farbe` wird beim Anlegen aus einer Palette vergeben |
| `vu` | Unfallfahrzeug: ohne `id` anlegen (Felder `art, kennzeichen, hersteller, modell, farbe, antrieb, lage, personen, eingeklemmt, rettung, notiz`), mit `id` Felder ändern, `massnahme` + `an` (Schlüssel: sichern, zuendung, rettungskarte, batterie, airbag, zugang, glas, oeffnung, befreit, betriebsstoffe) oder `loeschen`. Alles mit Tagebucheintrag; gespeichert in `einsatz.vu[]` |
| `check` | Checkliste: `liste` + `punkt` + `an` hakt ab (in `einsatz.checks[liste][punkt] = {t, user}`, Tagebucheintrag); `liste` + `hinzufuegen: true/false` nimmt eine weitere Liste in `einsatz.checkListen` |
| `uhr` | Einsatz-Uhren: `art:'aggregat'` mit `aktion` `neu` (+`name`), `nachgetankt`, `spaeter` (+`spaeter` Minuten), `aus`, `an`, `name`; `min` = Intervall für den Tagebuchtext; `std:true` legt beim ersten Eingriff das Vorgabe-Aggregat (ab Alarmzeit) fest an. `art:'lage', aktion:'spaeter'` verschiebt die Lage-Erinnerung. Gespeichert in `einsatz.uhren = {aggregate:[{id,name,basis,spaeter?,aus?}], lage:{spaeter,gesetzt}}`; fällig = basis + Intervall (Intervalle in `opta3.settings.uhren = {lage, aggregat, auto}`, Vorgabe 30/90/true) |
| `nachricht` | Nachricht an die Fahrzeug-App: `vids[]`, `text` (≤ 500), `einsatzId`, optional `bilder[]` (bis 3 Bild-IDs aus `POST /api/nachricht/bild`; dann darf `text` leer sein). Speichert in `opta3.nachrichten[vid]` (24 h, max. 20) und vermerkt sie als Ausgang im Tagebuch |
| `nachricht.quittung` | `vid`, `id`: „verstanden“ (von der Fahrzeug-App), Eingang im Tagebuch |
| `tb.neu` | Tagebucheintrag (Nummer und Zeit vergibt der Server; Korrektur über `korrigiert`; Nachtrag über `zeit` = früherer Zeitpunkt in ms → Eintrag erhält `nachtrag:true` und `erfasst`) |
| `archiv.loeschen`, `log.neu` | Archiveintrag löschen, Systemprotokoll |
| `fz.pos` | Standort eines Fahrzeugs (sonst über die Fahrzeug-App) |
| `fz.entlassen` | Fahrzeug aus dem Einsatz bzw. der Großschadenslage entlassen |
| `auftrag.neu`, `auftrag.aendern` | Auftrag einer Großschadenslage anlegen/ändern (`kat`, `prio` 1–3 oder null, `priolage`, `adresse`, `lat`, `lon`, `meldender`, `telefon`, `text`, `objektId`) |
| `auftrag.status` | `offen`, `disponiert`, `inArbeit`, `erledigt`, `storniert` (+ `ergebnis`); bei erledigt/storniert wird das Auftragstagebuch ins Einsatztagebuch übernommen |
| `auftrag.fz` | Fahrzeug disponieren (`vid`) bzw. abziehen (`entfernen:true`); alarmiert ein Fahrzeug außerhalb der Lage |
| `auftrag.tb` | Eintrag im Auftragstagebuch |
| `objekt.speichern`, `objekt.loeschen`, `objekt.dateiLoeschen` | Objekte mit Plänen pflegen |

Diese Schlüssel können Geräte nicht direkt überschreiben: `opta3.einsaetze`, `opta3.tb.*`, `opta3.auftraege.*`, `opta3.objekte`, `opta3.status`, `opta3.statusZeit`, `opta3.fmsRuf`, `opta3.personnel`, `opta3.einsatzZaehler`, `opta3.log`, `opta3.asueStatus`, `opta3.pos`. Fahrspuren (`spur.<id>`) sind privat und stehen nur im Archiv.

| Methode | Pfad | Zweck |
|---|---|---|
| GET | `/api/archiv` | Liste der archivierten Einsätze |
| GET | `/api/archiv/{id}` | vollständiger Archiveintrag (Einsatz, Tagebuch, Fahrzeuge, ASÜ, Karte) |
| GET | `/api/geocode?q=` | Adresssuche (Nominatim, max. 1 Anfrage/s, zwischengespeichert) |
| GET | `/api/wasser` | Wasserentnahmestellen aus OpenStreetMap (`pts`: [Breite, Länge, Typ H/B/S/T/Q, Angaben]), gespeichert in `wasser.json` |
| POST | `/api/wasser/aktualisieren` | Wasserentnahmestellen neu aus OpenStreetMap laden (bis zu 3 min) |
| GET | `/api/reverse?lat=&lon=` | Adresse zu einer Koordinate (für Aufträge, die auf der Karte angelegt werden) |
| GET | `/tiles/{z}/{x}/{y}.png` | OpenStreetMap-Kachel (Zoom 0–19), einmal geladen und im Ordner `tiles/` gespeichert; höchstens 4 gleichzeitige Abrufe beim Kartenserver |
| POST | `/api/objekte/{id}/datei?name=plan.pdf` | Datei zu einem Objekt hochladen (Rohdaten im Body; pdf, png, jpg, gif, webp, txt, doc(x), xls(x), dwg, dxf, zip) |
| GET | `/api/objekte/{id}/datei/{dateiId}` | Datei abrufen (PDF und Bilder im Browser, sonst als Download) |

Weitere Umgebungsvariablen: `OSM_TILE_URL`, `NOMINATIM_URL`, `OSM_USER_AGENT` (für einen eigenen Kartenserver).

### what3words (ab 3.5, nur mit `W3W_KEY`)

| Methode | Pfad | Zweck |
|---|---|---|
| GET | `/api/geocode?q=///wort.wort.wort` | erkennt drei Wörter mit Punkten und rechnet sie über what3words in eine Koordinate um; bei Tippfehlern bis zu 3 Vorschläge („Meinten Sie …“) |
| GET | `/api/w3w?lat=&lon=` | Koordinate → `{worte, ort}` (deutsche Wörter) |
| GET | `/api/w3w/status` | `{aktiv:true/false}` |
| GET | `/api/asue/einsaetze` | (Port 8080) geteilte ASÜ-Einsätze der letzten 24 h mit Einsatzdaten, Trupps, führendem Gerät und Zahl der verbundenen Geräte – für die Karte „Atemschutz“ |

Der Schlüssel bleibt auf dem Pi; Ergebnisse werden im Speicher zwischengespeichert.

## Meldeserver (Port 8081) – Fahrzeug-App

| Methode | Pfad | Zweck |
|---|---|---|
| GET | `/melden/{token}` | Fahrzeug-App (PWA, eigenes Manifest je Fahrzeug unter `/melden/{token}/manifest.webmanifest`) |
| GET | `/api/state/{token}` | Funkrufname, Typ, FMS-Status, Sprechwunsch, Einsatznummer/Stichwort, Stärke, Zeit der letzten Position |
| POST | `/api/status/{token}` | `{"status":"1"|"2"|"3"|"4"|"6"}` |
| POST | `/api/ruf/{token}` | Sprechwunsch (5) |
| POST | `/api/personnel/{token}` | `{"f":0,"uf":1,"m":7,"agt":4}` |
| POST | `/api/pos/{token}` | `{"lat":52.04,"lon":9.26,"acc":12,"speed":3.2,"heading":180,"t":1790000000000}` – höchstens alle 15 s |

`{token}`: 40 Hex-Zeichen je Fahrzeug (Einsatzverwaltung → Fahrzeug-App-Link). Seit Version 3.6 gibt es keinen Lagekarten-Link (KML/GeoJSON) mehr.

**Zugänge (ab 3.28):** Die Schlüssel erzeugt und speichert nur der Server (`auth.meldeTokens`, privat; bis 3.27 lag `opta3.meldeTokens` im öffentlichen Datenstand und wird beim Start übernommen und gelöscht). Öffentlich verteilt wird nur `opta3.meldeZugang` = `{ fahrzeugId: { seit, erneuertT, erneuertVon, gesperrt, gesperrtT, gesperrtVon, grund } }` (Server-Schlüssel, von Geräten nicht setzbar). Antworten des Meldeservers: ersetzter/unbekannter Link → `404 {"error":"not_found"}`, gesperrtes Fahrzeug → `403 {"error":"gesperrt"}` (für alle Pfade inkl. Manifest). Zugriffe mit ersetztem oder gesperrtem Link werden gezählt (`auth.meldeAktiv`) und einmal je Stunde ins Protokoll geschrieben.

Einsatzverwaltung (Port 8080, angemeldet):

| Methode | Pfad | Zweck |
|---|---|---|
| POST | `/api/melde/zugang` | `{"vid", "aktion", "grund"}` – `holen` (Link liefern, ggf. anlegen; gesperrt → `423`), `neu` (neuer Schlüssel, alter sofort ungültig), `sperren` – Einsatzleiter/Admin; `entsperren`, `alle_neu` (ohne `vid`) – nur Admin. Antwort `{ok, token?, zugang, aktiv?}` bzw. `{ok, anzahl}` |
| GET | `/api/melde/zugaenge` | Übersicht je Fahrzeug: `{vid, funkrufname, link, seit, gesperrt…, zuletzt, versuch:{t,n,art}}` – Einsatzleiter/Admin |

HTTPS für Port 8081: `MELDE_TLS_CERT` / `MELDE_TLS_KEY` (sonst `TLS_CERT` / `TLS_KEY`) oder ein vorgeschalteter Dienst wie Tailscale Funnel.

## Warnungen (ab 3.14)

- `GET /api/warnungen` → `{ ok, stand, ars, liste:[{ id, quelle, schwere (Minor|Moderate|Severe|Extreme), titel, ereignis, text, handlung, beginn, ende, gesendet }], fehler? }`; `?neu=1` ruft sofort ab.
- Quelle: NINA-Schnittstelle des BBK (`NINA_URL`, Vorgabe `https://warnung.bund.de/api31`), Dashboard für `WARN_ARS` (Vorgabe `032520000000`, Landkreis Hameln-Pyrmont; `aus` schaltet ab), Details je Warnung. Abruf alle 5 Minuten; Aufhebungen (`msgType: Cancel`) und abgelaufene Warnungen werden ausgelassen.
- Der Stand wird als Schlüssel `opta3.warnungen` an alle Geräte verteilt, aber nicht in data.json gespeichert. Neue Warnungen werden je laufendem Einsatz einmal im Tagebuch vermerkt (`einsatz.warnungen` = gemeldete IDs).
- Radar (`dwd:Niederschlagsradar`, mit `TIME` für den Verlauf) und Warnkarte (`dwd:Warnungen_Gemeinden_vereinigt`) lädt der Browser direkt als WMS (EPSG:3857) von `https://maps.dwd.de/geoserver/dwd/wms`.
- Archiv: `asueDetail` = vollständige ASÜ-Daten (Einsatz, Trupps) der zugeordneten Überwachungen für den Einsatzbericht.

## Ab 3.15

- Fahrzeug-App (Port 8081): `GET /api/state/:token` enthält `nachrichten` (letzte 12 h, max. 10: `{id, t, text, von, quittiert}`); `POST /api/quittung/:token` mit `{id}` quittiert.
- Datensicherung (Port 8080): `GET /api/sicherung` (Stand: `lokal`, `ziele[{pfad, ok, eingehaengt, zuletzt, frei, fehler}]`), `POST /api/sicherung/jetzt`, `GET /api/sicherung/datei` (vollständiger Stand als Download). Ziele: `BACKUP_ZIEL` (Vorgabe `/mnt/fwbackup`, mehrere mit Leerzeichen) und unter `/media` eingehängte Datenträger; geschrieben wird nur auf echte Einhängepunkte. Stand als Schlüssel `opta3.sicherung` (nicht in data.json).

## Ab 3.16

- Bilder zu Nachrichten: `POST /api/nachricht/bild` (Body = Bild, `Content-Type` image/jpeg|png|webp, ≤ 8 MB) → `{id}`; `GET /api/nachricht/bild/:id` (Port 8080). Fahrzeug-App: `GET /api/bild/:token/:id` (Port 8081, nur Bilder aus Nachrichten an dieses Fahrzeug). Dateien in `nachrichten/`, nach 7 Tagen gelöscht.
- Übungsgenerator (`/uebung/`, nur Port 8080): `GET /api/uebung/status` (laufende Einsätze, Fahrzeuge, Heimatort, Kategorien), `POST /api/uebung/senden` `{art:'einsatz'|'auftrag', daten, einsatzId?, szenario, leitung}` – Einsatz mit „ÜBUNG:“ im Meldebild, Tagebuchvermerk, optional `daten.alarmieren[]` (Funkrufnamen → Status A); Auftrag setzt den Ziel-Einsatz bei Bedarf auf Großschadenslage. Szenario-Ablage: `GET/POST /api/uebung/szenarien`, `DELETE /api/uebung/szenarien/:id` (privater Schlüssel `uebung.szenarien`).

## Ab 3.17

- **Anmeldung:** `GET /api/auth/benutzer` (Namen/Rollen für die Anmeldeseite), `POST /api/auth/login` `{userId, pin}` → Cookie `ev_sitzung` (HttpOnly, SameSite=Strict, 60 Tage gleitend, `SITZUNG_TAGE`), `GET /api/auth/ich`, `POST /api/auth/logout`. Ohne gültige Sitzung: alle anderen `/api/*` → 401, WebSocket wird mit Code 4001 geschlossen. 8 Fehlversuche je Gerät+Benutzer bzw. 40 insgesamt in 10 Minuten → 429.
- Benutzer liegen privat in `auth.benutzer` (PBKDF2-SHA256, 120 000 Runden, Salz); alte Browser-Prüfsummen werden beim ersten Login umgestellt. `opta3.users` enthält nur noch `{id, username, role}` (Serverschlüssel). Sitzungen in `auth.sitzungen` (nur SHA-256 des Tokens).
- **Rollen auf dem Server:** Betrachter – keine Aktionen, kein `set`. Einsatzleitung – alle Einsatzaktionen; `set` außer `opta3.settings`/`opta3.vehicles`. Admin – zusätzlich `archiv.loeschen`, `objekt.*`, Benutzer (`benutzer.speichern {id?, username, role, pin?}`, `benutzer.loeschen`, `sitzungen.liste`, `sitzung.beenden`) sowie REST: Sicherung, Wasser aktualisieren, Objektdateien, Atemschutz-Nachweis. Nachrichtenbilder und Übungsgenerator: Einsatzleitung. Der Benutzername für Tagebuch/Protokoll kommt aus der Sitzung.
- **Zustand des Pi:** `GET /api/system` (Temperatur, vcgencmd get_throttled, Speicher, Last, Laufzeit, Ordnergrößen, Verlauf 24 h, Warnungen); Kurzfassung als `opta3.system` (nicht gespeichert).
- **Nachbereitung:** Aktion `nachbereitung` `{einsatzId (laufend oder Archiv), vid | '_asue', aktion: neu|loeschen|erledigt|status|fertig|asue, feld: material|defekte|atemschutz, item, itemId, an, bereit, bemerkung}` → `einsatz.nachbereitung[vid]`; im Archiv mit Tagebuchvermerk „(nach Einsatzende)“. `GET /api/nachbereitung/offen?tage=` für die Gerätewart-Liste; `opta3.nbStand` signalisiert Änderungen.
- **Atemschutz-Nachweis:** `GET /api/atemschutz/nachweis` (Admin) – Einträge je Truppmitglied mit Beginn (aus `asue.einsaetze` und Archiv-`asueDetail`, dauerhaft in `asue.nachweis`); `DELETE /api/atemschutz/nachweis/:id` blendet aus.
- **Übungsauswertung:** `GET /api/uebung/auswertung?ids=` – je Einsatz (laufend oder Archiv) Fahrzeugzeiten (A/S3/S4), Lagemeldungen und Aufträge mit Zeiten.

## Ab 5.3

- ASÜ-API (hinter dem Wehr-Schlüssel, jede Feuerwehr, ohne Gerätewart-Anmeldung): `GET /api/pflege/offen` → benutzte Atemschutzgeräte (offen / bei der FTZ, 180 Tage, ohne Personennamen); `POST /api/pflege/aktion {ids[], aktion ftz|zurueck|offen, ersatz}` – „von“ = ASÜ-Feuerwehr und Gerätename. ASÜ-Reiter „Tausch / Prüfung“.
- Wehr-Schlüssel-Prüfung gilt nicht mehr für `/agw/*` (außer `/agw/tauglich`) und `/gdb/*` – diese haben die eigene Anmeldung der Gerätewarte (`X-AGW-Token`). Vorher scheiterten die Datenbanken, sobald ein Wehr-Schlüssel gesetzt war.

## Ab 5.1

- `AGW_PW_TAGE = 120` (Kennwort der Gerätewarte alle 4 Monate). `agwErinnern` schickt 7 Tage vor Ablauf eine Mail an den Zugang (Schlüssel `<konto>|pw|<pwT>`).

## Ab 5.0

- ASÜ-Port: `GET /geraete` und `GET /atemschutz` liefern `asue/index.html` mit `window.DB_SEITE` (nur dieser Bereich, Anmeldung direkt in der Datenbank).
- `GET /api/agw/nachweis` (Bereich atemschutz) → `{eintraege[]}` aus `asue.nachweis`, je Eintrag `wehr` (Person bzw. ASÜ-Feuerwehr), gefiltert nach den Ortswehren des Zugangs; `POST /api/agw/nachweis/ausblenden {id}`.
- `POST /api/gdb/fzstatus {vid, aus, grund, bis}` → `monitor.ausserDienst` (quelle gdb); `aus:false` entfernt alle Einträge des Fahrzeugs und erledigt offene Fahrzeug-Meldungen. `/gdb/daten` liefert `fzAusser`, `status6`, `fahrzeuge[].fz`.
- Einmalige Übernahme `asue.gdbMig50`: `monitor.fristen` → Geräte (kat Prüffrist), `monitor.ausserDienst` art geraet → Geräte (Zustand ausser); `monitor.fristen` danach leer. Die Admin-Abschnitte in der Monitor-Verwaltung entfallen (APIs bleiben vorerst).

## Ab 4.9

- Meldungen (`asue.gdbMeldungen[]`) haben `typ` schaden|verbrauch|check|beladung (+ `posten`, `offen`, `maengel`), `nachMail` (gesammelte Mail nach dem Einsatz), `erledigt.text` = Rückmeldung (in `state.schaden.meine[].antwort`).
- Meldeserver: `POST /api/verbrauch/:token {posten[{name,menge}], text}`, `POST /api/fzcheck/:token {punkte[{name,ok}], text}`, `POST /api/beladung/:token {geraete[{id, st ok|fehlt|defekt}], wer, text}` (fehlt → Zustand ausser, defekt → defekt).
- `state.schaden` zusätzlich `schnell[]`, `verbrauch[]`, `check[]`, `checkFaellig {t, einsatz}`, `beladung {letzte}`.
- Private Keys: `asue.gdbListen {[wehr]: {verbrauch[], check[]}}`, `asue.fzCheck {[vid]: {letzte, faellig}}`, `asue.gdbFzPruef {[vid]: {t, von, n, maengel}}`. Fahrzeug-Check mit offenen Punkten → `monitor.ausserDienst` (quelle check).
- Überwachung (jede Minute): Meldungen aus einem Einsatz, deren Fahrzeug den Einsatz verlassen hat (≥ 2 min alt) → eine Mail je Einsatz und Ortswehr; Fahrzeug verlässt Einsatz → Check fällig.
- ASÜ-API: `/gdb/daten` zusätzlich `listen`, `listenStd`, `beladung`, `alleWehren`; `POST /api/gdb/listen {wehr, verbrauch[], check[]}`; `/gdb/aktion` neu `ausleihen {an, bis}`, `rueckgabe`; Gerät `ausgeliehen {an, seit, bis, von}` → am Fahrzeug nicht verfügbar.

## Ab 4.8

- Fahrzeug-App: `state.schaden {geraete[{id,t,st}], meine[]}`; `POST /api/schaden/:token` (Meldeserver) `{geraetId | ziel:'fahrzeug' | was, text, ausserBetrieb, bilder[{typ,daten base64}] ≤3}` → im Einsatz `tb.neu` (Eingang vom Fahrzeug), sonst Mail an Zugänge mit Bereich geraete der Ortswehr (Ersatz: System-Empfänger). Fotos in `schadenbilder/`.
- Privat `asue.gdbMeldungen[{id,t,vid,fz,wehr,geraetId,was,text,ausserBetrieb,fzSelbst,bilder,einsatzId,einsatzNr,weg,erledigt}]` (max. 500). Gerät aus der DB: Verlauf „mangel“, bei außer Betrieb Zustand defekt; Fahrzeug selbst außer Betrieb → `monitor.ausserDienst` (quelle schaden).
- ASÜ-API: `/gdb/daten` liefert `meldungen`; `POST /api/gdb/meldung {id, erledigt}`; `GET /api/gdb/bild/:name` (mit Token).

## Ab 4.7

- Zugänge (`asue.agwKonten[]`): `bereiche` ['atemschutz','geraete'] (fehlend = Atemschutz). Atemschutz-Endpunkte prüfen den Bereich (403 `bereich`); Login/Daten liefern `konto.bereiche`.
- Gerätedatenbank `asue.gdb` {[id]: {id, inv, bez, anzeige, kat, menge, hersteller, typ, serien, wehr, vid, status bereit|defekt|pruefung|ausser, pruefArt, pruefMonate, pruefLetzte, pruefNaechste, notiz, historie[{t, art angelegt|pruefung|mangel|reparatur|status|umsetzen|notiz, text, von, ergebnis?, datum?}]}}; `asue.gdbStand` {aktiv, t, von, importiert}.
- Ist die DB aktiv, setzt der Server `opta3.vehicles[].ausruestung` (einsatzbereite Geräte am Fahrzeug) und `ausruestungNv[{text,status,grund}]`; auch nach jedem Speichern der Fahrzeugliste per WebSocket.
- ASÜ-API (Token `X-AGW-Token`, Bereich geraete): `GET /api/gdb/daten`, `POST /api/gdb/geraet`, `POST /api/gdb/aktion` `{id|ids[], aktion pruefung|mangel|reparatur|status|umsetzen|notiz, text, datum, ergebnis ok|mangel, status, vid}`, `DELETE /api/gdb/geraet/:id`.
- Einsatzverwaltung: `GET /api/gdb` (op, Übersicht), `POST /api/gdb/import` (admin + PIN, Übernahme der Ausrüstungslisten, aktiviert die DB). `/api/agw/konten` liefert `gdb`.
- Erinnerung: eine Woche vor `pruefNaechste` an Zugänge mit Bereich geraete (Schlüssel `<konto>|<gerät>|gdb|<datum>`). Monitor: nicht einsatzbereite Geräte unter „Außer Dienst“, Prüftermine in `fristenFuer` (je Tag und Wehr). QR-Format `GDB1:<id>`.

## Ab 4.6

- Monitor: `ausser` (bool, Vorgabe an), `nacht {an, von 'HH:MM', bis 'HH:MM', uhr}`; `zustand.monitor.nacht` (nur wenn an), `zustand.ausserDienst[{art fz|geraet|atemschutz, was, typ, grund, bis, seit?, status6?}]` (max. 12).
- Privat `monitor.ausserDienst[{id, art fz|geraet, vid, was, ortswehr, grund, bis, t, von}]`; `GET/POST /api/monitor/ausser` (op; `loeschen:true` = wieder im Dienst). Abgelaufene Einträge (`bis` < heute) werden nicht angezeigt.
- `/api/monitor/liste` zusätzlich `ausser`.

## Ab 4.5

- Monitor (`monitor.liste[]`): neu `karteS1`, `termine`, `fristen` (bool, Vorgabe an), `kalTage` (3–60), `kalender` (bis 5 iCal-Adressen, webcal→https). `/api/monitor/liste` liefert je Monitor `kalStand[{url,t,fehler,n}]` und `fristen`.
- `/api/monitor/zustand/:token` zusätzlich `unterwegs[{funkrufname,typ,lat,lon,t}]` (Status 1 mit Standort aus `opta3.pos`) und `termine[{titel,ort,start,ende,ganz,quelle kalender|frist}]` (max. 12).
- Privat `monitor.fristen[{id,titel,ortswehr,datum,monate,erinnern,notiz}]`; `POST /api/monitor/fristen` (admin, `loeschen:true` zum Löschen).
- `GET /api/monitor/kalender/:token.ics` (8080 und Meldeserver 8081, ohne Anmeldung, Schlüssel in der Adresse): Prüffristen (eigene + Prüftermine der Atemschutzgeräte, −60 bis +400 Tage) als iCal mit VALARM.
- iCal-Leser/-Schreiber in `server.js` (`kalender`): Zeiten ohne Z/mit TZID als Europe/Berlin, RRULE DAILY/WEEKLY(BYDAY)/MONTHLY/YEARLY, INTERVAL, COUNT, UNTIL, EXDATE, RECURRENCE-ID; Cache 15 min, Neuabruf alle 5 min geprüft.

## Ab 4.4

- Geräte (`asue.agwGeraete`): `pruef1`, `pruef2` (YYYY-MM-DD, von Hand); `pruefBis` = nächster anstehender Termin (Altbestand: bisheriges `pruefBis` gilt als Termin). `/agw/daten` liefert je Gerät `termine[]` und das aktuelle `pruefBis`.
- `POST /api/agw/geraet` nimmt `pruef1`, `pruef2`. Neu `POST /api/agw/geraete/termine` `{wehr, arten[], pruef1, pruef2}` → `{ok, n}`.
- Erinnerung: `agwErinnern` (alle 3 h) schickt je Zugang mit Mail und Termin einmal eine Mail, sobald der Termin ≤ 7 Tage entfernt ist (Schlüssel `<konto>|<gerät>|termin|<datum>` in `asue.agwErinnert`).

## Ab 4.3

- Atemschutz-Nachweis (`asue.nachweis`) zusätzlich: `la, flasche, maske, wehr, druckA, druckE`. ASÜ-Doku (`b.doku.trupps[].mitglieder[]`) überträgt `laNr, flascheNr, maskeNr, pid, druckA, druckE`.
- Privater Key `asue.agwPflege`: `{[nachweisId]: {ftz:{t,von,ersatz}, zurueck:{t,von}, erledigt:{t,von}, bem}}`.
- ASÜ-API (Token `X-AGW-Token`): `GET /api/agw/pflege` → `{nutzungen:[{id,code,art,beginn,ende,dauer,evNummer,einsatzstelle,trupp,funktion,name,wehr,druckA,druckE,geraete:[{art,nr,id,typ,wehr}],status offen|ftz|zurueck|erledigt,pflege}], geraete:[{art,nr,id,n,ms,letzte,zustand}], tage}` (365 Tage, nach Ortswehren des Zugangs; Wehr aus Person, Gerät oder ASÜ-Feuerwehr). `POST /api/agw/pflege` `{ids[], aktion: ftz|zurueck|erledigt|offen|bem, ersatz?, bem?}`.

## Ab 4.2

- Privater Key `mail.selbsttest`: `{aktiv, uhrzeit 'HH:MM', nurFehler, letzte:{t, ergebnisse:[{bereich, stufe ok|gelb|rot|info, text}], rot, gelb}, gesendet 'YYYY-MM-DD'}`. Läuft einmal täglich ab der Uhrzeit (Europe/Berlin), nicht in Demo/Probestart; Mail an `empfaenger.system`.
- `GET /api/selbsttest` (admin): Einstellungen, letztes Ergebnis, Empfänger, `mailBereit`.
- `POST /api/selbsttest` (admin): `{einstellungen:{aktiv, uhrzeit, nurFehler}}` speichern, sonst Test ausführen; `{mail:true}` schickt das Ergebnis → Antwort mit `mail` (Versandergebnis).
- ASÜ: Reiter „Einsatzbereitschaft“ rechnet clientseitig aus `/agw/daten` (keine neue API).

## Ab 4.1

- Store-Key `opta3.standorte` (öffentlich, live): `{liste:[{id,ortswehr,name,adresse,lat,lon,ausrueckMin?,quelle,geprueft}], regeln:{ausrueckMin,kmh,umweg}}`. Startwerte für die Ortswehren Aerzen, nur wenn leer und nicht Demo.
- `GET /api/standorte/anfahrt?lat&lon&n` (op): nächste Wehren `[{ortswehr,haus,name,km,fahrMin,ausrueckMin,min,geprueft,fahrzeuge[≤6]}]`, je Ortswehr das nächste Haus; `min = ausrueck + km·umweg/kmh·60`.
- `POST /api/standorte` (admin): `{liste?, regeln?}` speichern.
- `POST /api/standorte/osm` (admin): Overpass `amenity=fire_station` im Umkreis des Heimatorts → `{treffer:[…]}` mit Zuordnung zur Ortswehr per Namensvergleich.
- Übungsleitstelle: `zustand.feuerwehrhaeuser`; Übungsfahrzeuge starten am Haus ihrer Ortswehr; Automatik-Ausrückverzögerung = Ausrückzeit × (0,8–1,2); `kmh: 0` = realistisch nach Regeln.

## Ab 4.0

- **Atemschutz-Datenbank** auf dem ASÜ-Port (`/api/agw/*`, ohne Wehr-Schlüssel, eigene Anmeldung): `POST anmelden {user, passwort}` → `{token, konto}` bzw. 409 `kennwort_neu` (Erstanmeldung oder älter als 28 Tage); `POST kennwort {user, alt, neu}` (mind. 8 Zeichen, nicht die letzten 3); `POST abmelden`; mit Kopfzeile `X-AGW-Token`: `GET daten` (Konto, Personen der eigenen Ortswehren mit Status, Geräte, Regeln), `POST person {id?, nach, vor, wehr, ruhend, csa, nachweise:{lehrgang:{d}, g26:{d,bis}, belastung:{d}, unterweisung:{d}, uebung:{d}, csa:{d}}}`, `DELETE person/:id`, `GET verlauf/:id` (Einträge des Atemschutz-Nachweises mit `pid`), `POST geraet {id?, art: geraet|flasche|la|maske, nr, typ, wehr, pruefBis}`, `DELETE geraet/:id`. Sitzungen 12 h, nur im Speicher.
- `GET /api/agw/tauglich` (ASÜ-Port, hinter dem Wehr-Schlüssel): `{t, personen:[{i, n, v, w, ok, g:[Gründe], b:[bald], h}]}`.
- Einsatzverwaltung (Admin): `GET/POST /api/agw/konten` (Zugänge der Gerätewarte, `startpasswort`, `loeschen`), `GET /api/asue/schluessel-qr` (Wehr-Schlüssel und Adressen für den QR-Code, PIN).
- Schlüssel (privat, nicht an die Geräte): `asue.agwKonten`, `asue.agwPersonen`, `asue.agwGeraete`, `asue.agwErinnert`. Atemschutz-Nachweis und `asue.doku` führen zusätzlich `pid` je Person. Tägliche Prüfung (alle 3 h) verschickt Erinnerungen 28 Tage vor Ablauf und bei Ablauf.
- QR-Formate: Person `ASUEP1:{"i","n","v","w"}`, Gerät `ASUEG1:{"i","a","n","t"}`, Wehr-Schlüssel `ASUEK1:{"k","u"}`; Trupp `ASUE1:` mit Kennung an Position 8 jedes Mitglieds. Alle Nicht-ASCII-Zeichen als `\uXXXX`.
- Neue Seite `asue/sammeln.html` (Sammel-App, ohne Netzzugriff). Die ASÜ sendet zusätzlich `X-AGW-Token`; erlaubte Methoden für fremde Herkunft jetzt mit `DELETE`.

## Ab 3.99

- Übungsleitstelle, weitere Aktionen unter `POST /api/sim/:aktion`: `alarm` zusätzlich `gsl`, `bereitstellung` (Sonderlage); `auftrag` zusätzlich `meldender`, `telefon`, `lat`, `lon`; `bereit {vid, wert:'einsatz'|'verfuegbar', ergebnis, status1}` (wie Fahrzeug-App, „verfuegbar“ erledigt den Auftrag); `auftrag-melden {vid, kat, adresse, lat, lon, text}` (Auftrag aus dem Fahrzeug, `vonVid`); `automatik {ausruecken, auftraege, staerke, minA, maxA, kmh}`; `ablauf-start {name, szId, items, ziel, sofort}` (Szenario-Einträge des Übungsgenerators, zusätzlich `autoFz` = Zahl freier Übungsfahrzeuge, `zielEinsatz` für Aufträge); `ablauf-dazu {items}` (anhängen, Minuten ab jetzt); `ablauf-pause`, `ablauf-weiter`, `ablauf-stopp`, `ablauf-jetzt {id}`.
- `GET /api/sim/zustand` zusätzlich: je Fahrzeug `bereit`, `auftrag` (mit Ort), `auto {phase, due}`; je Einsatz `auftraege` mit `prio, priolage, lat, lon, fahrzeuge, vonVid`, `auftraegeZu`, `br`; `kategorien`. `opta3.sim` enthält zusätzlich `automatik` und `ablauf {name, t0, pause, items, sent, ziel, fertig}` – der Pi spielt das Drehbuch selbst ab (Takt 2 s), die Automatik läuft im Takt 3 s.

## Ab 3.98

- Übungsleitstelle (in `server.js`, Seite `public/uebleitstelle/`): `GET /api/sim/zustand`, `POST /api/sim/:aktion` mit `start {name, vids}`, `fahrzeuge {vids}`, `alarm {einsatzId?|stichwort, meldebild, adresse, lat, lon, text, vids}`, `status {vid, st}` (5/0 = Ruf), `staerke {vid, f, m, agt}`, `pos {vid, lat, lon}`, `fahrt {vid, lat, lon, kmh, status4}`, `fahrt-stopp {vid}`, `nachricht {vid, text}`, `quittung {vid, id}`, `leitstelle {einsatzId, text}`, `auftrag {einsatzId, kat, adresse, text, priolage}`, `ende {einsaetzeBeenden}` – alle mit Rolle Einsatzleitung/Admin.
- Neue Schlüssel (nur über den Server änderbar): `opta3.sim` {aktiv, name, start}, `opta3.uebFahrzeuge` (Übungsfahrzeuge, Kennung `ueb_<vid>`, `uebung:true`, `basis`). Einsätze der Übungsleitstelle: `uebung: {sim:true, name}`.
- `einsatz.js`: Fahrzeugliste = echte + Übungsfahrzeuge; `trennungPruefen` verhindert echte Fahrzeuge in Übungseinsätzen und umgekehrt (fz.status, fz.zuordnen, fz.umsetzen, fz.nachmelden). Alarmmonitor ignoriert Übungseinsätze; Fahrzeug-App-Zugänge für `ueb_…` werden abgelehnt.

## Ab 3.97

- `public/gefahrstoffe.json` Version 3: `stoffe[]` je Zeile der ADR-Tabelle A (un, name deutsch, en, kl, code, vg, zettel, tunnel, gn, erg, p, tih?, kurz?/namen? bei gepflegten Stoffen, suche:false sonst); `tabelle1{un}`: zeilen[{en, wasser, klein{iso,tag,nacht,plus}, gross{…}|{t3:true}}], t3[{beh, iso, tag[3], nacht[3], plus[]}], t2[Gase]; `werte`, `leitfaeden` wie bisher (deutsch).
- Einstellung `kartenHome` {lat, lon, radius} für die ⌂-Taste der Lagekarte (Vorgabe 52.05477, 9.23712, 1000 m).

## Ab 3.96

- `public/gefahrstoffe.json` Version 2: `stoffe[]` (un, name, en, kl, kl_adr?, gn?, erg?, tih?, q: "k" gepflegt / "w" Liste, such[], namen[] nur bei gepflegten), `werte{un}` (CAMEO), `leitfaeden{guide}` (ERG 2024 deutsch), `tabelle1{un}` (zeilen, t3, t2), `quellen[]`, `hinweis`.
- Alarmmail-Erkennung: Stichworte nur aus gepflegten Einträgen (`suche:false` für die Liste); Warntafel-Muster nur mit Gefahrnummer 2–9/X (keine Datumsangaben wie „12/2025“).

## Ab 3.89

- Op `abschnitt` akzeptiert `parent` (ID eines nicht festen Abschnitts ohne eigenen Parent; eine Ebene). Abschnitte mit Unterabschnitten können nicht selbst Unterabschnitt werden. Beim Löschen verlieren Kinder ihren `parent`, Fahrzeuge wandern zu `parent` bzw. `ea`.
- ASÜ-API: fehlender Wehr-Schlüssel erzeugt kein Sicherheitsereignis mehr, nur ein falscher. Alte offene Ereignisse „fehlendem Wehr-Schlüssel“ werden beim Start quittiert.
- Tagebuch `von`/`an` sind Freitext; Werte `ELW`/`ÖEL` bleiben Kennungen der Führungsstelle.

## Ab 3.88
- Einstellungen `opta3.settings.fuehrungFunk {elw, oel}` (Vorgabe 14-11-10 / 14-09-10); Absender von ELW-Nachrichten an Fahrzeuge = „ÖEL 14-09-10“ bzw. „ELW 14-11-10“.
- `uhr {art:'timer', aktion:'neu'|'spaeter'|'erledigt'|'loeschen', name, min|bis, zweck, id}` → `einsatz.uhren.timer[]`.
- `nachricht.fz` merkt `auftrag` (Nr.) am Verlaufseintrag; `nachricht.bericht {an:true}` schreibt Fahrzeug-Nachrichten im Auftrag zusätzlich ins Auftragstagebuch (`auto:'nachricht'`, wird beim Abschluss nicht doppelt übernommen), Eintrag erhält `aufTb`.
- Fahrzeug-App: `GET /api/wasser/:token?b=s,w,n,e` (höchstens 600 Stellen, Ausschnitt ≤ 0,2° × 0,3°).
- Alarmmonitor: Einstellungen `ortFz`, `kraefte` (Vorgabe an); Zustand `alarm.kraefte[]` aus `einsatz.mailKraefte` (Kräfte laut Alarm-Mail).
- Mail: Anhänge aller abgelegten Eingangs-Mails werden gespeichert; die App lädt sie per `fetch` (`/api/mail/anhang/:id?dl=1`).

## Ab 3.86
- Meldeserver: Gerätekennung im Cookie `fzg` (HttpOnly, 5 Jahre). Alle `/api/<route>/<token>` der Fahrzeug-App (außer extern, monitor, crew, br, geraet-anfrage) prüfen die Bindung in `auth.fzGeraete[vid] {id, name, ua, code, erst, zuletzt, wechselBis, abgewiesen, anfrage}`; fremdes Gerät → `423 {error:'anderes_geraet', code, gebunden}`. Fahrzeug `mehrereGeraete: true` → keine Prüfung.
- `POST /api/geraet-anfrage/:token` – abgewiesenes Gerät bittet um Freigabe.
- `POST /api/melde/zugang {aktion:'geraet_frei'|'geraet_wechsel', vid}` – Bindung lösen bzw. anfragendes Gerät binden. Öffentliche Zusammenfassung ohne Kennung in `opta3.meldeZugang[vid].geraet`. `meldeTokenNeu` löst die Bindung.

## Ab 3.85
- `GET /api/state/:token`: `kollegen[]` zusätzlich `st` (FMS-Status) und – wenn `MELDE_KARTE` nicht „aus“ – `pos {lat, lon, t, acc}` (höchstens 1 Stunde alt).

## Ab 3.83
- Fahrzeug-App: `POST /api/fz-nachricht/:token {an:[vid], text, bilder}` → Aktion `nachricht.fzfz` (nur Fahrzeuge desselben Einsatzes). Postfach Empfänger: `{richtung:'aus', fzfz:true, von, vonVid}`; Absender: `{richtung:'fzaus', an, anVids}`; Einsatzverlauf `einsatz.nachrichten`: `{richtung:'fz', von, an, vids}` – keine Tagebuch-/Ungelesen-Meldung. `GET /api/state/:token` liefert `kollegen:[{vid,name,typ}]`; `gesendet` enthält auch `fzfz`-Einträge.
- ASÜ `POST /api/status`: `einsatz.evAus: true` → nicht in `opta3.asueStatus` (nicht sichtbar). Neu `doku:{evNummer, trupps:[{id,rufgruppe,st,csa,notfall,ev:{beginn:{t},ende:{t}},mitglieder:[{id,name,vorname,nachname,funktion,geraetNr}]}]}` → privat `asue.doku` (Aufbewahrung `ASUE_AUFBEWAHRUNG_TAGE`), fließt in den Atemschutz-Nachweis (`code = user-einsatzId`; gemeinsame Einsätze `sync-…` ausgenommen).

## Ab 3.82
- `fz.entfernen {einsatzId, vid, grund?, auchAktiv?}` – mit `auchAktiv: true` wird ein noch aktives Fahrzeug erst entlassen (`fz.entlassen`) und dann entfernt.

## Ab 3.80
- Einsatz: `fuehrung` ('ELW' | 'ÖEL' | null = automatisch: gsl → ÖEL) bei `einsatz.neu`/`einsatz.aendern`. Beim Schreiben von Tagebuch, Auftragstagebuch, Nachrichtenverlauf und Fahrzeug-Nachrichten wird `ELW` durch die Führungsstelle ersetzt.
- Neue Aktion `fz.entfernen {einsatzId, vid, grund?}` – nur für nicht mehr aktive Fahrzeuge; löscht `einsatz.fahrzeuge[vid]`.
- `auftrag.fz` und `fz.abschnitt {auftrag}` legen zusätzlich eine Nachricht im Postfach des Fahrzeugs ab (`auftrag: nr`).
- `fz.status` mit Status 2 löscht `opta3.fzBereit[vid]`.
- `vu`: Feld `baujahr`; `crs: {bilder[≤3], punkte{airbags,gurt,hv,trennstelle,verstaerkung,tank,batterie12}, text, land, quelle}` (leer = entfernen); Antwort enthält `berichtBilder`.
- E-Mail: Anhänge werden in `mailanhaenge/` gespeichert (je Datei ≤ 15 MB), Metadaten `{id, name, typ, groesse}` an der Mail; `GET /api/mail/anhang/:id[?dl=1]` (Einsatzleitung).
- `POST /api/auth/schliessen` (sendBeacon beim Verlassen): Sitzung endet nach 20 s, wenn keine neue Anfrage kommt und kein anderes Fenster der Sitzung verbunden ist. Einstellung `ABMELDEN_BEIM_SCHLIESSEN` (an/aus).
- Automatisch angelegte Einsätze (`einsatz.auto {quelle, t, bearbeitet?}`): ohne Bearbeitung nach `AUTO_EINSATZ_ENDE_MIN` (Vorgabe 60, 0 = aus) `einsatz.ende` durch „System (automatisch)“.

## Ab 3.79 – Kommunikation mit den Fahrzeugen
- `nachricht`: Text bis **1000** Zeichen (vorher 500). Gespeichert je Fahrzeug 24 h, höchstens 60; `GET /api/status/:token` liefert `nachrichten` (24 h, max. 40) und `gesendet` (24 h, max. 20).
- `POST /api/br/link {aktion:'senden', vids, url}`: `url` (`http(s)://…/br/<token>`, muss zum aktuellen Token passen) wird an die Nachricht angehängt.
- `POST /api/auftrag/:token` (Fahrzeug-App): `selbst` wird ignoriert – das meldende Fahrzeug wird nicht mehr automatisch zugeteilt.
- Client: `karteAusschnittBild(b, maxPx, fortschritt, {titel, markerFilter, zeichnen(g, P)})`; Förderstrecke senden = ein Bild-Upload + je Fahrzeug eine `nachricht`.

## Ab 3.78 – ASÜ über GitHub, Anmeldung über den Pi

- ASÜ-Port: `POST /api/zugang/anmelden {user, passwort}` (ohne Wehr-Schlüssel, Fehlversuche wie `/zugang/kennwort`) → `{ok, benutzer:{user, name, ort, gemeinde, rolle, wappen, salt, hash, geaendert, muss?, startBis?}, gemeinden, iterationen, schluessel: ASUE_KEY}`; 403/410/429. `GET /asue-config.js` auf dem Pi → `window.ASUE_CONFIG = {pi: [], vomPi: true}`.
- Einsatzverwaltung: `GET /api/asue/github` (Admin) → `{seite, adressen, origins, schluessel, version}`. `POST /api/asue/github/paket {seite, adressen}` (Admin + PIN) → ZIP (eigener ZIP-Schreiber, deflate): `index.html, sw.js, manifest.webmanifest, icon-*.png, wappen/*, benutzer.js` (Gemeinden, **leere** Benutzerliste), `asue-config.js` (`{pi, seite, version, stand}`), `LIESMICH.txt`. Trägt die Herkunft der Seite in `ASUE_ORIGIN` ein (App-Einstellung) und speichert `settings.asueGithub = {seite, adressen, t, von}`.
- ASÜ-App: lädt `asue-config.js` vor `benutzer.js`. Geräte-Speicher: `asue.pi` (Adressen; auch `?pi=`), `asue.key` (Wehr-Schlüssel aus der Anmeldung; `authHdr` nutzt ihn, wenn kein eigener eingetragen ist), `asue.zugaenge` (gemerkte Zugänge; beim Start in die Liste gemischt, neuerer `geaendert` gewinnt). Anmeldung: zuerst `/zugang/anmelden` an alle Kandidaten (`Promise.any`, 6 s; von https-Seiten nur https-Adressen), bei 403/410/429 Abbruch, ohne Verbindung Prüfung gegen die Liste. `?u=<benutzer>` belegt den Benutzer vor. ASÜ-Cache `asue-v40`, Einsatzverwaltung `einsatzverwaltung-v74`.

## Ab 3.77 – Startcode und eigenes Kennwort

- ASÜ-Port: `POST /api/zugang/kennwort {user, alt, neu}`, **ohne** Wehr-Schlüssel (vor der ASUE_KEY-Prüfung, wie `/health`). `alt` = Startcode oder bisheriges Kennwort (PBKDF2-Vergleich gegen `asue/benutzer.js`). 403 `passwort`, 410 `abgelaufen` (`startBis`), 400 `kurz`/`gleich`, 429 nach 5 Fehlversuchen je Benutzer bzw. 30 insgesamt in 10 min (ab 3 Fehlversuchen Sicherheitsereignis `asue`). Erfolg: neues Salt/Hash, `muss`/`startBis` entfernt, `geaendertVon: "<Name> (selbst)"`, Sicherung und Protokoll. `/api/health` liefert zusätzlich `zugang: true`.
- `POST /api/asue/zugaenge`: `aktion:'kennwort'` mit `start:true` (ohne `kennwort`) erzeugt einen Startcode (8 Zeichen, `XXXX-XXXX`, ohne verwechselbare Zeichen) und setzt `muss:true`, `startBis` (+14 Tage). `aktion:'neu'` nimmt standardmäßig einen Startcode (`start:false` für ein fertiges Kennwort). `neu[]` enthält `start`, `startBis`. `GET` liefert je Benutzer `muss`, `startBis`.
- ASÜ-App: Anmeldung mit `muss` → Formular „Eigenes Kennwort festlegen“ → `POST …/zugang/kennwort` an `PI.base`, die eigene Adresse (`./api`) und die eingetragenen Server-Adressen; danach `benutzer.js` neu laden (`cache:'no-store'`). Gespeicherte Sitzung eines Benutzers mit `muss` wird beim Start beendet. Einstellungen → Benutzer → „Eigenes Kennwort ändern“. ASÜ-Cache `asue-v39`, Einsatzverwaltung `einsatzverwaltung-v73`.

## Ab 3.76 – ASÜ-Zugänge

- `GET /api/asue/zugaenge` (Admin) → `{iterationen, gemeinden, wappen[], benutzer:[{user, name, ort, gemeinde, rolle, wappen, gesetzt, geaendert, geaendertVon}]}` (nie Salt/Hash).
- `POST /api/asue/zugaenge` (Admin + PIN): `{aktion:'kennwort', user | users[], kennwort?}` (ohne `kennwort`: Vorschlag aus 4 Teilen, `crypto.randomInt`), `{aktion:'neu', user?, name, ort, gemeinde, rolle:'wehr'|'admin', wappen, kennwort?}`, `{aktion:'aendern', user, name?, ort?, gemeinde?, wappen?}`, `{aktion:'loeschen', user}` (nicht den letzten Admin). Antwort mit der neuen Liste und bei neuen Kennwörtern einmalig `neu:[{user, name, kennwort}]`.
- Schreiben: PBKDF2-SHA256, 16-Byte-Salt, `iterationen` der Datei (150 000), 32 Byte – wie ASÜ-App und `adminPruefen`. Atomar (`.tmp` + rename), vorher Kopie nach `backups/asue-zugaenge/benutzer-<ISO>.js` (15 Stände), Protokoll Bereich „ASÜ-Zugänge“. Zusätzliche Felder je Benutzer: `geaendert`, `geaendertVon`. Cache `einsatzverwaltung-v72`.

## Ab 3.75 – Verbindungsprüfung

- `GET /api/system/verbindung` (Admin) → `{t, ok, punkte:[{id, titel, st:'ok'|'warn'|'fehler'|'aus', text, hilfe, aktion?, vorschlag?}], tsName, basis, fehlSeit, auto}`. Punkte: `programm` (lokale Anfrage an MELDE_PORT `/melden/sw.js` und ASUE_PORT `/api/health`), `internet`, `tailscale` (`tailscale status --json`: BackendState, Self.Online, KeyExpiry), `funnel` (`tailscale funnel status --json`, Web/AllowFunnel), `adresse` (`settings.meldeBase` vs. Self.DNSName), `aussen`/`aussenAsue` (öffentliches DNS 1.1.1.1/8.8.8.8/9.9.9.9, dann HTTPS an die öffentliche IP mit SNI).
- `POST /api/system/verbindung/aktion {aktion:'funnel'|'tailscale'|'programm'|'pi', asue?}` (Admin + PIN). `funnel`: `tailscale funnel reset` + `--bg <http|https+insecure>://localhost:MELDE_PORT` + `--bg --https=8443 …:ASUE_PORT` (erst ohne, dann mit `sudo -n`); `tailscale`: `sudo -n systemctl restart tailscaled`; `pi`: `sudo -n reboot`. Ohne sudo-Erlaubnis `{ok:false, rechte:true, text:<Befehl für /etc/sudoers.d/einsatzverwaltung>}`. Antwort mit `pruefung` (neue Prüfung).
- Hintergrund: alle 10 min (wenn `meldeBase` https ist). Nach 2 Fehlprüfungen Warnung `{stufe:'rot', art:'verbindung'}` in `opta3.system` (→ ⛔ Pi, Mail über `mailSystem`). `settings.verbAuto` = automatische Reparatur (höchstens 1×/h). `install.sh` legt `/etc/sudoers.d/einsatzverwaltung` an. Cache `einsatzverwaltung-v71`.

## Ab 3.74 – Pendelverkehr im Kreisverkehr

- Pendelstrecke zusätzlich `rueck: [[lat,lon],…]` (A → F) und `pendel.modus: 'gegen'|'kreis'`, `pendel.kmR` (Rückweg), `pendel.beg` (min Zeitverlust je Begegnung, nur Gegenverkehr; Begegnungen je Umlauf = 2·(n−1)). Werkzeug `pendelRueck` (zeichnet den Rückweg zu `pendelRueckId`). Einstellung `settings.pendel.beg` (Vorgabe 0). Cache `einsatzverwaltung-v70`.

## Ab 3.73 – Pendelverkehr (nur Oberfläche)

- Neue Zeichnung in `opta3.karte.<id>` / `opta3.taktik.<id>`: `{type:'line', pendelStrecke:true, pts, pendel?:{q, km, vVoll, vLeer, fuell, abgabe, ruestF, ruestA, nF, nA, ref, fz:[{vid,l}], plan:{n,l}, erg:{Qeff, deckung, takt, puffer, fehlt, fahrzeuge, uMittel, eng}, t}}`. `pts[0]` = Füllstelle.
- Einstellungen `settings.pendel` (Faustwerte, `PENDEL_STD`). Tank aus Ausrüstung `Wasser (Liter): n`, sonst `tankTypwert()`.
- Einsatzbericht: `pendelBerichtHTML()`. Cache `einsatzverwaltung-v69`. Server unverändert.

## Ab 3.72 – Atemschutz-Karte nur mit zugewiesenen Überwachungen

- Nur Oberfläche: `asueBlockHTML` filtert auf `x.evId === e.id`, `ezAtemschutz` zeigt keine nicht zugeordneten `asueDaten` mehr. Server unverändert. Cache `einsatzverwaltung-v68`.

## Ab 3.71 – Priorität nur durch die Einsatzverwaltung, Priolage

- Auftrag: `prio` ist jetzt `1|2|3|null` (`null` = noch nicht vergeben). Bei `auftrag.neu` ohne `prio` bleibt sie `null`, Standard ist nicht mehr 2. Mit `prio: null` bei `auftrag.aendern` wird sie wieder offen. Neues Feld `priolage` (bool) bei `auftrag.neu`/`auftrag.aendern`, wird im Tagebuch protokolliert („Geändert: Priolage ja“).
- `POST /api/auftrag/:token` (Fahrzeug-App) wertet `prio` nicht mehr aus. Der Tagebucheintrag nennt keine Priorität.
- Leitstellen-Mail → Auftrag: keine `prio` mehr. `priolage = true` bei `L.prio` = `1|ja|sofort|hoch|priolage` oder bei „Priolage/Prio-Lage/PRIO/Priorität 1|hoch“ in Betreff, Meldebild oder Text. Der Tagebucheintrag lautet dann „E-Mail → Auftrag n – PRIOLAGE laut Leitstelle“.
- `ev.auftragFuer` / `sonderlage.meine[]` / Archiv-Aufträge liefern zusätzlich `priolage`. Der Push-Titel beginnt bei einer Priolage mit „⚡ PRIOLAGE · “.
- Übungsplaner: Das Auftragsfeld heißt jetzt `priolage` ('1' oder ''), `prio` entfällt. Das Drehbuch der Demo übernimmt `priolage`.
- Caches: `einsatzverwaltung-v67`, Fahrzeug-App `fzapp-v17`.

## Ab 3.70 – Aufträge aus der Fahrzeug-App

- `GET /api/state/:token` zusätzlich `sonderlage` (oder `null`): `{einsatzId, nummer, stichwort, meldebild, kategorien[{name, icon}], meine[{nr, kat, adresse, prio, status, eingang, bilder, selbst}], offen}`. Sonderlage = Einsatz des Fahrzeugs mit `gsl` oder Aufträgen; ohne Einsatz die einzige laufende Sonderlage.
- `POST /api/auftrag/:token {kat, prio, adresse?, lat?, lon?, acc?, text?, telefon?, bilder[≤3 Bild-IDs aus POST /api/bild/:token], selbst?}` (8 s Sperre, Body bis 64 kB) → `auftrag.neu` mit `vonVid`, `quelle:'fahrzeug'`, `genauigkeit`, `bilder`; ohne Adresse „Standort <Funkrufname> (GPS ±n m)“. Fotos → `berichtBilderSichern` und Fotodokumentation (`foto` neu). `selbst` → `auftrag.fz` + Status `inArbeit`. Tagebuch-Eingang vom Fahrzeug. 409 ohne Sonderlage, 400 ohne Ort.
- `auftrag.neu` übernimmt `bilder`, `vonVid`, `acc`. Oberfläche: Kennzeichnung in der Auftragsliste, Fotos im Auftragsfenster, Ton/Hinweis bei neuen Fahrzeug-Aufträgen (`aufVonFzPruefen`). Service Worker `einsatzverwaltung-v66`, `fzapp-v16`.

## Ab 3.69 – Alarmmonitor

- Privat `monitor.liste` (neues Präfix `monitor.`): `[{id, token, name, ortswehr, ort:{lat, lon, name}|null, crew, ton, alarmMin, info, gesperrt, zuletzt, geraet, test}]`.
- Ohne Anmeldung, mit Schlüssel (40 hex), auf Port 8080 **und** 8081: `GET /monitor/:token` (Seite `public/monitor.html`), `GET /monitor-gemeinsam.js`, `GET /api/monitor/zustand/:token` → `{monitor, wehr, jetzt, alarm|null, laufend[], fahrzeuge[], warnungen[], version}`, `GET /api/monitor/kachel/:token/:z/:x/:y.png`. 404 bei unbekanntem/gesperrtem Schlüssel.
- `alarm`: neuester laufender Einsatz mit Fahrzeug der Ortswehr (Beginn = späteste von Alarmzeit und frühester Zuordnung eines eigenen Fahrzeugs), solange jünger als `alarmMin`; `{id, nummer, stichwort, meldebild, adresse, lat, lon, alarmzeit, objekt, fahrzeuge[{funkrufname, typ, ortswehr, status, eigen}], weitereFz, wasser[≤4, 600 m], rp, crew (nur wenn Runde der Besatzungs-App = dieser Einsatz), test, entfernung}`. Probealarm: `test` 60 s.
- Admin: `GET /api/monitor/liste` (mit `wehren`, `online`), `POST /api/monitor/speichern`, `POST /api/monitor/aktion {id, aktion: test|testende|neu|sperren|entsperren|loeschen}`; Änderungen im Systemprotokoll.
- Stichwortliste, `krlEintrag`, `stwMerkmale` und `QRGEN` liegen jetzt in `public/gemeinsam.js` (von `index.html` und Monitor geladen). Service Worker `einsatzverwaltung-v65` (ohne `/monitor`).

## Ab 3.68 – Checklisten/Auswertung nach Stichwort-Merkmalen, Mail-Stichwort

- Oberfläche: `stwMerkmale(stichwort, meldebild)` → `{roh, mb, neu, z:{art, stufe, erg, zus[]}}` (eingegebenes Stichwort zuerst zerlegt, sonst über `krlEintrag` aus alten Stichworten), `ERG_SYN`, `ERG_ART`, `ZUS_SYN`. `checkMusterTreffer(muster, M)` → `alle|zus|mb|erg|art` (ohne Zerlegung: Länge des Stichwort-Anfangs wie bisher); `checkListenFuer`: Listen mit Ergänzung unterdrücken die allgemeine Liste derselben Einsatzart, Zusätze/Meldebild immer, BSW ohne Art-Listen. `CHECK_STD` mit neuen Listen BMA, VEG, W.
- Jahresauswertung: `AW_ARTEN` mit Merkmal-Prüfung `m(z)` (gefahr, bma, veg, vu, wasser, unwetter, brand, th, bsw), Rückfall auf die bisherigen Muster; `r.stufe` (B0…H4), CSV-Spalten „Stichwort (landeseinheitlich)“, „Einsatzart“, „Stufe“.
- `mail.js`: `STICHWORT_ZEILE` mit bis zu drei Teilen nach der Stufe und Umlauten (H1 VU Y, B2 LKW AY, H0 TÜR); Betreff-Erkennung mit Ergänzungen/Zusätzen. Service Worker `einsatzverwaltung-v64`.

## Ab 3.67 – Stichwortliste KRL, Rettungspunkte in der Fahrzeug-App

- Oberfläche: `KRL_STW` (Stichwortliste KRL Weserbergland ab 31.07.2026: `{n: neues Stichwort, a: bisherige(s), k: Kräfte/Fahrzeuge/Mittel, m: Meldebilder}`), `krlEintrag(stichwort, meldebild)` (genau → bisher → schrittweise ohne Zusätze/Ergänzung), `krlBedeutung`, `stichwortBlockHTML(e)` in der Einsatzübersicht mit Soll/Ist (Stärke 6 je Staffel / 9 je Gruppe, Wasser aus „Wasser (Liter): n“, Fahrzeugtypen per Muster). `STICHWORTE` = neue Stichworte + Sicherheitswache, Übung. Keine Server-Änderung dafür.
- Meldeserver: `GET /api/rettungspunkte/:token?b=süd,west,nord,ost` (höchstens 1,5° × 2,5°, max. 500 Punkte) bzw. `?q=HM-1018` (max. 10) → `{quelle, stand, anzahl, pts, zuGross?}`; 403 bei `MELDE_KARTE=aus`. Fahrzeug-App: Ebene ✚ (`localStorage fzapp.<token>.rp`), Service Worker `fzapp-v15`; Einsatzverwaltung `einsatzverwaltung-v63`.

## Ab 3.66 – Feedback, Rettungspunkte, Begleit-App, Betrachter, Symbole

- **Feedback:** `POST /api/feedback {art: fehler|wunsch|lob|frage|sonstiges, text (3–5000), kontakt?, bilder:[{typ: image/jpeg|image/png, daten: base64, bildschirm?}] (≤ 4, je ≤ 6 MB), kontext:{ansicht, browser, bildschirm, modus}}` (jede Rolle). Meldeserver: `POST /api/feedback/:token` (Body bis 30 MB), `GET /api/feedback/:token` → `{aktiv}`. Admin: `GET /api/feedback/liste`, `POST /api/feedback/nachsenden`. Ablage privat in `feedback.liste` (neues Präfix `feedback.`, max. 300, 180 Tage), Bilder in `feedback/` (30 Tage). Versand über `mailSenden` an `FEEDBACK_AN` (Vorgabe joern-preuss@web.de), sonst Wiederholung alle 15 min. Grenze 30 je Absender und Tag, 20 s Abstand. `opta3.feedbackStand {aktiv, wartend, gesamt, versand}` (Server-Schlüssel). Einstellungen `FEEDBACK_MODUS` (an|aus), `FEEDBACK_AN`.
- **Rettungspunkte:** `GET /api/rettungspunkte` → `{stand, quelle: 'KWF'|'OpenStreetMap', datei?, mitte, radiusKm, anzahl, gesamt?, pts:[[lat, lon, nummer, beschreibung]]}`; `POST /api/rettungspunkte/datei` (Admin, Rohdaten bis 150 MB, Kopf `X-Dateiname`): GPX (`wpt`/`name`/`desc`), KML (`Placemark`/`name`/`description` bzw. `ExtendedData`) oder CSV (Spalten Breite/Länge/Nummer), Filter auf den Umkreis `WASSER_RADIUS_KM`; `POST /api/rettungspunkte/osm` (Admin): Overpass `highway=emergency_access_point` / `emergency=access_point`. Datei `rettungspunkte.json`; OSM-Stand alle 30 Tage neu, KWF-Stand nur von Hand. `opta3.rettungStand`.
- **Begleit-App (Hintergrund-Standort):** `GET|POST /api/hintergrund/:token` auf dem Meldeserver – OsmAnd-Protokoll (`lat`, `lon`, `timestamp` s/ms/ISO, `speed` in Knoten, `bearing`, `accuracy`, `valid`), Traccar-JSON (`{location:{timestamp, coords:{latitude, longitude, accuracy, speed m/s, heading}}}` bzw. Liste) und OwnTracks (`{_type:'location', lat, lon, tst, acc, vel km/h, cog}`, Antwort `[]`). Zusätzlich `POST /` mit `id`/`deviceid`/`device_id` = Link-Code. Angenommen nur im Fenster `fzHintergrundFenster(vid)`: Beginn = max(Zuordnung zum Einsatz, „Im Einsatz“ der Fahrzeug-App), sonst Statuszeit bei A/1/3/4; Ende nach `FZ_HINTERGRUND_STD` Stunden (Vorgabe 3, 0 = aus) oder bei „Verfügbar“ / Status 2/6. Nur Standorte jünger als 10 min, der neueste je Anfrage, höchstens alle 4 s → `fz.pos` mit Quelle „Begleit-App“. Außerhalb: Antwort 200, verworfen, nichts gespeichert. `GET /api/hintergrund-stand/:token` → `{stunden, fenster:{offen, seit, bis, grund}, zuletzt:{t, ok, angenommen, verworfen, grund, app}}`.
- **Betrachter:** `GET /api/archiv` und `/api/archiv/:id` nur noch Einsatzleitung/Admin (403). Oberfläche: Reiter Archiv und Verwaltung ausgeblendet, `setTab` leitet auf Einheiten um.
- **Excel (Oberfläche):** Blatt „Fahrzeuge“ mit festen Spalten `ID … AGT` und je Ausrüstung einer Spalte (`x`, bzw. Wert bei „Name: Wert“), Blatt „Hinweise“; Import erkennt jede unbekannte Spalte als Ausrüstung, liest auch die alte Spalte `Ausruestung`, übernimmt sonstige Felder bei gleicher ID. JSON-Export/-Import der Stammdaten entfallen.
- **Symbole:** `public/icons/*`, `melde/icon-*.png` (Fahrzeug-App), `asue/icon-*.png`, neu `melde/{crew,br,staerke}-{192,512}.png` (Route `/melden/(crew|br|staerke)-(192|512).png`); Manifeste mit `purpose: any`. Service Worker `einsatzverwaltung-v62`, `fzapp-v14`, `asue-v38`, `crew-v5`, `staerke-v3`.

## Ab 3.65 – Stick-Erkennung, Web-Push für die Fahrzeug-App

- **Sicherung:** `ziele[]` in `GET /api/sicherung` bzw. `opta3.sicherung` zusätzlich `{stick: 'eingehaengt'|'eingehaengt-auto'|'bereit'|'nicht-eingehaengt'|'fehlt'|'unbekannt', automount, name (Label), fstab}`; Stand zusätzlich `skript` (Pfad von `docs/stick-einrichten.sh`). Erkennung über `/proc/self/mountinfo` (echte Einhängung vs. `autofs`), `/etc/fstab` (Quelle `LABEL=`/`UUID=`/`PARTUUID=`/`/dev/…`) und `/dev/disk/by-*`. Bei `x-systemd.automount` löst der erste Zugriff (`readdir`) das Einhängen aus – nur, wenn das Gerät da ist. Stick-Wächter alle 15 s (nur lesend); neu gesteckter Stick → `sicherungLaufen('Stick eingesteckt', true)`. Sicherheits-Check und Oberfläche werten `zuletzt` statt `ok` (abgezogener Stick mit frischer Sicherung ist „aktuell“).
- `docs/stick-einrichten.sh` (root): fstab-Zeile `LABEL=FWBACKUP /mnt/fwbackup auto defaults,nofail,noatime,x-systemd.automount,x-systemd.idle-timeout=60,x-systemd.device-timeout=5s,uid=…,gid=…,umask=0077 0 0`, Sicherung von `/etc/fstab`, `daemon-reload`, Neustart der `.automount`-Unit.
- **Web-Push (Meldeserver):** `GET /api/push/schluessel/:token` → `{aktiv, key (VAPID, base64url), inhalt, geraete}`; `POST /api/push/abo/:token {abo:{endpoint, keys:{p256dh, auth}}, geraet}` (nur Endpunkte von googleapis.com, push.apple.com, push.services.mozilla.com, notify.windows.com, push.microsoft.com; höchstens 5 je Fahrzeug); `POST /api/push/ab/:token {endpoint}`; `POST /api/push/test/:token {endpoint}` (10 s Sperre). 409 bei `MELDE_PUSH=aus`.
- Abos privat in `push.abos` (`{vid: [{endpoint, keys, token, t, geraet, letzte, ok, fehler}]}`, neues Präfix `push.` in den privaten Schlüsseln). Gültig nur, solange `token` der aktuelle Link des Fahrzeugs ist und es nicht gesperrt ist; 404/410 vom Dienst entfernt das Abo. Anzahl je Fahrzeug als `opta3.pushStand` (Server-Schlüssel) und `push` in `GET /api/melde/zugaenge`.
- VAPID-Schlüssel P-256 in `push-vapid.json` (Modus 600, nicht in `data.json`/Sicherung); `sub` = https-Ursprung der externen Adresse (`settings.meldeBase`), sonst `mailto:` aus `MAIL_ABSENDER`. Verschlüsselung RFC 8291 (`aes128gcm`), Header `TTL` 3600 (Test 300), `Urgency: high`, `Topic` für Auftrag/Einsatz. Ohne Zusatzpakete (Node-`crypto`/`https`), im Code von `server.js`.
- Auslöser: Änderungen an `opta3.nachrichten`, `opta3.einsaetze`, `opta3.auftraege.*` → nach 1,2 s Abgleich je Fahrzeug mit Abo: neue, unquittierte Nachricht an das Fahrzeug; neuer aktiver Auftrag (`auftragFuer`); Wechsel des Einsatzes (Umsetzen). Nutzdaten `{art, titel, text, url:'/melden/<token>', t, tag}`. Neue Einstellung `MELDE_PUSH` (`an`|`kurz`|`aus`).
- Fahrzeug-App: Service Worker `fzapp-v13` mit `push`, `notificationclick`, `pushsubscriptionchange` (Token im Cache `fzapp-push`). Einsatzverwaltung: Service Worker `einsatzverwaltung-v61`.

## Ab 3.64 – nur Oberfläche und Demo

- Keine Server-Änderung im Echtbetrieb. Kürzelliste korrigiert; `demo/bauen.js` setzt `CREW_FZ` in der Demo auf 77-11-10. Service Worker `einsatzverwaltung-v60`.

## Ab 3.63 – nur Oberfläche

- Keine Server-Änderung. CSS: `main .filters select` ohne native Darstellung (eigener Pfeil), `#stQ` mit Höhe 44 px wie Status und Ausrüstung. Service Worker `einsatzverwaltung-v59`. Demo-Paket mit `demo/bauen.js` und `demo/startdaten.js` neu gebaut.

## Ab 3.62 – ASÜ-Truppstatus aufräumen

- Neue Op `asue.entfernen {key}` (Schlüssel `Gerät:Einsatz` in `opta3.asueStatus`, nur Einsatzleitung/Admin) mit Vermerk im Tagebuch des zugeordneten Einsatzes, sonst im Systemprotokoll.
- `asueStatusAufraeumen()` (15 s nach dem Start, dann alle 15 min) entfernt Einträge ohne Meldung seit 24 h und Einträge mit `evId` eines nicht mehr laufenden Einsatzes, mit Broadcast und Serverprotokoll.
- Hinweis-Zentrale: ASÜ-Hinweis nur bei einem Alter unter 12 h. Service Worker `einsatzverwaltung-v58`.

## Ab 3.61 – nur Oberfläche

- Keine Server-Änderung. Neuer Markertyp `dekon` in `MARKER_TYPES` (Lage und Taktik), `TB_SYMBOL_STD` und in der Vorlage `gabc`. Der Ungelesen-Punkt im Posteingang heißt jetzt `.mp-neu-punkt`, weil er mit `.mp-punkt` (Zeilen von „Mitsenden“) kollidierte. Service Worker `einsatzverwaltung-v57`.

## Ab 3.60 – nur Oberfläche

- Keine Server-Änderung. `fz.umsetzen` bietet die Oberfläche nur noch für Fahrzeuge des geöffneten Einsatzes an (`darfUmsetzen`: `fzEinsatzId(vid)===currentEid`): in der Fahrzeugansicht (`openDetailModal`, Auswahl `#dEinsatz`), im Status-Fenster und in der Mehrfachauswahl. Die Fahrzeuge-Tabelle nutzt den lokalen Schlüssel `opta3.fzNurEinsatz` (Standard an). Service Worker `einsatzverwaltung-v56`.

## Ab 3.59 – nur Oberfläche

- Keine Server-Änderung. Einsatz-Übersicht: `uhrenKachelHTML` zeigt bei `e.gsl` oder vorhandenen Aufträgen `aufUebersichtHTML` (aus `opta3.auftraege.<eid>`) neben kompakten Uhren. Ausrüstung: Freitext `stationFilters.q`, Trefferzählung je Ortswehr (`stationTrefferMarkieren`). Service Worker `einsatzverwaltung-v55`.

## Ab 3.58 – Bereit-Meldung und Aufträge

- `POST /api/bereit/:token {wert, ergebnis?}` (≤ 500 Zeichen). `fz.bereit`: hat das Fahrzeug einen aktiven, nicht abgeschlossenen Auftrag, dann `einsatz` → Auftrag `inArbeit` (aus `offen`/`disponiert`), `verfuegbar` → `aufFrei`; war es das letzte aktive Fahrzeug, Auftrag `erledigt` (+ `ergebnis`, `aufUeberfuehren`). Antwort `{vid, w, auftrag?, auftragStatus?}`.
- `GET /api/state/:token` zusätzlich `auftrag: {nr, kat, prio, status, seit, adresse?, text?, lat?, lon?}` (Ort nur bei `MELDE_KARTE = an`); `ev.auftragFuer(vid, mitOrt)`. Fahrzeug-App-Cache `fzapp-v12`.

## Ab 3.57 – Fahrzeug-App: Im Einsatz / Verfügbar statt Status

- Meldeserver: `POST /api/status/:token` und `POST /api/ruf/:token` antworten `410 {error:'abgeschaltet'}`. Neu `POST /api/bereit/:token {wert:'einsatz'|'verfuegbar'}` (1 je 3 s) → Op `fz.bereit {vid, wert}`: Serverschlüssel `opta3.fzBereit {[vid]: {w, t}}`, Tagebuch „Besatzung meldet: im Einsatz/verfügbar“ (im Einsatz) bzw. Systemprotokoll; kein FMS-Status. `GET /api/state/:token` zusätzlich `bereit`. Fahrzeug-App-Cache `fzapp-v11`, Service Worker `einsatzverwaltung-v54`.

## Ab 3.56 – Portale (FeWIS, Waldbrandeinsatzkarte)

- `fewis.json` wird zu `portale.json` (Modus 600, nicht in Sicherung): `{fewis:{url, anleitung, benutzer, passwort, stand, von}, wbek:{…}}`; eine vorhandene `fewis.json` wird übernommen und beim ersten Speichern gelöscht.
- `GET /api/portal/:id` (`fewis` | `wbek`, angemeldet) → `{id, name, url, anleitung, stand, von, zugangDa, darfZugang}`; `?zugang=1` (Einsatzleitung/Admin) zusätzlich `{benutzer, passwort}` mit Systemprotokoll (`&einst=1` aus den Einstellungen ohne Eintrag). `POST /api/portal/:id` (Admin + PIN) wie bisher `/api/fewis`. Die Endpunkte `/api/fewis` entfallen. Service Worker `einsatzverwaltung-v53`.

## Ab 3.55 – FeWIS

- Datei `fewis.json` (Modus 600, nicht in `data.json`/Sicherung): `{url, anleitung, benutzer, passwort, stand, von}`.
- `GET /api/fewis` (angemeldet) → `{url, anleitung, stand, von, zugangDa, darfZugang}`; mit `?zugang=1` und Rolle Einsatzleitung/Admin zusätzlich `{benutzer, passwort}` (Systemprotokoll „FeWIS-Zugangsdaten angezeigt“). Betrachter bekommen die Zugangsdaten nie.
- `POST /api/fewis {url?, anleitung?, benutzer?, passwort?, passwortLoeschen?}` (Admin + PIN-Bestätigung): leeres `passwort` = unverändert; `url` muss mit http(s):// beginnen. Protokolleintrag nennt nur, was geändert wurde (ohne Werte). Service Worker `einsatzverwaltung-v52`.

## Ab 3.54 – Bereitstellungsräume im Abschnittsreiter

- Keine neuen Schnittstellen. Die Oberfläche nutzt `br.speichern`, `br.aufloesen`, `br.fz {aktion:'ein'|'aus'}` und die Link-Endpunkte jetzt aus dem Reiter Abschnitte; Ziehen in einen Raum = `br.fz ein`, aus dem Raum in einen Abschnitt = `br.fz aus` (ohne `ziel`) + `fz.abschnitt`.
- `fz.nachmelden` übernimmt zusätzlich `stadt` (60) und `kennzeichen` (20) und legt das Fahrzeug vollständig an (`filterType`, `personnelDefault`, `einsatz:false`); es bleibt dauerhaft in `opta3.vehicles` (`nachgemeldet` bis zur Prüfung durch einen Admin). Service Worker `einsatzverwaltung-v51`.

## Ab 3.53 – ASÜ: einzelne Geräteträger

- ASÜ-Zustand (nur im Gerät, `localStorage`): `S.personen = [{id, nachname, vorname, name, geraetNr, laNr, flascheNr, maskeNr, druck, funktion:'Person', t}]`. Wird nicht abgeglichen und nicht an die Einsatzverwaltung gemeldet; erst der gebildete Trupp (`mitglieder[0].funktion = 'Truppführer'`, dann `Truppmann`, `Truppmann 2`) geht wie bisher in Abgleich, QR und Truppstatus. ASÜ-Cache `asue-v37`.

## Ab 3.52 – Stärke ohne Unterführer, Status 2, Umsetzen, Objekt-Ort, Mail gelesen

- Stärke: `opta3.personnel[vid] = {f, uf: 0, m, agt}`. Op `staerke` und alle Schnittstellen nehmen `uf` weiter an (ältere Apps) und zählen es zu `m`; beim Start werden gespeicherte `uf > 0` umgerechnet. Tagebuch: „Stärkemeldung F/M/G, davon n AGT“ (die Demo liest beide Formate). Melde-Apps: `fzapp-v10`, `crew-v4`, `staerke-v2`.
- `fz.status` mit `st: '2'`: löscht `opta3.personnel[vid]`; verlässt das Fahrzeug dabei den Einsatz, wird die letzte Stärke in `einsatz.fahrzeuge[vid].staerke` gesichert (Archiv nutzt sie für nicht mehr aktive Fahrzeuge). Laufen mehrere Einsätze, bleibt ein Fahrzeug mit Status 2 auch bei `gsl` nicht im Einsatz.
- Neue Op `fz.umsetzen {vid, nachEinsatzId, vonEinsatzId?}` (Einsatzleitung): alter Einsatz `aktiv:false, bis, umgesetzt:{t, nach, nummer, user}, staerke`, Bereitstellungsraum/Auftrag verlassen; neuer Einsatz `aktiv:true, abschnitt:'ea', von:{t, einsatz, nummer}`; Vermerke in beiden Tagebüchern. Fehler: `nicht_im_einsatz`, `anderer_einsatz`, `einsatz_fehlt`, `gleicher_einsatz`.
- Objekte: `ortswehr` wird in der Oberfläche als „Ort“ geführt (Auswahl aus den Ortswehren der Gemeinde, leer = aus der Adresse).
- E-Mail: Einträge in `mail.eingang` bekommen `gelesen: {t, user}`. `POST /api/mail/gelesen {ids:[…] | alle:true, an?: false}` (Einsatzleitung) → `{ok, geaendert}`, danach WebSocket `{type:'mailGelesen'}`. Beim ersten Start mit 3.52 werden vorhandene Mails als gelesen markiert (`mail.gelesenSeit`).
- Service Worker `einsatzverwaltung-v50`.

## Ab 3.51 – Wasserförderung über lange Wegstrecke

- Geländehöhen auf dem Pi: Ordner `hoehe/` mit SRTM-Kacheln `N52E009.hgt` (1201 oder 3601 Punkte je Seite, Int16 Big-Endian). Geladen von `HOEHE_KACHEL_URL` (Vorgabe `https://elevation-tiles-prod.s3.amazonaws.com/skadi`, Dateien `N52/N52E009.hgt.gz`) für `HOEHE_RADIUS_KM` (Vorgabe 25) um den Heimatort, beim ersten Start und alle 6 h erneut, solange etwas fehlt (nicht in der Demo). Eigene `.hgt`-Dateien können von Hand in den Ordner gelegt werden. Nicht in der Datensicherung (lässt sich neu laden), bleibt beim Programm-Update erhalten.
- `POST /api/hoehe {pts:[[lat,lon], …]}` (max. 2000, angemeldet) → `{h:[m …], quelle}`; Punkte außerhalb der Kacheln über `C_HOEHE_URL` vom Pi aus (je 100 Punkte, Zwischenspeicher im Speicher). Ohne Daten: 502 `{error:'offline'|'luecke', text}`.
- `GET /api/hoehe/stand` → `{kacheln:[{name, punkte, bytes, ok}], bedarf:[Namen], laeuft, stand}`; `POST /api/hoehe/laden` (Admin) → `{ok, neu, kacheln, fehlend, fehler}`. Serverschlüssel `opta3.hoeheStand {stand, kacheln, fehlend, ort, fehler?}`.
- Browser: zuerst `/api/hoehe`, sonst direkt `C_HOEHE_URL`. `GET /api/system` → `ordner.hoehe`.
- Leitung (Shape mit `art:'B'`) bekommt `foerder: {q, n (1|2), pAus, pEin, pMax, quelleArt: 'pi'|'hand', quelle, hand:[{s,h}], profil:[[s,h] … ≤300], erg:{ok, fest, rv, L, hStart, hEnde, hMin, hMax, schlaeuche, fuell, fuellMin, pEnde, warn:[{art:'wenig'|'steil'|'hoch', s, t}], verlauf:[[s,bar] … ≤160], pumpen:[{s, h, lat, lon, pEin, pAus, pAusEmpf?, fz?}], t, user}}`. Pumpensymbole der Strecke: Marker `{type:'pumpe', leitung:<Shape-id>, vp:<0 = Entnahme, 1 …>, fz?}`.
- Faustwerte in `opta3.settings.foerder {r800, pAus, pEin, pMax, fuell}` (Vorgabe 1,0 / 8 / 1,5 / 10 / 4,4).
- Service Worker `einsatzverwaltung-v49`.

## Ab 3.50 – Bereitstellungsräume mit Handy-Link

- Einsatz: `brs: [{id, name, adresse, lat, lon, t}]` (fehlt das Feld, gilt `bereitstellung/brLat/brLon` bzw. `gsl` als virtueller `br1` „BR 1“; `ev.brListe(e)`). `brs[0]` ist mit `bereitstellung/brLat/brLon` synchron (auch über `einsatz.aendern`). Fahrzeug im Raum: `e.fahrzeuge[vid].br = brId`, `brSeit`, `brLog: [{br, ein, aus}]`.
- Ops: `br.speichern {einsatzId, id?, name, adresse, lat, lon}` (Name eindeutig je Einsatz), `br.aufloesen {einsatzId, id}`, `br.fz {einsatzId, brId, vid, aktion: ein|aus, ziel?: '3'|'1'}` (ein: Status 4, ggf. in den Einsatz; Fahrzeug in anderem Einsatz → `anderer_einsatz`). `fz.status` mit 1/2/3/6 oder Entlassen löscht `br` (Tagebuch „… Bereitstellungsraum verlassen“).
- Privat: `brl.links` `{"<eid>:<brId>": {token(40 hex), eid, brId, t, fz:[vid], gesperrt}}` (Präfix `brl.` in PRIVATE_PREFIXES; Links beendeter Einsätze werden nach 1 h entfernt).
- Einsatzverwaltung (Einsatzleitung): `GET /api/br/link/:eid/:brId` → `{token, fz}` (legt den Link an), `POST /api/br/link {eid, brId, aktion: neu|senden|entziehen, vids?, vid?}` (senden: Nachricht ohne Schlüssel + Knopf in der Fahrzeug-App).
- Meldeserver: `GET /br/:token` (`melde/br.html`), `GET /api/br/state/:token` → `{br, andere, einsatz, drin:[{vid, funkrufname, typ, org, status, seit, staerke}], raus:[{vid, funkrufname, ein, aus}], imEinsatz:[…], t}`, `GET /api/br/fahrzeuge/:token?q=` (`anderer` = in anderem Einsatz), `POST /api/br/ein/:token {vid | neu:{funkrufname, typ, organisation}, staerke?}`, `POST /api/br/aus/:token {vid, ziel}`, `POST /api/br/staerke/:token {vid, f, uf, m, agt}` (nur Fahrzeuge in diesem Raum). Je Aktion 400 ms Sperre. Unbekannt → 404, Einsatz beendet / Raum aufgelöst → 410 `{text}`. Quelle in Tagebuch/Protokoll: „Bereitstellungsraum <Name>“.
- Fahrzeug-App `GET /api/state/:token` zusätzlich `br: [{name, einsatz, url:'/br/<token>'}]`; Service Worker `fzapp-v9`.

## Ab 3.49 – Fahrzeuge nachmelden

- Op `fz.nachmelden {einsatzId, vid? | funkrufname, typ, organisation, st: '4'|'3', staerke?: {f,uf,m,agt}}` → `{vid, neu, schonDa}`. Ohne `vid` wird per Funkrufname (Groß/Klein, Leerzeichen egal) gesucht, sonst neu angelegt: `{id:'vn…', funkrufname, fahrzeugtyp, ortswehr, stadt:'', …, nachgemeldet:{t, von, einsatz}}` + Tagebuch-Vermerk. Fahrzeug in anderem Einsatz → Fehler `anderer_einsatz`; ohne Name → `name_fehlt`. Rolle Einsatzleitung genügt (kein Admin). Speichern in der Fahrzeugverwaltung entfernt `nachgemeldet`.
- `POST /api/crew/staerke/:token`: Einträge ohne bekannte `vid` mit `neu: {funkrufname, typ, organisation}` (max. 30) → `fz.nachmelden`; Antwort zusätzlich `neuAngelegt:[Namen]`, `zuordnung:[{funkrufname, vid}]`.
- Sammelseite (EVST1): „weitere Einheiten“ `x` können beim Einlesen als neues Fahrzeug angelegt werden (`fz.nachmelden` mit Stärke).
- Service Worker der Besatzungs-App: `crew-v3`.

## Ab 3.48 – Stärken sammeln in der Besatzungs-App

- QR-Daten „Per Handy sammeln“ zusätzlich mit `i` (Einsatz-ID): `{v:1,k,i,n,s,m,t,f:[[vid,name,typ,f,uf,m,agt],…]}`.
- Meldeserver: `GET /crew/qrlesen.js` (QR-Leser ohne BarcodeDetector); `GET /api/crew/fahrzeuge/:token?q=` (ab 2 Zeichen) → bis 15 `[{vid, funkrufname, typ, ortswehr}]`; `POST /api/crew/staerke/:token {i, n, k, werte:[{vid,f,uf,m,agt}]}` (Body bis 64 kB, 1 je 1,5 s) → `{ok, anzahl, neuImEinsatz:[Namen], anderer:[Namen], t}`. Einsatz über `i`, sonst Nummer `n`; läuft er nicht → 404 `{error:'einsatz', text}`. Werte 0–99 (danach Grenzen von `staerke.mehrere`), unbekannte Fahrzeuge ignoriert. Fahrzeuge ohne Einsatz → `fz.status` 4 in diesem Einsatz + Tagebuch-Vermerk; Fahrzeuge in anderem Einsatz bleiben unverändert. Dann `staerke.mehrere` mit `quelle: 'Besatzungs-App, <Name>'`, Protokoll, WS-Broadcast `{type:'staerkeOnline', einsatzId, nummer, anzahl, von, neu}` (Hinweis in der Einsatzverwaltung).
- Service Worker der Besatzungs-App: `crew-v2`.

## Ab 3.47 – ELW-Besatzung („Wer kommt?“)

- Privat: `crew.personen` `{pid: {id, name, token(40 hex), gesperrt, t, zuletzt}}`, `crew.runde` `{key: eid|'bereit', seit, antworten: {pid: {antwort: komme|nicht|da, minuten, t, ankunft}}}` (neuer Einsatz des ELW → neue Runde; Antworten der letzten 15 min aus „bereit“ bleiben). Öffentlich (nur Server setzt): `opta3.besatzung` `{fz:{id, funkrufname, status, pos}, runde:{seit, einsatz}, liste:[{pid, name, antwort, minuten, t, ankunft}], ohne:[Namen], personen}`; alle 5 s bzw. bei Änderung gesendet.
- Einstellung `CREW_FZ` (Funkrufname, Vorgabe 14-11-10).
- Meldeserver: `GET /crew/:token` (App `melde/crew.html`), `/crew/:token/manifest.webmanifest`, `/crew/sw.js`; `GET /api/crew/state/:token` → `{ich, fz, runde, meine, liste, ohne, karte}`; `POST /api/crew/antwort/:token {antwort: komme|nicht|da|zurueck, minuten}` (1/s) – nur informativ, kein Tagebuch-Eintrag (ab 3.47.1); Kacheln `/api/kachel/:token/…` auch mit Besatzungs-Link. Gesperrt → 403, unbekannt → 404.
- Einsatzverwaltung: `GET /api/crew/personen` (Einsatzleitung), `GET /api/crew/link/:pid`, `POST /api/crew/person` (`{name}` neu bzw. `{id, aktion: neu|sperren|entsperren|name|loeschen, name}`), `POST /api/crew/zuruecksetzen`. Reiter `crew`.

## Ab 3.46 – Karte mit what3words in der Fahrzeug-App

- Meldeserver: `GET /api/kachel/:token/:z/:x/:y.png` (z 8–18, Kachelmitte ≤ 1° Breite / 1,5° Länge vom Heimatort, 600/min je Fahrzeug; gleicher Zwischenspeicher `tiles/` wie `/tiles`, Funktion `kachelLiefern`), `GET /api/w3w/:token?lat&lon` → `{worte, ort}`, `GET /api/w3w-suche/:token?q=` → `[{name, lat, lon, w3w}]` (30/min je Fahrzeug, Cache `geoCache`).
- `GET /api/state/:token` zusätzlich `karte: {w3w, heimat:{lat,lon}, einsatzort:{lat,lon,adresse}|null}` bzw. `null`, wenn abgeschaltet.
- Einstellung `MELDE_KARTE` (`an` | `ohne-einsatzort` | `aus`, Vorgabe `an`); bei `aus` antworten Kachel/w3w mit 403.

## Ab 3.45 – Kräfte-Kürzel mit Funkrufnamen, „Auftrag“ = Großschadenslage

- `mail.konfig.kraefte[]`: `{kuerzel, ortswehr}` **oder** `{kuerzel, fahrzeuge:[Funkrufnamen]}`; Vorgaben ergänzt um GBM-AE (14-01-1, 14-02-1, 14-02-2), WF Aerzener Maschinenfabrik (Ortswehr „Aerzener Maschinenfabrik GmbH“), Drohnenstaffel (89-59-1); einmalige Ergänzung bestehender Konfigurationen (`kraefteV2`). Kürzel-Abgleich: exakt oder als Anfang („Reh 40 DRK …“), längstes Kürzel zuerst. Ortswehr: Fahrzeuge der eigenen Gemeinde, sonst alle mit dieser Ortswehr (`istEinsatzFz`). `fahrzeugeAusMail(L)` → `{liste, fremd, kraefteOk, kraefteFremd}`.
- Leitstellen-/Testmail mit `/\bauftr(a|ä)g/i` in Betreff oder Text → Auftrag (`auftrag.neu`) in der laufenden GSL (Test: laufende Test-GSL), sonst `einsatz.neu` mit `gsl:true`; Fahrzeuge per `auftrag.fz`. Ohne „Auftrag“ → normaler Einsatz, auch während einer GSL. Erkunder während GSL → Auftrag.

## Ab 3.43 – Überwachung Mail-Alarm, Gefahrstoffe, Update per Knopfdruck

- **Mail-Überwachung:** `MAIL_WARN_MIN` (Vorgabe 5; wirksam mind. 3 × `MAIL_ABRUF_SEK`). `mail.status.postfaecher[nr].letzterOk/fehlerSeit`. Warnung im Systemzustand (`opta3.system.warnungen[]` mit `{stufe:'rot', art:'mail', postfach, seit, text, detail}`) → Leiste `#maBanner` auf allen Geräten, `mailSystem`, Protokoll; „wieder in Ordnung“ ebenso. Abruf je Postfach mit Zeitlimit 3 min.
- **Gefahrstoffe:** `public/gefahrstoffe.json` `{stoffe:[{un, name, gn, kl, namen[], nicht[]?, suche?, giftig?, hinweis?}]}`. `mail.gefahrstoffeFinden(text, tabelle)` (UN-Nummer, Warntafel `gn/un`, Stoffnamen als Wortanfang). Aktion `gefahrstoff` `{einsatzId, aktion:'neu'|'loeschen', un, name, gn, kl, quelle, fund | id}` → Einsatz-Feld `gefahrstoffe[]` `{id, un, name, gn, kl, quelle, fund, t, user}` + Tagebuch-Vermerk. Alarmmail: Funde am Einsatz, neuer Einsatz mit Koordinate zusätzlich `ringe` 50/100 m.
- **Update:** `GET /api/system/update` (Admin) `{version, status, sicherungen[], unzip, paket, laeuft}`; `POST /api/system/update/pruefen` (Admin + PIN, Rumpf = ZIP, ≤ 100 MB): `unzip -Z1` (nur `einsatzverwaltung/…`, kein `..`), entpacken nach `$TMP/ev-update`, keine Links, Pflichtdateien, gleicher Paketname, `node --check`, ggf. `npm install`, **Probestart** mit `EV_PROBESTART=1` auf Zufallsports (Health ASÜ + Startseite, 45 s) → `{id, version, aktuell, aelter, gleich, depsNeu, neuerungen[], laufendeEinsaetze, dateien}`; `POST /api/system/update/einspielen {id}` (Admin + PIN, ≤ 30 min nach Prüfung): Sicherung, `backups/programm/<version>_<datum>_<zeit>/` (+ `zuruecksetzen.sh`, letzte 3), Kopieren wie install.sh (asue/benutzer.js bleibt), `update-status.json`, `process.exit(0)` (systemd startet neu). `POST /api/system/update/zurueck {name}`. `EV_PROBESTART=1`: keine Sicherungen, kein Mailabruf, keine Systemmails.

## Ab 3.42 – Seite E-Mail, Einstellungen geordnet

- Private Schlüssel `mail.eingang` / `mail.ausgang` (je höchstens 300 Einträge, 90 Tage): Eingang `{id, t, datum, von, an[], betreff, text (≤ 20 000, bei nicht freigegebenen Absendern ≤ 3 000; Kennwort entfernt), postfach, art, ergebnis, einsatz, eid, anhaenge[{name,typ,groesse}], bilder[]}` (Duplikate werden nicht abgelegt); Ausgang `{id, t, an[], betreff, text (≤ 8 000), anhaenge[], grund, user, einsatzId, ok, fehler?, abgelehnt?}`.
- `GET /api/mail/postfach` (Einsatzleitung) → `{eingang[], ausgang[]}` neueste zuerst, ohne Volltext (`vorschau`), dazu `versand`, `empfang`, `abruf`. `GET /api/mail/postfach/ein|aus/:id` → Volltext. `POST /api/mail/abholen` (Einsatzleitung) = sofortiger Abruf.
- WebSocket `{type:'mailNeu', t}` bei jeder abgelegten eingehenden Mail (ohne Inhalt).
- `POST /api/mail/senden` nimmt zusätzlich `grund` (Protokoll/Gesendet).
- Oberfläche: Reiter `mail` (nur Einsatzleitung/Admin); Einstellungen mit Bereichen `data-sg` (allgemein, einsatz, karte, alarm, fzapp, stationen, schnitt, system), Auswahl in `localStorage opta3.stGruppe`.

## Ab 3.41 – E-Mail (Versand und Posteingang)

- **3.41.4:** Absender-Art `test`: Leitstellen-Auswertung, Einsatz mit `uebung:{test:true}`, Meldebild „TEST: …“, kein GSL-Auftrag, Nachalarmierung nur in Testeinsätzen; `mail.konfig.testFahrzeuge` (Vorgabe true); Fahrzeuge in echten Einsätzen werden übersprungen. Vorgabe-Absender `joern-preuss@web.de` (test, Kennwort `TESTALARM`), in bestehende Konfigurationen einmalig ergänzt (`testV1`). `text/plain; format=flowed` (RFC 3676, auch `delsp=yes`) wird entfaltet.
- **3.41.3:** Zweites Postfach nur für den Empfang: `MAIL2_IMAP_HOST` (Vorgabe `imap.strato.de`), `MAIL2_IMAP_PORT` (993), `MAIL2_IMAP_SICHER` (ssl), `MAIL2_BENUTZER` (`elw@feuerwehr-aerzen.de`), `MAIL2_PASSWORT` (geheim) – kein SMTP. `mailAbruf` ruft alle Postfächer mit Passwort nacheinander ab (Fehler eines Postfachs → `warnung`, das andere läuft weiter); Duplikate über Message-ID. `mail.status.postfaecher[nr]`, Protokolleinträge mit `postfach`; `GET /api/mail/konfig` liefert `postfaecher:[{nr, name, passwort, stand}]`.
- **3.41.2:** `mail.leitstelleLesen(text, betreff, orte)` liest zusätzlich Stichwort-Zeilen `H3 X: …`, Felder mit Wert in der Folgezeile (`EINSATZORT:`), `Eröffnung` (→ `eroeffnungT`, Alarmzeit wenn ≤ 12 h alt), `[lat=..][long=..]`, getrennt `kraefteListe` (Alarmierte Kräfte) und `fahrzeugListe` (Alarmierte Einsatzmittel). `mail.ortZerlegen(text, {gemeinden, ortsteile})` zerlegt „Objekt Gemeinde Ortsteil Straße Nr“. Fahrzeugzuordnung über Kennung `\d-\d-\d`. `mail.konfig` neu: `kraefteAlarmieren` (Vorgabe true), `kraefte:[{kuerzel, ortswehr}]` (Vorgabe Aer/GrB/Reh); `absender` ohne Speicherung = Vorgabe `els@krl-wb.de` (leitstelle).

- Neues Modul `mail.js` (ohne Fremdpakete): SMTP (SSL 465 / STARTTLS 587 / unverschlüsselt, AUTH PLAIN/LOGIN), IMAP (SSL 993 / STARTTLS 143; `UID SEARCH UNSEEN`, `BODY.PEEK[]`, danach `\Seen`), MIME-Aufbau/-Zerlegung (RFC 2047/2231, Base64/QP).
- Einstellungen (API_EINST, Gruppe „E-Mail“, in `einstellungen.json`): `MAIL_SMTP_HOST`, `MAIL_SMTP_PORT`, `MAIL_SMTP_SICHER` (ssl|starttls|aus), `MAIL_IMAP_HOST`, `MAIL_IMAP_PORT`, `MAIL_IMAP_SICHER`, `MAIL_BENUTZER`, `MAIL_PASSWORT` (geheim), `MAIL_ABSENDER`, `MAIL_ABRUF_SEK` (0 = kein Abruf). Vorgaben ab 3.41.1: Strato (`smtp.strato.de:465` ssl, `imap.strato.de:993` ssl), Benutzer/Absender `elw@gemeindefeuerwehr-aerzen.de`. Ohne `MAIL_PASSWORT` sind Versand (`503`, „Passwort fehlt“) und Abruf aus; `GET /api/mail/konfig` liefert zusätzlich `konto {benutzer, server, passwort: bool}`. Umgebung: `CHROMIUM` (Pfad für PDF), `MAIL_TLS_PRUEFEN=0` (Zertifikat nicht prüfen – nur für Tests).
- Private Schlüssel (Präfix `mail.`, nie per WebSocket): `mail.konfig` `{berichtAuto, lageAuto, systemAuto, empfaenger:{bericht[],lage[],system[]}, absender:[{adresse|@domain, art: leitstelle|erkunder, name, kennwort}]}`, `mail.status` `{versand, abruf, log[200]}`, `mail.gesehen` (Message-IDs, 500).
- `POST /api/mail/senden` (Einsatzleitung) `{einsatzId?, an, betreff, text, anhaenge:[{name, typ, daten(Base64)}], bericht?:{html, name}}` → `{ok, an, abgelehnt, pdf}`; Bericht-HTML wird mit Chromium (Skripte/Netz per CSP gesperrt) zum PDF, sonst als `.html` angehängt. Anhänge ≤ 20 MB. 503 `nicht_eingerichtet`. Tagebuch „Ausgang“ + Protokoll.
- `GET /api/mail/info` (angemeldet) `{versand, empfang, berichtAuto, lageAuto, empfaenger (nur Einsatzleitung), pdf}`.
- `GET/POST /api/mail/konfig` (Admin; GET zusätzlich Status und letzte 60 Protokolleinträge), `POST /api/mail/test {an}`, `POST /api/mail/abruf` (Admin) → `{ok, neu}`.
- Automatisch: nach Aktion `lage` Mail an Lage-Empfänger (+ Tagebuch-Vermerk); `mailSystem()` bei neuen Sicherheitsereignissen, fehlgeschlagener Sicherung, roten Pi-Warnungen (je Schlüssel ≤ 1×/6 h). Bericht nach Einsatzende verschickt der Browser (`mailBerichtAuto`).
- Eingang (`mailEingang`): Duplikat (Message-ID) → Absender-Freigabe → `Authentication-Results` (dmarc=fail bzw. spf/dkim fail ohne pass → Sicherheitsereignis `mail`) → Kennwort → Fotos (`bildSpeichern`, ≤ 10) → GSL-Einsatz läuft: `auftrag.neu`; sonst Leitstelle: `einsatz.neu` bzw. Nachalarmierung bei gleichem Einsatz-Feld `mailNummer` (neu, gesetzt über `ev.einsatzMarkieren`), Fahrzeuge per normalisiertem Funkrufnamen → `fz.status A`; sonst Erkunder: `tb.neu` im neuesten laufenden Einsatz bzw. neuer Einsatz. Benutzer/Quelle „E-Mail“.

## Ab 3.40 – ASÜ: CSA und Sicherheitstrupp-Bestätigung

- Trupp (ASÜ, auch im Abgleich `/api/einsaetze/:code/trupps/:id`): neues Feld `csa: true|false`. Einstellung `config.csaMin` (Vorgabe 20). Einsatz der ASÜ: `stAus: {t}` = Sicherheitstrupp-Warnung für diesen Einsatz bestätigt.
- Atemschutz-Nachweis (`asue.nachweis`): Eintrag mit `csa`.

## Ab 3.38 – Farben der Gefahrenkreise

- Zeichnung `{type:'ringe', lat, lon, radien, text, farben?}`: `farben` = Liste `#RRGGBB` je Ring von innen nach außen (fehlt = Standard `#B3121F, #E07000, #D4A800, #1F4E79, #555555`). Ungültige Werte zeigt der Browser in der Standardfarbe.

## Ab 3.37 – Objektdaten in der Fahrzeug-App

- Objekt (`opta3.objekte[]`) hat neu `ortswehr` (zuständige Ortsfeuerwehr; leer = aus der Adresse).
- Objekt eines Einsatzes: `objektId`, sonst gleiche Anschrift (Straße + Nr., gleicher Ort bzw. ≤ 300 m) oder nächstes Objekt ≤ 50 m. Ort: `objekt.ortswehr` → Ortsteil aus Objekt-Adresse → aus Einsatz-Adresse (Namen der Ortsfeuerwehren der Gemeinde `settings.city`; Ortsteil vor Gemeindename).
- Berechtigt: Fahrzeug aktiv im laufenden Einsatz, `stadt` = Gemeinde, `ortswehr` = Ort. Einsatz-Felder `objektZugriff {oid, vid, t}` und `elVorOrt {vid, t, quelle}`.
- Meldeserver: `GET /api/state/:token` → `objekt: null | {status:'frei', name, art, dateien, ort} | {status:'vergeben', an, seit} | {status:'eigen', name, art, seit}`; `POST /api/objekt-uebernehmen/:token` → 200 `{objekt}` | 409 `{error:'vergeben', an}` | 403; `GET /api/objekt/:token` (nur Inhaber) → `{name, art, adresse, lat, lon, hinweise, kontakte, stichworte, dateien:[{id,name,typ,groesse}], seit, einsatz}`; `GET /api/objekt-datei/:token/:fid` (nur Inhaber, `no-store`).
- Aktionen: `objekt.uebernehmen {vid}` (nur Quelle Fahrzeug-App), `objekt.zugriffZuruecksetzen {einsatzId}` (Einsatzleitung/Admin). `GET /api/objektfreigabe/:eid` (angemeldet) → `{objekt:{id,name,zugeordnet}, ort, zugriff:{vid,name,t}|null}`.

## Ab 3.36 – Stärken per Handy sammeln

- Meldeserver (8081): `GET /staerke/` liefert `melde/staerke.html` (statisch, ohne Token, `Referrer-Policy: no-referrer`), `GET /staerke` → 301 auf `/staerke/`, `GET /staerke/sw.js` (Service Worker, Bereich `/staerke/`, nur die Seite im Cache).
- Daten Einsatzverwaltung → Handy nur im Fragment: `…/staerke/#<code>`; `<code>` = `z` + Base64url(deflate-raw(JSON)) oder `j` + Base64url(JSON). JSON `{v:1, k:<Sitzung>, n:<Einsatznummer>, s:<Stichwort>, m:<Meldebild>, t, f:[[vid, Funkrufname, Typ, f, uf, m, agt], …]}`.
- Handy → Einsatzverwaltung als QR-Code (Fehlerkorrektur M) oder Text: `EVST1:` + Code wie oben mit JSON `{v:1, k, n, t, r:[[vid, f, uf, m, agt], …], x:[[Name, f, uf, m, agt], …]}` (nur erfasste Einheiten; `x` = weitere Einheiten ohne Fahrzeug-Kennung).
- Neue Aktion `staerke.mehrere {werte:[{vid, f, uf, m, agt}], quelle?}` (Einsatzleitung/Admin): prüft zuerst alle Fahrzeuge (`fahrzeug_fehlt`), setzt dann je Fahrzeug wie `staerke` (Tagebuch „Stärkemeldung … (Sammelerfassung per Handy)“) → `{anzahl}`.
- `public/qrlesen.js`: eigener QR-Leser ohne externe Bibliothek (`QRLESEN.lesen(canvas|ImageData)` → Text oder `null`; Fehlerkorrektur L und M, Version 1–40, schräge/gedrehte/gespiegelte Aufnahmen). Der Browser nutzt zuerst `BarcodeDetector`, falls vorhanden.

## Ab 3.35 – Demo-Modus und Listen-Adresse

- `EV_DEMO=1` schaltet den Demo-Modus ein (Modul `demo-modus.js`, ohne `EV_DEMO` wirkungslos). Daten im Ordner `demo-daten/`: `demo-karte.json` (`{name, mitte, kern:{s,w,n,o}, zMin, zMax}`), `adressen.json`, `demo-info.json` (`{zugaenge:[{name,pin}]}`), `leer.png`, `luftbild/z/x/y.jpg`.
- Im Demo-Modus haben folgende Einstellungen feste Werte (Einstellungen und Umgebung wirken nicht): `NINA_URL`, `WETTER_URL`, `NOMINATIM_URL`, `OVERPASS_URL`, `W3W_URL`, `W3W_KEY`, `OSM_TILE_URL`, `GEOCODE_ORT`, `BACKUP_ZIEL=aus`, `ASUE_KEY=''`, TLS leer; im Browser `C_WIND_URL`, `C_DWD_WMS`, `C_SAT_URL`, `C_HOEHE_URL` als relative Adressen `/demo-dienste/…`.
- Ersatzdienste unter `/demo-dienste/` (Port 8080): `nominatim/search`, `nominatim/reverse`, `overpass` (POST), `wetter`, `nina/dashboard/:ars`, `nina/warnings/:id`, `w3w/convert-to-coordinates`, `w3w/convert-to-3wa`, `w3w/autosuggest`, `hoehe`, `wms`, `luftbild/:z/:x/:y.jpg`.
- `/tiles/…`: fehlende Kacheln werden im Demo-Modus **nicht** geladen, sondern als `demo-daten/leer.png` beantwortet. Keine externen Sicherungsziele. Der Server-`fetch` lehnt jede Adresse außer 127.0.0.1/localhost ab.
- `/` und `/index.html` setzen im Demo-Modus `window.EV_DEMO = {name, karte, zugaenge}` in den Kopf; der Browser begrenzt damit die Karte (`mvSet`), zeigt „DEMO“ und die Zugänge an der Anmeldung.
- `EV_HOST` (auch im Normalbetrieb): Adresse, an die alle drei Ports gebunden werden (z. B. `127.0.0.1`); leer = alle Schnittstellen wie bisher.
- Bau des Demo-Pakets: `demo/karte/welt.js` (fiktive Geometrie, Adressen, Wasserentnahmestellen) → `demo/karte/zeichnen.js` (Kacheln mit Chromium) → `demo/wappen.py` → `demo/bauen.js` → `demo/startdaten.js` (Beispiel-Einsätze mit `demo/uhr-preload.js`).

## Ab 3.31 – Feuerwehr einer Atemschutzüberwachung

- Die ASÜ sendet zusätzlich `X-ASUE-Wehr: <benutzer>` (Kennung der angemeldeten Feuerwehr bzw. „arbeiten als“; Admin-Konten senden nichts). CORS erlaubt den Kopf.
- Der Pi löst die Kennung nur über `asue/benutzer.js` auf → `wehr = {user, name, ort, gemeinde, wappen}` (unbekannte Kennungen werden ignoriert). Gespeichert in `asue.einsaetze[code].fuehrung.wehr`, `.wehr` (aktuell führende Feuerwehr) und `.angelegtVon`; Übergabe übernimmt die Feuerwehr des Zielgeräts.
- `GET /api/einsaetze/{code}` (Port 8082) liefert zusätzlich `wehr` (oder `null`); `geraete[]` enthält `wehr` (Name). Ohne Kennung (ältere ASÜ) kommt der Name aus der Statusmeldung `opta3.asueStatus` mit `einsatz.id = "sync-<code>"`.
- `GET /api/asue/einsaetze` (Port 8080) enthält `wehr` und `angelegtVon` (Name, nur wenn abweichend).
- `GET /asue-wappen/{datei}` (Port 8080): Wappen aus `asue/wappen/` (nur Bilddateien) für die Karte „Atemschutz“.

## Ab 3.30 – Demo- und Übungseinsätze aus realen Einsätzen

- Modul `demo.js` (rein, ohne Speicher). Drehbücher privat in `uebung.demos` `{id, name, erstellt, importiert?, kopf, dauer, ereignisse, statistik, rec}`; `rec` hat die Form eines Archivdatensatzes mit Platzhaltern `{{NR}}` (Einsatznummer) und `demo` (Einsatz-ID), Zeiten auf dem Bezugstag 3.1.2000 (Tageszeit des Alarms bleibt), keine Bilder (`fotos`, `bilder` leer, `bild` null), `objektId`/`kontaktId` entfernt.
- `POST /api/demo/vorschau` (Admin) `{archivId, personen?, extra?:[{von,zu}], ort?:{art:'behalten'|'ohneNr'|'verlegen', adresse, lat, lon}, maxPauseMin?}` → `{vorschlag:[{original, ersatz, vornamen:[[alt,neu]], quellen, titel, anzahl, nurKontext}], statistik:{namen, benutzer, telefon, email, kennzeichen, hausnummern, bilder}, dauerAlt, dauerNeu, kopf, texte:[{bereich, text, t}], ereignisse, original:{nummer, adresse, lat, lon}}`.
- `POST /api/demo/erstellen` (Admin, gleiche Felder + `name`) → `{ok, demo}`; Protokoll „Demo-Einsatz … aus Einsatz … erstellt“.
- `GET /api/demo` (Einsatzleitung) – Liste ohne `rec`; `GET /api/demo/:id/export` → `{format:'einsatzverwaltung-demo/1', name, kopf, dauer, statistik, rec}`; `POST /api/demo/import {demo}` (Admin); `POST /api/demo/:id/name {name}`; `DELETE /api/demo/:id` (Admin).
- `POST /api/demo/:id/start` (Einsatzleitung): `{art:'archiv', start}` → Archivdatensatz `DEMO-nnn` (`einsatz.demo`, `einsatz.uebung`, Meldebild „DEMO: …“; Zähler `uebung.demoZaehler`; Archivzeile mit `demo:true`); `{art:'live', tempo:1|2|3|4|6|10, fahrzeuge:bool}` → neuer Einsatz „ÜBUNG: …“ mit `einsatz.uebung {demo, name}` und Lauf in `uebung.laeufe` `{id, demoId, einsatzId, events:[{t, art:'status'|'staerke'|'tb'|'nachricht'|'pos'|'auftrag', …}], i, tempo, pausiert, beendet, uebersprungen}`. Ein Takt je Sekunde führt fällige Ereignisse über `ev.handleOp` aus (Benutzer „Übungsleitung (Drehbuch)“, Quelle „Drehbuch“; Nachrichten als `nachricht.fz` der Fahrzeug-App). Fahrzeuge in einem anderen Einsatz oder mit aktivem Status werden ausgelassen (einmaliger Vermerk).
- `POST /api/demo/lauf/:id {aktion:'pause'|'weiter'|'weiterspringen'|'tempo'|'stopp', tempo}` (Einsatzleitung). Öffentliche Zusammenfassung `opta3.uebungLaeufe` (Server-Schlüssel) `[{id, einsatzId, nummer, name, tempo, start, pausiert, beendet, gesamt, erledigt, naechsteT, naechsteArt, ende, fahrzeuge, uebersprungen}]`.
- Atemschutz-Nachweis ignoriert Archivdatensätze mit `einsatz.demo`. `archivZeile` enthält `uebung`/`demo`.

## Ab 3.29 – Sicherheit und Datenschutz

- **PIN-Bestätigung:** `POST /api/auth/bestaetigen {pin}` → `{ok, bis}` (401 falsche PIN, 429 nach 8 Fehlversuchen/10 min); gilt je Sitzung `PIN_BESTAETIGUNG_MIN` Minuten (Vorgabe 5, 0 = aus). `GET /api/auth/frisch` → `{frisch, min}`. Ohne frische Bestätigung antworten geschützte Endpunkte mit `428 {"error":"pin_noetig","code":"pin_noetig","text":…}`, die WebSocket-Aktionen `archiv.loeschen`, `benutzer.speichern`, `benutzer.loeschen`, `sitzung.beenden` mit `opResult {ok:false, code:"pin_noetig"}`. Geschützt (HTTP): `POST /api/einstellungen/schnittstellen`, `POST /api/system/neustart`, `GET /api/sicherung/datei`, `GET /api/exposition` (ohne `ev`), `DELETE /api/exposition/:id`, `POST /api/melde/zugang` mit `entsperren`/`alle_neu`, `POST /api/loeschfristen/jetzt`. Die Oberfläche fragt dann die PIN ab und wiederholt die Anfrage.
- **Sicherheitshinweise** (privat `auth.sicherheit`, 180 Tage, max. 300): `{id, t, erst, art, text, n, quittiert?:{t,user}}`, `art` = `anmeldung` (≥ 3 Fehlversuche/10 min), `sperre` (429), `pin` (≥ 3 falsche PINs bei Bestätigung), `geraet` (Admin-Anmeldung mit neuem User-Agent; Fingerabdrücke in `auth.geraete`), `asue` (falscher/fehlender Wehr-Schlüssel an Port 8082), `fzapp` (gesperrter/ersetzter Link). Gleicher Anlass innerhalb 6 h → `n` hochgezählt. Admins bekommen per WebSocket `{"type":"sicherheit","offen":[…]}` (nach `init` und bei jeder Änderung). `GET /api/sicherheit` (Admin) → `{liste, check:[{ok,text,tipp}], loeschen}`; `POST /api/sicherheit/quittieren {id}` bzw. `{alle:true}`.
- **Verschlüsselte Sicherung:** Schnittstellen-Eintrag `SICHERUNG_PASSWORT` (geheim, ≥ 12 Zeichen). Dateiformat: `EVSICH01` (8 Byte) · Salz (16) · IV (12) · Daten AES-256-GCM · Tag (16); Schlüssel `scrypt(Passwort, Salz, N=32768, r=8, p=1)`. Auf dem Ziel: `data-JJJJ-MM-TT.json.enc`, `objekte/…enc`, `berichtbilder/…enc`, `protokoll/…enc`, `asue/benutzer.js.enc`, `passwort-pruefung.enc` (Inhalt `EV-SICHERUNG`), `LIESMICH.txt`, `sicherung-entschluesseln.js`. Unterordner werden gespiegelt (in der Quelle gelöschte Dateien werden entfernt). `GET /api/sicherung/datei` liefert bei gesetztem Passwort `application/octet-stream` `….json.enc`. `opta3.sicherung.ziele[]` hat zusätzlich `verschluesselt` und ggf. `hinweis`, `opta3.sicherung.verschluesselt`.
- **Löschfristen** (Schnittstellen-Gruppe „Datenschutz“): `LOESCH_SPUR_MONATE`, `LOESCH_FOTO_MONATE`, `LOESCH_NACHR_MONATE`, `LOESCH_ARCHIV_JAHRE` (0 = nie). Gilt für `arch.<id>` ab `einsatz.ende`: Spuren/Positionen → `{}`, `einsatz.fotos`/`einsatz.nachrichten` → `[]`, Vermerk `geloescht {spuren|fotos|nachrichten: Zeit}`; ganze Einsätze über `archiv.loeschen`. Nicht mehr referenzierte Dateien in `berichtbilder/` (älter als 1 Tag) werden entfernt. Lauf 2 min nach Start und alle 6 h; letzter Lauf in `auth.loeschLauf`. `GET /api/loeschfristen` (Admin) → `{fristen, vorschau, zuletzt}`; `POST /api/loeschfristen/jetzt` (Admin + PIN) → `{ok, ergebnis:{einsaetze, spuren, fotos, nachrichten, dateien}}`.

## Ab 3.27

- Aktionen: `besprechung {einsatzId, text, teilnehmer?, naechste(min 0–240)}` → `einsatz.besprechungen[] {t, user, text, teilnehmer, naechste}`, `einsatz.uhren.besprechung {faellig}`; `uhr {art:'besprechung', aktion:'spaeter'|'aus'}`; `einsatz.uebergabe {einsatzId, an, punkte[], bemerkung}` → `einsatz.einsatzleiter`, `einsatz.elWechsel[] {t, von, an, punkte, bemerkung, user}`.
- Einsatz-Bereich `zeitstrahl` (nur Anzeige). Einstellung `opta3.settings.plausi {amin, s3min, gpskm, lagemin, abloesung, verpflegung}` (0 = aus).
- Exposition (privat, Schlüssel `asue.exposition`): `GET /api/exposition` (Admin) → `{liste, arten, schutz}`; `GET /api/exposition?ev=<Einsatznummer>` (Einsatzleitung) → `{liste, vorschlaege (aus dem Atemschutz-Nachweis), arten, schutz}`; `POST /api/exposition {eintraege:[{id?, nachname, vorname, evNummer, einsatzId, einsatz, datum, art, stoff, taetigkeit, dauer, schutz, haut, kleidung, bemerkung, quelle}]}`; `DELETE /api/exposition/:id` (Admin, ausblenden).
- Änderungsprotokoll: `protokoll/JJJJ-MM.jsonl` (`{t, user, bereich, text, quelle?, einsatz?}`), `GET /api/protokoll?von&bis&user&bereich&q&max` (Admin, höchstens 400 Tage). Erfasst alle Aktionen (außer `fz.pos`, `nachricht.gelesen`, `nachricht.quittung`), `set` auf Stammdaten/Einstellungen, Benutzer, Anmeldungen, Schnittstellen (nur Namen), Neustart. Schnittstellen-Eintrag `PROTOKOLL_MONATE` (Vorgabe 13).

## Ab 3.26

- WebSocket: die App sendet `{type:'ping'}`, wenn 8 s nichts kam; der Server antwortet `{type:'pong'}`. Nach 22 s Stille baut die App die Verbindung neu auf.
- Aktionen (`op`) ohne Verbindung warten in der App bis zu 2 Minuten (`opWarte`) und werden nach dem Verbinden gesendet.
- `fz.status` mit `rueck:true` (Rückgängig in der App) schreibt ins Tagebuch „(zurückgenommen)“. Rückgängig nutzt nur vorhandene Aktionen: `fz.status`, `fz.abschnitt`, `auftrag.fz` (mit/ohne `entfernen`), `staerke`.
- Einstellung `opta3.settings.tbBausteine` (Text, ein Baustein je Zeile; leer = Vorgabe).

## Ab 3.25

- Nebenfenster zusätzlich `&anzeige=1` (Anzeige-Modus) und die Ansichten `?fenster=tableau` (Status-Tableau) und `?fenster=uhren` (Einsatz-Uhren). Keine neuen Server-Schnittstellen.
- `BroadcastChannel('ev-fenster')`, jede Nachricht mit `von` (Fensterkennung): `{typ:'da', name, haupt, tab, karte, anzeige, pos}` alle 3 s, `{typ:'weg'}`, `{typ:'wer'}` (alle antworten mit `da`), `{typ:'einsatz', id}`, `{typ:'hinweis'}`, `{typ:'fokus', nr, f:{art:'punkt'|'fz', lat?, lon?, z?, label?, vid?, eid}}` → Antwort des Kartenfensters mit der kleinsten Kennung `{typ:'fokusOk', nr}` (sonst nach 600 ms Karte im eigenen Fenster).
- Browser-Speicher je Gerät: `opta3.arbeitsplaetze = [{name, fenster:[{name, tab, karte, anzeige, pos:{x,y,b,h}}], hinweis, auto, t}]`, `opta3.hinweisFenster` (Fenstername, leer = Hauptfenster), `opta3.fensterAnzeige`, `opta3.anzeigeZoom.<fenster>`, `opta3.tableau.<fenster>`.

## Ab 3.24

- Nebenfenster: `/?fenster=<reiter>[&karte=<bereich>]` (Reiter `list|stations|einsatz|map|objekte|gefahr|archiv|admin`, Bereich = Einsatz-Karte `uebersicht|tb|abschnitte|atemschutz|auftraege|fahrzeuge|nachrichten|fotos|vu|checklisten|nachbereitung`). Fenstername `ev_<reiter>[_<bereich>]`. Nur Browser-seitig, keine neuen Server-Schnittstellen; jedes Fenster hat eine eigene WebSocket-Verbindung mit derselben Sitzung.
- Einsatzwahl zwischen den Fenstern über `BroadcastChannel('ev-fenster')`, Nachricht `{typ:'einsatz', id}`. Fensterlage im Browser unter `opta3.fensterPos.<fenstername>` gemerkt.

## Ab 3.23

- Alle Adressen/Schlüssel stehen in `server.js` in der Liste `API_EINST` (`{id, gruppe, name, typ:'text'|'url'|'zahl'|'geheim', vorgabe, hilfe?, muster?, form?, browser?, neustart?}`); im Programm gelesen über `A.<ID>` bzw. `einstWert(id)`. Reihenfolge: `einstellungen.json` (App) → Umgebungsvariable (Dienstdatei) → Vorgabe. **Neue Schnittstellen nur dort eintragen** – sie erscheinen dann automatisch in den Einstellungen.
- `GET /api/einstellungen/schnittstellen` (Admin) → `{liste:[{id, gruppe, name, typ, hilfe, quelle:'app'|'dienst'|'vorgabe', vorgabe, wert, neustart, browser, gesetzt?, aktiv?, neustartNoetig?}]}`. Bei `typ:'geheim'` ist `wert` immer leer, nur `gesetzt`.
- `POST /api/einstellungen/schnittstellen {werte:{ID: text | '' | null}}` (Admin): Text setzt, `''`/`null` entfernt den App-Wert (bei geheimen Werten ist `''` = behalten). Prüfung → 400 `{error:'ungueltig', fehler:{ID:text}, text}`. Antwort `{ok, geaendert, liste}`. Ändern von `WARN_ARS`/`NINA_URL` lädt die Warnungen neu; Browser-Adressen werden als WebSocket-Nachricht `{type:'einstBrowser', werte}` verteilt.
- `GET /api/einstellungen/browser` (angemeldet) → `{C_WIND_URL, C_DWD_WMS, C_SAT_URL, C_HOEHE_URL}` (vom Browser direkt genutzt, keine Schlüssel).
- `POST /api/system/neustart` (Admin): Antwort, dann beendet sich der Prozess; systemd (`Restart=always`) startet neu. Nötig für `PORT`, `MELDE_PORT`, `ASUE_PORT`, `TLS_*`, `MELDE_TLS_*`.
- `einstellungen.json` liegt neben `server.js` (Rechte 600), nicht in `data.json`, nicht in der Datensicherung, wird vom Update nicht überschrieben.

## Ab 3.22

- Wetter: Der Server fragt `WETTER_URL` (Vorgabe `https://api.open-meteo.com/v1/forecast`, `current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m`) für jeden laufenden Einsatz bei Beginn und dann alle `settings.wetter.intervall` Minuten (Vorgabe 60, 0 = nur Beginn; `settings.wetter.an=false` schaltet ab). Tagebuch-Vermerk `auto:'wetter'`, `einsatz.wetter = {erste, letzte}` mit `{t, temp, feuchte, niederschlag, code, wind, richtung, boeen, ort}`. `POST /api/einsatz/:id/wetter` (Einsatzleitung/Admin) fragt sofort ab.
- Fotos: `einsatz.fotos = [{id, t, aufgenommen?, bild, von, user, text, lat?, lon?, ortQuelle:'gps'|'geraet'|'einsatzort'|'karte', quelle:'elw'|'fahrzeug', vid?, bericht}]` (höchstens 400). Aktion `foto {einsatzId, aktion:'neu', fotos:[{bild, text, lat, lon, ortQuelle, aufgenommen, von, bericht}]}` bzw. `aktion:'aendern'|'bericht'|'loeschen'` (auch im Archiv). Bilder werden sofort nach `berichtbilder/` kopiert. Nachrichten mit Bild aus der Fahrzeug-App werden im Einsatz automatisch zu Fotos (Ort = letzte GPS-Position des Fahrzeugs, falls jünger als 15 min).
- Funkskizze: Aktion `funk {einsatzId, leitstelle, fuehrungName, fuehrung, bemerkung, bericht}` → `einsatz.funk`.
- `GET /api/auswertung?jahr=JJJJ` (angemeldet): `{jahr, jahre, einsaetze:[{id, nummer, stichwort, meldebild, adresse, lat, lon, alarm, ende, uebung, fz:[{vid, name, ortswehr, typ, a, s3, s4, seit, bis, personen, agt}]}]}` aus dem Archiv.
- Fahrzeugstatus von außen: `GET|POST /api/extern/status/<schlüssel>` auf Port 8081 (vor dem JSON-Parser, eigene Grenze 16 kB) und 8080 (ohne Anmeldung, Schlüssel in der Adresse, 40 Hex-Zeichen, Vergleich zeitkonstant, höchstens 30 Meldungen/s). Body JSON (auch verschachtelt, Punkt-Pfade), `application/x-www-form-urlencoded` oder URL-Parameter. Fahrzeugfeld: eingestellt oder erstes von `fahrzeug, vehicle, funkrufname, rufname, fzg, fz, unit, issi, fms, fmskennung, kennung, address, name`; Statusfeld: eingestellt oder `status, fmsstatus, fms_status, state, statuscode, code` (erste Ziffer zählt). 1/2/3/4/6 → `fz.status`, 5/0 → `fz.ruf`, Quelle „PowerAlarm“. Zuordnung: Tabelle Kennung → Fahrzeug, sonst Funkrufname/Kennzeichen/`fms`-Feld des Fahrzeugs. Antwort `{ok, ergebnis}`; falscher Schlüssel oder abgeschaltet → 404. Einstellungen (privat, `extern.status`): `GET/POST /api/extern/einstellung` (nur Admin) mit `aktiv, feldFz, feldSt, zuordnung, neuerSchluessel, leeren`; liefert `pfad`, `letzte` (25 Meldungen) und `unbekannt`.

## Ab 3.21

- Neue Zeichnungstypen in `shapes`: `{type:'line', stil:'angriff'|'vormarsch'|'rueckzug'|'anfahrt'|'absperr'|'grenze'|'gefahr', pts, text?}`, `{type:'text', lat, lon, text, gr:'k'|'m'|'g', farbe}`, `{type:'dlk', lat, lon, rot, modell, amax?, name?}`. Symbole und Zeichnungen können `gesperrt:true` tragen (Client verhindert Verschieben/Löschen). Neue Symboltypen `e_trupp|e_staffel|e_gruppe|e_zug|e_verband|e_fuehrung|e_abschnitt|fz_lf|fz_hlf|fz_tlf|fz_dlk|fz_rw|fz_elw|fz_gw|fz_mtf`.
- Lagestände: Serverschlüssel `opta3.lagestand.<eid>` = `[{id, t, name, user, modus:'lage'|'taktik', karte:{markers, shapes}, fz:{vid:{lat,lon,st,name,typ}}, abschnitte, bericht}]` (höchstens 40, je ≤ 600 kB). Aktion `lagestand {einsatzId, aktion:'neu', name, modus, bericht?, stand:{karte, fz}}` bzw. `aktion:'loeschen'|'bericht'|'umbenennen'` (auch im Archiv). Beim Einsatzende als `lagestaende` im Archivdatensatz.
- Einstellung `opta3.settings.tbSymbole = [typ …]` (Symbole/Zeichnungen, die beim Setzen einen Tagebuch-Vermerk erzeugen; Vorgabe siehe Bedienung).

## Ab 3.20

- Nachrichten in beide Richtungen. Postfach `opta3.nachrichten[vid]` enthält jetzt `richtung:'aus'` (ELW → Fahrzeug, `quittiert`) und `richtung:'ein'` (Fahrzeug → ELW, `gelesen:{t,user}`), je Eintrag `eid` und `nid` (Verweis auf den Einsatzverlauf), 24 h, höchstens 30.
- Einsatzverlauf `einsatz.nachrichten = [{id, t, richtung, von, an, vids, text, bilder, quittiert:{vid:t}, gelesen, bericht, berichtVon}]` (höchstens 300, wird archiviert).
- Aktionen: `nachricht {…, bericht?}` (→ `{anzahl, berichtBilder}`), `nachricht.gelesen {vid, ids? | nids?, einsatzId?}`, `nachricht.bericht {einsatzId, id | ids, an}` (laufend und Archiv; Bilder werden nach `berichtbilder/` kopiert und nicht mehr gelöscht). `nachricht.fz` nur über den Meldeserver (per WebSocket gesperrt).
- Meldeserver (8081): `POST /api/bild/:token` (Body = Bild, jpeg/png/webp, ≤ 4 MB, 1 je 1,5 s, höchstens 60 je Fahrzeug und 24 h) → `{id}`; `POST /api/nachricht/:token {text, bilder:[id]}` (1 je 3 s); `GET /api/state/:token` liefert zusätzlich `gesendet:[{id,t,text,bilder,gelesen}]`. `GET /api/bild/:token/:id` gilt für Bilder in beide Richtungen dieses Fahrzeugs.
- Bilder: `nachrichten/` (7 Tage) und `berichtbilder/` (dauerhaft, in der Datensicherung). `GET /api/nachricht/bild/:id` (8080) liefert aus beiden Ordnern.

## Ab 3.19

- Karte ändern ohne Überschreiben: Aktion `karte.aendern {key:'opta3.karte.<eid>'|'opta3.taktik.<eid>', aenderungen:[{liste:'markers'|'shapes'|'vehPos', id, wert|null}], felder:{mScale?, vScale?, bild?, view?}}` (Einsatzleitung/Admin, nur laufende Einsätze, max. 1000 Änderungen). `wert:null` entfernt das Element. Der Pi setzt `geaendert:{t, user}` und verteilt die ganze Karte wie bisher als `update`. Neue Symbole/Zeichnungen tragen `t` (Zeitpunkt des Setzens).
- Neue Zeichnungstypen in `shapes`: `{type:'flaeche', pts:[[lat,lon],…], text?}`, `{type:'raster', pts:[[lat,lon],[lat,lon]], zelle:25..500, name, felder:{A1:{status:'offen'|'laeuft'|'abgesucht'|'gesperrt', trupp, bemerkung, t, user}}}`; Leitungen (`art`) zusätzlich `q, pAus, pEin, dh` der letzten Förderberechnung.
- Präsenz über WebSocket: Gerät sendet `{type:'praesenz', karte:'<eid>'|'<eid>:taktik'|'', tool}`; der Pi schickt jedem Gerät `{type:'praesenz', liste:[{user, karte, tool, t}]}` (alle anderen, Einträge älter als 70 s entfallen; alle 30 s und bei Änderungen).
- `GET /api/einsatz/:id/verlauf` (angemeldet): laufender oder archivierter Einsatz → `{einsatz, laufend, fahrzeuge:{vid:{name, typ, seit, bis, zeiten}}, spuren, positionen, karte, taktik, tagebuch:[{t,text,von,an,auto}], auftraege:[{nr,kat,lat,lon,eingang,zeiten}]}` für den Zeitraffer.
- Höhenprofil für die Wasserförderung (ab 3.51): Geländehöhen offline auf dem Pi (`hoehe/`, SRTM), nur außerhalb davon online über `C_HOEHE_URL` (zuerst vom Pi, sonst vom Browser).

## Ab 3.18

- Ansprechpartner: Serverschlüssel `opta3.kontakte` = `[{id, funktion, name, telefon, telefon2, email, bemerkung}]`. Aktionen (Einsatzleitung/Admin): `kontakt.speichern {id?, …}`, `kontakt.loeschen {id}`, `kontakt.import {liste:[…]}` (gleiche Funktion+Name → aktualisieren), `einsatz.kontakt {einsatzId, kontaktId | Felder [, speichern:true], rolle?}` bzw. `{einsatzId, id, entfernen:true}` → Kopie in `einsatz.kontakte`, Tagebucheintrag.

## Ab 5.4 – Superadmin

- Ein EV-Benutzer (Rolle **admin**) kann in Verwaltung → Benutzer als **Superadmin** markiert werden (`benutzer.speichern` mit `superadmin:true`). Es gibt höchstens einen.
- Kennwort: mind. 12 Zeichen mit Buchstaben und Ziffern; Benutzername klein (`a–z 0–9 . _ -`), darf nicht mit ASÜ- oder AGW/GDB-Konten kollidieren.
- Dasselbe Kennwort gilt für: EV-Anmeldung, ASÜ (`/api/zugang/anmelden`, Eintrag in `asue/benutzer.js` mit `superadmin:true`, Rolle admin), Atemschutz-DB `/atemschutz` und Geräte-DB `/geraete` (`/api/agw/anmelden` → virtuelles Konto `SUPER`, alle Wehren, beide Bereiche).
- Kennwortwechsel nur in der EV; `/api/agw/kennwort` lehnt den Superadmin ab. Ist das Kennwort älter als 120 Tage, verweigert `/agw/anmelden` mit 409 `kennwort_neu`; EV-Login liefert `superKennwortAlt:true`.
- `/api/auth/benutzer` und `/api/auth/login` liefern `superadmin:true`. Jede Superadmin-Anmeldung wird als Sicherheitsereignis protokolliert.
- Entfernen des Häkchens oder Löschen des Benutzers entfernt auch den ASÜ-Eintrag.

## Ab 5.5 – Datenbanken als App mit Benachrichtigungen

- `/geraete` und `/atemschutz` haben eigene Manifeste (`geraete.webmanifest`, `atemschutz.webmanifest`, id = Pfad, eigene Symbole `icon-geraete-*.png`, `icon-atemschutz-*.png`, eigene Theme-Farbe) → als eigenständige Apps installierbar (Android/Chrome/Edge: „App installieren“, iOS: „Zum Home-Bildschirm“).
- Push (Web Push, VAPID-Schlüssel wie Fahrzeug-App), gespeichert in `asue.agwPush = {[kontoId|'SUPER']: [{endpoint, keys, bereich, geraet, t, ok}]}`, max. 5 Geräte je Konto, ein Gerät gehört nur einem Konto.
- API (X-AGW-Token): `GET /api/agw/push` → {aktiv, key, geraete}; `POST /api/agw/push/abo` {abo, bereich, geraet}; `POST /api/agw/push/ab` {endpoint}; `POST /api/agw/push/test`.
- Auslöser: Erinnerungslauf (alle 3 h) – Geräteprüfungen GDB 7 Tage vorher, AGW-Geräteprüftermine, ablaufende Nachweise, Kennwort 7 Tage vor Ablauf (je Punkt einmal, Schlüssel `p|…` in `asue.agwErinnert`, läuft auch ohne Mailversand); Schadensmeldung aus der Fahrzeug-App (`gwBenachrichtigen`, Bereich geraete, Wehr); Gerätetausch / Prüfung aus der ASÜ (`/pflege/aktion`, Bereich atemschutz, Wehr).
- Service Worker `asue/sw.js` (asue-v54) zeigt die Meldung, Klick öffnet `/geraete` bzw. `/atemschutz`.

## Ab 5.6 – Sicherheit, Gerätewarte, Atemschutz, Datenschutz

- **Angemeldet bleiben** (Datenbank-Apps): `/api/agw/anmelden` mit `merken:true, geraet` → Token gilt 30 Tage; gespeichert nur als SHA-256 in `asue.agwGeraete = {[hash]: {id, kid, t, bis, geraet, ip, zuletzt}}` (max. 10 je Zugang). Ungültig bei Kennwortwechsel (`pwT > t`), gesperrtem/gelöschtem Zugang, `/agw/abmelden` oder Fern-Abmeldung. Client: `localStorage asue.agwTokenDauer`.
- **Sicherheitsübersicht** (EV, Admin): Journal `sicherheit.anmeldungen` (90 Tage, max. 1500; app, user, ip, aussen, ok, grund, geraet) für EV-, ASÜ- und DB-Anmeldungen. `GET /api/sicherheit/anmeldungen` → {liste, stat, geraete}; `POST /api/sicherheit/geraet-abmelden` {id | kid | alle}. Neues Ereignis „Erfolg nach ≥3 Fehlversuchen“. Neue Sicherheitsereignisse gehen zusätzlich als Push an die Geräte des Superadmins.
- **Gerätedatenbank:** QR-Etiketten enthalten jetzt `https://<host>/geraete#GDB1:<id>` (Handy-Kamera öffnet die Gerätekarte; alte `GDB1:`-Etiketten bleiben gültig); Live-Scan in der App. Prüfprotokoll: `/gdb/aktion` pruefung mit `protokoll {liste, punkte[{t, ok:true|false|null, bem}], pruefer, befaehigt, unterschrift (PNG-DataURL < 160 kB)}` → `asue.gdbProtokolle`, Verlauf-Eintrag `prot`; `GET /gdb/protokoll/:id`, `GET /gdb/prueflisten`. Druck/PDF über die Browser-Druckfunktion.
- **Wochenüberblick:** montags ab 7 Uhr je Zugang mit Bereich Geräte (Mail + Push): offene Schäden, Fahrzeuge außer Dienst, Geräte nicht bereit, überfällige Prüfungen, Prüfungen in 4 Wochen, Ausleihen. `GET /gdb/woche`; Stand `asue.gdbWoche`.
- **Atemschutz:** Push bei neuen Nutzungen mit Geräten (alle 5 min, `asue.nwGepusht`). `GET /agw/auswertung?jahr=` (je Ortswehr: Personen, einsatzbereit, Einsätze/Übungen/Minuten, fehlende Nachweise). Persönlicher Link: `POST /agw/agtlink {pid, aktion:'neu'|'aus'}` → `/agt/<token>` (nur Lesen, Hash in `asue.agtLinks`, ein Link je Person, Ratenbegrenzung).
- **Löschfrist** `LOESCH_AGT_JAHRE` (0 = aus): Personen mit „ausgeschieden am“ (`aus`) werden nach Ablauf anonymisiert (Name, Nachweise, Link); Einsatznachweis-Einträge werden namenlos (`asue.agwAnonym`). Teil von `loeschfristenAnwenden` (`personen`).

## Ab 5.7 – Vorschriften und Datenschutz

- **ASÜ, FwDV 7:** Beim „Beginn“ eines Trupps mit weniger als 2 eingetragenen Personen erscheint eine Rückfrage (nur für Nachträge bestätigen). Ein laufender Trupp unter 2 Personen zeigt die Warnung „Weniger als 2 Personen im Trupp (FwDV 7)“.
- **Gerätedatenbank, Prüfarten:** gemeindeweite Auswahlliste `asue.gdbPruefarten` [{name, monate}]; Vorgabe `GDB_PRUEFARTEN_STD` (Intervalle sind Vorschläge, nach DGUV 305-002 bzw. Hersteller anzupassen). `/gdb/daten` liefert `pruefarten`, `pruefartenStd`; `POST /gdb/pruefarten {liste | standard:true}`. Auswahl setzt das Intervall; freie Eingabe bleibt möglich.
- **Bezeichnung:** „Eignungsuntersuchung Atemschutz (G 26.3)“.
- **Datenschutzhinweise:** `/datenschutz` auf allen drei Ports (EV, Fahrzeug-App, ASÜ). Einstellungen `DS_VERANTWORTLICHER`, `DS_DSB`, `DS_ZUSATZ` (Zeilen mit „ | “ trennen); Speicherdauern aus den Löschfristen. Verlinkt in EV-Anmeldung, Datenbank-Apps, Fahrzeug-App (Feedback-Fenster) und persönlichem AGT-Link.
- **Schriften ohne Google:** `/schrift.css` und `/schrift/<hash>.woff2` auf allen Ports. Der Pi lädt Barlow / Barlow Condensed / Roboto Mono einmal von Google Fonts in den Ordner `schrift/` (bei Fehler neuer Versuch nach 10 min, bis dahin Systemschrift). Die Endgeräte verbinden sich nicht mehr mit Google.
- **Sicherheits-Check:** neue Punkte „Zugang von außen nur über HTTPS“, „Datenschutzhinweise ausgefüllt“, „Schriften liegen auf dem Pi“; die Löschfrist für Atemschutzgeräteträger zählt als gesetzte Löschfrist.
- Stärke-Sammelseite `/staerke/`: geprüft – sie arbeitet nur im Browser (Daten im QR-Code bzw. im Gerät), der Server speichert dort nichts; kein Schlüssel nötig.

## Ab 5.8 – Berichte, Notfall, GitHub

- **Jahresbericht:** `GET /api/druck/jahresbericht?jahr=JJJJ` (Einsatzleitung/Admin) → Druckseite (HTML); mit `format=json` die Zahlen: einsaetze, kategorien (nach Stichwort: Brand, Technische Hilfe, Gefahrgut/ABC, Brandmeldeanlage/Fehlalarm, Sonstige), monate[12], stichworte, stunden, personenstunden (Stärke je Fahrzeug × Zeit im Einsatz), fahrzeugeinsaetze, wehren[], atemschutz, geraete, schaeden, exposition. Grundlage: `arch.index` + `arch.<id>` des Jahres (ohne Demo/Übung).
- **Notfallmappe:** `GET /api/druck/notfallmappe` (Einsatzleitung/Admin) → Druckseite: Ansprechpartner (`NOTFALL_KONTAKT`), Checkliste, Fahrzeuge, Feuerwehrhäuser, leere Vordrucke Einsatztagebuch (FwDV 100), Stärkemeldung, Atemschutzüberwachung (FwDV 7). Wird protokolliert.
- **ASÜ direkt auf GitHub:** Einstellungen in `auth.githubVeroeffentlichen` {repo, branch, pfad, token, auto, letzte} (privat, Token nie an Clients). `GET /api/asue/github` liefert zusätzlich `veroeffentlichen` (ohne Token, `token: true/false`, `veraltet`). `POST /api/asue/github/einstellen` {repo, branch, pfad, token?, tokenLoeschen?, auto} und `POST /api/asue/github/veroeffentlichen` (Admin + PIN). Ablauf über die Git-Data-API: ref → commit → blobs → tree (base_tree) → commit → PATCH ref; unveränderter Baum = kein Commit. Paketinhalt aus `asueGhDateien(seite, adressen)` (wie das ZIP). Automatisch 90 s nach dem Start, wenn `auto` und die veröffentlichte Version ≠ Programmversion; Fehler → Mail an System-Empfänger. Sicherheits-Check zeigt „veraltet“/Fehler.
- Neue Einstellung `NOTFALL_KONTAKT` (Gruppe Betrieb). Demo-Modus setzt `DS_VERANTWORTLICHER`, `DS_DSB`, `NOTFALL_KONTAKT` auf erfundene Werte.
- Neue Doku: `docs/BETRIEBSHANDBUCH.md`, `docs/KURZBESCHREIBUNG.md`, `docs/KURZANLEITUNG_Geraetewart.md`, `docs/KURZANLEITUNG_Atemschutzgeraetewart.md`, `docs/KURZANLEITUNG_Geraetetraeger.md`.

## Ab 5.9 – Hydrantenprüfung

- Speicher `opta3.hydranten` (öffentlich, per WebSocket an die EV): `{[k]: {k, lat, lon, art, info, neu?, letzte:{t, datum, ergebnis ok|mangel|defekt, punkte{schild,frei,kappe,oeffnen,wasser,entleert: true|false|null}, maengel[], bem, druck, fz, wehr, behoben?{t,von,text}}, hist[≤12]}}`. `k` = Koordinate der OSM-Wasserentnahmestelle auf 5 Nachkommastellen. Status: ok · mangel · defekt · faellig (älter als `HYD_INTERVALL_MONATE`, Vorgabe 12) · offen.
- Fahrzeug-App: `POST /api/hydrant/:token` {k?, lat, lon, punkte, ausser, druck, bem, neu} – ordnet den nächsten OSM-Punkt im Umkreis von 25 m zu; ohne Treffer 404, mit `neu:true` wird ein neuer Hydrant angelegt. Ergebnis defekt bei „außer Betrieb“ oder „lässt sich nicht öffnen“, sonst mangel bei mindestens einem ✗. Mail bei Mangel/defekt an `HYD_MAIL` (sonst System-Empfänger). `GET /api/hydrant/:token?lat&lon` → Prüfpunkte, Intervall, bis 15 nicht geprüfte/fällige/mangelhafte Hydranten in der Nähe. `GET /api/wasser/:token` liefert zusätzlich `st: {k: [status, datum, mängel]}` und selbst gemeldete Hydranten.
- EV: `GET /api/hydranten` (Liste, gesamt, intervall, punkte), `GET /api/hydranten.csv` (Excel), `POST /api/hydranten/behoben` {k, text | zurueck | loeschen} (Einsatzleitung/Admin; löschen nur für selbst gemeldete). `GET /api/wasser` enthält selbst gemeldete Hydranten und `hydIntervall`. Alarmmonitor: `wasser[].st`.
- Einstellungen (Gruppe „Hydrantenprüfung“): `HYD_INTERVALL_MONATE`, `HYD_MAIL`.

## Ab 5.10 – Hydrantenfotos, Löschwasser-Abdeckung, Fahrtenbuch

- **Hydrantenfotos:** `POST /api/hydrant/:token` nimmt `bilder: [{typ: image/jpeg|png, daten: base64}]` (höchstens 2, je ≤ 6 MB; Body-Grenze wie Schadensmeldung) → Ordner `hydrantbilder/` (in der Sicherung gespiegelt), Namen in `letzte.bilder`; Fotos hängen an der Mängel-Mail. EV: `GET /api/hydranten/bild/:name`.
- **Löschwasser-Abdeckung:** Einstellung `LW_RADIUS_M` (Vorgabe 300). Kartenebene `loeschwasser` (Canvas `#mvLw`): Kreise um alle Entnahmestellen außer „außer Betrieb“; außer Betrieb rot gestrichelt. `GET /api/wasser` liefert `lwRadius`. `GET /api/loeschwasser` → {radius, quellen, ausserBetrieb, wehren[] (Hydranten je Ortswehr über das nächste Feuerwehrhaus, Status-Zählung), objekteOhne[] (Objekte ohne Entnahmestelle im Umkreis), objekteGesamt}.
- **Fahrtenbuch:** `asue.fahrtenbuch = {[vid]: [{id, t, datum, art fahrt|tanken|stunden, kmStart, kmEnde, km, zweck, ziel, fahrer, liter, adblue, pumpe, aggregat, bem, von, einsatzNr, geloescht?}]}` (≤ 3000 je Fahrzeug). Fahrzeug-App: Zustand enthält `fahrtenbuch` {stand{km,pumpe,aggregat}, letzte[5], zwecke, fristen (≤ 60 Tage bzw. ≤ 1000 km)}; `POST /api/fahrtenbuch/:token` mit Plausibilitätsprüfung (km nicht kleiner, ≤ 2000 km Sprung, Zähler nicht kleiner). Keine Kosten.
- **Fahrzeugfristen:** `asue.fzFristen = {[vid]: {hu, sp, uvv, wartung, pumpePruef, wartungKm, notiz}}`. Gerätedatenbank: `GET /gdb/fahrtenbuch?vid&jahr`, `POST /gdb/fzfristen`, `POST /gdb/fahrtenbuch/loeschen` {vid, id, grund} (markiert als falsch, bleibt sichtbar). Erinnerungslauf: Frist ≤ 28 Tage bzw. abgelaufen, km-Wartung ≤ 500 km → Mail + Push an die Gerätewarte der Ortswehr. Jahresbericht: Abschnitt „Fahrleistung“ (Fahrten, km, Liter je Fahrzeug).

## Ab 5.10.1 – Fahrtenbuch vereinfacht

- Fahrzeug-App: Bei einer Fahrt wird nur der km-Stand eingegeben. Zweck ist vorausgewählt (im Einsatz „Einsatz“, sonst der letzte Zweck), Ziel als Auswahlliste; Datum, Fahrer, Bemerkung klappbar.
- Läuft für das Fahrzeug ein Einsatz, setzt der Server `einsatzNr` immer automatisch (und `zweck` = Einsatz, wenn keiner gewählt ist).
- `fahrtenbuch` im Zustand der Fahrzeug-App zusätzlich: `einsatzNr`, `zweckVorschlag`, `zielVorschlag`, `ziele` (Einstellung `FB_ZIELE`, Vorgabe „Feuerwehrtechnische Zentrale | Ortsgebiet | Aerzen“, plus bis zu 15 zuletzt eingetragene Ziele des Fahrzeugs). Demo-Bau ersetzt „Aerzen“ durch „Musterstadt“.

## Ab 5.10.2 – Abfahrt/Ankunft aus dem Status, Fahrer merken

- Server beobachtet alle 5 s `opta3.status`: Wechsel von Status 2/6 auf einen anderen Status = Abfahrt, zurück auf Status 2 = Ankunft (Zeit aus `opta3.statusZeit`). Gespeichert in `asue.fbLauf = {[vid]: {start, ende}}`, nur für Fahrzeuge (`fahrzeugtyp`). Wird beim Eintragen einer Fahrt mit Zeiten verbraucht.
- `fahrtenbuch` im Zustand der Fahrzeug-App zusätzlich: `lauf`, `fahrerListe` (bis 25 zuletzt eingetragene Fahrer des Fahrzeugs), `fahrerVorschlag`; `letzte[]` mit `start`, `ende`, `fahrer`.
- `POST /api/fahrtenbuch/:token` (Fahrt) nimmt `start`, `ende` (ISO, änderbar; Ankunft nicht vor Abfahrt) → Eintrag `start`, `ende`, `datum` aus der Abfahrt. Das Gerät merkt sich zusätzlich den zuletzt gewählten Fahrer.
- Gerätedatenbank: Zeiten in der Tabelle, CSV mit Spalten Abfahrt/Ankunft.

## Ab 5.10.3 – Fahrtenbuch-Erinnerung, Fahrzeugfristen auf dem Alarmmonitor

- Geht ein Fahrzeug nach einer Fahrt zurück auf Status 2 (`asue.fbLauf[vid].ende` wird gesetzt), schickt der Pi eine Benachrichtigung an die Fahrzeug-App (`pushAnFz`, art `fahrtenbuch`). Einstellung `FB_ERINNERUNG` (an/aus, Vorgabe an; nur wenn `MELDE_PUSH` nicht aus). Die Fahrzeug-App öffnet das Fahrtenbuch dann von selbst (Hinweis „Zurück auf Status 2 – bitte den km-Stand eintragen“, Abzeichen „km“), bis die Fahrt eingetragen ist.
- `fristenFuer()` (Alarmmonitor „Prüffristen“ und Kalender-Abo) enthält jetzt die Fahrzeugfristen aus `asue.fzFristen` (art `fahrzeug`, Erinnerung 28 Tage vorher). Überfällige Fristen erscheinen mit „⚠ überfällig:“ auf dem heutigen Tag.

## Ab 5.10.4 – Gesamttest, Fehlerbehebung

- Gesamttest der Software (Einsatzverwaltung 63 Schritte, Fahrzeug-App 20, ASÜ/Datenbanken 43, Alarmmonitor/Update/Sicherung/Druck/GitHub 27) ohne Programmfehler; Testbericht `docs/TESTBERICHT-5.10.4.md`.
- Behoben: In der Atemschutz- und Gerätedatenbank meldete „Kennwort ändern“ → „Abbrechen“ den Benutzer ab (Anmeldung ging verloren). Jetzt bleibt die Anmeldung bestehen; das Kennwort-Formular wird über `DB.kwNeu` (grund `selbst`) eingeblendet, ohne das Sitzungs-Token zu löschen.

## Ab 5.11 – Excel-Import und -Export der Datenbanken (je Ortswehr)

- Eigener, abhängigkeitsfreier XLSX-Schreiber/-Leser in `server.js` (`xlsxSchreiben`, `xlsxLesen`; ZIP mit deflate über `zlib`, Inline-Strings beim Schreiben, Shared Strings/Inline/Zahlen/Datumsserials beim Lesen; erstes Tabellenblatt).
- `GET /agw/excel?was=gdb|agwp|agwg&wehr=<Ortswehr|leer>&vorlage=1?` (X-AGW-Token; Bereich `geraete` für gdb, sonst `atemschutz`) → .xlsx mit Blatt „Geräte“/„Personen“/„Atemschutzgeräte“ und Blatt „Hinweise“. Dateiname `geraetedatenbank-<Wehr>-<Datum>.xlsx` usw.; `wehr` leer = alle Ortswehren des Kontos. Spalten: siehe `XL_GDB`, `XL_AGWP`, `XL_AGWG` (ID zuerst; Datumsspalten als echte Excel-Datumswerte dd.mm.yyyy; Spalten „nur Anzeige“ werden beim Import ignoriert).
- `POST /agw/excel?was=…&wehr=<Standard-Ortswehr für Zeilen ohne Ortswehr>&einspielen=1?` mit der .xlsx als Body (≤ 12 MB). Ohne `einspielen` nur Prüfung. Antwort `{zeilen, neu, geaendert, fehler:[{zeile,text}], beispieleNeu, beispieleGeaendert, eingespielt}`. Bei Fehlern wird nie eingespielt (alles oder nichts). Zuordnung: ID → vorhandener Eintrag; ohne ID Gerätedatenbank über Inventar-Nr.+Ortswehr, Personen über Nachname+Vorname+Ortswehr, Atemschutzgeräte über Art+Nummer+Ortswehr; sonst neu. Leere Zelle = Wert bleibt (bei Datumsfeldern), „-“ löscht ein Datum. Überschriften werden tolerant erkannt (Umlaute/Satzzeichen egal, Aliasse). Ortswehr- und Bereichsrechte wie überall (`agwDarfWehr`); fremde Ortswehr → Zeilenfehler. Löschen ist über Excel nicht möglich; Gerätedatenbank schreibt Verlaufseinträge („per Excel-Import …“) und ruft `gdbSync()`.
- Oberfläche: Knopf „📊 Excel“ in der Gerätedatenbank (Werkzeugleiste) sowie in der Atemschutz-Datenbank unter Personen und Atemschutzgeräte → Dialog mit Ortswehr-Auswahl, Export, leere Vorlage, Datei prüfen → einspielen. Änderungsprotokoll: „Excel-Export …“ / „Excel-Import …“.
- **Persönlicher Atemschutz-Link (ab 5.11):** `/agt/:token` wird auf dem ASÜ-Server **und** dem Meldeserver bedient (`agtSeite`, GET + POST urlencoded). `agtExterneBasis()` = externe Adresse der Fahrzeug-App (`opta3.settings.meldeBase`, https), sonst Origin der ASÜ-Pi-Adresse; `POST /agw/agtlink` liefert zusätzlich `url` und `extern`. Link-Eintrag `asue.agtLinks[hash] = {pid, t, von, pw?{salt,hash} (PBKDF2 wie AGW-Konten), pwT, sitzungen:{hash: bis}, fehl:{n,bis}}`. Ohne `pw` zeigt die Seite das Formular „Passwort festlegen“ (≥ 6 Zeichen, zweimal); danach Cookie `agt` (HttpOnly, Path = Link-Pfad, 90 Tage bei „merken“, sonst 12 h; höchstens 10 Sitzungen je Link). Falsches Passwort: 8 Fehlversuche → 10 Minuten Sperre + Sicherheitsereignis. `POST /agw/agtlink {pid, aktion:'pwreset'}` löscht Passwort und Sitzungen; `agwPersonAus().linkPw` zeigt, ob ein Passwort gesetzt ist. CSP mit `form-action 'self'`.

## Ab 5.12 – PowerAlarm-Anbindung (JSON-Schnittstelle)

- Grundlage: PowerAlarm-Anleitung Version 2.22, Kapitel 9 (`https://www.poweralarm.de/api/custom/`, POST mit JSON `{apikey, action, …}`; Ersatz `www2.poweralarm.de`). Websocket-Schnittstelle (Kapitel 10, Rückmeldungen) braucht eine Freischaltung durch FITT und ist nicht eingebaut.
- Einstellungen (Gruppe „PowerAlarm“): `PA_API_KEY` (geheim), `PA_URL`, `PA_ALARME` (aus | hinweis | einsatz), `PA_STATUS_SENDEN` (an | aus), `PA_GRUPPE` (vorgewähltes Gruppenkürzel). Stand `pa.stand = {gruppen[], gruppenT, gesehen[], abgefragt, alarmeZuletzt[], letzte[], letzteAbfrage, letzterFehler}`.
- `paAufruf(action, params)`; `GET /api/poweralarm` (op) Stand; `POST /api/poweralarm/pruefen` (admin) = `getgroups`; `POST /api/poweralarm/testalarm {kuerzel}` (admin, PIN); `POST /api/poweralarm/alarm {einsatzId?, kuerzel[], text, einsatzmittel?, objekt?, uebungOk?}` (op, PIN) = `triggergroupalarm` je Gruppe mit `lat/long`, `strasse/hsnr/plz/ort` (aus `e.adresse` zerlegt), `land D`, `einsatzmittel`; Ergebnis-`eventid` wird am Einsatz in `e.paEvents[]` gemerkt, Tagebucheintrag „Nachalarmierung über PowerAlarm …“ (Ausgang an PowerAlarm). `POST /api/poweralarm/update {einsatzId, text}` (op, PIN) = `updategroupalarm` mit `send_info:true` an alle `paEvents`. `POST /api/poweralarm/abfragen` (admin) liest sofort ein. Demo: nichts wird gesendet.
- Alarme einlesen: `paAlarmeAbfragen()` jede Minute (`getalarms`), Kennung = sha256(date|group|text); erste Abfrage markiert nur; danach neue Alarme ≤ 30 min alt → `hinweis`: Systemprotokoll + Broadcast `{type:'paAlarm'}` (Toast in der EV) · `einsatz`: `mailEingang({quelle:'poweralarm', …}, 'PowerAlarm')` – derselbe Weg wie die Leitstellen-Mail (Absender-Art `leitstelle`, keine Echtheitsprüfung, Benutzer „PowerAlarm“), Doppelte über `K_MAIL_GESEHEN` (`pa:<id>`).
- Status senden: nach `fz.status` per WebSocket (nicht `rueck`) ruft `paStatusSenden(vid, st, user)` `setfms` mit `kennung` (8 Ziffern) | `opta` (≥ 20 Zeichen) | `issi` aus dem neuen Fahrzeugfeld `paKennung` (Fahrzeugverwaltung „PowerAlarm-Kennung“). Von PowerAlarm empfangene Status (Schnittstelle) werden nicht zurückgesendet.
- Oberfläche: Verwaltung → Einstellungen → Alarmierung → „PowerAlarm-Anbindung“ (Zustand, Gruppen, Verbindung prüfen, Alarme jetzt einlesen, Probealarm an Gruppe, Protokoll); Einsatz → Übersicht → Kräfteanforderungen „📣 PowerAlarm“ (Dialog `paAlarmDialog`: Gruppen, Text vorbelegt, Einsatzmittel, Lage-Info).
- Gruppen → Ortswehr: `paGruppenZuordnen()` – Name beginnt mit einer Ortswehr (aus `agwWehrenAlle()` + Fahrzeugliste, längster Treffer zuerst), gleiche vierstellige Ortsnummer im Kürzel erbt die Zuordnung, sonst „Gemeinde“; Endung A/I/V → `art` alarm/info/verteiler; manuelle Zuordnung `pa.stand.zuordnung {kuerzel: ortswehr}` über `POST /api/poweralarm/zuordnung` (admin). `GET /api/poweralarm` liefert `gruppen[].ortswehr/art/manuell` und `wehren[]`. Dialog: Ortswehren der alarmierten Fahrzeuge bzw. der Einsatzadresse zuerst/aufgeklappt, Teilnamen „Königsförde-Selxen“ passen zu „Königsförde“.

## Ab 5.13 – Checklisten als Excel, Alarmmonitor mit Ortsfeuerwehren, Hydranten nur eigene Gemeinde, Feuerwehrhäuser nach Gemeinde

- **Checklisten:** `GET /api/checklisten.xlsx` (admin) – ein Tabellenblatt je Checkliste (Blattname = Name, ≤ 31 Zeichen, Sonderzeichen ersetzt, Dubletten nummeriert), Zeile 1 Spaltenköpfe, Zeile 2 „Stichwörter …“ | Muster, ab Zeile 3 ein Punkt je Zeile; Blatt „Hinweise“. `POST /api/checklisten/excel?einspielen=1?` (admin, Einspielen mit PIN) mit der .xlsx als Body: alle Blätter außer „Hinweise“; Zeilen 1–3 mit „Stichw…“ in A liefern das Muster aus B, Spaltenköpfe werden übersprungen, Spalte A = Punkte (≤ 40). Antwort `{listen:[{name,muster,punkte}], fehler[], eingespielt}`; Einspielen ersetzt `opta3.settings.checklisten` komplett (Text `# Name | Muster` + Punkte) und sendet `update`. `xlsxLesen(buf, true)` liefert jetzt alle Blätter `[{name, zeilen}]` (Hilfsfunktion `xlsxBlattZeilen`).
- **Alarmmonitor:** `alarm.wehren = [{name, eigen}]` – Ortswehren der Fahrzeuge im Einsatz (eigene zuerst) plus Ortswehren, deren Name in `mailKraefte` vorkommt; `monitor.html` zeigt sie als Block „Alarmierte Ortsfeuerwehren“ (`.a-wehren`, eigene rot) vor den Fahrzeugen.
- **Hydranten:** `hydGemeindeFilter()` – Hydrant gehört zum nächsten Feuerwehrhaus (≤ 8 km); nur Feuerwehrhäuser von Ortswehren der Heimatgemeinde (`opta3.settings.city`, Fahrzeuge mit `stadt`) zählen. Wirkt auf `GET /api/hydranten` (`gemeinde` in der Antwort), `GET /api/hydranten.csv` und die Wehren-Übersicht in `GET /api/loeschwasser`. Ohne `city` oder ohne Feuerwehrhäuser: kein Filter. Lagekarte und Fahrzeug-App zeigen weiterhin alle Entnahmestellen.
- **Feuerwehrhäuser:** Verwaltung → Feuerwehrhäuser gruppiert nach Gemeinde/Stadt (aus der Fahrzeugliste; eigene Gemeinde zuerst, dann alphabetisch, zuletzt ohne Zuordnung) mit Gruppenzeilen `tr.grp`.

## Ab 5.14 – Ein Einsatz je PowerAlarm-Alarm, Zusammenführung mit der Leitstellen-Mail, Fahrzeuge in der Nachalarmierung

- `paAlarmeAbfragen()`: nur Gruppen mit `art === 'alarm'` (Zuordnung aus `paGruppenZuordnen`, unbekannte Kürzel nach Endung) erzeugen Einsätze; Info/Verteiler werden nur protokolliert. Neue Alarme werden nach normalisiertem Text gebündelt (≤ 10 min Abstand) → ein `mailEingang()`-Aufruf mit Betreff `PowerAlarm-Alarm (<Kürzel…>)` und Text + `Alarmierte Feuerwehren: <Ortswehren bzw. Gruppennamen>` + `Alarmierte Gruppen: …`.
- `mailEingang()`, Leitstellen-Zweig: `alt` = Einsatz mit gleicher `mailNummer` **oder** (laufend, ≤ 30 min alt) gleiches Stichwort (erstes Wort) und gleiche/ähnliche Adresse (normalisiert, Präfix 12 Zeichen) oder Koordinate < 400 m (oder beide ohne Adresse). Beim Treffer werden fehlende `adresse`, `lat/lon`, `mailNummer`, `meldebild` nachgetragen; Tagebuch „Ergänzung per <Quelle> zum Alarm über <andere Quelle>“ / „Nachalarmierung per <Quelle>“; `auto.quelle` = Quelle (`E-Mail` | `PowerAlarm`).
- `POST /api/poweralarm/alarm` zusätzlich `vids[]` (≤ 60): Fahrzeuge/Funktionen werden mit `fz.status A` dem Einsatz zugeordnet (Quelle PowerAlarm), Funkrufnamen in `einsatzmittel`; ohne `kuerzel` nur EV-Alarmierung (`nurEv:true`). Antwort zusätzlich `fahrzeuge[]`, `fahrzeugFehler[]`. Dialog: Fahrzeuge der Heimatgemeinde (`settings.city`) nach Ortswehr, bereits im Einsatz befindliche markiert.
- 5.14.1: `paGemeinde()` (Ortswehren + Fahrzeuge/Funktionen der Heimatgemeinde) ersetzt die Landkreis-weite Liste in `GET /api/poweralarm` (`wehren`, `fahrzeuge`, `gemeinde`). Zuordnung `pa.stand.zuordnung[kuerzel]` = Ortswehr **oder** `fz:<vid>`; `paGruppenZuordnen` liefert `vid`, `fz` (Funkrufname), `vidAuto` (aus Funkrufname im Namen oder Ortswehr + Typ/Funktion, bei Mehrdeutigkeit exakter Typ). Gelesene Alarme tragen `Alarmierte Einsatzmittel: <Funkrufnamen der Gruppen>`; `POST /api/poweralarm/alarm` ergänzt `vids` um die Fahrzeuge der gewählten Gruppen und meldet „bereits im Einsatz …“.
- 5.14.2: `pa.stand.zuordnung[kuerzel] = {wehr, vids[], einsatz: true|false|null}` (alte String-Form bleibt lesbar); `paGruppenZuordnen` liefert `vids[]`, `fz[]`, `einsatz` (null → Vorgabe art === 'alarm'). Alarme einlesen prüft `einsatz` je Gruppe; Nachalarmierung und gelesene Alarme alarmieren alle `vids` der Gruppen. Verwaltung: Spalten „Fahrzeuge / Funktionen“ (Mehrfachauswahl im Dialog) und „Einsatz anlegen“.

## Ab 5.15 – Gerätetausch in der ASÜ: scannen, FTZ oder Elemente, Tauschgerät anlegen mit QR

- `GET /pflege/offen` liefert je Nutzung zusätzlich `name` (Träger), `ende`, `dauer`, `druckA/E`, `csa`, Geräte mit `id/typ/wehr`; außerdem `wehren` (Gemeinde, `agwWehrenAlle()`), `geraete` (alle Atemschutzgeräte mit `zustand` bereit|benutzt|ftz) und `arten`.
- `POST /pflege/geraet {art, nr, typ?, wehr, pruef1?, pruef2?}` (Wehr-Anmeldung): legt ein Atemschutzgerät an oder weist ein vorhandenes (Art + Nummer) der Ortswehr zu (Typ/Termine nur wenn angegeben); `wehr` muss zur Gemeinde gehören. Antwort `{geraet, neu}`; Protokoll „Tauschgerät angelegt/zugewiesen“.
- `POST /pflege/aktion` neue Aktion `elemente` (nur Flasche/LA/Maske gewechselt → Nutzung `erledigt` mit `elemente[]`, `text`), Aktion `ftz` mit `tausch: [{alt:{art,nr}, neu:{art,nr,id}}]` (ersetzt den Freitext `ersatz`, der daraus gebildet wird). Beide speichern einen Schnappschuss `nutzung` {name, beginn, ende, dauer, art, evNummer, einsatzstelle, trupp, funktion, druckA, druckE} am Pflege-Eintrag.
- ASÜ → Tausch/Prüfung: „Gerät scannen“ (Live-Kamera, Foto-Fallback) oder Nummer eingeben → Dialog `tauGeraetDlg` mit allen offenen Nutzungen des Geräts (Einsatz/Übung, Datum/Uhrzeit, Minuten, Druck, Träger, Trupp/Funktion) → „Zur FTZ – Gerät tauschen“ (`tauTauschDlg(n,'ftz',ids)`: je Gerät Tauschgerät vorhanden/neu, Ortswehr-Auswahl Vorgabe = angemeldete Wehr) oder „Nur Elemente tauschen“ (PA bleibt). Neue Geräte → QR-Etikett über `dbDrucken(geraetQR)`. Mehrere offene Nutzungen eines Geräts werden zusammen abgehakt.


## Ab 5.16 – Benachrichtigungen je Zugang auswählbar

- `AGW_BENACHR_ARTEN` (server.js): termin, schaden (geraete), woche (geraete), nutzung (atemschutz, nur Push), pflege (atemschutz, nur Push), kennwort, sicherheit (nur SUPER, nur Push).
- Gespeichert am Gerätewart-Konto als `benachr: { push: {art: bool}, mail: {art: bool} }`; Superadmin unter `store['asue.superBenachr']`. Fehlender Eintrag = eingeschaltet.
- `agwWill(k, kanal, art)` filtert in `agwPush` (Push) sowie bei den Mails Termin-Erinnerung, Wochenüberblick, Schadensmeldung (`gwBenachrichtigen`) und Kennwort-Erinnerung.
- `POST /agw/benachr` `{ push:{…}, mail:{…} }` → `{ ok, benachr }` (Protokolleintrag).
- `konto` in `/agw/daten` und `/gdb/daten` enthält `benachr` und `benachrArten` (nach Bereichen des Zugangs gefiltert).
- ASÜ-Client: `dbBenachrAuswahl()` im Panel 🔔 Benachrichtigungen; Service-Worker-Cache `asue-v63`.


## Ab 5.17 – Benachrichtigungen in Fahrzeug-App und System-Mails auswählbar

- Fahrzeug-App: ab 5.17.1 keine Auswahl – alle Push-Arten gehen immer an alle eingeschalteten Geräte (Cache `fzapp-v36`).
- System-Mails: `SYS_MAIL_ARTEN` (sicherheit, sicherung, pi, mailalarm, verbindung, github, selbsttest, hydrant, schaden). Mail-Konfiguration `systemArten: { adresse: { art: false } }`; `systemEmpfaenger(art)` filtert; `mailSystem` leitet die Art aus dem Schlüssel ab (`sysMailArt`). `GET /api/mail` liefert `sysArten`. Cache `einsatzverwaltung-v118`.


## Ab 5.17.2 – Oberfläche

- `.st-seite` klebt unter Kopf + Unterreitern (`--kopf-h` + neues `--sub-h`, per ResizeObserver auf `#adminSubtabs`), eigene Scrollleiste bei wenig Höhe.
- Handy (≤ 640 px): `#bottomTabs` wird per JS direkt an `<body>` gehängt (WebKit verschiebt `position:fixed` innerhalb des klebenden `header.top`), zusätzlich `translateZ(0)`. Cache `einsatzverwaltung-v119`.


## Ab 5.17.3 – Darstellung

- EV: Handy `table.grid/.dbtab/.ml-abs` als Block mit `overflow-x:auto`, `main{overflow-x:clip}`; `.map-main{order:-1}` ≤ 760 px; Einsatzkopf umbrechend; `.ez-sum` kompakt 641–1180 px; Kopf 641–1360 px kompakt (Verbindung als Punkt), Titel ab 1361 px fest; `.uhr-alarm` unter `--kopf-h`. Cache v120.
- ASÜ: Reiter am Handy als Auto-Spalten in einer Zeile und per JS an `<body>`; DB-Seiten (`data-dbnur`) ohne Reiterleiste; Tablet-Spalten der Übersicht. Cache asue-v64.
- Fahrzeug-App: `.meldungen` unter `--kopf-h` (JS), Untertitel einzeilig. Cache fzapp-v37.
- Alarmmonitor: `einpassen()` verkleinert `.a-links` bis 0,62 em, bis nichts mehr abgeschnitten ist.


## Ab 5.18

- Fahrzeug `bestand: {b, c, d, wasser, schaum, agt}`; `gdbSync` stellt `FZ_BESTAND`-Zeilen („Wasser (Liter): 2000“) vorn in `ausruestung` (mit und ohne Gerätedatenbank) und übernimmt abweichende Zeilen (Umstieg, Excel-Import) per `fzBestandAus`. GDB-Geräte mit solchen Namen werden nicht mehr synchronisiert.
- GDB-Gerät `ausst: 'standard'|'zusatz'` (`gdbAusst`, Vorgabe zusatz); nur Zusatzausstattung geht in `vehicle.ausruestung`. Excel-Spalte „Ausstattung (Standard / Zusatz)“.
- `sicherheitsEreignis`: Arten geraet/superadmin und Schlüssel `nachfehl|…` ohne Mail/Push (nur Hinweis-Zentrale).
- `fzEinsatzFuerMeldung(vid)`: laufender Einsatz oder ≤ 3 h nach `f.bis`/Archiv-`ende`; Schadensmeldung bekommt `einsatzId`, `nachEinsatz`; bei archiviertem Einsatz `berichtNachtrag`.
- `autoEinsatzPruefen`: `e.auto.mensch` (über `einsatzMenschMerken` bei WebSocket-Ops und Lagekarten-`set`) oder TB-Eintrag eines Benutzers ⇒ bearbeitet. Sonst: ausgerückt (3/4/7/8) ⇒ schließen nach `AUTO_RUHE_MS` (10 min) ohne aktives Fahrzeug außerhalb 1/2 (`e.auto.zurueck`); nicht ausgerückt ⇒ nach `AUTO_EINSATZ_ENDE_MIN`.
- `berichtNachEnde(eid, {auto})` nach `einsatz.ende` (WebSocket) und Auto-Schluss: `berichtWehr` (Adresse → nächstes Feuerwehrhaus → erstes eigenes Fahrzeug), `obmAdressen` aus Mail-Konfig `obm {Ortswehr: Adressen}`, `obmBericht` (an/aus); HTML + Text, PDF über `htmlZuPdf`; Ergebnis im Archiv `rec.obmBericht`. `GET /api/mail/konfig` liefert `obmWehren`.
- Client: höchstens 3 Einsatz-Uhren-Erinnerungen (`MAXU`), Cache v121; ASÜ asue-v65.


## Ab 5.18.1

- Einsatzbericht nicht sofort: `berichtVormerken(eid, auto)` legt ihn in `opta3.berichtWarteschlange` mit `faellig = Ende + MELDUNG_NACH_MS` (3 h); `berichteSenden()` minütlich, übersteht Neustarts. Archiv `rec.obmBericht.geplant` bis zum Versand. `berichtNachtrag` entfällt.


## Ab 5.18.2

- `POST /gdb/bestand {vid, bestand}` (Gerätewart, eigene Ortswehr) setzt `vehicle.bestand`, entfernt alte Bestandszeilen aus `ausruestung`, dann `gdbSync()`. `/gdb/daten` liefert `fahrzeuge[].bestand`. In der Einsatzverwaltung sind die Felder bei aktiver Gerätedatenbank nur Anzeige. Cache asue-v66, einsatzverwaltung-v123.


## Ab 5.19 – Kalender der Gerätedatenbank

- `GET /api/gdb/kalender?wehr=` (Gerätewart) → `{wehren, wehr, termine[], links{https, webcal, google, download, oeffentlich}}`; `gdbKalTermine(wehr, von, bis, einzeln)` = `fristenFuer` ohne Atemschutz, Geräte einzeln (mit `gid`, `ueber`), plus geplante Rückkehr außer Dienst.
- `POST /api/gdb/kalender/neu {wehr}` erneuert den Token. Tokens in `asue.gdbKalender {Ortswehr: hex36}`.
- iCal ohne Anmeldung: `/kalender/geraete/<token>.ics` auf 8080, 8081 (öffentlich) und 8082 (`/api/kalender/geraete/…`); `?download=1` als Anhang. Erinnerung 7 Tage vorher, UID `…@einsatzverwaltung`. Link-Basis: `meldeBase` (https), sonst die aufgerufene Adresse.
- Client: Unterreiter `gkal` (`gkalHTML`, `gkalLaden`), Cache asue-v67.


## Ab 5.20 – Gerätedatenbank

- `GDB_STATUS.fehlt`; `gdbLebend()` = ohne `ausgesondert` (Sync, Fristen, Kalender, Wochenüberblick, Monitor, Fahrzeug-App).
- Gerät: `raum` (Geräteraum, Excel-Spalte), `mangelFrist {bis, text, t}`, `ausgesondert {d, grund, von, t}`, Verlaufseinträge mit `bilder` (gm…-Dateien in SCHADEN_DIR, `/gdb/bild/:name`) und `stapel`.
- `POST /gdb/aktion`: `mangel` (+ `frist`, `bilder[]`), `fehlt`, `aussondern` (Text Pflicht), `wiederaufnehmen`; `reparatur` löscht `mangelFrist`.
- `POST /gdb/stapel {datum, pruefart, pruefer, eintraege[{id, ergebnis, text}]}` → Prüfungen + Sammelprotokoll `asue.gdbStapel`; `GET /gdb/stapel/:id`.
- `GDB_PRUEFLISTEN` erweitert (Feuerwehrleinen, Druckschläuche, Hydraulische Rettungsgeräte, Tragkraftspritze, Sprungpolster, Absturzsicherung, Motorkettensäge, Wärmebildkamera).
- `fzAmpel(vid)` → `{farbe, gruende}`; in `/gdb/daten` je Fahrzeug (`ampel`, `baujahr`, `kennzeichen`), dazu `lager`, `raeume`.
- Lager: `asue.gdbLager {[wehr]: [...]}`, `POST /gdb/lager {wehr, aktion: setzen|buchen|loeschen}`.
- `GET /gdb/lebenslauf/:id` (Gerät, Meldungen, Protokolle); `GET /gdb/uebersicht` (je Ortswehr Fahrzeuge mit Ampel/Baujahr/Frist/Bestand, Material, Lager knapp).
- Fahrzeug-App: `POST /api/schaden/:token` mit `fehlt: true` → Gerät `fehlt`, Meldung `fehlt`. Fahrzeug `baujahr` (Einsatzverwaltung, Excel).
- Client: Unterreiter `glager`, `guebers`; Offline-Warteschlange `asue.gdbOffline`, Cache `asue.gdbCache`. Caches asue-v68, fzapp-v38, einsatzverwaltung-v124.

## Ab 5.21 – Vereinfachung der Oberfläche

- `POST /gdb/geraet`: gleiche Inventar-Nr. (ohne Groß-/Kleinschreibung) in derselben Ortswehr bei einem nicht ausgesonderten Gerät → `409 {error:'dublette', text, dublette:{id, bez}}`; mit `trotzdem: true` wird trotzdem gespeichert.
- Einsatzverwaltung (Client): persönliche Ansicht in `localStorage['opta3.ansicht.<benutzer>'] = {karten[], ausgaben[], tabs[]}` (ausgeblendete IDs); `ezReiterKompakt` mit Stufe `mittel` (≥ 641 px); `ADMIN_GRUPPEN` für die Verwaltung; `printHTML` mit Kopf `.dr-kopf` und `@page`-Fußzeile (nicht bei eigenem `@page size`).
- Gerätedatenbank (Client): Filter `DB.gnb` (nicht bereit), `DB.gleih` (Verleih überfällig); geöffnete Fahrzeuge `localStorage['asue.gdbAuf']`; Reiter im Gerätedialog `DB.gdTab`.
- Fahrzeug-App: `body.fz-einsatz` bei laufendem Einsatz, Zusatzbereiche in `#mehrHost`.
- Bugfix: Umbenennen von Demo-Einsätzen (Eingabedialog) schlug fehl, weil der Superadmin-Schalter im falschen Dialog verdrahtet war.
- Caches einsatzverwaltung-v125, asue-v69, fzapp-v39.

## Ab 5.22 – Ampel in der Fahrzeug-App

- `GET /api/melde/:token` (Fahrzeug-App-Stand) enthält `ampel: {farbe: 'gruen'|'gelb'|'rot', gruende[]}` aus `fzAmpel(vid)`, sobald die Gerätedatenbank Geräte hat (sonst `null`).
- Fahrzeug-App: `#ampelHost` im Reiter „Einsatz“, bei Rot automatisch aufgeklappt. Caches fzapp-v40, einsatzverwaltung-v126.

## Ab 5.23 – Gerätedatenbank

- Gerät: `haltbar` (Datum); `reparatur {stufe: gemeldet|werkstatt|ersatzteil, werkstatt, seit, ab, bis, von}` über `POST /gdb/aktion {aktion:'repstufe', stufe, werkstatt, bis}`; `reparatur`/`aussondern` löschen sie. `gdbRepZuLange`: `bis` überschritten oder ohne `bis` > 28 Tage.
- `fzAmpel`: Haltbarkeit abgelaufen → rot, ≤ 30 Tage → gelb. Kalender-Arten `haltbar`, `rep`. Wochenüberblick mit Haltbarkeit und „zu lange in Reparatur“.
- Vorlagen: `asue.gdbVorlagen` (sonst `GDB_VORLAGEN_STD`), in `/gdb/daten` als `vorlagen`, `vorlagenStd`; `POST /gdb/vorlagen {aktion: speichern|loeschen|standard, name, bez, kat, pruefArt, pruefMonate, ausst, haltbarMonate, hersteller, typ}`.
- Monatsliste: am 1. ab 7 Uhr je Gerätewart (Benachrichtigungsart `monat`, Stand `asue.gdbMonat`), HTML-Mail; `POST /gdb/monatsliste` → `{ende, zeilen}` bzw. mit `senden: true` Mail an das eigene Konto.
- `GET /gdb/jahresbericht?jahr=` → je Ortswehr Kennzahlen aus dem Geräteverlauf.
- Fahrzeug-QR: `/geraete#GDBFZ:<vid>` öffnet die Gerätedatenbank gefiltert auf das Fahrzeug.
- 404-/Fehler-Handler der ASÜ-API stehen jetzt hinter den letzten Routen. Caches asue-v70, einsatzverwaltung-v127.

## Ab 5.24 – Einheitliche Begriffe, Bestand in der Ausrüstung

- `asue.gdbBegriffe = [{name, alias[]}]` (sonst `GDB_BEGRIFFE_STD`), in `/gdb/daten` als `begriffe`. `gdbBegriffNorm` (Kleinschreibung, Umlaute, ohne Leer-/Satzzeichen), `gdbBegriffFinde(t)`, `gdbBegriffVorschlaege(t)` (Levenshtein/Teilwort).
- `POST /gdb/geraet`: bekannte Schreibweise → Begriff; unbekannt → `409 {error:'begriff', vorschlaege[]}`; mit `begriffNeu: true` wird der Begriff aufgenommen. Unveränderte alte Bezeichnungen bleiben erlaubt. Excel-Import gleicht nur an.
- `POST /gdb/begriffe {aktion: neu|loeschen|alias|standard|vereinheitlichen, name, alias, von[]}` – `vereinheitlichen` benennt Geräte der eigenen Ortswehren um und merkt die alte Schreibweise als Alias.
- Einsatzverwaltung: `equipmentCatalogMitBestand()`, `fzBestandWert(v,k)`, `bestandTreffer(q)`; Suchbox „Ausrüstung“ mit Summen-Kasten `.bst-box`, Karten mit `.card-bestand`. Caches asue-v71, einsatzverwaltung-v128.

## Ab 5.25 – ASÜ vom Pi, eigenständige Ausgabe

- ASÜ (Client): `CFG.solo` (asue-config.js `{solo:true}`) → `SOLO`: keine Anmeldung (lokale Identität `localStorage['asue.solo'] = {name, zusatz, appName, wappen, wappen2}` als Daten-URLs), keine Pi-Erkennung/Übergabe/Abgleich, Reiter `tau`/`db` und Sammel-App ausgeblendet; Einstellungen-Export (`asue-einstellungen`), Einsatz-Sicherung (`asue-sicherung`).
- `asueSoloDateien()` baut aus `asue/index.html` die eigenständige Ausgabe (neutrales Kopf-Wappen, eigener Service-Worker-Cache `asue-solo-v…`, Manifest, README.md, .nojekyll, leere benutzer.js).
- `POST /api/asue/github/paket` → ZIP der eigenständigen Ausgabe; `ghVeroeffentlichen` veröffentlicht nur noch diese. Alte GitHub-Einstellungen (ohne `solo`) gelten nicht mehr (`veroeffentlichen.alt`).
- `POST /api/asue/adresse {adressen}` (Admin, PIN) speichert die Internetadresse des Pi (`settings.asueGithub.adressen`); `zugAppLink` nutzt sie statt der GitHub-Seite.
- Caches asue-v72, einsatzverwaltung-v129.

## Ab 5.26 – Umzugshinweis

- `asue-config.js` mit `umzug: <neue Adresse>` → ASÜ zeigt Banner `#umzugBanner`, Hinweis auf der Anmeldeseite und einmal täglich `umzugDlg()` (nicht bei Trupps unter Atemschutz; `localStorage['asue.umzugGezeigt']`). Link mit `?u=<benutzer>`.
- `asueUmzugDateien()` = bisheriges Paket (`asueGhDateien`) mit `umzug`; `POST /api/asue/github/umzug` (Admin, PIN): ZIP oder `{aktion:'veroeffentlichen'}` in das alte Repository (`ghAltCfg()`: alte Einstellung bzw. `altGh`, wird beim Speichern der neuen Einstellungen aufbewahrt). `ghStand()` mit `altRepo`, `altToken`, `umzugLetzte`.
- Caches asue-v73, einsatzverwaltung-v130.

## Ab 5.27

- Rollen `gbm`, `obm` (mit `wehren[]`); `istOp` schließt sie ein; `nurWehren(u)` filtert `/api/archiv`, `/api/archiv/:id` (403), `/api/auswertung`, `/api/archiv-statistik`.
- Archivzeilen mit `wehren`, `nb`, `ergebnis`, `objekt`, `bma`, `geschwaerzt` (`archivZeileErg` ergänzt alte Zeilen). `ev.archivAendern(id, fn)`.
- `POST /api/archiv/:id/nachbesprechung {ergebnis, bmaHinweis, teilnehmer, gut, besser, material, personalFehlt, personal, sonstiges, massnahmen[{text, wer, erledigt}]}`; Ergebnisse `NB_ERGEBNIS`.
- `GET /api/archiv-statistik?jahr=` → `{wehren[], gesamt, bma[], nurWehren}`.
- `GET /api/agt-status` (op) → Personen der Atemschutz-DB nur mit Name und Status.
- Einstellung `DATENSCHUTZ_MONATE`; `archivSchwaerzen(rec)` (Personen aus `demo.personenSammeln`, TEL/MAIL/KENNZ, Fotos entfernt, `rec.geschwaerzt`), Lauf nach 5 min und alle 12 h; `GET /api/datenschutz/stand`, `POST /api/datenschutz/jetzt` (Admin, PIN).
- Fahrzeug-App: `ziel {adresse, lat, lon}` (nur `MELDE_KARTE=an`); `POST /api/nachricht/:token {text, lage:true}` → Tagebuch „LAGEMELDUNG“ und `e.lage`.
- Caches einsatzverwaltung-v131, fzapp-v41.

## 5.28
- Auftragsstatus `erkundung` (zwischen `offen` und `disponiert`).
- Op `auftrag.erkunden {einsatzId, id, vid, hinweis?}` – nur bei `offen`; setzt `a.erkunder {vid, seit, user}`, `a.fahrzeuge[vid].rolle='erkunden'`, `zeiten.erkundung`, Nachricht an die Fahrzeug-App mit Erkundungshinweis.
- Op `auftrag.erkundet {einsatzId, id, ergebnis?, prio?}` – gibt den Erkunder frei, setzt `a.erkundet {t, vid, fz, ergebnis, user}`, `zeiten.erkundet`, Status zurück `offen`.
- Nachrichten/Lagemeldungen/Fotos des Erkunders → sofort ins Auftragstagebuch (`auto:'nachricht'`, nlog `aufTb`); Erkunder frei ohne Abschluss → `offen` (Vermerk „Erkundung abgebrochen“); `auftrag.fz` während der Erkundung → `disponiert`.
- Cache einsatzverwaltung-v132.

## 5.28.1
- Nur Oberfläche (Priolage-Kästchen, fester Kopf im Auftragsfenster `.auf-fix`, Gerätezeile `tr.gd-klick data-gdb=auf`). Caches einsatzverwaltung-v133, asue-v74.

## 5.29
- `FZ_BESTAND` + `strom` (kVA, 0,1), `lichtI`, `lichtE` (Ja = 1); `fzBestandNorm(key, x)`; Ausrüstungszeilen „Stromaggregat (kVA): 13,5“, „Beleuchtung intern: ja“. `POST /api/gdb/bestand` nimmt die neuen Schlüssel an. Caches einsatzverwaltung-v134, asue-v75.

## 5.30
- Nur Oberfläche: `gdbNamenListe` (ASÜ/GDB, Begriffe + Geräte-Bezeichnungen, Normalisierung `gdbNorm`), Ausrüstungs-Chips in den Fahrzeugstammdaten. Caches einsatzverwaltung-v135, asue-v76.

## 5.31
- `POST /api/gdb/fzstamm {vid, hersteller, aufbau, baujahr, kennzeichen}` → Fahrzeug `hersteller`, `aufbau` (auch im EV-Fahrzeugformular).
- `POST /api/gdb/material {vid, liste:[{name, menge, einheit, platz}]}` → `v.material`; Fahrzeug-App `GET /api/state` liefert `material`; Verbrauchsliste der App stellt `v.material` voran.
- `GET /api/gdb/stand` → `{t}` (Hash über Geräte, Fahrzeuge, Status, Lager, Meldungen, außer Dienst …; Client prüft alle 15 s). `datenStand` wird in `saveStore()` gesetzt.
- `POST /api/gdb/feedback` (Gerätewart-Sitzung) → wie `/api/feedback`, App „Gerätedatenbank“. `/gdb/daten` liefert `feedback` (Feedback-Modus an).
- `gdbStromGeraet(v, kva, von)`: Gerät `auto:'strom'` (bez Stromerzeuger, Prüfart DGUV 305-002, 12 Monate); `gdbSync` zeigt es nicht zusätzlich, bei defekt/ausgeliehen wandert die Zeile „Stromaggregat (kVA)“ nach `ausruestungNv`.
- Lager: Feld `platz`. Testzugang `window.__A(code)` in der ASÜ/GDB-Seite.
- Caches einsatzverwaltung-v136, asue-v77, fzapp-v42.

## 5.32
- Nur Oberfläche: `gdbFzDatenDlg(vid, tab)` (Daten/Beladung/Fristen; speichert über `/gdb/fzstamm`, `/gdb/bestand`, `/gdb/fzfristen`), `gdbFbDlg` ohne Fristen, mit Filtern Monat/Fahrer/Zweck/Ziel. Caches einsatzverwaltung-v137, asue-v78.

## 5.33
- Gerät: Feld `fach` (`POST /api/gdb/geraet`). Beladeplan `gdbBeladeplan` (Optionen, localStorage `asue.gbp`) → `gdbBeladeplanDruck`. EV-Fahrzeugformular ohne Baujahr/Hersteller/Aufbau. Caches einsatzverwaltung-v138, asue-v79.

## 5.34
- Fahrzeug-App: Schnelltexte (`schnell`) werden nicht mehr angezeigt; `smText` unter der Geräteauswahl. Cache fzapp-v43.

## 5.35
- `schadenInfo`: Beladung (b/c/d/agt mit Anzahl, lichtI/lichtE) als Auswahl, Bestandszeilen ausgeblendet; `verbrauch` mit „Schaummittel (Liter)“ bei `bestand.schaum`; `state.material` ergänzt Schaummittel. EV `ausrTxt()`. Cache einsatzverwaltung-v139.

## 5.36
- `fzMaterial(v)` = `v.material` + Schaummittel aus `bestand.schaum`; `schadenInfo().verbrauch` und `state.material` nur daraus (keine Ortswehr-Liste mehr). Cache fzapp-v44.

## 5.37
- Fahrzeug-App: Einsatz-Reiter in `.tb-l` / `.tb-r` / `.tb-m`, ab 820 px Raster „l r / m r“; `#matHost` entfernt. Cache fzapp-v45.

## 5.38
- Fahrzeug-App: Reiter Nachrichten ab 820 px Raster „t n / s n“ (Senden links, sticky; Verlauf rechts). Cache fzapp-v46.

## 5.39
- Fahrzeug-App: `#kpGps`/`#kpPush` im Kopf verschieben `#klStandort`/`#klPush` in das Fenster `#kpOver` (und zurück); auf der Seite ausgeblendet. Nachrichten-Raster „n t / n s“. Cache fzapp-v47.

## 5.40
- `POST /api/agw/benachr {push, mail, vorlauf:{push:{gp,fz}, mail:{gp,fz}}}` (Wochen 0–26, Vorgabe gp 1 / fz 4); `agwVorlauf(k)`, `agwVorlaufOk(k, kanal, punkt)`; Erinnerungspunkte mit `typ` (gp|fz) und `tage`, Horizont 26 Wochen. Cache asue-v80.

## 5.41
- `POST /api/agw/mail {mail}` (eigener Zugang, nicht Superadmin; leer = entfernen); `/gdb/daten` konto `istSuper`. Cache asue-v81.

## 5.42
- Standorte: `num()` wertet leer/null als null (vorher 0); Start-Reparatur 0,0 → null. Client `fhAbgleich()`.
- Gerätewarte: `agwLeiter(wehr)` (explizit `k.leitung[]`, sonst ältester aktiver Zugang der Ortswehr), `agwLeitungVon(k)`; `GET /api/agw/team`, `POST /api/agw/team {aktion: neu|kennwort|sperren|entsperren|loeschen|uebergeben, …}`; konto `leitung`. Caches einsatzverwaltung-v141, asue-v82.

## 5.43
- monitor.html: Abschnitte „Kräfte laut Stichwort“ und „Weitere Kräfte laut Alarmierung“ ausgeblendet.

## 5.44
- Standorte: Feld `stadt`; `POST /api/standorte` entfernt Doppelte je stadt|ortswehr (`fhStadtServer`, Kreis/THW/DRK … zählen nicht als Gemeinde). Client `fhPaare`, `fhKey`. Cache einsatzverwaltung-v142.

## 5.45
- ASÜ/GDB: `.db-bereich` (Menü der Bereiche) im Kopf, auf dem Handy statt `.db-sub`. Cache asue-v83.

## 5.46
- `mailEingang`: Text mit `Status Änderung X => Y` → `fz.status` für das Fahrzeug, dessen Funkrufname im Text steht (längster Treffer), Rückgabe ohne Einsatz.

## 5.47
- Einstellung `PA_WS_KEY` (geheim). `paWsStart()` verbindet `wss://www.poweralarm.de:8001` (Test: env `PA_WS_URL`), sendet `{apikey}`, erwartet `{accepted:true}`, Ping 60 s, Neuaufbau mit Backoff bis 5 min. `status_summary` gemerkt, feedback/news ignoriert, Objekte mit Fahrzeugfeld + Status → `externVerarbeiten(o, 'PowerAlarm (Websocket)')`. `GET /api/extern/einstellung` → `ws {…}`. Cache einsatzverwaltung-v143.

## 5.48
- `externVerarbeiten`: Kandidatenfelder (gewähltes Feld, bezeichnung, opta, name, funkrufname, kennung, issi), Nullen-Kennungen ignoriert, Funkrufname als Teilstring; gleicher Status → „unverändert“ ohne Protokoll.

## 5.49
- `fz.status` mit `extern:true`: bei alt = A im Einsatz nur 3/4 (sonst Fehler `noch_alarmiert`); gesetzt von `externVerarbeiten` und Mail-Statusmeldung. `autoEinsatzPruefen`: nur Fahrzeuge mit Status 3/4/7/8 in den Zeiten zählen als unterwegs.

## 5.50
- ASÜ/GDB: Mehr-Knöpfe mit `.mz-zu`/`.mz-auf`. Cache asue-v84.

## 5.51
- `extern.status.nurFz` (Vorgabe true): `externVerarbeiten` überspringt Personen/Funktionen (OPTA/Bezeichnung bzw. Fahrzeugtyp). Cache einsatzverwaltung-v144.

## 5.52
- `nurFz`: nur Klarnamen (keine Ziffern in allen Kennfeldern, nur Buchstaben) werden übersprungen; Fahrzeugtyp-Prüfung entfernt. Cache einsatzverwaltung-v145.

## 5.53

- Op `ablauf` (Rolle wie `check`): `{einsatzId, plan:'ELW'|'ÖEL', platz, titel, von, aktion}`.
  - `aktion:'person'` mit `person`.
  - `aktion:'schritt'` mit `schritt` und `an`.
  - `aktion:'wehren'` mit `wehren:[…]`.
  - `aktion:'hilfe'` mit `feld` (abschnitte, kommunikation, schwerpunkt, nachforderungen), `text` und optional `anhaengen`.
- Gespeichert wird in `e.ablauf = {plaetze:{'<plan>:<platz>':{person, wehren, erledigt:{schritt:{t,user}}}}, hilfe:{…}}`. Es gibt einen Tagebuch-Vermerk.
- Die Vorlagen stehen in `settings.ablaufplaene` (`{ELW, 'ÖEL'}: {titel, plaetze:[{id, titel, wer, schritte[], wehrFilter}]}`). Ohne Eintrag gilt die eingebaute Vorgabe.

## 5.54

- `POST /asue/api/gdb/fzapp` mit `{vid, schaden, verbrauch, check, checkNachEinsatz, beladung, ampel, fristen, checkPunkte[]}` (Gerätewart, eigene Ortswehr). Wird am Fahrzeug als `v.fzApp` gespeichert; fehlende Werte zählen als an.
- Fahrzeug-App `/api/state`:
  - `schaden.app` enthält die Schalter.
  - `schaden.check` ist die eigene Liste, sonst die Liste der Ortswehr.
  - `checkFaellig`, `beladung`, `ampel` und `fahrtenbuch.fristen` sind leer, wenn sie ausgeschaltet sind.
  - `schaden` ist `null`, wenn alle vier Meldearten aus sind.
- `POST /api/fzcheck/:token` antwortet mit 403, wenn der Check aus ist.

## 5.55

- `settings.ablaufplaene.<plan>.erklaerung` und `plaetze[].erklaerung` (Text). Ohne Eintrag gilt die eingebaute Vorgabe. Der Server ist unverändert.

## 5.56

- Nur die Oberfläche hat sich geändert (Editor der Ablaufpläne); das Datenformat bleibt gleich.

## 5.57

- Keine neuen Endpunkte. Die Karte `betreuung` nutzt `e.ablauf.plaetze[...].wehren`. Der automatische Name kommt über Op `ablauf` mit `aktion:'person'`.

## 5.58

- `GET /elw` liefert `public/index.html`. Der Client erkennt den Pfad und startet die ELW-Info-Ansicht (`elwStart`, nur lesen; die Daten kommen über den normalen Live-Sync). Es gibt keine neuen API-Endpunkte. Für das Tablet ist ein Benutzer mit der Rolle Betrachter empfohlen.

## 5.59

- `/geraete` und `/atemschutz` setzen jetzt auch das Favicon (`icon-<bereich>-192.png`). Neue Dateien `asue/icon-geraete-192.png` und `asue/icon-geraete-512.png`.

## 5.60

- Neue Icons in `public/icons/` (`icon-192.png`, `icon-512.png`, `apple-touch-icon.png` 180×180). Der Cache heißt jetzt `einsatzverwaltung-v152`.

## 5.61

- `POST /api/schaden/:token`, `/api/verbrauch/:token` und `/api/beladung/:token` antworten mit 403 `{error:'aus'}`, wenn die Funktion in `v.fzApp` ausgeschaltet ist.
- Op `ablauf` mit `aktion:'person'` kennt zusätzlich `uebergabe:true`; der Tagebuchtext lautet dann „übergeben von … an … (Ablöse)“.
- `/elw?monitor=1` startet die Großanzeige.

## 5.62

- Nur die Oberfläche hat sich geändert. In „Meine Ansicht“ gibt es neu das Feld `direkt` (lokal auf dem Gerät).

## 5.63

- Nur die Oberfläche hat sich geändert (Fahrzeugkarte `.card-mitte`; CSS aus 5.62 an die richtige Stelle verschoben).

## 5.64

- Op `objekt.speichern`: neues Feld `merkmale[]` (je bis 40 Zeichen, höchstens 20).
- Op `kontakt.speichern` und `kontakt.import`: neue Felder:
  - `kategorie` ('person'|'dienst'|'geraet'|'behoerde')
  - `stichworte` (Text, mit Komma getrennt)
  - `ort`
  - `rund` (bool, 24 h erreichbar)
- `einsatz.kontakt` übernimmt diese Felder in den Einsatz.

## 5.65

- Nur die Oberfläche hat sich geändert (Formular für Objekte).

## 5.66

- Nur die Oberfläche hat sich geändert (Karte Ablaufplan).

## 5.67

- Nur die Oberfläche hat sich geändert (`.modal>h2` und Fahrzeug-App `.fb-box h2` bleiben beim Scrollen stehen). Caches: `einsatzverwaltung-v159`, `fzapp-v49`.

## 5.68

- Nur die Oberfläche hat sich geändert (Gerätedatenbank `.gd-unten` bis 1100 px Breite). Cache `asue-v90`.

## 5.69

- Neuer Server-Schlüssel `opta3.extStatus` `{vid:{st,t}}`: Er wird bei jeder Statusmeldung von außen (`fz.status` mit `extern:true`) gesetzt, auch wenn die Meldung wegen „noch alarmiert“ ignoriert wird.
- Einsatzende: Ein aktives Fahrzeug auf „A“ mit `extStatus` geht auf den gelesenen Status zurück (wenn dieser nicht A/3/4 ist), sonst auf 2.

## 5.70

- Nur die Oberfläche der Gerätedatenbank hat sich geändert. Cache `asue-v91`.

## 5.71

- Nur die Oberfläche der Gerätedatenbank hat sich geändert. Cache `asue-v92`.

## 5.72

- Nur die Oberfläche der Gerätedatenbank hat sich geändert (`.gd-d-pr`); eine überzählige CSS-Klammer aus 5.71 ist entfernt. Cache `asue-v93`.


## 5.73
Nur Oberfläche (GDB-Reiterleiste am Desktop), keine Server-Änderung. Cache asue-v94.

## 5.74
Nur Oberfläche, Cache asue-v95.

## 5.75
Nur Oberfläche, Cache asue-v96.

## 5.76
Nur Oberfläche, Cache asue-v97.

## 5.77
Nur Oberfläche, Cache einsatzverwaltung-v161.

## 5.78
Nur Oberfläche, Cache asue-v98.

## 5.79
- `POST /api/agw/leitung` (Admin, PIN-bestätigt) `{wehr, id}` – setzt die Leitung der Ortswehr auf den Zugang `id` (muss aktiv und der Ortswehr zugeordnet sein); entfernt die Ortswehr aus `leitung` aller anderen Zugänge. Protokolleintrag. Cache einsatzverwaltung-v162.

## 5.80
- `POST /agw/geraet` (ASÜ-API): bei `art:'geraet'` zusätzlich `la` und `flasche` (Geräte-IDs gleicher Ortswehr und passender Art, sonst leer). Ein Teil gehört nur zu einem Pressluftatmer; bei Neuzuordnung wird es beim bisherigen entfernt. Cache asue-v99.

## 5.81
- `POST /agw/geraet`: bei `art:'geraet'` Textfelder `laNr`, `flNr` (statt der IDs `la`/`flasche` aus 5.80, entfällt); `typ` optional (bleibt erhalten, wenn nicht gesendet). Neue Geräte ohne Termine übernehmen die zuletzt gesetzten Termine der Ortswehr (`asue.agwTermineStd`).
- `POST /agw/geraete/termine`: `wehr` optional bzw. `'*'` = alle eigenen Ortswehren; `arten` optional (Vorgabe: alle). Speichert die Termine je Ortswehr als Vorgabe. Cache asue-v100.

## 5.82
QR-Format `ASUEG1` bei `a:'geraet'` zusätzlich `l` (LA-Nr.) und `f` (Flaschen-Nr.); `t` (Typ) entfällt. Nur Oberfläche, Cache asue-v101.

## 5.83
- Personen und Atemschutzgeräte haben `kz` (4-stellig, eindeutig über beide), wird beim Speichern bzw. beim Abruf vergeben. `GET /agw/tauglich` liefert je Person zusätzlich `z`.
- QR-Formate `ASUEP1`/`ASUEG1` mit `z`.
- `GET /vendor/zxing.js` (ASÜ-Port): ZXing 0.21.3, vom Pi einmal von jsDelivr/unpkg geholt und als `zxing-0.21.3.min.js` neben server.js gespeichert; 404 solange nicht verfügbar. Cache asue-v102.

## 5.84
Nur Oberfläche (ASÜ: `/agw/tauglich` jede Minute, bei Sichtbarkeitswechsel und beim Öffnen eines Trupps). Cache asue-v103.

## 5.85
Nur Oberfläche (ASÜ), Cache asue-v104.

## 5.86
Nur Oberfläche (ASÜ), Cache asue-v105.

## 5.87
ASÜ übernimmt `#asuek=<JSON {k,u} URL-kodiert>` aus der Adresse (wie QR `ASUEK1`) und entfernt den Hash danach. Caches einsatzverwaltung-v163, asue-v106.

## 5.88
`GET /agw/tauglich`: ruhend gemeldete/ausgeschiedene Personen mit `ok:false` und Grund „ruhend gemeldet / ausgeschieden“. Cache asue-v107.

## 5.89
`POST /einsaetze/:code/fuehrung`:
- `{an}` (nur führendes Gerät) legt `fuehrung.angebot = {an, anName, t}` an, wechselt die Führung **nicht**.
- `{angebot:'annehmen'|'ablehnen'}` (nur das angebotene Gerät, 10 Min. gültig) – Annehmen setzt die Führung (`wie:'uebergeben'`), Ablehnen setzt `fuehrung.abgelehnt`.
- `{angebot:'zurueck'}` (führendes Gerät) zieht das Angebot zurück.
- `{uebernahme, benutzer, passwort}`: akzeptiert Admin **oder** den ASÜ-Benutzer des führenden Geräts (`fuehrung.wehr.user`). Cache asue-v108.

## 5.90
Nur Oberfläche (ASÜ), Cache asue-v109.

## 5.91
Nur Oberfläche (ASÜ; Einsatz-Ende über `PUT /einsaetze/:code/einsatz` war serverseitig schon auf das führende Gerät beschränkt). Cache asue-v110.

## 5.91
`asue.doku` speichert je Mitglied zusätzlich `laNr`, `flascheNr`, `maskeNr`, `druckA`, `druckE` (gehen in `asue.nachweis` als `la`, `flasche`, `maske`, `druckA`, `druckE`). Cache asue-v110.

## 5.92 – Träger-App
Speicher `asue.traeger` {pid: {salt, hash, muss, aktiv, pwT, tok[{h,bis}], termine{strecke,g26}, schulung{gesperrt, versuche[]}, push[], erinnert{}}}. Seite `GET /traeger` (asue/traeger.html, Manifest traeger.webmanifest).
- `POST /api/agw/traeger/login {user: 4-stellige Nummer, pw, merken}` → `{token, muss}` (Kopf `X-TR-Token` für alle weiteren Aufrufe; 5 Fehlversuche/10 min).
- `GET /api/agw/traeger/ich` – Name, Wehr, Status (agwStatus), Regeln, Termine, Schulung, Push-Key, Verlauf.
- `POST /api/agw/traeger/kennwort {alt, neu}`, `POST …/termine {strecke, g26}`, `POST …/push {abo}|{aus,endpoint}`, `POST …/abmelden`.
- `POST /api/agw/traeger/schulung {bestanden, punkte, max, version}` – bestanden: `nachweise.unterweisung = {d: heute, quelle: 'Online-Schulung'}`; nicht bestanden: gesperrt (403 bei weiteren Versuchen) + Push an die Atemschutzgerätewarte der Ortswehr.
- `POST /api/agw/traeger/zugang {pid, aktion: anlegen|reset|sperren|entsperren|freigeben}` (AGW-Sitzung, Bereich Atemschutz, eigene Ortswehr) – anlegen/reset liefert `{user, passwort, pfad}`.
- `/agw/daten`: Personen enthalten `app` (aktiv, muss, letzte, termine, gesperrt, versuche, push).
- Erinnerungen `trErinnern()` alle 6 h. Cache asue-v111.

## 5.93
- `GET /api/schulungen` (Admin) → `{aktiv, liste[{id,titel,jahr,t,von,dateien,groesse}]}`.
- `POST /api/schulungen/upload?datei=&titel=&jahr=&aktivieren=1` (Admin, PIN-bestätigt, Rohdaten bis 80 MB): ZIP (index.html wird gesucht, gemeinsamer Ordner abgeschnitten) oder HTML → `schulungen/<id>/`.
- `POST /api/schulungen {aktion: aktivieren|deaktivieren|loeschen, id}`.
- ASÜ-Port: `/schulung/` liefert die aktive Schulung (sonst wie bisher `asue/schulung/`), `/schulung-vorschau/<id>/` jede importierte. Caches einsatzverwaltung-v164, asue-v112.

## 5.94
`POST /agw/nachweis/manuell {art, datum, zeit, dauer(min), einsatzstelle, evNummer, csa, trupp, personen:[{pid, geraet, la, flasche, maske, funktion}]}` (AGW, Bereich Atemschutz, eigene Ortswehren) – legt Einträge in `asue.nachweis` mit `manuell:{von,t}` an. Cache asue-v113.

## 5.95
Nur Oberfläche, Cache asue-v114.

## 5.96 – Bereiche entkoppelt
- `/geraete` liefert `asue/geraete.html` (eigene Programmdatei der Gerätedatenbank), `/atemschutz` weiter `asue/index.html`.
- Zugänge: neue Zugänge nur mit **einem** Bereich (400 `getrennt` sonst). `POST /api/agw/konten {id, aufteilen:true}` teilt einen Altzugang (Atemschutz bleibt, neuer Benutzer `…-gw` für Geräte, gleiches Kennwort).
- ASÜ-Port, nur Superadmin-Sitzung (`SUPER`): `GET /api/agw/admin/konten?bereich=atemschutz|geraete`, `POST /api/agw/admin/konten {bereich, …wie /api/agw/konten}`, `POST /api/agw/admin/leitung {wehr, id}`. `/agw/daten`- und Login-Antwort enthalten `konto.admin`.
- Gemeinsame Kernfunktionen `agwKontoSpeichernKern()`, `agwLeitungKern()`. Caches einsatzverwaltung-v165, asue-v115.

## 5.97 – Berichtswesen
- Seite `GET /berichte` (asue/berichte.html, eigene Programmdatei, Manifest berichte.webmanifest). Zugänge = AGW-Konten mit Bereich `bericht` (Anmeldung über `/api/agw/anmelden`, Kennwortwechsel `/api/agw/kennwort`).
- `GET /api/agw/bericht/quellen`, `GET /api/agw/bericht/daten?quelle=einsaetze|traeger|pa|geraete|schaeden` → `{titel, spalten[{k,l,typ}], zeilen[], wehren}` – nur Ortswehren des Zugangs (`agwDarfWehr`), Abruf wird protokolliert.
- `GET/POST /api/agw/bericht/ansichten` (gespeicherte Berichtsformen je Zugang, `asue.berichtAnsichten`, max. 40), `POST /api/agw/bericht/xlsx {titel, spalten, zeilen}` → .xlsx.
- `POST /api/agw/admin/bericht-uebernehmen` (Superadmin): EV-Benutzer mit Rolle `obm`/`gbm` → Zugänge (`evUser`, `rolle`, Startkennwort, `muss`). `/api/agw/admin/konten?bereich=bericht`.

## 5.171

- `GET /api/mail/postfach`: jede Mail im Ausgang hat `ev` (bool) – wahr bei `einsatzId`, `grund` Einsatzbericht/Lagemeldung/Nachricht/Pressetext oder `user` = Benutzer der Einsatzverwaltung.

## 5.170

- `GET /api/system/speicher` (Admin, `?neu=1` = neu berechnen, sonst 10 min Cache) → `{t, disk:{gesamt,frei}, ordner:[{k,t,bytes,dateien,hinweis?}], bereiche:[{k,t,bytes,schluessel}], groesste:[{key,bytes}], archiv}`. Bereiche nach Schlüssel-Präfix (`SPEICHER_BEREICHE`).

## 5.205

- Keine Schnittstellenänderung. Einsatz-Reiter: `.cnt` immer vorhanden (`.leer` = `visibility:hidden`), `min-width:2.6em`, Ziffern gleich breit. Service-Worker `einsatzverwaltung-v270`.

## 5.204

- Keine Schnittstellenänderung. Einsatzverwaltung: Kategorie `/^sonstig/i` → `text` Pflicht im Formular; Anzeige `aufKatText(a)` = „Sonstiges: <erste Zeile text, 50 Zeichen>“. what3words je Auftrag über `GET /api/w3w?lat&lon` (im Browser je Koordinate zwischengespeichert). Fahrzeug-App: Melden mit „Sonstiges“ verlangt Text. Service-Worker `einsatzverwaltung-v269`, `fzapp-v66`.

## 5.203

- `mail.abrufen(cfg, verarbeiten, {stand})`: zusätzlich zu `UID SEARCH UNSEEN` auch `UID SEARCH SINCE <heute−2 Tage>`; UIDs, die nicht in `stand.uids` (bei gleicher `UIDVALIDITY`) stehen, werden geholt. Ergebnis `{gelesen, verarbeitet, nachgeholt, erstmals, stand:{v, uids}}`. Erster Lauf (oder neue UIDVALIDITY): nur ungelesene, ältere gelesene gelten als bekannt.
- Speicher `mail.uids` (privat) = `{ "<nr>:<postfach>": {v, uids[≤800], t} }`.
- Mail-Protokoll: „N schon als gelesen markierte Mail(s) nachgeholt …“.

## 5.202.1

- `paGanzeWehr(g)`: false bei `g.fz`, sonst Gruppenname ohne Ortswehr gegen `/(ortsb|gemb|obm|gbm|bm\d|bm$|brandmeister|fuehr|fuhr|stab|stv|stellv|kdo|kommando|leitung|daten|uebermittl|uebernahme|fireboard|sonderlage|presse|team)/` – gilt auch bei manueller Ortswehr.
- `fzErkennen`: Funkrufname im Gruppennamen wird ziffernweise ohne führende Nullen verglichen.

## 5.202

- `fahrzeugeAusMail`: Einträge in „Alarmierte Kräfte/Feuerwehren“ ohne Treffer in `mail.konfig.kraefte` werden mit den Ortswehren der eigenen Gemeinde (Fahrzeugliste, `istEinsatzFz`) verglichen und dann wie ein Eintrag `{ortswehr}` behandelt.
- PowerAlarm-Alarm → Einsatztext: „Alarmierte Feuerwehren“ nur aus Gruppen ohne zugeordnetes Fahrzeug und ohne Führungs-Kennung im Namen (bm, brandmeister, führ, stab, stv, kdo, leitung) bzw. mit manueller Ortswehr; Zeile fehlt, wenn leer. Gruppenzeile heißt `PowerAlarm-Gruppen:` (statt „Alarmierte Gruppen:“).

## 5.201

- `einsatz.ende`: alle Nachrichten an Fahrzeuge (`opta3.nachrichten`, `richtung:'aus'`, auch `fzfz`) mit `eid` = Einsatz und ohne `quittiert` bekommen `erledigt: <t>`.
- `GET /api/state/:token` (Meldeserver) → `nachrichten[]`: `quittiert` = `quittiert || erledigt`, zusätzlich `erledigt` (nur wenn nicht bestätigt). Keine Push-Nachricht mehr für erledigte.
- Fahrzeug-App: Wechsel von Einsatz auf keinen/anderen Einsatz (Einsatznummer) leert die Einblendungen, unterdrückt die Statuseinblendung und schließt Benachrichtigungen (`registration.getNotifications()`); beim Öffnen ohne Einsatz und ohne offene Nachrichten ebenso. Service-Worker `fzapp-v65`.

## 5.200.2

- Keine Schnittstellenänderung. Fahrzeug-App: Knopf aus 5.200.1 entfernt (Stand wie 5.200). Service-Worker `fzapp-v64`.

## 5.200

- Speicher `extern.osm` (privat, nicht in Exporten) = `{clientId, secret, token, verbunden:{t,von}, pkce:{v,state,t}}`.
- `GET /api/osm/status` (op) → `{clientId, hatSecret, verbunden, seit, von, redirect}` – nie Secret oder Token.
- `POST /api/osm/einstellen` (admin) `{clientId, secret?}` – Secret leer = unverändert; neue Client-ID löscht die Anmeldung.
- `POST /api/osm/anmelden` (admin) → `{url}`: `…/oauth2/authorize?response_type=code&client_id&redirect_uri=urn:ietf:wg:oauth:2.0:oob&scope=write_api&state&code_challenge&code_challenge_method=S256` (PKCE, 30 min gültig).
- `POST /api/osm/code` (admin) `{code}` → Token-Tausch an `…/oauth2/token` (authorization_code, code_verifier, client_secret); verlangt Scope `write_api`.
- `POST /api/osm/trennen` (admin) löscht Token.
- `POST /api/hydranten/osm` (op) `{k}` – nur übernommene neue Hydranten (`neu.bestaetigt`): `GET /api/0.6/map?bbox=±0.0003°` → bei `emergency=fire_hydrant` ≤ 15 m `409 {osmId}`; sonst `PUT changeset/create` (`created_by`, `comment`, `source=survey`), `PUT node/create` (`emergency=fire_hydrant`, `fire_hydrant:type`, `fire_hydrant:diameter`), `PUT changeset/{id}/close`. Ergebnis `{node, cs, url}`; am Hydranten `osmNode:{id, cs, t, von}`; Protokolleintrag. 401 von OSM löscht das Token.
- `GET /api/hydranten/neu`: je Eintrag zusätzlich `osmNode:{id, t, url}|null`.
- Test: Umgebungsvariablen `OSM_WEB` (Standard `https://www.openstreetmap.org`) und `OSM_API` (Standard `https://api.openstreetmap.org/api/0.6`).
- Service-Worker `einsatzverwaltung-v268`.

## 5.199

- `GET /api/agw/bericht/filter` → `[{id, tab, name, f, t}]` (eigener Zugang, Bereich bericht).
- `POST /api/agw/bericht/filter` `{tab: 'karte'|'fr'|'anf', name, f}` speichert (gleicher Name je Reiter = überschreiben, max. 30 je Reiter) bzw. `{id, loeschen:true}` löscht → `{filter:[…]}`. Speicher `asue.berFilter` = `{<Zugang-ID>: […]}`; `f` wird auf einfache Werte begrenzt.
- Service-Worker `asue-v169`.

## 5.198.4

- Keine Schnittstellenänderung. Bogendruck: `localStorage['db.qrKal.<Bogen>'] = {o, u, l, r}` (mm), Position je Etikett `x = x0 + col·dx + l + (r−l)·col/(cols−1)`, `y = y0 + row·dy + o + (u−o)·row/(rows−1)`; alte Werte `{x, y}` werden übernommen. Service-Worker `asue-v168`.

## 5.198.3

- Keine Schnittstellenänderung. Bogendruck: Seitenhöhe 296 mm, Umbruch nur zwischen den Bögen (`.s+.s{break-before:page}`) statt nach jedem Bogen. Service-Worker `asue-v167`.

## 5.198.2

- `POST /api/agw/qr/zuweisen`: zusätzliche Arten `fahrzeug` (id = Fahrzeug-ID, Bereich geraete), `funk` / `akku` (Digitalfunk, Bereich geraete), `lager` (Artikel-ID, Recht `lager`; Lager Gemeinde nur Gemeinde-Pflege).
- Übersetzung beim Scannen: `fahrzeug` → `…/datenbank#GDBFZ:<id>`, `funk` → `FUNK-GERAET:<id>`, `akku` → `FUNK-AKKU:<id>`, `lager` → `LAGER1:<id>` (neu, öffnet den Lagerartikel). `/agw/tauglich` liefert für die ASÜ weiterhin nur `agt` und `traeger`. Service-Worker `asue-v166`.

## 5.198.1

- `POST /api/agw/qr/erzeugen`: beide Bögen für Zugänge mit Bereich `geraete` oder `atemschutz` (vorher je Bogen nur ein Bereich). Datenbank: `qrEtikettMenue()` (scannen, eintippen, einzeln drucken mit `anzahl:1` + Position, lösen). Service-Worker `asue-v165`.

## 5.198

- Speicher `asue.qrCodes` = `{ CODE: { t, serie, bogen ('L7872'|'L6146'), von, z: {a:'geraet'|'agt'|'traeger', i, t, von} | null, gesperrt?: {t, grund, von} } }`; CODE = 8 Zeichen aus `ABCDEFGHJKLMNPQRSTUVWXYZ23456789`. QR-Inhalt: `<origin>/datenbank#Q1:CODE`.
- `POST /api/agw/qr/erzeugen` `{bogen, anzahl}` (L7872: Bereich geraete, L6146: Bereich atemschutz; max. 10 Bögen) → `{serie, codes}`.
- `POST /api/agw/qr/zuweisen` `{code, art, id, ueberschreiben?}` → `{code, ersetzt:[…]}`; 409 `belegt` (schon zugewiesen), 409 `gesperrt`, 404 `unbekannt`. Ein früheres Etikett desselben Ziels wird gesperrt.
- `POST /api/agw/qr/loesen` `{code}` → sperrt das Etikett.
- `GET /api/agw/qr/liste` → `{karte: {CODE: {a, i, w, …}|{a:null, bogen}}}` (gefiltert nach Ortswehren; ohne Namen; AGT mit `art, n, z, l, f`; Träger mit `z`).
- `GET /api/agw/tauglich` liefert zusätzlich `qr` (Zuordnung ohne Geräte der Gerätedatenbank) für die ASÜ.
- Apps: `qrUebersetzen()` setzt `Q1:CODE` beim Scannen in `GDB1:` / `ASUEG1:` / `ASUEP1:` um (in `detectCodes` und `parseCode`). Service-Worker `asue-v164`.

## 5.197

- Tagebucheinträge (`opta3.tb.<eid>`, Archiv `rec.tagebuch`) tragen `h` = SHA-256(`<h des vorigen Eintrags>\n<JSON der Felder nr, t, erfasst, nachtrag, richtung, von, an, text, user, auto, auftrag, tOrig, korrigiert>`); Start = SHA-256(`EV-Einsatztagebuch|<eid>`). `korrigiertDurch` ist nicht Teil der Kette.
- `einsatz.js`: `tbPruefen(eid, tb)` → `{ok, n, gesichert, ohne, ab, kopf, fehler:[{nr, grund}]}` (auch `module.exports.tbPruefen`).
- Archiv: `rec.tbSiegel = {t, n, kopf, ok}` beim Einsatzende; bei Schwärzung `rec.tbVorSchwaerzung = {t, ok, n, gesichert, kopf, fehler}`.
- `GET /api/tagebuch/pruefen/:id` – laufender Einsatz: alle Angemeldeten; Archiv: Einsatzleitung/Admin. Antwort wie oben plus `laufend`, `siegel`, ggf. `geschwaerzt`/`vorher`.
- Service-Worker `einsatzverwaltung-v267`.

## 5.196

- Keine Schnittstellenänderung. ASÜ (`asue/index.html`): neue Einstellung `config.ruheMin` (Minuten, Vorgabe 30, 0 = aus); `ruheBis(m)` = Ende des letzten beendeten Trupps der Person + Ruhezeit; Anzeige an Karte/Übersicht/Trupp-Dialog, Warnung bei „Beginn“ vor Ablauf. Service-Worker `asue-v163`.

## 5.195

- `POST /api/agw/traeger/nachweis` (Träger-Token `X-TR-Token`) – Body `{belastung:{d}, g26:{bis}}`:
  - `belastung.d` ≤ heute und ≥ heute−24 Monate → `nachweise.belastung = {d, von:'traeger', t}`
  - `g26.bis` > heute und ≤ heute+36 Monate → `nachweise.g26 = {d, bis, von:'traeger', t}`; `d` = bisheriges Untersuchungsdatum, sonst Tag der Eintragung
  - Antwort `{ok, ich}` (bzw. `unveraendert:true`), Fehler 400 `{error:'datum', text}`; Protokolleintrag; erledigte Erinnerungstermine (`termine`) werden geleert.
- `POST /api/agw/person`: Kennzeichen `von:'traeger'` bleibt erhalten, solange Datum/gültig bis unverändert sind.
- `POST /api/agw/traeger/termine`: Termine in der Vergangenheit → 400 `vergangen` (Oberfläche nutzt jetzt `/nachweis`).
- Träger-App: Karte „📅 Meine Termine“ mit zwei Feldern (Übungsstrecke absolviert am, G 26 gültig bis). Service-Worker `asue-v162`.

## 5.194

- Keine Schnittstellenänderung. Neues gemeinsames Skript `docs/einheit/qrnur.js` (eingebaut in `public/index.html`, `asue/index.html`, `asue/datenbank.html`):
  - `evQrNurDrucken(quellen, {titel, wahl})` – druckt nur Codes (Bild-URL, `<img>` oder `<canvas>`), Auswahl Größe (cm) und 1×/ganze Seite; Druck über unsichtbares iframe.
  - `evQrDruckWahl({mitText, einzeln})` → `Promise<{nur, cm, n}|null>`; letzte Wahl in `localStorage['ev.qrNur']`.
  - Automatischer Knopf unter `.fzapp-qr img`, `img[data-qr]`, `canvas[data-qr]`, `.qrwrap canvas|img` (MutationObserver); ausgenommen Container mit `[data-qr-ohne]` (Trupp-Übergabe, Beitreten).
- `dbDrucken(etiketten)` ist jetzt `async` und fragt „Mit Beschriftung / Nur QR-Code“.
- Hydranten-App-QR (Wassermeister-Links) als Fenster (`modalShell`) statt `window.open`.
- Service-Worker `einsatzverwaltung-v266`, `asue-v161`.

## 5.193.4

- Keine Schnittstellenänderung. `asue/traeger.html`: `.grid2` mit `minmax(0,1fr)`, Datumsfelder `appearance:none`/`max-width:100%` (iOS-Mindestbreite), bis 480 px Breite einspaltig. Service-Worker `asue-v160`.

## 5.193.3

- Keine Schnittstellenänderung. `asue/index.html` und `asue/datenbank.html`: lokale Funktion `evFrage()` (Frage „Einsatz anschließen?“) in `evAnschlussFrage()` umbenannt – sie verdeckte im Skript-Gültigkeitsbereich die gemeinsame Sicherheitsabfrage `window.evFrage(text, o)` (aus `docs/einheit/dialog.js`); alle Rückfragen lieferten dadurch `undefined` = abgebrochen. Service-Worker `asue-v159`.

## 5.193.2

- Keine Schnittstellenänderung. Fahrzeug-App: `.badge[hidden]{display:none!important}` (die gemeinsame Design-Regel `.badge{display:inline-flex}` hatte `hidden` aufgehoben). Service-Worker `fzapp-v62`.

## 5.193.1

- Beim Serverstart wird `opta3.users` jetzt mit derselben Funktion gebaut wie nach dem Speichern (`benutzerListeOeff()`): enthält `gbm`, `mail`, `fzVid`, `superadmin`, `wehren`. Vorher fehlten nach einem Neustart `gbm`/`superadmin`, sodass ein Speichern in der Benutzerverwaltung `gbm:false` schickte und die Funktion löschte.

## 5.193

- `POST /api/hydrant/:token` mit `neu:true` nimmt `info {a: underground|pillar|wall, d}` an (`hydInfoSauber`).
- `opta3.hydranten[k].neu = {t, fz, bestaetigt?: {t, von}}`. `GET /api/hydranten/neu` → `{liste:[{k, lat, lon, name, info, gemeldet, status, bilder, bem, fz, nah:{k, dist, name, osm}|null}]}`; `POST /api/hydranten/neu` (op) `{k, aktion:'uebernehmen', a?, d?, lat?, lon?}` (neue Lage → neuer Schlüssel, höchstens 2 km) · `{k, aktion:'ablehnen'}` · `{k, aktion:'zusammen', ziel}` (nächster Hydrant ≤ 60 m, OSM oder eigene Meldung; Prüfungen werden vereinigt). Gleiches für den Wassermeister: `POST /api/wm/:token/neu`; `GET /api/wm/:token` liefert zusätzlich `neu` (nicht bestätigte Meldungen).
- `GET /api/hydranten/karte/:k.png` (Kartenbild, blau = neu gemeldet).
- `hydOsmAbgleich()` nach jedem Laden der Wasserentnahmestellen und 20 s nach dem Start: gemeldete Hydranten mit OSM-Hydrant ≤ 15 m daneben werden zusammengeführt (`neu` entfällt).
- Wochenmail: Abschnitt „Neu gemeldete Hydranten“ (nicht bestätigt, seit der letzten Mail bzw. alle bei `alle:true`); Mail auch, wenn es nur neue Meldungen gibt.

## 5.192.1

- `POST /api/hydranten/wochenmail {alle:true}`: alle offenen Mängel (letzte Prüfung nicht ok, nicht behoben), unabhängig vom Prüfdatum; Protokoll „Mail von Hand …“ mit dem Benutzer.

## 5.192

- Einstellungen `HYD_MAIL_ZEIT` (`woche` | `sofort`, Vorgabe `woche`) und `HYD_MAIL_UHR` (Vorgabe 18). Die Sofort-Mail in `POST /api/hydrant/:token` nur noch bei `sofort`.
- Wochenmail `hydWochenmail()` (alle 10 min geprüft; sonntags ab `HYD_MAIL_UHR`, einmal je Tag, Stand in `opta3.hydWochenmail = {t, tag, n}`): Hydranten der Gemeinde, deren letzte Prüfung nicht ok und nicht behoben ist und die seit der letzten Wochenmail eine Prüfung mit Mangel haben. HTML + Text, Fotos und Kartenbild als Inline-Anhänge (`cid`, `multipart/related` – `mail.js`), zusammen höchstens 18 MB.
- `POST /api/hydranten/wochenmail` (Admin) `{vorschau?, testAn?, tage?}` → `{gesendet, n, an?, html?, grund?}`; `GET /api/hydranten/wochenmail` (op) → `{zuletzt, an, modus, uhr, mailAktiv}`.
- Kartenbild: `hydKarteBild(lat, lon, farbe)` – 520×300 PNG aus OSM-Kacheln (z 17, `kachelHolen` mit Zwischenspeicher `tiles/`), eigener PNG-Leser/-Schreiber (8 bit, Farbtypen 0/2/3/4/6), Markierung rot (außer Betrieb) bzw. orange.
- Wassermeister-Links `opta3.hydWassermeister = [{id, token, name, t, von, zuletzt}]`: `GET /api/hydranten/wassermeister` (op), `POST …` (Admin) `{aktion:'neu', name}` / `{aktion:'loeschen', id}`.
- Meldeserver: `GET /wassermeister/:token` (Seite `melde/wassermeister.html`), `GET /api/wm/:token` (Hydranten mit Mangel/außer Betrieb, offen oder in den letzten 90 Tagen behoben), `GET /api/wm/:token/bild/:name`, `GET /api/wm/:token/karte/:k.png`, `POST /api/wm/:token/behoben {k, text?, zurueck?}` (Protokoll „Name (Wassermeister)“).

## 5.191

- Meldeserver: Middleware für alle `POST /api/…` mit JSON-Body: `cid` (6–40 Zeichen) → Wiederholung derselben `cid` auf demselben Pfad (inkl. Token) innerhalb von 3 Tagen liefert `200 {ok:true, doppelt:true}` ohne Ausführung (gemerkt nach Antwort < 300, nur im Speicher). `t` älter als 1 min (max. 14 Tage) → `req.meldeNachT`; ein `text` bekommt „(ohne Netz geschrieben …, nachgereicht)“ (gekürzt auf 500 Zeichen), `meldeOp` trägt als Benutzer „Fahrzeug-App (ohne Netz HH:MM, nachgereicht)“ ein. `/api/hydrant/` behandelt `cid`/`t` selbst (5.190).
- `einsatz.js`: `nachrichtFz`/`nachrichtFzFz` akzeptieren Benutzer, die mit „Fahrzeug-App“ beginnen.
- Fahrzeug-App: `senden(art, pfad, body, {info, fotos, fotoFeld})` – ohne Netz in IndexedDB `fzapp-offline/warte` (inkl. Foto-Blobs, die beim Senden erst über `/api/bild/` hochgeladen werden), Fehler 400/404/413 beim Nachsenden verwerfen den Eintrag mit Hinweis.

## 5.190

- `POST /api/hydrant/:token` (Meldeserver): neue Felder `cid` (Kennung der Prüfung, 6–40 Zeichen `[A-Za-z0-9_-]`) und `t` (Prüfzeit, ms). Gleiche `cid` schon vorhanden → `200 {ok, doppelt:true}` ohne neuen Eintrag. `t` gilt, wenn älter als 1 min und nicht älter als 14 Tage („nachgereicht“): Eintrag `letzte.t = t`, `gesendet`, `datum` nach `t`, Mail und Protokoll mit der Prüfzeit. Eine nachgereichte ältere Prüfung kommt nur in `hist`, `letzte` bleibt die neueste.
- `GET /api/wasser/:token?alle=1`: alle Wasserentnahmestellen im Umkreis von ±0,5° / ±0,75° um den Heimatort (höchstens 10 000) mit Status `st` – für die Prüfung ohne Netz.
- Fahrzeug-App: Warteschlange in IndexedDB `fzapp-offline` (Store `warte`), Service Worker `fzapp-v59` speichert Kartenkacheln `/api/kachel/…` im Cache `fzapp-karte` (höchstens rund 4000) und liefert die App-Seite nach 6 s ohne Antwort aus dem Speicher.

## 5.189.1

- Abmelden nach Inaktivität nur für Rollen `INAKTIV_ROLLEN = ['admin', 'einsatzleiter', 'obm']` (`inaktivGilt(s0)`). Für andere Rollen (Betrachter, alte Rolle `gbm`) liefern `GET|POST /api/auth/aktiv` `min: 0, rest: null`, `/api/auth/ich` `inaktivMin: 0`; die Sitzung wird nicht beendet.

## 5.189

- Neue Einstellung `ABMELDEN_INAKTIV_MIN` (Betrieb, Vorgabe 30, 0 = aus).
- Sitzungen (`auth.sitzungen`) führen `aktiv` (letzte Bedienung). `POST /api/auth/aktiv` setzt `aktiv` (Seite meldet Bedienung höchstens einmal je Minute) → `{ok, min, rest}`; `GET /api/auth/aktiv` → `{min, rest}` (Sekunden bis zur Abmeldung, `null` wenn aus). Beide brauchen eine gültige Sitzung (401 sonst).
- Alle 30 s: Sitzungen mit `jetzt − aktiv > min` werden beendet (Websocket `4001`), Protokoll „Nach … Minuten ohne Bedienung automatisch abgemeldet“. Sitzungen ohne `aktiv` (vor dem Update) beginnen beim ersten Lauf neu zu zählen.
- `GET /api/auth/ich` liefert zusätzlich `inaktivMin`; `sitzungen.liste` zusätzlich `aktiv` und `rest`.

## 5.188

- Neu: `GET /datenbank` (ASÜ-Port) liefert `asue/datenbank.html` (eine Programmdatei für Geräte- und Atemschutz-Datenbank, `window.DB_SEITE='datenbank'`), Manifest `datenbank.webmanifest`, Symbole `icon-datenbank-192/512.png`. `GET /geraete`, `/atemschutz` (auch mit `/`) → `302 /datenbank` (Query bleibt, `#…` behält der Browser). `asue/geraete.html` entfällt.
- Rechte (`agwRecht`): `agtGeraete` = Bereich `atemschutz` **oder** `geraete` für `POST /agw/geraet`, `DELETE /agw/geraet/:id` (vorher ohne Bereichsprüfung), `POST /agw/geraete/termine`, `GET|POST /agw/pflege`, `GET|POST /agw/inbetrieb`, Excel `was=agwg` (`XL_WAS.agwg.recht`). `lager` = `geraete` **oder** `atemschutz` für `GET /gdb/daten`, `POST /gdb/lager`, `POST /gdb/lager/anfordern`.
- `GET /agw/daten` für reine Gerätewart-Zugänge: `personen: []`, `geraete` = Atemschutzgeräte der eigenen Ortswehren.
- `GET /gdb/daten` für Zugänge ohne Bereich `geraete`: `{ nurLager: true, lager, lagerGemeindePflege, konto, alleWehren, … }`, alle Geräte-/Fahrzeuglisten leer.
- Push: `url` ist jetzt `/datenbank` (Service Worker `asue-v158` leitet alte `/geraete`/`/atemschutz` dorthin um). QR-Etiketten der Gerätedatenbank: `…/datenbank#GDB1:<id>` bzw. `#GDBFZ:<vid>` (alte Etiketten gehen weiter).
- `PROG_PFLICHT` enthält `asue/datenbank.html`.

## 5.187.2

- `GET /api/wetter/radar`: je Ebene zusätzlich `refs` (REFERENCE_TIME-Werte im Zeitfenster) und `ref` (neueste Messzeit = Vorgabe des DWD). Reihenfolge: `Niederschlagsradar` zuerst. Der Browser fragt Verlaufsbilder mit `TIME=REFERENCE_TIME=t`, Vorhersagen mit `TIME=t&REFERENCE_TIME=ref` und das aktuelle Bild ohne Zeitangabe an.

## 5.187.1

- Neu: `GET /api/wetter/radar` (angemeldet, Port 8080) → `{ok, ebenen:[{k:'wn'|'alt', layer, zeiten:[ISO…], standard}], jetzt, stand}`. Der Pi liest beim DWD-Kartendienst (`C_DWD_WMS`) per `GetCapabilities` die Ebenen `Radar_wn-product_1x1km_ger` (mit Vorhersage) und `Niederschlagsradar` samt Zeitdimension (Liste oder Intervall `Start/Ende/PT5M`), Zeitfenster −75 … +135 min. Zwischenspeicher 4 min (bei Fehler 30 s); bei Fehler `{ok:false, ebenen:[]}`. Der Browser fällt dann auf `Niederschlagsradar` ohne `TIME` zurück.

## 5.186

- Entfernt: `GET /design-test.js`, `GET /design-test.css` und die Schrift-Routen der Designvorschau (Atkinson, Plex Mono) auf Port 8080/Fahrzeug-App.
- Neu: `POST /agw/gdb/rueckgaengig {token}` (Bereich geraete) – macht eine Geräteaktion rückgängig. `POST /agw/gdb/aktion` liefert dafür `undo` (Token, 2 Minuten gültig, nur derselbe Zugang, nur wenn das Gerät seitdem unverändert ist; sonst 410/409).
- Neu: `GET /melden/wappen.png` (Fahrzeug-App-Port) – Wappen für die Kopfzeile.

## 5.183

- `POST /agw/anf`: neues optionales Feld `vorlage` (id einer früheren, für das Konto sichtbaren Anforderung). Gespeichert als `a.vorher = {id, nr, jahr, status}`; erster Verlaufseintrag „Erneut angefordert (vorher Nr. …, HH …)“. Die Anzeige „Schon angefordert: 2024 (…)“ ermittelt das Berichtswesen clientseitig aus `vorher`-Verweisen und gleichem Text (normalisiert) derselben Ortswehr.

## 5.169

- `GET/POST /agw/bericht/benachr` (eigener Zugang, Bereich bericht): `{rolle: gbm|obm, mail, zentral, arten:[{k,t,mail,push,nurMail}], wartendTage, fz:{id,funkrufname,typ,geraete,arten:[{k,t,an}]}}`; POST `{mail:{art:bool}, push:{art:bool}, wartendTage, mailAdr (nicht bei gbmSso), fzArten:{art:bool}}`. Gespeichert in `konto.benachrBer`; Fahrzeug-App-Sperren in `push.fzArten[vid]`.
- `POST /agw/bericht/benachr/test` → Test-Mail und Test-Push.
- Arten `BER_BENACHR`: `anf_neu`, `anf_wartend`, `lager_mindest` (GBM), `anf_status`, `einsatzbericht` (OBM). Versand über `berSenden(konten, art, …)`.
- `konto.fzVid`: vom Admin über `POST /agw/admin/konten {fzVid}` bzw. für GBM über `benutzer.speichern {gbm, mail, fzVid}` (Abgleich ins zentrale Konto). `GET /agw/admin/konten?bereich=bericht` liefert `fzEintraege`.
- `pushAnFz()` beachtet `push.fzArten`.
- `anfWartendErinnern()` alle 3 Stunden geprüft, je GBM höchstens einmal in 7 Tagen (`konto.anfErinnertT`).
- Anforderungen: Feld `jahr` (Anlegen, `aendern`). Lager: `x.log` (neueste zuerst, max. 300) – für Ortswehren im Lager Gemeinde nicht ausgeliefert.

## 5.168

- `POST /agw/anf/:id` neue Aktion `aendern` {was?, menge?, kosten?, link?, begruendung?} (Anfordernder oder GBM; nicht nach Bestellung/Ablehnung/Rückzug/Ausgabe) → Verlauf „Geändert: …“; ohne Änderung `nichts: true`.
- `bewerten` mit `abgelehnt`/`anschaffen` sendet Mail an `obmAdressen(wehr)` (`anfMailObm`), Antwort `mail: {ok, text}`.
- `POST /api/gdb/lager/anfordern` (Bereich geraete) {id, menge, begruendung, wehr} → legt Anforderung an (`a.lager = {id, name}`), Antwort `{anf: {id, nr}}`.
- `POST /api/gdb/lager` im Lager Gemeinde: neu unter Mindestbestand gefallene Artikel → Mail an aktive AGW-Konten mit Mail und (`gbmSso` oder `wehren:*` + Bereich geraete); Antwort `warn: {ok, text}`.
- `personZuNachweis(x)`: Personen-ID, sonst normalisierter Name (vertauscht, Umlaute, gleiche Ortswehr bevorzugt) – für Pseudonyme.
- `istEinsatzFz(v)` = gleiche Regel wie `istFahrzeugTyp` im Browser (FZ_TYP_JA / FZ_TYP_NEIN, ohne Typ = Funktion, mit Personenname = Funktion); genutzt in Alarmierung, Kräfte aus Mail, Berichtswesen, Jahresbericht, GDB-Übersicht.
- `/agw/anmelden`: `konto.ohneNamen` (bool).

## 5.167

- `gbmOhneNamen(k)` = `k.gbmSso`. Für solche Zugänge: `berZeilen()` anonymisiert (sonst Klarnamen); `agwSitzung()` ersetzt `res.json` durch eine anonymisierende Fassung (`nach`/`vor`, `nachname`/`vorname`, `name` in Nutzungen, `n`/`v`, `traeger`, `pruefer`; Kontaktfelder entfernt), `konto.ohneNamen = true`. Schreibende Atemschutz-Routen sowie `GET /agw/excel` und `/agw/feueron` → 403 `datenschutz`.

## 5.166

- `berZeilen()` (alle Berichtswesen-Quellen, Export, Mail, Jahresbericht): Feld `name` bei `traeger`, `pa`, `fristen` wird zu einer festen Kennung „Person n“ (Zuordnung in `asue.berPseudo`, Schlüssel = Personen-ID, sonst Name). Felder `pruefer`, `vorname`, `nachname`, `traeger` werden entfernt; Spalte `pruefer` bei `inbetrieb` entfällt.

## 5.165

- `POST /agw/anf/:id` neue Aktion `eingetroffen` (nur GBM; erst nach `bestellt`, vor `ausgegeben`, einmalig; `grund` = Hinweis) → `a.eingetroffen = {t, von, notiz, mail?}`. Mail an `obmAdressen(a.wehr)`; Antwort enthält `mail: {ok, text}`. Ergebnis des Versands wird im Verlauf vermerkt.

## 5.164

- Lager `Gemeinde` in `asue.gdbLager`: `POST /api/gdb/lager` mit `wehr:"Gemeinde"` nur für Gemeinde-Zugänge (`SUPER`, Admin oder `wehren` enthält `*`), sonst 403 `gemeinde`. Feld `oeffentlich` (bool) nur im Lager Gemeinde.
- `GET /api/gdb/daten`: `lager.Gemeinde` = alle Artikel für Gemeinde-Zugänge, sonst nur `oeffentlich`; neu `lagerGemeindePflege` (bool).

## 5.162

- `POST /agw/anf`: neues optionales Feld `link` (max. 500 Zeichen, nur http/https; ohne Schema wird `https://` ergänzt; ungültig → 400 `link`). Gespeichert als `a.link`.

## 5.160

- `wehrenZusammenlegen()` beim Start und stündlich: Werte „Königsförde“, „Selxen“, „Königsförde-Selxen“ unter Feldern mit `wehr` im Namen (auch Arrays wie `wehren`) und gleichnamige Objekt-Schlüssel werden zu „Königsförde/Selxen“; doppelte Array-Einträge entfallen, Objekte werden zusammengeführt. `asue/benutzer.js`: `ort` und `name` angepasst. Marker `migr.koenigsfoerdeSelxen`.
- `paGruppenZuordnen()`: Wehrnamen mit „/“ passen auch auf jeden Teilnamen.

## 5.159

- `GET /api/einstellungen/zustand` (Admin) → `{punkte:[{id, ok, text, tipp, ziel, wichtig}], anbindungen:[{art, name, eingerichtet, ok, t, text}], geaendert:{API-ID:{t,user}}}`. `ziel` = id des Einstellungs-Blocks (z. B. `stbBetrieb`) oder `sub:users`.
- `POST /api/einstellungen/test` (Admin) `{art: pa|mail|wetter|karten|fzapp}` → `{ok, erg:[{name, ok, text}], anbindungen}`. Ergebnisse werden in `einst.anbindungen` gemerkt. `mail` schickt eine Test-Mail an das eigene Absender-Postfach und ruft den Posteingang ab.
- `GET /api/einstellungen/export` (Admin + PIN) → JSON-Datei `{art:'einsatzverwaltung-einstellungen', version, erstellt, von, settings, api}` ohne geheime Werte.
- `POST /api/einstellungen/import` (Admin + PIN) `{daten, teile:['settings','api']}` → `{ok, api, settings, fehler}`. Geheime Werte werden nie übernommen.
- `POST /api/einstellungen/schnittstellen` merkt je geänderter ID `{t, user}` in `einst.geaendert`.
- Neue Websocket-Operation `benutzer.ausgeschieden {id, name}` (kritisch, PIN) → `{erledigt:[…], offen:[…]}`: Benutzer entfernen, Sitzungen beenden, verknüpfte/gleichnamige AGW-Konten deaktivieren.
- `settings.geaendertAm` (Client): `{Blocktitel:{t, user}}` für „Zuletzt geändert“.

## 5.158

Keine Änderung an der Schnittstelle. `/api/einstellungen/schnittstellen` liefert wie bisher alle Werte mit `gruppe`; die Oberfläche ordnet die Gruppen jetzt den Themen-Blöcken zu (unbekannte neue Gruppen landen unter „Sicherung & System“).

## 5.156

- ASÜ-Port, Bereich `bericht`: `GET /api/agw/anf` → `{gbm, wehren, liste}` (OBM nur eigene Ortswehren). `POST /api/agw/anf {wehr, was, kosten, begruendung}`. `POST /api/agw/anf/:id {aktion: bewerten (status wartend|anschaffen|abgelehnt, grund – Pflicht bei abgelehnt) | bestellt (grund) | ausgegeben (an) | zurueckziehen}` – bewerten/bestellt/ausgegeben nur GBM (Wehren `*`, Admin, Superadmin). Speicher `ber.anforderungen` mit `verlauf`.

## 5.154

- Benutzer: neues Feld `gbm` (Funktion Gemeindebrandmeister, unabhängig von `role`); `benutzer.speichern` nimmt `gbm: true|false`. Rolle `gbm` wird beim Start in `gbm: true` + `role: betrachter` umgewandelt; `opta3.users` enthält `gbm`. Zentraler Datenbank-Zugang hängt an `gbm`, nicht mehr an der Rolle.

## 5.153

- `benutzer.speichern` (Rolle `gbm`): legt/aktualisiert einen verknüpften Datenbank-Zugang an (`evUser`, `gbmSso: true`, Bereiche atemschutz/geraete/bericht, Wehren `*`); Antwort zusätzlich `gbm: {ext, hinweise}`. `/api/agw/anmelden` prüft bei `gbmSso` die EV-PIN; 409 `zentral_erst` solange `einmalPin`. `/api/agw/kennwort` und `/api/agw/admin/konten` lehnen `gbmSso`-Zugänge ab (400 `zentral`).

## 5.152

- Keine neuen Schnittstellen. 5.151.4: `opta3.pos`-Einträge älter als 24 h werden alle 15 Minuten entfernt.

## 5.151

- Keine neuen Schnittstellen. `mailEingang` arbeitet Meldungen in einer Warteschlange ab; Zuordnung zu laufenden Einsätzen über normalisierte `mailNummer`, Nummer im Freitext, Stichwort + Straßenname.

## 5.150

- `GET /api/agw/feueron?wehr=&kod=utf8|` (ASÜ-Port, Atemschutz-Zugang): CSV für den FeuerON-Personenimport (Spalten `PV_DB.1.*`, `PV_AUSB.1–4.*`, `PV_UNTSU.1.*`, Trennzeichen `;`, Datum tt.mm.jjjj, Standard Windows-1252). `&pruefen=1` liefert `{anzahl, ohne}`.
- `POST /api/agw/person`: neue freiwillige Felder `fonNr` (max. 10 Zeichen) und `fonGeb` (Datum); fehlen sie im Aufruf, bleiben die gespeicherten Werte. Excel Personen: Spalten „Personalnummer (FeuerON)“ und „Geburtsdatum (nur für FeuerON)“.

## 5.149

- Keine neuen Schnittstellen.

## 5.148

- Keine neuen Schnittstellen.

## 5.147

- Einsatz-Feld `alarmVorschlag` (Liste von Fahrzeug-IDs): Fahrzeuge der in der Alarm-Mail genannten Kräfte, wenn „Kräfte automatisch alarmieren“ aus ist. Übernehmen über `fz.status` (st `A`, `einsatzId`). Ziehen aus Kräfte & Mittel nutzt `fz.status`, `fz.zuordnen`, `fz.umsetzen` und `fz.abschnitt`.

## 5.146

- Keine neuen Schnittstellen.

## 5.145

- Keine neuen Schnittstellen. Karte zum Einsatzort nutzt `/tiles`, `/api/geocode`, `/api/reverse` und `/api/w3w`; Anfordern nutzt `anforderung` (und optional `fz.status`).

## 5.144

- Operation `funk`: zusätzlich `leitstelleName`, `zusatz` (Liste {id, name, kanal, leiter, an: lst|el|ab:<id>, teilnehmer, farbe}, höchstens 20) und `pos` ({Kastenschlüssel: {x, y}}; Schlüssel lst, el, frei, ab:<id>, z:<id>).
- Operation `besprechung`: zusätzlich `rollt` und `benoetigt` (Anforderungen); Text darf leer sein, wenn `benoetigt` oder `rollt` gesetzt ist.
- `GET /api/wasser`: Punkte tragen bei vorhandener Umrechnung `info.w` (what3words ohne ///). Neu `GET /api/wasser/w3w` → {aktiv, gesamt, mitW3w, laeuft, fehler}. Zwischenspeicher `w3w-cache.json` (Pi füllt ihn im Hintergrund, alle 6 Stunden und nach dem Neuladen der Wasserstellen).
- Berichtswesen „Hydranten / Löschwasser“: Spalte `w3w`.

## 5.143

- Keine neuen Schnittstellen (nur Darstellung).

## 5.142

- Keine neuen Schnittstellen. Reiter „Kräfte & Mittel“ (Fenster-Kennung weiter `list` bzw. `stations`).

## 5.141

- Keine neuen Schnittstellen. Übung beim Eröffnen über `einsatz.neu` (Meldebild „ÜBUNG: …“) und `tb.neu` (Vermerk), wie beim Übungsgenerator.

## 5.140

- Keine neuen Schnittstellen. Aufbau „Leitstand“ im Browser (localStorage `ev-layout`), Adresszusatz `?design=leitstand`.

## 5.139

- Keine neuen Schnittstellen. Erkennung, Diktieren und Erinnerungen laufen im Browser; Status und Anforderungen über die bekannten Operationen `fz.status` und `anforderung`.

## 5.138

- Keine neuen Schnittstellen. Neue Fensteransicht `/?fenster=lagetisch[&anzeige=1]` (Lagetisch für Wandbildschirme).

## 5.137

- `GET /design-test.js`, `GET /design-test.css` (Port 8080, ASÜ-Port, Fahrzeug-App-Port) – Designvorschau „Signal Klar“ mit Umschalter; wirkt nur nach Einschalten im Browser (localStorage `ev-design`, `ev-design-stufe`, `ev-design-knopf`).
- `GET /vendor/font/atkinson-400.woff2`, `atkinson-700.woff2`, `plexmono-600.woff2` – Schriften der Vorschau; vom Pi einmal aus dem Internet geholt und mit Prüfsumme in `vendor-cache/` zwischengespeichert (ohne Internet: Systemschrift).

## 5.136

- `GET /hilfe[?q=Suchbegriff]` (Port 8080 und ASÜ-Port) – Bedienungsanleitung aus `docs/BEDIENUNG.md` als HTML, springt zum ersten passenden Abschnitt.
- `GET /api/neu?seit=Version` → `{version, neu:[{version, titel, html}]}` aus den Abschnitten „### Neu in …“ (ASÜ-Port ohne Wehr-Schlüssel).
- QR-Inhalte Digitalfunk: `FUNK-GERAET:<id>`, `FUNK-AKKU:<id>`.

## 5.135.2

- Kein Sicherheitsereignis mehr für ASÜ-API-Zugriffe mit falschem/ohne Wehr-Schlüssel (nur `console.warn`); bestehende Einträge mit Schlüssel `asue|…`/`asueohne|…` werden beim Start gelöscht.

## 5.135.1

Keine Server-Änderungen (Darstellung Digitalfunk).

## 5.135

- `POST /api/agw/admin/konten {bereich:'geraete', …, funk:true|false}` setzt bzw. entfernt `funk:'leitung'`; `GET /api/agw/admin/konten` liefert `funk` je Zugang.

## 5.134

- Konto-Feld `funk`: `leitung` (Funkbeauftragter) | `beauftragt`. Pflegen (`POST /api/gdb/funk`, Excel-Import, Schäden erledigen) nur Admin/Superadmin, `leitung`, `beauftragt` (alle Ortswehren); sonst 403 `rolle`. `GET /api/gdb/funk` zusätzlich `rolle`, `darfPflegen`, `beauftragte`; ohne Rolle nur eigene Ortswehren.
- `GET/POST /api/gdb/funk/beauftragte {id, funk}` (Admin oder `leitung`; `leitung` vergibt nur der Admin).
- `GET /api/gdb/funk/excel` → .xlsx (Blätter Funkgeräte, Sicherheitskarten, Akkus); `POST /api/gdb/funk/excel[?pruefen=1]` (Rohdaten .xlsx) → `{neu, geaendert, fehler[], eingespielt}`.
- `POST /api/gdb/funk/schaden {was, id, text, ausser}` (jeder Gerätewart der Ortswehr) → `{ok, mails}`; Mail + Push an `leitung`/`beauftragt`. `{aktion:'erledigt', was, id, sid, text, bereit}` nur Pflegende. Einträge `schaeden[]` am Gerät/Karte/Akku.
- OPTA → Fahrzeug/Ortswehr: Funkrufname „NN-NN-NN“ (Trenner - / Leerzeichen) in der OPTA, sonst Ortswehrname.

## 5.133

- `GET/POST /api/agw/bericht/monatsbericht` (Bereich `bericht`): `{aktiv, tag, teile[], wehren[]}` speichern; `aktion:'vorschau'` → `{html, zr}`, `aktion:'test'` → Mail an den Zugang. Speicher `agw.monatsbericht`; Versand ab dem eingestellten Tag einmal je Monat (ab 7 Uhr).
- Op `verpflegung {einsatzId, aktion:'neu'|'status'|'extra'|'hinweis', …}` → `einsatz.verpflegung {bestellungen[], extra, hinweisStd}`.
- `POST /api/gdb/funk {was:'soll', …, mail}` → `{ok, mails}`; bei geändertem Soll-Stand Mail an Gerätewarte (Bereich `geraete`) mit den abweichenden Geräten ihrer Ortswehren.

## 5.132

- `GET /api/gdb/funk` (ASÜ-Port, X-AGW-Token, Bereich `geraete`, nur eigene Ortswehren; `?archiv=1` mit Ausgesonderten) → `{geraete, karten, akkus[+stand{letzter, tauschen, testFaellig}], soll, grenze, hinweise[], wehren, arten, status, kartenStatus, fahrzeuge}`.
- `POST /api/gdb/funk {was:'geraet'|'karte'|'akku', daten:{…}}` anlegen/ändern; `{…, aktion:'aussondern', grund}`; Akku-Test `{was:'akku', aktion:'test', daten:{id}, kap, zyklen, datum, bem}`; `{was:'soll', firmware, programmierung, grenze}`. Speicher `asue.funk`. Erinnerungen für Karten (≤ 60 Tage, abgelaufen, verloren) und Akkus unter der Grenze über die bestehenden Gerätewart-Erinnerungen.
- Op `funk`: zusätzlich `fzRufgruppe`, `fzAbschnitt`, `fzSenden`, intern `gesendet`; Server verteilt alle 5 s per Op `nachricht` an Fahrzeuge, deren `fzGesendet` abweicht. `GET /api/status/:token` (Meldeserver) liefert `rufgruppe {rufgruppe, abschnitt}` oder `null`.

## 5.131.4

Keine Server-Änderungen (nur Darstellung der Objektliste).

## 5.131.3

- `GET /api/agw/bericht/daten`: Quellen `fahrzeuge`, `ausruestung` nur Einträge mit `fahrzeugtyp`; bei `einsaetze` zählen `fahrzeuge`/`anzahl` keine Funktionen (Stärke unverändert).

## 5.131.2

Keine Server-Änderungen (Abmelden nach Schließen des Browsers im Browser: `localStorage ev.lebt`, `ev.dauerAnmeldung`, `sessionStorage ev.sitzung`; danach `POST /api/auth/logout`).

## 5.131.1

- `GET /api/agw/admin/konten` → `ext` ist jetzt die Internetadresse der ASÜ (Origin aus den ASÜ-Adressen, sonst `meldeBase`-Host mit :8443), nicht mehr die Adresse des Meldeservers.

## 5.131

- WebSocket-`op` mit `cid` (6–32 Zeichen a–z0–9): gleiche `cid` desselben Benutzers wird 48 h nur einmal ausgeführt; Wiederholung liefert das gespeicherte Ergebnis mit `doppelt: true` (Offline-Puffer der Tablets).
- Update: `SIGNATUR.json` im Paket (`{format:1, programm, version, erstellt, dateien:{pfad:sha256}, schluessel, signatur}`, Ed25519 über die sortierten Felder). `POST /api/system/update/pruefen` → zusätzlich `signiert`, `signatur{erstellt, schluessel}`; falsche Signatur/veränderte Dateien → 400. `POST /api/system/update/einspielen {id, unsigniertOk}` – nicht signiert nur Superadmin mit `unsigniertOk: true`. Werkzeug: `node docs/update-signieren.js <ordner> <privat.pem>` bzw. `--schluessel <ordner>`.
- `POST /api/sicherung/probe` (Admin) → `{t, ok, details[{ort, datei, ok, text, warn}], extern}`; auch in `opta3.sicherung.probe`, wöchentlich automatisch, Datei `backups/wiederherstellungsprobe.json`.
- `GET /api/system` zusätzlich `zeitSync`, `schreibbar`, `starts24`; neue Warnungen (NTP, SD-Karte schreibgeschützt, Neustarts, Wiederherstellungsprobe).
- `GET /vendor/zxing.js`, `/vendor/tess/{tesseract.min.js, worker.min.js, tesseract-core-simd-lstm.wasm.js, tesseract-core-lstm.wasm.js, deu.traineddata.gz}` (ASÜ-Port) – Zwischenspeicher `vendor-cache/` mit `pruefsummen.json`.
- Exposition: automatische Einträge `asue:<nachweis-id>` mit `offen: true`, `trupp`; neue Felder `hygiene[]` (Liste `hygiene` in der Antwort), `beschwerden`, `abgefragt{t,user}`. Anlage bei `GET /api/exposition?ev=` und alle 10 Minuten für Einsätze der letzten 14 Tage (nicht Demo).
- Benutzer-PIN mindestens 6 Zeichen (`pin_kurz`); Anmeldung/`/api/auth/ich` liefern `kurzPin` bei kürzerer PIN.

## 5.130

- `POST /api/auth/pin {alt, neu}` – eigene PIN ändern (Pflicht bei Standard-PIN; nicht für Superadmin). `GET /api/auth/ich` liefert `standardPin` zuverlässig (Merker `stdPin`).
- `POST /api/xlsx/lesen` (Admin, Rohdaten) → `{blaetter:[{name, zeilen:[[…]]}]}`.
- `POST /api/system/update/pruefen` liefert `sha256`.
- Neue private Präfixe (nicht per WebSocket verteilt): `sicherheit.`, `agw.`.
- ASÜ-API ohne `ASUE_KEY`: Anfragen mit `Tailscale-Funnel-Request` bzw. über die externe Adresse → 401 `kein_schluessel`.
- Alle Apps senden Sicherheits-Header (X-Content-Type-Options, X-Frame-Options SAMEORIGIN, Referrer-Policy, Permissions-Policy, COOP, HSTS bei HTTPS).

## 5.129

Keine Server-Änderungen (nur Darstellung).

## 5.128

Keine Server-Änderungen (nur Berichtswesen-Oberfläche).

## 5.127

- Quelle `fristen` (ablaufende Atemschutz-Nachweise, 6 Monate Vorschau).
- `GET /agw/bericht/standorte` – Feuerwehrhäuser mit Ausrückzeit und Regeln (kmh, umweg) für die Anfahrtszeit-Karte.
- Berichtsformen: Feld `abo` (`''|'monat'|'jahr'`); Versand am 1. des Monats ab 7 Uhr (Schlüssel `agw.berichtAbo`); `POST /agw/bericht/abo-test {id}`.

## 5.126

- `GET /agw/bericht/daten?quelle=` neu: `fahrzeuge`, `hydranten`, `ausruestung` (Zeilen mit `lat`/`lon` des Feuerwehrhauses bzw. Hydranten); `einsaetze` und `traeger` liefern zusätzlich `lat`/`lon`.
- `GET /agw/bericht/kachel/:z/:x/:y.png?t=<Token>` – Kartenkacheln für das Berichtswesen (Sitzung erforderlich).

## 5.125

Keine Server-Änderungen (Übungsleitstelle schickt beim Start alle Fahrzeug-IDs an `/api/sim/start`).

## 5.124

- `GET /api/monitor/zustand/:token`: `alarm.sonderlage` (nur bei `gsl`) = Liste der eigenen aktiven Fahrzeuge `{funkrufname, typ, status, lat, lon, auftrag:{nr,kat,adresse,status,prio,priolage,lat,lon}|null}` (max. 30), sonst `null`.

## 5.123

Keine Server-Änderungen.

## 5.122

Keine Server-Änderungen.

## 5.121

Keine Server-Änderungen.

## 5.120

Keine Server-Änderungen.

## 5.119

Keine Server-Änderungen.

## 5.118

Keine Server-Änderungen.

## 5.117

Keine Server-Änderungen.

## 5.116

Keine Server-Änderungen.

## 5.115

Keine Server-Änderungen.

## 5.114

Keine Server-Änderungen.

## 5.113

Keine Server-Änderungen.

## 5.112

Keine Server-Änderungen.

## 5.111

Keine Server-Änderungen.

## 5.110

- Auftrag: neues Feld `dispo` (true nach Erkundung oder wenn alle Fahrzeuge abgezogen wurden; Status bleibt `offen`).
- `auftrag.fz` mit `entfernen` sowie Umdisponieren setzen auch einen Auftrag „inArbeit“ ohne aktive Fahrzeuge zurück auf `offen` + `dispo`.

## 5.109

Keine Server-Änderungen (nur Oberfläche: Priolage-Zähler Spalte Neu, Rufzeichen-Suche bei Anforderung).

## 5.108
`opta3.sim.vonUser` (Starter); `/api/sim/zustand` und `/api/sim/:aktion` → 403 `gesperrt` für andere Benutzer außer Superadmin. Prioritätstexte „Priorität hoch/mittel/niedrig“ (Tagebuch, Push). Oberfläche: Mehrfach-Dispo, Fahrzeugauswahl beim neuen Einsatz (`fz.status` A je Fahrzeug), Mehrfachauswahl in der Übungsleitstelle, `platzNamen()`. Cache einsatzverwaltung-v176.

## 5.107
Nur Oberfläche: Ausgabe `ezElw` (QR-Code `location.origin + '/elw'`). Cache einsatzverwaltung-v175.

## 5.106
`POST /api/sim/entfernen {einsatzId, vid}` – Übungsfahrzeug aus dem Übungseinsatz nehmen (`fz.entfernen` mit `auchAktiv`). Übungsleitstelle: `?ansicht=fahrzeuge` (nur Fahrzeuge), Listenfilter. Cache einsatzverwaltung-v174.

## 5.105
`POST /agw/traeger/zugang` liefert `url` (Internetadresse /traeger). Bericht-Quelle `inbetrieb`; `pa` und Jahresauswertung mit `traegerWehr`. `GET /agw/nachweis` je Eintrag `inbetrieb {t,name,ok,druck}` (aus `ibAlle().eingesetzt.nw`). ASÜ-Doku-Mitglied mit `wehr`, `ibId`, `druckOk`. berichte.html mit den Farb-/Schrift-Variablen der Datenbank-Apps. Cache einsatzverwaltung-v173, asue-v122.

## 5.104
Nur Oberfläche: `AGW_GRP` fasst die Reiter `personen`+`nachweis` und `geraete`+`pflege`+`inbetrieb` zusammen (zweite Knopfzeile `grpZeile`). Cache einsatzverwaltung-v172, asue-v121.

## 5.103
ASÜ-Mitglied `wehr` (Ortswehr des Trägers; aus `ASUEP1.w` bzw. `TAUG.w`). Nachweis-Eintrag `traegerWehr`; Zuordnung der Ortswehr in `/agw/nachweis` und `agwNutzungen`: Person (pid) → `traegerWehr` → Gerät → überwachende Wehr. Atemschutz-DB ohne Reiter `bereit` (Standard `personen`), Summenleiste `sumLeiste` auf jeder Seite. Cache einsatzverwaltung-v171, asue-v120.

## 5.102
`agwAdmin(req,res,ber)`: Superadmin oder Zugang mit `admin:true` und Bereich `ber` (nicht `bericht`) – für `/agw/admin/konten` (GET `?bereich`, POST `bereich`, neu Feld `admin`), `/agw/admin/leitung` (Bereich des Ziel-Zugangs), `/agw/admin/asue/*` und `/agw/admin/schulungen*` (atemschutz), `/agw/admin/gdb-import` (geraete). `konto.admin` = Superadmin oder `admin`, `konto.superadmin`. Leitung je Ortswehr und Bereich: `agwLeiter(wehr, ber)`, `agwLeitungVon(k, ber)`, `GET/POST /agw/team?bereich=` (Team und neue Zugänge nur im Bereich). Kalender Atemschutz: `GET /agw/kalender?wehr`, `POST /agw/kalender/neu`, ICS `/kalender/atemschutz/:token(.ics)` (ASÜ-API, EV, Meldeserver), Token in `asue.agwKalender`. Träger-App: `trIstExtern` (Host bzw. X-Forwarded-Host = Internetadresse der ASÜ oder Loopback) – `/traeger` leitet sonst um, `/agw/traeger/*` → 403 `extern`. Cache einsatzverwaltung-v170, asue-v119.

## 5.101
Inbetriebnahme `store['agw.inbetrieb']` `{[id 'I…']: {id, t, name, von, quelle:'asue'|'traeger'|'db', wehr, geraet, la, flasche, maske, pruef:{hd,warn,druck,sicht:'ok'|'nio'}, druck, ok, bem, eingesetzt?:{nw, code, beginn, art, einsatzstelle, evNummer, trupp, funktion, name, druckA, druckOk}}}`. `ibAufloesen` ergänzt LA/Flasche aus dem Atemschutzgerät (Nummer oder `kz`). `ibVerknuepfen()` (nach `nachweisAktualisieren` und bei GET) verbindet mit dem ersten Nachweis-Eintrag ab `t` mit `ib`-Id oder gleicher Geräte-/Flaschennummer. Nachweis-Einträge haben neu `ib`, `druckOk` (aus ASÜ-Mitglied `ibId`, `druckOk`). Routen: `GET/POST /api/pflege/inbetrieb` (ASÜ, hinter dem Wehr-Schlüssel; GET → `{punkte, liste (offen, 180 Tage), gesperrt[nr], wehren}`), `GET/POST /api/agw/traeger/inbetrieb` (X-TR-Token), `GET/POST /api/agw/inbetrieb` (AGW-Zugang, `loeschen`). Cache einsatzverwaltung-v169, asue-v118.

## 5.100
Admin-Routen der Einsatzverwaltung in die ASÜ-Schnittstelle verlegt (nur Superadmin über `X-AGW-Token`, `agwSuperBen` setzt `req.benutzer`; keine PIN-Abfrage mehr): `GET/POST /api/agw/admin/asue/zugaenge` (vorher `/api/asue/zugaenge`), `GET /api/agw/admin/asue/schluessel-qr`, `GET /api/agw/admin/asue/github`, `POST …/asue/github/einstellen|veroeffentlichen|umzug|paket`, `POST /api/agw/admin/asue/adresse`, `GET/POST /api/agw/admin/schulungen`, `POST /api/agw/admin/schulungen/upload` (octet-stream), `POST /api/agw/admin/gdb-import`. `GET /api/agw/admin/konten?bereich=geraete` liefert zusätzlich `gdb` (= `gdbStand()`). Entfallen: `GET/POST /api/agw/konten`, `POST /api/agw/leitung`, alle obigen alten Pfade unter `/api/`. EV-Reiter `asuezug`/`agw` → `apps` (`renderAppZugaenge`). Cache einsatzverwaltung-v168, asue-v117.

## 5.99
`obmAdressen(wehr)` liefert nur noch Adressen aus dem Berichtswesen (kein Rückfall). `mailKonfig()` übernimmt einmalig `mail.obm` in Berichts-Zugänge ohne `mail` (Flag `obmV599`); Reste ohne Zugang stehen in `obmUebrig` (nur Anzeige / Vorbelegung bei `bericht-uebernehmen`, kein Versand). `GET /api/mail/konfig`: `obmQuelle.alt` = `obmUebrig`. `asue/index.html` ohne GDB-Code (kein `#GDB1:`/`#GDBFZ:`-Hash mehr unter /atemschutz), `asue/geraete.html` ohne ASÜ-/Atemschutz-Code. Cache einsatzverwaltung-v167, asue-v116.

## 5.98
`obmAdressen(wehr)` = E-Mails der aktiven Berichts-Zugänge mit genau dieser Ortswehr; Rückfall auf `mail.obm` (alt), solange keine vorhanden. `GET /api/mail/konfig` liefert `obmQuelle {wehr:{bericht[], alt[]}}`; die EV speichert keine OBM-Adressen mehr (Feld `obm` wird nicht mehr gesendet, Altwerte bleiben erhalten). Cache einsatzverwaltung-v166.
