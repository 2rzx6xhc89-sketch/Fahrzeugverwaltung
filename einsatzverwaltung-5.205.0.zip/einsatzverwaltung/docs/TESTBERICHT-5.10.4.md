# Testbericht Einsatzverwaltung 5.10.4

Stand: 11.10.2026 · Gesamttest aller Programmteile vor der Freigabe von 5.10.4.

## Zusammenfassung

| Teil | Schritte | Ergebnis |
|---|---|---|
| Statische Prüfung (Syntax aller JS-Dateien und eingebetteten Skripte, alle Seiten erreichbar) | – | ✅ ohne Befund |
| Einsatzverwaltung (Browser-Test, alle Reiter, Einsatz von Anlage bis Archiv) | 63 | ✅ 63 / 63 |
| Fahrzeug-App (Status, Stärke, Nachrichten, Karte, Hydrantenprüfung, Schaden, Fahrtenbuch, Push-Hinweis) | 20 | ✅ 20 / 20 |
| Atemschutzüberwachung + Atemschutz-Datenbank + Gerätedatenbank + Superadmin | 43 | ✅ 43 / 43 (nach Fehlerbehebung) |
| Alarmmonitor, Update-Paket, Datensicherung, Druckseiten, Exporte, GitHub-Veröffentlichung, PWA-Dateien | 27 | ✅ 27 / 27 |

**Gefundener und behobener Fehler (1):** In der Atemschutz- und Gerätedatenbank meldete „Kennwort ändern“ → „Abbrechen“ den Benutzer ab; man musste sich neu anmelden. Jetzt bleibt die Anmeldung bestehen.

Keine weiteren Programmfehler. Alle anderen Auffälligkeiten im Test waren gewollte Sicherungen des Programms (siehe unten „Beobachtungen“).

## Testumgebung

- Kopie des Programms in einem Testordner, eigene Ports (Einsatzverwaltung, Fahrzeug-App, ASÜ), frische Daten mit Fahrzeugen aller Ortswehren, Objekten, Hydranten, einem laufenden Einsatz, Gerätedatenbank (151 importierte Geräte), Atemschutz-Datenbank (10 Personen, 4 Geräte).
- Browser-Tests mit Chromium (Playwright), Bildschirm 1300–1600 px (Verwaltung) und 430 px (Fahrzeug-App).
- Ersatz-Server („Attrappen“) für Web-Push und die GitHub-API, damit diese Wege ohne Internet geprüft werden konnten.

## 1 · Einsatzverwaltung (63 Schritte)

Anmeldung mit PIN; alle Hauptreiter (Übersicht, Standorte, Einsatz, Besatzung, Objekte, Gefahrstoffe, Archiv, E-Mail, Verwaltung); alle Verwaltungsseiten (Fahrzeuge, Benutzer, Einstellungen inkl. aller Einstellungsgruppen, System, ASÜ-Zugänge, Gerätewarte, Feuerwehrhäuser, Exposition, Protokoll, Fahrzeug-App, Sicherheit, Alarmmonitor, Berichte, Hydranten).

Vollständiger Einsatzablauf: Einsatz über das Formular anlegen (Stichwort, Meldebild, Adresse, Koordinate, Einsatzleiter) → drei Fahrzeuge alarmieren → Status 3 und 4 → alle Einsatz-Karten (Übersicht, Tagebuch, Fahrzeuge, Abschnitte, Nachrichten, Fotos, Atemschutz, VU, Checklisten, Nachbereitung, Zeitstrahl) → Tagebucheintrag, Stärke, Lagemeldung, Abschnitt → Lagekarte mit Marker, Werkzeug- und Ebenenleiste → Einsatzbericht-Vorschau → Einsatz beenden (PIN-Bestätigung) → Archiv, Archiv-Einsatz öffnen, Jahresauswertung, Hinweis-Zentrale.

Verwaltung: Benutzer anlegen, Superadmin anlegen, Gerätewart anlegen, Fahrzeug-App-Zugang, Objekt anlegen, Gefahrstoffsuche, E-Mail-Reiter, Abmelden, Anmeldung als Superadmin mit Kennwort.

## 2 · Fahrzeug-App (20 Schritte)

Laden über den Fahrzeug-Link; laufender Einsatz wird angezeigt; „Im Einsatz“/„Verfügbar“; Stärke melden; Nachricht von der Einsatzverwaltung empfangen und beantworten; Karte mit Reitern und Knöpfen; Hydrantenprüfung (Punkt wählen, Prüfpunkte, Ergebnis); Standort senden; Schaden melden (kommt in der Einsatzverwaltung und Gerätedatenbank an); Fahrtenbuch: Fahrt nur mit km-Stand, Getankt, Betriebsstunden; Benachrichtigungs-Bereich; Fahrzeug-Check; Status 2 → Fahrtenbuch-Hinweis öffnet sich von selbst; Besatzungs-App und Stärke-Sammelseite laden; gesperrter Link wird abgewiesen.

## 3 · Atemschutzüberwachung, Datenbanken, Superadmin (43 Schritte)

ASÜ: Wehr-Kennwort über die Verwaltung setzen; Anmeldung als Ortswehr; leeren Einsatz beginnen; Trupp mit zwei Personen und Gerätenummern anlegen; Beginn bestätigen (Gerätename wird abgefragt; die ASÜ erkennt den laufenden Einsatz der Einsatzverwaltung und bietet „Einsatz anschließen“ an – angenommen); Trupp-Dialog; Reiter Trupps & Geräte, Einsatzdaten, Protokoll, Tausch/Prüfung, Einstellungen; „Jetzt senden“ – Truppstatus kommt in der Einsatzverwaltung an; MAYDAY auslösen (Checkliste); weitere Schritte; Einsatzende.

Atemschutz-Datenbank: Anmeldung; alle Unterreiter (Einsatzbereitschaft, Personen, Atemschutzgeräte, Einsatznachweis, Gerätepflege, Jahresauswertung, QR-Codes); Person anlegen; persönlichen Link erzeugen (mit QR) und die AGT-Seite damit aufrufen; Atemschutzgerät anlegen; Benachrichtigungs-Panel; Kennwort ändern/Abbrechen (**Fehler gefunden und behoben**); Abmelden.

Gerätedatenbank: Anmeldung; Gerät anlegen; Prüfung eintragen; Mangel melden → repariert; QR-Etikett; Wochenüberblick; Listen & Prüfarten; Fahrtenbuch & Fristen (HU eintragen); Benachrichtigungs-Panel; Gerät löschen; Abmelden.

Superadmin: Anmeldung mit demselben Kennwort in ASÜ, Gerätedatenbank und Atemschutz-Datenbank.

## 4 · Alarmmonitor, Update, Sicherung, Druck, GitHub (27 Schritte)

- Alarmmonitor: anlegen; Seite, Zustand, Kalender-Abo (ICS) und gemeinsames Skript erreichbar; falscher Link → 404; Seite im Browser ohne Skriptfehler; neuer Einsatz mit alarmiertem Fahrzeug erscheint innerhalb von Sekunden als Alarm; Fahrzeugfrist (HU in 5 Tagen) erscheint unter „Termine“; Liste und Löschen.
- Programm aktualisieren: das Paket 5.10.x wird geprüft (Entpacken, Pflichtdateien, Syntax, **Probestart in Ordnung**); eine falsche Datei wird mit klarer Meldung abgelehnt. Das tatsächliche Einspielen (Neustart) wurde in der Testumgebung nicht ausgeführt.
- Datensicherung: stündliche Kopie läuft; vollständiger Download als JSON; mit gesetztem Sicherungspasswort kommt die Datei verschlüsselt (EVSICH01) und lässt sich mit `sicherung-entschluesseln.js` wieder lesbar machen.
- Druck/Export: Jahresbericht (HTML + JSON), Notfallmappe, Datenschutzhinweise (ohne Anmeldung auf allen drei Servern), Hydranten-CSV, Hydrantenliste – alle ohne Skriptfehler.
- GitHub-Veröffentlichung: Einstellungen, Paket erzeugen, Veröffentlichen (23 API-Aufrufe gegen die Attrappe, Commit erzeugt), Schlüssel löschen.
- PWA: Manifest und Service Worker der Einsatzverwaltung, Fahrzeug-App und ASÜ erreichbar.

## Beobachtungen (kein Fehler – gewollte Sicherungen)

- Gerätenummern in der ASÜ sind reine Zahlen (Eingabe „PA-1“ wird abgelehnt) – passend zu den Etiketten.
- Bei unverändertem Flaschendruck verlangt die ASÜ eine ausdrückliche Bestätigung („Druck wurde abgefragt“).
- Beim ersten Start fragt die ASÜ nach einem Gerätenamen (nötig für den gemeinsamen Einsatz mehrerer Geräte).
- Die Fahrzeug-App zeigt die Schadensmeldung nur für Fahrzeuge mit erfasster Ausrüstung.
- Fahrzeugfristen erscheinen auf dem Alarmmonitor erst innerhalb des Termin-Zeitraums (Vorgabe 14 Tage).

## Nicht in der Testumgebung prüfbar

- Echte Push-Benachrichtigungen an Handys (nur gegen Attrappe geprüft), echte GitHub-Pages-Veröffentlichung, Versand echter E-Mails, Alarm-Eingang über die Leitstellen-Mail, Schriftarten-Download vom Pi (kein Internet im Testsystem), USB-Stick-Sicherung, Neustart nach Update.
- Diese Punkte bitte nach dem Einspielen von 5.10.4 einmal auf dem Pi gegenprüfen (Sicherheits-Check in der Verwaltung → System).

## Hinweis zu den Anleitungen

Die Anleitungen (ANLEITUNG, BEDIENUNG, Kurzanleitungen) und die Demo sind auf dem Stand 5.8; die Neuerungen 5.9–5.10.4 (Hydrantenprüfung, Fahrtenbuch, Fahrzeugfristen) sind dort noch nicht beschrieben. Technische Beschreibung: `docs/SERVER_API.md`.
