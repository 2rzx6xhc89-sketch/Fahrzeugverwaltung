#!/bin/bash
# Sicherungsstick FWBACKUP einmalig einrichten (ab Version 3.65)
#
#   sudo bash ~/einsatzverwaltung/docs/stick-einrichten.sh
#
# Danach hängt der Pi den Stick von selbst ein, sobald die Einsatzverwaltung sichert –
# auch nach Abziehen und Wiedereinstecken. Nach einer Minute ohne Zugriff hängt er ihn
# wieder aus; dann kann der Stick gefahrlos abgezogen werden.
# Mehrfaches Ausführen schadet nicht (eine alte FWBACKUP-Zeile wird ersetzt).
set -e

ZIEL="${ZIEL:-/mnt/fwbackup}"
LABEL="${LABEL:-FWBACKUP}"

if [ "$(id -u)" -ne 0 ]; then
  echo "Bitte mit sudo starten:  sudo bash $0"; exit 1
fi
NUTZER="${SUDO_USER:-}"
if [ -z "$NUTZER" ] || [ "$NUTZER" = "root" ]; then
  NUTZER="$(systemctl show -p User --value einsatzverwaltung 2>/dev/null || true)"
fi
if [ -z "$NUTZER" ] || [ "$NUTZER" = "root" ]; then
  echo "Benutzer der Einsatzverwaltung nicht gefunden. Bitte als dieser Benutzer mit sudo starten."; exit 1
fi
UID_N="$(id -u "$NUTZER")"; GID_N="$(id -g "$NUTZER")"

mkdir -p "$ZIEL"
cp /etc/fstab "/etc/fstab.vor-stick-$(date +%Y%m%d-%H%M%S)"
# alte Zeile(n) für den Stick bzw. diesen Einhängepunkt entfernen
TMP="$(mktemp)"
awk -v z="$ZIEL" -v l="LABEL=$LABEL" '!($1 == l || ($2 == z && $1 ~ /^(LABEL|UUID|PARTUUID)=|^\/dev\//))' /etc/fstab > "$TMP"
echo "LABEL=$LABEL $ZIEL auto defaults,nofail,noatime,x-systemd.automount,x-systemd.idle-timeout=60,x-systemd.device-timeout=5s,uid=$UID_N,gid=$GID_N,umask=0077 0 0" >> "$TMP"
cat "$TMP" > /etc/fstab; rm -f "$TMP"

UNIT="$(systemd-escape -p --suffix=automount "$ZIEL")"
umount "$ZIEL" 2>/dev/null || true
systemctl daemon-reload
systemctl restart "$UNIT"

echo
echo "Eingerichtet: $ZIEL (Stick mit dem Namen $LABEL, Benutzer $NUTZER)."
if [ -e "/dev/disk/by-label/$LABEL" ]; then
  ls "$ZIEL" >/dev/null 2>&1 || true
  df -h "$ZIEL" | tail -1
  echo "Stick erkannt. In der Einsatzverwaltung: Verwaltung → Einstellungen → Sicherung & System → „Jetzt sichern“."
else
  echo "Zurzeit steckt kein Stick mit dem Namen $LABEL. Einfach einstecken – die Einsatzverwaltung erkennt ihn von selbst."
fi
