#!/usr/bin/env node
/* Update-Pakete der Einsatzverwaltung signieren (ab 5.131)

   Ein Schlüsselpaar erzeugen (einmalig, privaten Schlüssel sicher aufbewahren!):
     node update-signieren.js --schluessel <Ordner>
       → <Ordner>/update-privat.pem   (geheim – nur auf dem Rechner, der Pakete erstellt)
       → <Ordner>/update-oeffentlich.pem und die Zeile für server.js (UPDATE_SCHLUESSEL)

   Ein entpacktes Paket signieren (Ordner „einsatzverwaltung“):
     node update-signieren.js <Ordner einsatzverwaltung> <update-privat.pem>
       → schreibt <Ordner>/SIGNATUR.json mit SHA-256 jeder Datei und einer Ed25519-Signatur.
     Danach SIGNATUR.json mit in die ZIP-Datei packen.

   Der Pi prüft beim Update: Signatur passt zu einem der eingetragenen Schlüssel, jede Datei im Paket
   steht mit derselben Prüfsumme in SIGNATUR.json, und keine Datei fehlt oder ist hinzugekommen. */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function dateienListe(wurzel) {
  const out = [];
  (function lauf(dir) {
    for (const n of fs.readdirSync(dir).sort()) {
      const f = path.join(dir, n); const st = fs.lstatSync(f);
      if (st.isDirectory()) lauf(f);
      else if (st.isFile()) { const rel = path.relative(wurzel, f).split(path.sep).join('/'); if (rel !== 'SIGNATUR.json') out.push(rel); }
    }
  }(wurzel));
  return out.sort();
}
function inhaltFuerSignatur(m) {   // feste Reihenfolge der Felder und Dateien
  const dateien = {}; Object.keys(m.dateien).sort().forEach((k) => { dateien[k] = m.dateien[k]; });
  return Buffer.from(JSON.stringify({ format: m.format, programm: m.programm, version: m.version, erstellt: m.erstellt, dateien }));
}
module.exports = { dateienListe, inhaltFuerSignatur };

if (require.main === module) {
  const [a, b] = process.argv.slice(2);
  if (a === '--schluessel') {
    const ziel = b || '.';
    fs.mkdirSync(ziel, { recursive: true });
    const priv = path.join(ziel, 'update-privat.pem');
    if (fs.existsSync(priv)) { console.error(`${priv} gibt es schon – nicht überschrieben.`); process.exit(1); }
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
    fs.writeFileSync(priv, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
    fs.writeFileSync(path.join(ziel, 'update-oeffentlich.pem'), publicKey.export({ type: 'spki', format: 'pem' }));
    console.log('Öffentlicher Schlüssel für server.js (UPDATE_SCHLUESSEL):');
    console.log(publicKey.export({ type: 'spki', format: 'der' }).toString('base64'));
    process.exit(0);
  }
  if (!a || !b) { console.error('Aufruf: node update-signieren.js <Ordner einsatzverwaltung> <update-privat.pem>   oder   --schluessel <Ordner>'); process.exit(1); }
  const wurzel = path.resolve(a);
  let pk = {}; try { pk = JSON.parse(fs.readFileSync(path.join(wurzel, 'package.json'), 'utf8')); } catch (e) { console.error('package.json im Ordner nicht lesbar.'); process.exit(1); }
  const m = { format: 1, programm: pk.name || 'einsatzverwaltung', version: pk.version || '', erstellt: new Date().toISOString(), dateien: {} };
  dateienListe(wurzel).forEach((rel) => { m.dateien[rel] = crypto.createHash('sha256').update(fs.readFileSync(path.join(wurzel, rel))).digest('hex'); });
  const schluessel = crypto.createPrivateKey(fs.readFileSync(b));
  const sig = crypto.sign(null, inhaltFuerSignatur(m), schluessel).toString('base64');
  const oeff = crypto.createPublicKey(schluessel).export({ type: 'spki', format: 'der' }).toString('base64');
  fs.writeFileSync(path.join(wurzel, 'SIGNATUR.json'), JSON.stringify({ ...m, schluessel: oeff, signatur: sig }, null, 1));
  console.log(`SIGNATUR.json geschrieben: ${Object.keys(m.dateien).length} Dateien, Version ${m.version}.`);
}
