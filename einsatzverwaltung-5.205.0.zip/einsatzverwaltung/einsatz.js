/*
 * Einsatzverwaltung – Einsatz-Logik auf dem Server
 * -------------------------------------------------
 * Alles, was mehrere Geräte gleichzeitig ändern können (Einsätze, FMS-Status,
 * Einsatztagebuch, Kräfteanforderungen, Lagemeldungen, Stärke), wird hier auf
 * dem Server ausgeführt. So gehen keine Einträge verloren, wenn zwei Geräte
 * gleichzeitig schreiben, und Tagebuchnummern sind eindeutig.
 *
 * Datenmodell (Schlüssel in data.json):
 *   opta3.einsaetze        { [eid]: Einsatz }                         laufende Einsätze
 *                          (Einsatz.uhren = Tankuhren/Lage-Erinnerung, Einsatz.vu = Unfallfahrzeuge, .checks = abgehakte Checklistenpunkte, .warnungen = vermerkte Warn-IDs)
 *   opta3.tb.<eid>         [ Tagebucheintrag ]                         Einsatztagebuch (nur anhängen)
 *   opta3.karte.<eid>      { v:2, markers[{lat,lon}], vehPos{vid:{lat,lon}}, shapes, bild … }  Lagekarte je Einsatz
 *   opta3.karteBg.<eid>    data:-URL                                   eigenes Kartenbild (Lageplan) je Einsatz
 *   opta3.taktik.<eid>     wie opta3.karte (zweite Karte „Einsatztaktik“), opta3.taktikBg.<eid> ihr Kartenbild
 *   opta3.auftraege.<eid>  { zaehler, liste:[Auftrag] }                Aufträge einer Großschadenslage (Unwetter)
 *   opta3.objekte          [ Objekt ]                                  besondere Objekte mit Plänen (Dateien in objekte/)
 *   opta3.kontakte         [ {id, funktion, name, telefon, telefon2, email, bemerkung} ]  Ansprechpartner (Einsatz.kontakte = Kopie im Einsatz)
 *   opta3.nachrichten      { [fahrzeugId]: [ {id, t, text, von, eid, quittiert} ] }  Nachrichten an die Fahrzeug-App
 *   opta3.status           { [fahrzeugId]: '1'|'3'|'4'|'6'|'A' }       FMS-Status (fehlt = 2)
 *   opta3.statusZeit       { [fahrzeugId]: Zeitpunkt der letzten Änderung }
 *   opta3.fmsRuf           { [fahrzeugId]: { code:'5'|'0', t } }       Sprechwunsch / Notruf
 *   opta3.personnel        { [fahrzeugId]: { f, uf: 0, m, agt } }      Stärke je Fahrzeug (ab 3.52 ohne Unterführer: uf zählt zur Mannschaft)
 *   opta3.einsatzZaehler   { [Jahr]: laufende Nummer }
 *   opta3.pos              { [fahrzeugId]: { lat, lon, acc, speed, heading, t } }  letzte Position
 *   spur.<eid>             { [fahrzeugId]: [[t, lat, lon], …] }        Fahrspur (privat)
 *   arch.index / arch.<eid>  Archiv (privat, nur per /api/archiv abrufbar)
 */

const FMS = {
  '1': 'Einsatzbereit über Funk',
  '2': 'Einsatzbereit auf Wache',
  'A': 'Alarmiert',
  '3': 'Einsatzauftrag übernommen',
  '4': 'Am Einsatzort',
  '6': 'Nicht einsatzbereit',
};
const AKTIV = ['A', '3', '4'];
const RUF = { '5': 'Sprechwunsch', '0': 'Notruf' };
const ANF_STATUS = ['angefordert', 'alarmiert', 'unterwegs', 'eingetroffen', 'storniert'];
const TB_RICHTUNG = ['Eingang', 'Ausgang', 'Vermerk'];
const AUF_STATUS = ['offen', 'erkundung', 'disponiert', 'inArbeit', 'erledigt', 'storniert'];
const AUF_LABEL = { offen: 'offen', erkundung: 'in Erkundung', disponiert: 'disponiert', inArbeit: 'in Arbeit', erledigt: 'erledigt', storniert: 'storniert' };
const AUF_ZU = ['erledigt', 'storniert'];
/* Verkehrsunfall: Maßnahmen je Unfallfahrzeug (Schlüssel → Text im Einsatztagebuch) */
const VU_MASSNAHMEN = {
  sichern: 'Fahrzeug gesichert / stabilisiert',
  zuendung: 'Zündung aus, Schlüssel entfernt (mind. 5 m)',
  rettungskarte: 'Rettungsdatenblatt geprüft',
  batterie: 'Batterie bzw. Hochvolt-System getrennt',
  airbag: 'Airbags geprüft',
  zugang: 'Erstzugang, Patient betreut',
  glas: 'Glasmanagement',
  oeffnung: 'Rettungsöffnung hergestellt',
  befreit: 'Patient befreit',
  betriebsstoffe: 'Betriebsstoffe aufgenommen',
};
const VU_CRS_PUNKTE = { airbags: 'Airbags / Gasgeneratoren beachten', gurt: 'Gurtstraffer', hv: 'Hochvolt-Leitungen / -Bauteile', trennstelle: 'Rettungstrennstelle / HV-Trennung vorhanden', verstaerkung: 'Hochfeste Verstärkungen – nur in freien Bereichen schneiden', tank: 'Tank / Gasbehälter beachten', batterie12: '12-V-Batterie' };
const VU_FELDER = { art: 'Art', kennzeichen: 'Kennzeichen', hersteller: 'Hersteller', modell: 'Modell', baujahr: 'Baujahr', farbe: 'Farbe', antrieb: 'Antrieb', lage: 'Lage', personen: 'Personen', eingeklemmt: 'eingeklemmt', rettung: 'Rettung', notiz: 'Notiz' };
const HV_ANTRIEB = /elektro|hybrid/i;

const K = {
  einsaetze: 'opta3.einsaetze',
  status: 'opta3.status',
  extStatus: 'opta3.extStatus',   // ab 5.69: zuletzt von außen (PowerAlarm/E-Mail) gelesener Status je Fahrzeug
  statusZeit: 'opta3.statusZeit',
  fmsRuf: 'opta3.fmsRuf',
  personnel: 'opta3.personnel',
  zaehler: 'opta3.einsatzZaehler',
  vehicles: 'opta3.vehicles',
  log: 'opta3.log',
  asueStatus: 'opta3.asueStatus',
  archIndex: 'arch.index',
  pos: 'opta3.pos',            // letzte GPS-Position je Fahrzeug (aus der Fahrzeug-App)
  karte: 'opta3.karte.',
  objekte: 'opta3.objekte',
  nachrichten: 'opta3.nachrichten',
  kontakte: 'opta3.kontakte',         // Ansprechpartner-Datenbank   // Nachrichten an die Fahrzeug-App je Fahrzeug
};
const aufKey = (eid) => `opta3.auftraege.${eid}`;
const spurKey = (eid) => `spur.${eid}`;   // Fahrspuren je Einsatz (privat, nur im Archiv)
const SPUR_MAX = 720;                      // 24 h bei einer Meldung alle 2 Minuten
const tbKey = (eid) => `opta3.tb.${eid}`;
/* ab 5.197: Prüfsummen-Kette im Einsatztagebuch (fälschungserkennend).
   Jeder Eintrag trägt h = SHA-256(h des vorigen Eintrags + feste Felder). Eine nachträgliche Änderung, ein Löschen
   oder Einfügen bricht die Kette ab dieser Stelle. „korrigiertDurch“ ist bewusst nicht enthalten (Korrekturvermerk). */
const TB_KETTE_FELDER = ['nr', 't', 'erfasst', 'nachtrag', 'richtung', 'von', 'an', 'text', 'user', 'auto', 'auftrag', 'tOrig', 'korrigiert'];
const tbKetteStart = (eid) => require('crypto').createHash('sha256').update(`EV-Einsatztagebuch|${eid}`).digest('hex');
function tbKetteHash(vorher, x) {
  const o = {}; TB_KETTE_FELDER.forEach((f) => { if (x[f] !== undefined && x[f] !== null && x[f] !== '') o[f] = x[f]; });
  return require('crypto').createHash('sha256').update(`${vorher}\n${JSON.stringify(o)}`).digest('hex');
}
function tbKetteAnhaengen(eid, tb, e) { let v = tbKetteStart(eid); for (let i = tb.length - 1; i >= 0; i -= 1) if (tb[i] && tb[i].h) { v = tb[i].h; break; } e.h = tbKetteHash(v, e); return e; }
/* Prüft die Kette. → { ok, n, gesichert, ohne (Einträge vor Einführung), ab (erste gesicherte Nr.), kopf, fehler:[{nr, grund}] } */
function tbPruefen(eid, tb) {
  const l = Array.isArray(tb) ? tb : []; const fehler = []; let v = tbKetteStart(eid), begonnen = false, ohne = 0, gesichert = 0, ab = null, vorNr = null;
  l.forEach((x, i) => {
    if (!x || typeof x !== 'object') { fehler.push({ nr: null, pos: i + 1, grund: 'ungültiger Eintrag' }); return; }
    const luecke = vorNr !== null && x.nr !== vorNr + 1;
    if (luecke) fehler.push({ nr: x.nr, grund: x.nr > vorNr + 1 ? `Eintrag Nr. ${vorNr + 1}${x.nr > vorNr + 2 ? `–${x.nr - 1}` : ''} fehlt (entfernt)` : `Nummer ${x.nr} folgt auf ${vorNr} – Eintrag eingefügt oder doppelt` });
    vorNr = x.nr;
    if (!x.h) { if (begonnen) fehler.push({ nr: x.nr, grund: 'Eintrag ohne Prüfsumme innerhalb der Kette – nachträglich eingefügt oder verändert' }); else ohne += 1; return; }
    if (!begonnen) { begonnen = true; ab = x.nr; }
    const soll = tbKetteHash(v, x);
    if (soll !== x.h && !luecke) fehler.push({ nr: x.nr, grund: tbKetteHash(tbKetteStart(eid), x) === x.h || l.some((y) => y && y.h && tbKetteHash(y.h, x) === x.h) ? 'Reihenfolge verändert oder Eintrag davor entfernt' : 'Inhalt nachträglich verändert' });
    v = x.h; gesichert += 1;
  });
  return { ok: !fehler.length, n: l.length, gesichert, ohne, ab, kopf: begonnen ? v : null, fehler: fehler.slice(0, 50) };
}
const karteKey = (eid) => `opta3.karte.${eid}`;
const karteBgKey = (eid) => `opta3.karteBg.${eid}`;
const lagestandKey = (eid) => `opta3.lagestand.${eid}`;   // gespeicherte Lagestände der Karten (je Einsatz)
const archKey = (eid) => `arch.${eid}`;

const str = (v, max) => (v == null ? '' : String(v).trim().slice(0, max || 200));
const int = (v, max) => Math.max(0, Math.min(max || 999, Math.floor(Number(v) || 0)));
const rid = (p) => `${p}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

function fehler(code, text) { const e = new Error(text || code); e.code = code; return e; }

module.exports = function createEinsatz({ store, save, broadcast, objektDir }) {
  /* ---------- Speicher-Helfer ---------- */
  function setKey(key, value) {
    store[key] = value;
    broadcast({ type: 'update', key, value });
  }
  function delKey(key) {
    if (!(key in store)) return;
    delete store[key];
    broadcast({ type: 'delete', key });
  }
  const einsaetze = () => (store[K.einsaetze] && typeof store[K.einsaetze] === 'object' ? store[K.einsaetze] : {});
  const vehiclesEcht = () => (Array.isArray(store[K.vehicles]) ? store[K.vehicles] : []);
  // ab 3.98: Übungsfahrzeuge der Übungsleitstelle (eigene Kennung „ueb_…“, nie an echte Fahrzeug-Apps)
  const K_UEBFZ = 'opta3.uebFahrzeuge';
  const vehiclesUeb = () => (Array.isArray(store[K_UEBFZ]) ? store[K_UEBFZ] : []);
  const vehicles = () => vehiclesUeb().length ? vehiclesEcht().concat(vehiclesUeb()) : vehiclesEcht();
  const istUebFz = (vid) => String(vid || '').startsWith('ueb_');
  const istSim = (e) => !!(e && e.uebung && e.uebung.sim);
  function trennungPruefen(e, vid) {
    if (!e) return;
    if (istSim(e) && !istUebFz(vid)) throw fehler('uebung_trennung', 'In einem Übungseinsatz der Übungsleitstelle sind nur Übungsfahrzeuge möglich – echte Fahrzeuge bleiben unberührt.');
    if (!istSim(e) && istUebFz(vid)) throw fehler('uebung_trennung', 'Übungsfahrzeuge können nur in Übungseinsätzen der Übungsleitstelle eingesetzt werden.');
  }
  const vehName = (vid) => { const v = vehicles().find((x) => x.id === vid); return (v && (v.funkrufname || v.name)) || String(vid); };
  const stOf = (vid) => (store[K.status] || {})[vid] || '2';
  function fzEinsatz(vid) {
    const all = einsaetze();
    return Object.keys(all).find((eid) => all[eid].fahrzeuge && all[eid].fahrzeuge[vid] && all[eid].fahrzeuge[vid].aktiv) || null;
  }
  function putEinsatz(e) { setKey(K.einsaetze, { ...einsaetze(), [e.id]: e }); }

  function systemLog(user, text) {
    const log = Array.isArray(store[K.log]) ? store[K.log].slice() : [];
    log.push({ time: Date.now(), user: user || 'System', text });
    setKey(K.log, log.slice(-500));
  }
  /* Führungsstelle (ab 3.80): ÖEL bei Sonderlage, sonst ELW – beim Anlegen/Bearbeiten wählbar; „ELW“ wird beim Schreiben ersetzt */
  const FST = ['ELW', 'ÖEL'];
  function fst(eid) { const e = einsaetze()[eid]; return !e ? 'ELW' : FST.includes(e.fuehrung) ? e.fuehrung : e.gsl ? 'ÖEL' : 'ELW'; }
  const fstTausch = (v, eid) => (v === 'ELW' || v === 'ÖEL' ? fst(eid) : v);
  // ab 3.88: Funkrufname der Führungsstelle (Einstellungen; Vorgabe ELW 14-11-10, ÖEL 14-09-10) – Absender in der Fahrzeug-App
  function fstFunk(eid) { const ff = ((store['opta3.settings'] || {}).fuehrungFunk) || {}; return fst(eid) === 'ÖEL' ? (ff.oel || '14-09-10') : (ff.elw || '14-11-10'); }
  const fstLabel = (eid) => `${fst(eid)} ${fstFunk(eid)}`;
  function aufEid(a) { return Object.keys(einsaetze()).find((eid) => { const d = store[aufKey(eid)]; return d && Array.isArray(d.liste) && d.liste.some((x) => x.id === a.id); }) || null; }
  function tbAdd(eid, entry) {
    if (!einsaetze()[eid]) return null;
    const tb = Array.isArray(store[tbKey(eid)]) ? store[tbKey(eid)].slice() : [];
    const nr = tb.length ? tb[tb.length - 1].nr + 1 : 1;
    const e = {
      nr, t: Date.now(),
      richtung: TB_RICHTUNG.includes(entry.richtung) ? entry.richtung : 'Vermerk',
      von: str(fstTausch(entry.von, eid), 80), an: str(fstTausch(entry.an, eid), 80), text: str(entry.text, 2000),
      user: str(entry.user, 60) || 'System',
    };
    if (entry.nachtragZeit) { e.erfasst = e.t; e.t = entry.nachtragZeit; e.nachtrag = true; }   // nachträglich mit früherer Uhrzeit
    if (entry.auto) e.auto = entry.auto;           // 'status' | 'asue' | 'system' | 'auftrag'
    if (entry.auftrag) { e.auftrag = int(entry.auftrag, 99999); if (entry.tOrig) e.tOrig = Number(entry.tOrig) || undefined; }
    if (entry.korrigiert) {
      const orig = tb.find((x) => x.nr === Number(entry.korrigiert));
      if (orig) { e.korrigiert = orig.nr; orig.korrigiertDurch = nr; }
    }
    tbKetteAnhaengen(eid, tb, e);   // ab 5.197
    tb.push(e);
    setKey(tbKey(eid), tb);
    return e;
  }

  /* ---------- Einsatz anlegen / ändern ---------- */
  function naechsteNummer(t) {
    const jahr = String(new Date(t).getFullYear());
    const z = { ...(store[K.zaehler] || {}) };
    z[jahr] = (z[jahr] || 0) + 1;
    setKey(K.zaehler, z);
    return `${jahr}-${String(z[jahr]).padStart(3, '0')}`;
  }
  const KOPF_FELDER = ['stichwort', 'meldebild', 'adresse', 'meldender', 'einsatzleiter', 'bereitstellung', 'notiz'];
  function kopfAus(args, alt) {
    const k = {};
    KOPF_FELDER.forEach((f) => { if (args[f] !== undefined) k[f] = str(args[f], f === 'notiz' ? 1000 : 200); else if (alt) k[f] = alt[f] || ''; });
    if (args.alarmzeit !== undefined) { const t = Number(args.alarmzeit); k.alarmzeit = t > 0 ? t : Date.now(); } else if (alt) k.alarmzeit = alt.alarmzeit;
    if (args.lat !== undefined || args.lon !== undefined) {
      const lat = Number(args.lat), lon = Number(args.lon);
      const ok = Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && (lat || lon);
      k.lat = ok ? lat : null; k.lon = ok ? lon : null;
    } else if (alt) { k.lat = alt.lat ?? null; k.lon = alt.lon ?? null; }
    if (args.brLat !== undefined || args.brLon !== undefined) {
      const la = Number(args.brLat), lo = Number(args.brLon);
      const ok = args.brLat != null && args.brLon != null && Number.isFinite(la) && Number.isFinite(lo) && Math.abs(la) <= 90 && Math.abs(lo) <= 180 && (la || lo);
      k.brLat = ok ? +la.toFixed(6) : null; k.brLon = ok ? +lo.toFixed(6) : null;
    } else if (alt) { k.brLat = alt.brLat ?? null; k.brLon = alt.brLon ?? null; }
    if (args.gsl !== undefined) k.gsl = !!args.gsl; else if (alt) k.gsl = !!alt.gsl;
    if (args.fuehrung !== undefined) k.fuehrung = FST.includes(args.fuehrung) ? args.fuehrung : null; else if (alt) k.fuehrung = alt.fuehrung || null;
    if (args.objektId !== undefined) k.objektId = objekte().some((o) => o.id === args.objektId) ? String(args.objektId) : null;
    else if (alt) k.objektId = alt.objektId || null;
    return k;
  }
  function einsatzNeu(args, user) {
    const kopf = kopfAus(args);
    if (!kopf.alarmzeit) kopf.alarmzeit = Date.now();
    const id = rid('e');
    const e = {
      id, nummer: naechsteNummer(kopf.alarmzeit), ...kopf,
      eroeffnet: { t: Date.now(), user },
      abschnitte: [{ id: 'ea', name: 'Nicht zugeteilt', leiter: '', kanal: '', fixed: true }],
      fahrzeuge: {}, anforderungen: [], lage: [],
    };
    putEinsatz(e);
    store[tbKey(id)] = [];
    tbAdd(id, { richtung: 'Vermerk', von: user, text: `Einsatz ${e.nummer} eröffnet: ${[e.stichwort, e.meldebild].filter(Boolean).join(' – ') || 'ohne Stichwort'}${e.adresse ? `, ${e.adresse}` : ''}.${e.gsl ? ` Geführt als Großschadenslage mit Auftragsverwaltung. Bereitstellungsraum eingerichtet${e.bereitstellung ? `: ${e.bereitstellung}` : ' (Adresse noch offen)'}.` : ''}`, user, auto: 'system' });
    if (e.gsl) setKey(aufKey(id), { zaehler: 0, liste: [] });
    systemLog(user, `Einsatz ${e.nummer} eröffnet (${e.stichwort || 'ohne Stichwort'}).`);
    return e;
  }
  function einsatzAendern(args, user) {
    const e = einsaetze()[args.id]; if (!e) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const neu = { ...e, ...kopfAus(args, e) };
    const geaendert = ['stichwort', 'meldebild', 'adresse', 'einsatzleiter', 'bereitstellung'].filter((f) => (neu[f] || '') !== (e[f] || ''));
    if (Array.isArray(neu.brs) && neu.brs.length) neu.brs = neu.brs.map((b, i) => (i ? b : { ...b, adresse: neu.bereitstellung || '', lat: neu.brLat ?? null, lon: neu.brLon ?? null }));   // 1. BR = Bereitstellungsraum im Einsatzkopf
    putEinsatz(neu);
    const namen = { stichwort: 'Stichwort', meldebild: 'Meldebild', adresse: 'Einsatzort', einsatzleiter: 'Einsatzleiter', bereitstellung: 'Bereitstellungsraum' };
    if (geaendert.length) tbAdd(e.id, { richtung: 'Vermerk', von: user, text: geaendert.map((f) => `${namen[f]}: ${neu[f] || '–'}`).join('; '), user, auto: 'system' });
    const fAlt = FST.includes(e.fuehrung) ? e.fuehrung : e.gsl ? 'ÖEL' : 'ELW', fNeu = fst(e.id);
    if (fAlt !== fNeu) tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Führungsstelle: ${fNeu}${fNeu === 'ÖEL' ? ' (Örtliche Einsatzleitung)' : ''}.`, user, auto: 'system' });
    if (!!neu.gsl !== !!e.gsl) {
      tbAdd(e.id, { richtung: 'Vermerk', von: user, text: neu.gsl ? `Einsatz wird ab jetzt als Großschadenslage mit Auftragsverwaltung geführt. Bereitstellungsraum eingerichtet${neu.bereitstellung ? `: ${neu.bereitstellung}` : ' (Adresse noch offen)'}.` : 'Auftragsverwaltung (Großschadenslage) beendet.', user, auto: 'system' });
      if (neu.gsl && !store[aufKey(e.id)]) setKey(aufKey(e.id), { zaehler: 0, liste: [] });
    }
    return neu;
  }

  /* ---------- FMS-Status ---------- */
  const ANF_FOLGE = { A: 'alarmiert', 3: 'unterwegs', 4: 'eingetroffen' };
  function anforderungenNachziehen(e, vid, st) {
    const ziel = ANF_FOLGE[st]; if (!ziel) return false;
    let ch = false;
    (e.anforderungen || []).forEach((a) => {
      if (a.vid !== vid || a.status === 'storniert') return;
      if (ANF_STATUS.indexOf(ziel) > ANF_STATUS.indexOf(a.status)) { a.status = ziel; a.zeiten = { ...(a.zeiten || {}), [ziel]: Date.now() }; ch = true; }
    });
    return ch;
  }
  function fzStatus(args, user, quelle) {
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    const st = String(args.st);
    if (!FMS[st]) throw fehler('status_ungueltig', 'Unbekannter Status');
    const alt = stOf(vid);
    const now = Date.now();
    if (args.extern) setKey(K.extStatus, { ...(store[K.extStatus] || {}), [vid]: { st, t: now } });   // ab 5.69: gelesener Status merken
    // ab 5.49: Ein alarmiertes Fahrzeug bleibt „A“, bis Status 3/4 kommt oder der Einsatz endet – Meldungen von außen (PowerAlarm, E-Mail) mit 1/2/6 ändern daran nichts
    if (args.extern && alt === 'A' && fzEinsatz(vid) && !['3', '4'].includes(st)) throw fehler('noch_alarmiert', 'Das Fahrzeug bleibt alarmiert, bis Status 3 kommt oder der Einsatz beendet wird');
    if (args.rueck && !quelle) quelle = 'zurückgenommen';   // „Rückgängig“ in der App
    let eid = fzEinsatz(vid);
    const all = einsaetze();

    if (AKTIV.includes(st) && !(store[K.personnel] || {})[vid]) {
      // Vorgabe-Stärke des Fahrzeugs übernehmen (altes Format mannschaft/paTraeger wird umgerechnet)
      const d = (vehicles().find((v) => v.id === vid) || {}).personnelDefault;
      if (d) setKey(K.personnel, { ...(store[K.personnel] || {}), [vid]: d.mannschaft !== undefined ? { f: 0, uf: 0, m: int(d.mannschaft, 200), agt: int(d.paTraeger, 200) } : { f: int(d.f, 20), uf: 0, m: Math.min(200, int(d.m, 200) + int(d.uf, 50)), agt: int(d.agt, 200) } });
    }
    if (AKTIV.includes(st) && !eid) {
      const passend = Object.keys(all).filter((id) => istSim(all[id]) === istUebFz(vid));   // Übung und Ernstfall getrennt (ab 3.98)
      if (args.einsatzId && all[args.einsatzId]) eid = args.einsatzId;
      else if (passend.length === 1) eid = passend[0];
      else if (!args.ohneEinsatz) throw fehler('einsatz_waehlen', passend.length ? 'Bitte einen Einsatz wählen' : 'Bitte zuerst einen Einsatz anlegen');
    }
    if (eid) trennungPruefen(all[eid], vid);
    // ab 3.52: mit Status 2 ist die Besatzung abgerückt – Stärke zurücksetzen (beim nächsten Alarm gilt wieder die Vorgabe des Fahrzeugs)
    const staerkeVorher = (store[K.personnel] || {})[vid] || null;   // bleibt im Einsatz gespeichert (Bericht)
    if (st === '2' && (store[K.personnel] || {})[vid]) { const p = { ...(store[K.personnel] || {}) }; delete p[vid]; setKey(K.personnel, p); }
    // ab 3.80: mit Status 2 ist auch „Im Einsatz“/„Verfügbar“ der Fahrzeug-App erledigt
    if (st === '2' && (store['opta3.fzBereit'] || {})[vid]) { const b = { ...(store['opta3.fzBereit'] || {}) }; delete b[vid]; setKey('opta3.fzBereit', b); }
    // Status setzen
    const sm = { ...(store[K.status] || {}) };
    if (st === '2') delete sm[vid]; else sm[vid] = st;
    setKey(K.status, sm);
    setKey(K.statusZeit, { ...(store[K.statusZeit] || {}), [vid]: now });
    // Sprechwunsch ist mit jeder neuen Statusmeldung erledigt, Notruf nicht
    const ruf = store[K.fmsRuf] || {};
    if (ruf[vid] && ruf[vid].code === '5') { const r = { ...ruf }; delete r[vid]; setKey(K.fmsRuf, r); }

    if (eid) {
      const e = JSON.parse(JSON.stringify(all[eid]));
      const f = e.fahrzeuge[vid] || { seit: now, abschnitt: 'ea', zeiten: [] };
      const warAktiv = !!f.aktiv;
      if (!f.aktiv && AKTIV.includes(st)) { f.aktiv = true; delete f.bis; if (!f.zeiten.length) f.seit = now; }
      f.zeiten.push({ st, t: now });
      // Bei einer Großschadenslage bleiben Fahrzeuge mit Status 1 oder 2 in der Lage (frei für den nächsten Auftrag);
      // sie verlassen sie erst mit Status 6, „Aus dem Einsatz entlassen“ oder dem Einsatzende.
      // ab 3.52: laufen mehrere Einsätze, verlässt ein Fahrzeug mit Status 2 (einsatzbereit auf der Wache) den Einsatz immer.
      const mehrere = Object.keys(all).length > 1;
      const bleibt = AKTIV.includes(st) || (e.gsl && !args.entlassen && warAktiv && (st === '1' || (st === '2' && !mehrere)));
      if (!bleibt) { f.aktiv = false; f.bis = now; if (staerkeVorher) f.staerke = staerkeVorher; }
      // Bereitstellungsraum: mit Status 1/2/3/6 oder Entlassen gilt er als verlassen (ab 3.50)
      let brWeg = null;
      if (f.br && (!bleibt || ['1', '2', '3', '6'].includes(st))) { brWeg = brListe(e).find((x) => x.id === f.br) || { name: 'Bereitstellungsraum' }; f.br = null; f.brSeit = null; const l = (f.brLog || []).slice(-1)[0]; if (l && !l.aus) l.aus = now; }
      e.fahrzeuge[vid] = f;
      anforderungenNachziehen(e, vid, st);
      putEinsatz(e);
      const aufNr = aufVonFz(eid, vid);
      if (alt !== st) tbAdd(eid, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Status ${st} – ${FMS[st]}${aufNr ? ` (Auftrag ${aufNr})` : ''}${brWeg ? ` – Bereitstellungsraum „${brWeg.name}“ verlassen` : ''}${quelle ? ` (${quelle})` : ''}`, user, auto: 'status' });
      if (!bleibt && (warAktiv || AKTIV.includes(alt))) tbAdd(eid, { richtung: 'Vermerk', von: user, text: `${vehName(vid)} aus dem Einsatz entlassen.`, user, auto: 'status' });
      auftragStatusFolge(eid, vid, st, alt, !bleibt, user, quelle);
    } else if (alt !== st) {
      systemLog(user, `${vehName(vid)}: Status ${alt} → ${st}${quelle ? ` (${quelle})` : ''}${AKTIV.includes(st) ? ' – keinem Einsatz zugeordnet' : ''}`);
    }
    return { vid, st, einsatzId: eid };
  }
  /* Fahrzeug-App (ab 3.57): Besatzung meldet „im Einsatz“ oder „verfügbar“ – ohne FMS-Status (der kommt über PowerAlarm) */
  const BEREIT = { einsatz: 'im Einsatz', verfuegbar: 'verfügbar' };
  function fzBereit(args, user, quelle) {
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    const w = String(args.wert || '');
    if (!BEREIT[w]) throw fehler('wert_ungueltig', 'Unbekannter Wert');
    const alt = (store['opta3.fzBereit'] || {})[vid];
    setKey('opta3.fzBereit', { ...(store['opta3.fzBereit'] || {}), [vid]: { w, t: Date.now() } });
    const eid = fzEinsatz(vid);
    const ergebnis = str(args.ergebnis, 500);
    // ab 3.58: in der Großschadenslage mit dem Auftrag des Fahrzeugs verknüpft
    const d0 = eid && store[aufKey(eid)];
    if (d0 && Array.isArray(d0.liste)) {
      const doc = aufDoc(eid);
      const a = doc.liste.find((x) => x.fahrzeuge && x.fahrzeuge[vid] && x.fahrzeuge[vid].aktiv && !AUF_ZU.includes(x.status));
      if (a) {
        const q = quelle ? ` (${quelle})` : '';
        if (w === 'einsatz') {
          aufTb(a, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Besatzung meldet: im Einsatz – Auftrag übernommen${q}`, user, auto: 'auftrag' });
          if (a.status === 'offen' || a.status === 'disponiert') { a.status = 'inArbeit'; a.zeiten = { ...(a.zeiten || {}), inArbeit: Date.now() }; }
          setKey(aufKey(eid), doc);
          tbAdd(eid, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Besatzung meldet: im Einsatz – Auftrag ${a.nr} übernommen${q}`, user, auto: 'status' });
          return { vid, w, auftrag: a.nr, auftragStatus: a.status };
        }
        aufTb(a, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Besatzung meldet: Auftrag erledigt, verfügbar${ergebnis ? ` – ${ergebnis}` : ''}${q}`, user, auto: 'auftrag' });
        aufFrei(a, vid, 'frei für den nächsten Auftrag.', user);
        const nochDa = Object.values(a.fahrzeuge || {}).some((f) => f.aktiv);
        if (!nochDa) {
          a.status = 'erledigt'; a.zeiten = { ...(a.zeiten || {}), erledigt: Date.now() };
          if (ergebnis) a.ergebnis = a.ergebnis ? `${a.ergebnis}\n${ergebnis}` : ergebnis;
          aufTb(a, { richtung: 'Vermerk', von: user, text: `Auftrag erledigt (gemeldet von ${vehName(vid)})${a.ergebnis ? `. Ergebnis: ${a.ergebnis}` : ''}`, user, auto: 'auftrag' });
          aufUeberfuehren(eid, a, user);
        } else {
          aufTb(a, { richtung: 'Vermerk', von: user, text: 'Weitere Fahrzeuge sind noch am Auftrag – Auftrag bleibt in Arbeit.', user, auto: 'auftrag' });
        }
        setKey(aufKey(eid), doc);
        tbAdd(eid, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Besatzung meldet: Auftrag ${a.nr} erledigt, verfügbar${ergebnis ? ` – ${ergebnis}` : ''}${nochDa ? ' (weitere Fahrzeuge noch am Auftrag)' : ''}${q}`, user, auto: 'status' });
        return { vid, w, auftrag: a.nr, auftragStatus: a.status };
      }
    }
    if (alt && alt.w === w && Date.now() - alt.t < 60000 && !ergebnis) return { vid, w };
    if (eid) tbAdd(eid, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Besatzung meldet: ${BEREIT[w]}${ergebnis ? ` – ${ergebnis}` : ''}${quelle ? ` (${quelle})` : ''}`, user, auto: 'status' });
    else systemLog(user, `${vehName(vid)}: Besatzung meldet ${BEREIT[w]}${quelle ? ` (${quelle})` : ''}`);
    return { vid, w };
  }
  /* Auftrag eines Fahrzeugs für die Fahrzeug-App (ab 3.58) – mit Adresse nur, wenn mitOrt */
  function auftragFuer(vid, mitOrt) {
    const eid = fzEinsatz(vid); const d = eid && store[aufKey(eid)];
    if (!d || !Array.isArray(d.liste)) return null;
    const a = d.liste.find((x) => x.fahrzeuge && x.fahrzeuge[vid] && x.fahrzeuge[vid].aktiv && !AUF_ZU.includes(x.status));
    if (!a) return null;
    const out = { nr: a.nr, kat: a.kat || '', prio: a.prio || null, priolage: !!a.priolage, status: a.status, seit: a.fahrzeuge[vid].seit };
    if (mitOrt) Object.assign(out, { adresse: a.adresse || '', text: String(a.text || '').slice(0, 300), lat: a.lat ?? null, lon: a.lon ?? null });
    return out;
  }
  function fzRuf(args, user, quelle) {
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    const r = { ...(store[K.fmsRuf] || {}) };
    const code = args.code == null ? null : String(args.code);
    const eid = fzEinsatz(vid);
    if (code && RUF[code]) {
      r[vid] = { code, t: Date.now() };
      if (eid) tbAdd(eid, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `${RUF[code]} (Status ${code})${quelle ? ` (${quelle})` : ''}`, user, auto: 'status' });
      else systemLog(user, `${vehName(vid)}: ${RUF[code]}${quelle ? ` (${quelle})` : ''}`);
    } else {
      if (!r[vid]) return { vid };
      const war = r[vid].code;
      delete r[vid];
      if (eid) tbAdd(eid, { richtung: 'Vermerk', von: user, text: `${RUF[war] || 'Ruf'} von ${vehName(vid)} quittiert.`, user, auto: 'status' });
    }
    setKey(K.fmsRuf, r);
    return { vid };
  }
  function fzZuordnen(args, user) {
    const vid = String(args.vid || ''); const e0 = einsaetze()[args.einsatzId];
    if (!e0) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    if (fzEinsatz(vid)) throw fehler('schon_zugeordnet', 'Fahrzeug ist bereits einem Einsatz zugeordnet');
    trennungPruefen(e0, vid);
    const st = stOf(vid);
    if (!AKTIV.includes(st)) throw fehler('nicht_aktiv', 'Fahrzeug ist nicht alarmiert');
    const e = JSON.parse(JSON.stringify(e0));
    e.fahrzeuge[vid] = { seit: Date.now(), abschnitt: 'ea', zeiten: [{ st, t: Date.now() }], aktiv: true };
    anforderungenNachziehen(e, vid, st);
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `${vehName(vid)} dem Einsatz zugeordnet (Status ${st}).`, user, auto: 'status' });
    return {};
  }
  /* Fahrzeug aus einem laufenden Einsatz in einen anderen umsetzen (ab 3.52).
     Status und Stärke bleiben; im alten Einsatz gilt es als entlassen, im neuen beginnt es im Abschnitt „Nicht zugeteilt“. */
  function fzUmsetzen(args, user) {
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    const vonId = fzEinsatz(vid);
    if (!vonId) throw fehler('nicht_im_einsatz', 'Das Fahrzeug ist keinem laufenden Einsatz zugeordnet.');
    if (args.vonEinsatzId && args.vonEinsatzId !== vonId) throw fehler('anderer_einsatz', 'Das Fahrzeug ist inzwischen in einem anderen Einsatz.');
    const nach0 = einsaetze()[args.nachEinsatzId];
    if (!nach0) throw fehler('einsatz_fehlt', 'Ziel-Einsatz nicht gefunden.');
    if (nach0.id === vonId) throw fehler('gleicher_einsatz', 'Das Fahrzeug ist bereits in diesem Einsatz.');
    trennungPruefen(nach0, vid);
    const now = Date.now(), st = stOf(vid), name = vehName(vid);
    const von = JSON.parse(JSON.stringify(einsaetze()[vonId]));
    const f0 = von.fahrzeuge[vid];
    let brWeg = null;
    if (f0.br) { brWeg = brListe(von).find((x) => x.id === f0.br) || { name: 'Bereitstellungsraum' }; const l = (f0.brLog || []).slice(-1)[0]; if (l && !l.aus) l.aus = now; f0.br = null; f0.brSeit = null; }
    f0.aktiv = false; f0.bis = now; f0.umgesetzt = { t: now, nach: nach0.id, nummer: nach0.nummer, user };
    const p = (store[K.personnel] || {})[vid]; if (p) f0.staerke = p;
    putEinsatz(von);
    auftragStatusFolge(vonId, vid, st, st, true, user, `in Einsatz ${nach0.nummer} umgesetzt`);
    tbAdd(vonId, { richtung: 'Vermerk', von: user, text: `${name} in Einsatz ${nach0.nummer} (${[nach0.stichwort, nach0.meldebild].filter(Boolean).join(' – ') || 'ohne Stichwort'}) umgesetzt${brWeg ? ` – Bereitstellungsraum „${brWeg.name}“ verlassen` : ''}.`, user, auto: 'status' });
    const nach = JSON.parse(JSON.stringify(einsaetze()[nach0.id]));
    const alt = nach.fahrzeuge[vid];
    nach.fahrzeuge[vid] = { ...(alt || {}), seit: alt && alt.seit ? alt.seit : now, abschnitt: 'ea', zeiten: [...((alt && alt.zeiten) || []), { st, t: now }], aktiv: true, von: { t: now, einsatz: vonId, nummer: von.nummer } };
    delete nach.fahrzeuge[vid].bis; delete nach.fahrzeuge[vid].umgesetzt; delete nach.fahrzeuge[vid].staerke;
    anforderungenNachziehen(nach, vid, st);
    putEinsatz(nach);
    tbAdd(nach.id, { richtung: 'Vermerk', von: user, text: `${name} aus Einsatz ${von.nummer} übernommen (Status ${st}).`, user, auto: 'status' });
    return { vid, von: vonId, nach: nach.id };
  }
  // Abschnitt und/oder Auftrag (Freitext) eines Fahrzeugs im Einsatz
  function fzAbschnitt(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    if (!e0.fahrzeuge[args.vid]) throw fehler('fahrzeug_fehlt');
    if (args.abschnitt != null && !e0.abschnitte.some((a) => a.id === args.abschnitt)) throw fehler('abschnitt_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    const f = e.fahrzeuge[args.vid];
    if (args.abschnitt != null) f.abschnitt = args.abschnitt;
    if (args.auftrag != null) {
      const neu = str(args.auftrag, 200);
      if (neu !== (f.auftrag || '')) {
        f.auftrag = neu;
        if (neu) tbAdd(e.id, { richtung: 'Ausgang', von: 'ELW', an: vehName(args.vid), text: `Auftrag: ${neu}`, user });
      }
    }
    putEinsatz(e);
    if (args.auftrag != null && f.auftrag && f.auftrag !== (e0.fahrzeuge[args.vid].auftrag || '')) {   // ab 3.80: auch im Reiter Nachrichten der Fahrzeug-App
      try { const alle = { ...nachrichtenAlle() }, jetzt = Date.now(); alle[args.vid] = (alle[args.vid] || []).filter((x) => x.t >= jetzt - 24 * 3600 * 1000).concat({ id: rid('n'), t: jetzt, richtung: 'aus', text: `📋 Auftrag: ${f.auftrag}`, von: fstLabel(e.id), user, eid: e.id }).slice(-60); setKey(K.nachrichten, alle); } catch (err) { /* optional */ }
    }
    return {};
  }

  /* ab 3.80: ein Fahrzeug, das nicht mehr im Einsatz ist, ganz aus dem Einsatz entfernen (z. B. versehentlich zugeordnet) –
     erscheint dann nicht mehr in Fahrzeugliste, Stärke und Bericht; der Vorgang steht im Tagebuch */
  function fzEntfernen(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const vid = String(args.vid || ''); const f = e0.fahrzeuge && e0.fahrzeuge[vid];
    if (!f) throw fehler('fahrzeug_fehlt', 'Fahrzeug gehört nicht zu diesem Einsatz');
    if (f.aktiv) {   // ab 3.82: aus der Fahrzeugansicht – erst entlassen (Status 2, Auftrag frei), dann entfernen
      if (!args.auchAktiv) throw fehler('noch_aktiv', 'Das Fahrzeug ist noch im Einsatz – bitte zuerst entlassen');
      fzEntlassen({ vid, einsatzId: e0.id }, user);
    }
    const e1 = einsaetze()[e0.id];
    const e = JSON.parse(JSON.stringify(e1)); delete e.fahrzeuge[vid];
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `${vehName(vid)} aus dem Einsatz entfernt${args.grund ? ` (${str(args.grund, 200)})` : ''} – erscheint nicht mehr in Fahrzeugliste und Bericht.`, user, auto: 'status' });
    return {};
  }
  function fzEntlassen(args, user) {
    const vid = String(args.vid || '');
    const eid = fzEinsatz(vid);
    if (!eid || (args.einsatzId && args.einsatzId !== eid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug ist diesem Einsatz nicht zugeordnet');
    const st = stOf(vid);
    return fzStatus({ vid, st: AKTIV.includes(st) ? '2' : st, entlassen: true }, user);
  }

  /* ---------- Großschadenslage: Aufträge (Einsatzstellen) ----------
     Jeder Auftrag hat eigene Daten, Fahrzeuge und ein eigenes Tagebuch. Beim
     Abschluss (erledigt/storniert) bzw. spätestens beim Einsatzende wird das
     Auftragstagebuch in das Einsatztagebuch des Haupteinsatzes übernommen. */
  function aufVonFz(eid, vid) {
    const d = store[aufKey(eid)];
    const a = d && Array.isArray(d.liste) && d.liste.find((x) => x.fahrzeuge && x.fahrzeuge[vid] && x.fahrzeuge[vid].aktiv);
    return a ? a.nr : null;
  }
  function aufDoc(eid) {
    const d = store[aufKey(eid)];
    return d && Array.isArray(d.liste) ? JSON.parse(JSON.stringify(d)) : { zaehler: 0, liste: [] };
  }
  function aufTb(a, entry) {
    a.tb = Array.isArray(a.tb) ? a.tb : [];
    if (entry.von === 'ELW' || entry.an === 'ELW' || entry.von === 'ÖEL' || entry.an === 'ÖEL') { const eid = aufEid(a); entry = { ...entry, von: fstTausch(entry.von, eid), an: fstTausch(entry.an, eid) }; }
    const nr = a.tb.length ? a.tb[a.tb.length - 1].nr + 1 : 1;
    const x = {
      nr, t: Date.now(), richtung: TB_RICHTUNG.includes(entry.richtung) ? entry.richtung : 'Vermerk',
      von: str(entry.von, 80), an: str(entry.an, 80), text: str(entry.text, 2000), user: str(entry.user, 60) || 'System',
    };
    if (entry.auto) x.auto = entry.auto;
    if (entry.korrigiert) {
      const orig = a.tb.find((y) => y.nr === Number(entry.korrigiert));
      if (orig) { x.korrigiert = orig.nr; orig.korrigiertDurch = nr; }
    }
    a.tb.push(x);
    return x;
  }
  const zeitHM = (t) => (t ? new Date(t).toLocaleTimeString('de-DE', { timeZone: 'Europe/Berlin', hour: '2-digit', minute: '2-digit' }) : '–');
  const prioText = (p) => (p ? `Priorität: ${({ 1: 'sofort', 2: 'dringend', 3: 'kann warten' })[p] || p}` : 'Priorität offen');
  function aufTitel(a) { return `Auftrag ${a.nr} (${a.kat || 'ohne Kategorie'}, ${a.priolage ? 'PRIOLAGE, ' : ''}${prioText(a.prio)})${a.adresse ? ` ${a.adresse}` : ''}`; }
  function aufFelder(args, alt) {
    const d = {};
    ['kat', 'adresse', 'meldender', 'telefon'].forEach((f) => { if (args[f] !== undefined) d[f] = str(args[f], f === 'adresse' ? 200 : 80); else if (alt) d[f] = alt[f] || ''; });
    if (args.text !== undefined) d.text = str(args.text, 2000); else if (alt) d.text = alt.text || '';
    // ab 3.71: Die Priorität vergibt die Einsatzverwaltung (Disposition) – ohne Angabe bleibt sie offen (null).
    if (args.prio !== undefined) { const p = int(args.prio, 3); d.prio = p >= 1 && p <= 3 ? p : null; } else d.prio = alt ? (alt.prio ?? null) : null;
    // „Priolage“ meldet die Leitstelle – wird besonders gekennzeichnet
    if (args.priolage !== undefined) d.priolage = !!args.priolage && args.priolage !== 'false' && args.priolage !== '0'; else d.priolage = alt ? !!alt.priolage : false;
    if (args.lat !== undefined || args.lon !== undefined) {
      const lat = Number(args.lat), lon = Number(args.lon);
      const ok = args.lat != null && args.lon != null && Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && (lat || lon);
      d.lat = ok ? +lat.toFixed(6) : null; d.lon = ok ? +lon.toFixed(6) : null;
    } else if (alt) { d.lat = alt.lat ?? null; d.lon = alt.lon ?? null; }
    else { d.lat = null; d.lon = null; }
    if (args.objektId !== undefined) d.objektId = objekte().some((o) => o.id === args.objektId) ? String(args.objektId) : null;
    else if (alt) d.objektId = alt.objektId || null;
    return d;
  }
  function aufHole(args) {
    const e = einsaetze()[args.einsatzId]; if (!e) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const doc = aufDoc(e.id);
    const a = args.id ? doc.liste.find((x) => x.id === args.id) : null;
    if (args.id && !a) throw fehler('auftrag_fehlt', 'Auftrag nicht gefunden');
    return { e, doc, a };
  }
  function aufFrei(a, vid, text, user) {
    const f = a.fahrzeuge && a.fahrzeuge[vid];
    if (!f || !f.aktiv) return false;
    f.aktiv = false; f.bis = Date.now();
    aufTb(a, { richtung: 'Vermerk', von: user, text: `${vehName(vid)} ${text}`, user, auto: 'status' });
    return true;
  }
  /* disponierter Auftrag ohne Fahrzeug fällt auf „offen“ zurück */
  function aufPruefeOffen(a, user, auchArbeit) {   // ab 5.110: zurück nach „In Dispo“ (auch aus „In Arbeit“, wenn alle Fahrzeuge abgezogen werden)
    if (a.status !== 'disponiert' && !(auchArbeit && a.status === 'inArbeit')) return;
    if (Object.values(a.fahrzeuge || {}).some((f) => f.aktiv)) return;
    a.status = 'offen'; a.dispo = true;
    aufTb(a, { richtung: 'Vermerk', von: user, text: 'Kein Fahrzeug mehr zugewiesen – Auftrag wieder in Dispo.', user, auto: 'auftrag' });
  }
  /* ab 5.28: Erkundung – Erkunder weg, ohne Ergebnis → Auftrag wieder offen */
  function aufPruefeErkundung(a, user) {
    if (a.status !== 'erkundung') return;
    if (Object.values(a.fahrzeuge || {}).some((f) => f.aktiv)) return;
    a.status = 'offen'; delete a.erkunder;
    aufTb(a, { richtung: 'Vermerk', von: user, text: 'Erkundung abgebrochen (kein Erkunder mehr) – Auftrag wieder offen.', user, auto: 'auftrag' });
  }
  function auftragErkunden(args, user) {
    let { e, doc, a } = aufHole(args);
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Bitte ein Fahrzeug zum Erkunden wählen');
    if (a.status !== 'offen') throw fehler('nicht_offen', 'Erkunden geht nur bei offenen (noch nicht disponierten) Aufträgen');
    if (stOf(vid) === '6') throw fehler('nicht_bereit', 'Das Fahrzeug ist nicht einsatzbereit (Status 6)');
    const inEinsatz = fzEinsatz(vid);
    if (inEinsatz && inEinsatz !== e.id) throw fehler('anderer_einsatz', 'Das Fahrzeug ist einem anderen Einsatz zugeordnet');
    if (!inEinsatz) { fzStatus({ vid, st: 'A', einsatzId: e.id }, user); ({ e, doc, a } = aufHole(args)); }
    doc.liste.forEach((o) => { if (o !== a && aufFrei(o, vid, `abgezogen, zur Erkundung von Auftrag ${a.nr}.`, user)) { aufPruefeOffen(o, user); aufPruefeErkundung(o, user); } });
    a.fahrzeuge = a.fahrzeuge || {};
    const f = a.fahrzeuge[vid];
    a.fahrzeuge[vid] = { seit: Date.now(), aktiv: true, rolle: 'erkunden', ...(f ? { vorher: (f.vorher || 0) + 1 } : {}) };
    a.status = 'erkundung'; a.erkunder = { vid, seit: Date.now(), user };
    a.zeiten = { ...(a.zeiten || {}), erkundung: Date.now() };
    const hinweis = str(args.hinweis, 500);
    aufTb(a, { richtung: 'Ausgang', von: 'ELW', an: vehName(vid), text: `${vehName(vid)} zur Erkundung von Auftrag ${a.nr}${a.adresse ? `: ${a.adresse}` : ''}${hinweis ? ` – ${hinweis}` : ''}.`, user, auto: 'auftrag' });
    setKey(aufKey(e.id), doc);
    auftragAlsNachricht(e.id, a, vid, user, `🔍 ERKUNDEN – bitte Lage feststellen und zurückmelden.${hinweis ? `\n${hinweis}` : ''}`);
    if (['1', '2'].includes(stOf(vid))) fzStatus({ vid, st: 'A', einsatzId: e.id }, user, 'Erkundung');
    return aufDoc(e.id).liste.find((x) => x.id === a.id);
  }
  function auftragErkundet(args, user) {
    const { e, doc, a } = aufHole(args);
    if (a.status !== 'erkundung') throw fehler('keine_erkundung', 'Der Auftrag ist nicht in Erkundung');
    const ergebnis = str(args.ergebnis, 1000);
    const vid = (a.erkunder && a.erkunder.vid) || Object.keys(a.fahrzeuge || {}).find((v) => a.fahrzeuge[v].aktiv) || null;
    Object.keys(a.fahrzeuge || {}).forEach((v) => { if (a.fahrzeuge[v].rolle === 'erkunden') aufFrei(a, v, 'Erkundung beendet – frei für neue Aufträge.', user); });
    a.erkundet = { t: Date.now(), vid, fz: vid ? vehName(vid) : '', ergebnis, user };
    if (args.prio !== undefined && args.prio !== null && args.prio !== '') { const p = int(args.prio, 3); if (p >= 1 && p <= 3) a.prio = p; }
    delete a.erkunder;
    a.status = 'offen'; a.dispo = true;
    a.zeiten = { ...(a.zeiten || {}), erkundet: Date.now() };
    aufTb(a, { richtung: 'Eingang', von: vid ? vehName(vid) : 'Erkunder', an: 'ELW', text: `Erkundung abgeschlossen${ergebnis ? `: ${ergebnis}` : ''} – Auftrag wartet auf Disposition.`, user, auto: 'auftrag' });
    setKey(aufKey(e.id), doc);
    return a;
  }
  function auftragNeu(args, user) {
    const { e, doc } = aufHole({ ...args, id: null });
    const d = aufFelder(args);
    if (!d.adresse && d.lat == null) throw fehler('ort_fehlt', 'Bitte eine Adresse oder Koordinate eintragen');
    doc.zaehler = (doc.zaehler || 0) + 1;
    const a = { id: rid('o'), nr: doc.zaehler, ...d, status: 'offen', eingang: Date.now(), user, zeiten: { offen: Date.now() }, fahrzeuge: {}, tb: [], ueberfuehrt: 0 };
    const bilder = bildIds(args.bilder); if (bilder.length) a.bilder = bilder;   // ab 3.70: Fotos zum Auftrag (z. B. aus der Fahrzeug-App)
    if (args.vonVid && vehicles().some((v) => v.id === String(args.vonVid))) { a.vonVid = String(args.vonVid); a.quelle = 'fahrzeug'; }
    if (args.acc != null && Number.isFinite(Number(args.acc))) a.genauigkeit = Math.round(Math.min(99999, Math.max(0, Number(args.acc))));
    aufTb(a, { richtung: 'Eingang', von: a.meldender || 'Meldender', an: 'ELW', text: `Auftrag aufgenommen: ${a.kat || 'ohne Kategorie'}${a.priolage ? ', PRIOLAGE (Leitstelle)' : ''}${a.prio ? `, Priorität ${a.prio}` : ''}${a.adresse ? `, ${a.adresse}` : ''}${a.text ? ` – ${a.text}` : ''}${a.telefon ? ` (Rückruf ${a.telefon})` : ''}`, user, auto: 'auftrag' });
    doc.liste.push(a);
    setKey(aufKey(e.id), doc);
    return a;
  }
  function auftragAendern(args, user) {
    const { e, doc, a } = aufHole(args);
    const neu = aufFelder(args, a);
    const namen = { kat: 'Kategorie', prio: 'Priorität', priolage: 'Priolage', adresse: 'Adresse', text: 'Beschreibung', meldender: 'Meldender', telefon: 'Telefon' };
    const geaendert = Object.keys(namen).filter((f) => (f === 'priolage' ? !!neu[f] !== !!a[f] : String(neu[f] ?? '') !== String(a[f] ?? '')));
    const posNeu = (neu.lat ?? null) !== (a.lat ?? null) || (neu.lon ?? null) !== (a.lon ?? null);
    Object.assign(a, neu);
    if (posNeu) aufTb(a, { richtung: 'Vermerk', von: user, text: neu.lat != null ? `Position verschoben auf ${neu.lat.toFixed(5)}, ${neu.lon.toFixed(5)}` : 'Position entfernt', user, auto: 'auftrag' });
    const wert = (f) => (f === 'priolage' ? (neu[f] ? 'ja' : 'nein') : f === 'prio' ? (neu[f] || 'offen') : (neu[f] || '–'));
    if (geaendert.length) aufTb(a, { richtung: 'Vermerk', von: user, text: `Geändert: ${geaendert.map((f) => `${namen[f]} ${wert(f)}`).join('; ')}`, user, auto: 'auftrag' });
    setKey(aufKey(e.id), doc);
    return a;
  }
  function auftragStatus(args, user) {
    const { e, doc, a } = aufHole(args);
    const st = String(args.status || '');
    if (!AUF_STATUS.includes(st)) throw fehler('status_ungueltig', 'Unbekannter Auftragsstatus');
    if (args.ergebnis !== undefined) a.ergebnis = str(args.ergebnis, 2000);
    if (st === a.status && args.ergebnis === undefined) return a;
    const vorher = a.status;
    a.status = st;
    a.zeiten = { ...(a.zeiten || {}), [st]: Date.now() };
    if (AUF_ZU.includes(st)) Object.keys(a.fahrzeuge || {}).forEach((vid) => aufFrei(a, vid, `vom Auftrag abgezogen (Auftrag ${AUF_LABEL[st]}).`, user));
    aufTb(a, { richtung: 'Vermerk', von: user, text: `Auftrag ${AUF_LABEL[st]}${vorher !== st ? '' : ' (Ergebnis ergänzt)'}${a.ergebnis && AUF_ZU.includes(st) ? `. Ergebnis: ${a.ergebnis}` : ''}`, user, auto: 'auftrag' });
    if (AUF_ZU.includes(st)) aufUeberfuehren(e.id, a, user);
    setKey(aufKey(e.id), doc);
    return a;
  }
  function auftragFz(args, user) {
    let { e, doc, a } = aufHole(args);
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    if (args.entfernen) {
      if (aufFrei(a, vid, 'vom Auftrag abgezogen.', user)) { aufPruefeOffen(a, user, true); setKey(aufKey(e.id), doc); }
      return a;
    }
    if (AUF_ZU.includes(a.status)) throw fehler('auftrag_zu', 'Der Auftrag ist abgeschlossen – bitte zuerst wieder öffnen');
    if (stOf(vid) === '6') throw fehler('nicht_bereit', 'Das Fahrzeug ist nicht einsatzbereit (Status 6)');
    const inEinsatz = fzEinsatz(vid);
    if (inEinsatz && inEinsatz !== e.id) throw fehler('anderer_einsatz', 'Das Fahrzeug ist einem anderen Einsatz zugeordnet');
    if (!inEinsatz) {
      fzStatus({ vid, st: 'A', einsatzId: e.id }, user);   // alarmieren und der Lage zuordnen
      ({ e, doc, a } = aufHole(args));
    }
    doc.liste.forEach((o) => { if (o !== a && aufFrei(o, vid, `abgezogen, neu disponiert zu Auftrag ${a.nr}.`, user)) aufPruefeOffen(o, user, true); });
    a.fahrzeuge = a.fahrzeuge || {};
    const f = a.fahrzeuge[vid];
    if (f && f.aktiv) return a;
    a.fahrzeuge[vid] = { seit: Date.now(), aktiv: true, ...(f ? { vorher: (f.vorher || 0) + 1 } : {}) };
    if (a.status === 'offen' || a.status === 'erkundung') { if (a.status === 'erkundung') { delete a.erkunder; a.fahrzeuge[vid].rolle = undefined; } a.status = 'disponiert'; a.zeiten = { ...(a.zeiten || {}), disponiert: Date.now() }; }
    aufTb(a, { richtung: 'Ausgang', von: 'ELW', an: vehName(vid), text: `${vehName(vid)} zum Auftrag ${a.nr} disponiert${a.adresse ? `: ${a.adresse}` : ''}.`, user, auto: 'auftrag' });
    setKey(aufKey(e.id), doc);
    auftragAlsNachricht(e.id, a, vid, user);
    // freies Fahrzeug der Lage bekommt „Alarmiert“, bis es den Auftrag mit Status 3 übernimmt
    if (['1', '2'].includes(stOf(vid))) fzStatus({ vid, st: 'A', einsatzId: e.id }, user, 'Disposition');
    return aufDoc(e.id).liste.find((x) => x.id === a.id);
  }
  /* ab 3.80: der Auftrag steht in der Fahrzeug-App zusätzlich im Reiter Nachrichten (mit Ort als anklickbarer Koordinate) */
  function auftragAlsNachricht(eid, a, vid, user, zusatz) {
    try {
      const ko = a.lat != null && a.lon != null ? ` (${Number(a.lat).toFixed(5)}, ${Number(a.lon).toFixed(5)})` : '';
      const text = str(`📋 Auftrag ${a.nr}: ${a.kat || 'Auftrag'}${a.priolage ? ' – ⚡ PRIOLAGE' : ''}${a.prio ? ` – Priorität: ${({ 1: 'sofort', 2: 'dringend', 3: 'kann warten' })[a.prio] || a.prio}` : ''}\n📍 ${a.adresse || 'ohne Adresse'}${ko}${a.text ? `\n${a.text}` : ''}${a.telefon ? `\nRückruf: ${a.telefon}` : ''}${zusatz ? `\n${zusatz}` : '\nBitte mit Status 3 bzw. „Im Einsatz“ übernehmen.'}`, 1000);
      const alle = { ...nachrichtenAlle() }, jetzt = Date.now();
      alle[vid] = (alle[vid] || []).filter((x) => x.t >= jetzt - 24 * 3600 * 1000).concat({ id: rid('n'), t: jetzt, richtung: 'aus', text, von: fstLabel(eid), user, eid, auftrag: a.nr }).slice(-60);
      setKey(K.nachrichten, alle);
    } catch (err) { /* Nachricht optional */ }
  }
  function auftragTbNeu(args, user) {
    const { e, doc, a } = aufHole(args);
    if (!str(args.text)) throw fehler('text_fehlt', 'Bitte einen Text eintragen');
    const x = aufTb(a, { richtung: args.richtung, von: args.von, an: args.an, text: args.text, user, korrigiert: args.korrigiert });
    setKey(aufKey(e.id), doc);
    return x;
  }
  /* FMS-Status eines Fahrzeugs im Auftrag nachführen (aus fzStatus) */
  function auftragStatusFolge(eid, vid, st, alt, verlaesst, user, quelle) {
    const d = store[aufKey(eid)];
    if (!d || !Array.isArray(d.liste)) return;
    const doc = aufDoc(eid);
    const a = doc.liste.find((x) => x.fahrzeuge && x.fahrzeuge[vid] && x.fahrzeuge[vid].aktiv);
    if (!a) return;
    if (alt !== st) aufTb(a, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Status ${st} – ${FMS[st]}${quelle ? ` (${quelle})` : ''}`, user, auto: 'fms' });
    if (st === '4' && (a.status === 'disponiert' || a.status === 'offen')) { a.status = 'inArbeit'; a.zeiten = { ...(a.zeiten || {}), inArbeit: Date.now() }; }
    if (verlaesst || ['1', '2', '6'].includes(st)) { aufFrei(a, vid, st === '6' ? 'nicht einsatzbereit – vom Auftrag abgezogen.' : `frei (Status ${st}).`, user); aufPruefeOffen(a, user); aufPruefeErkundung(a, user); }
    setKey(aufKey(eid), doc);
  }
  /* Auftragstagebuch in das Einsatztagebuch übernehmen (nur noch nicht übernommene Einträge) */
  function aufUeberfuehren(eid, a, user, hinweis) {
    const tb = Array.isArray(a.tb) ? a.tb : [];
    const ab = a.ueberfuehrt || 0;
    // FMS-Statusmeldungen stehen bereits im Einsatztagebuch – nicht doppelt übernehmen
    const neu = tb.slice(ab).filter((x) => x.auto !== 'fms' && x.auto !== 'nachricht');   // Nachrichten stehen schon im Einsatztagebuch
    if (!neu.length) { a.ueberfuehrt = tb.length; return; }
    const fz = Object.keys(a.fahrzeuge || {}).map(vehName).join(', ');
    const zt = ['disponiert', 'inArbeit', 'erledigt', 'storniert'].filter((s) => (a.zeiten || {})[s]).map((s) => `${AUF_LABEL[s]} ${zeitHM(a.zeiten[s])}`).join(', ');
    const kopf = tbAdd(eid, {
      richtung: 'Vermerk', von: user, user, auto: 'auftrag', auftrag: a.nr,
      text: `${aufTitel(a)} – ${hinweis || AUF_LABEL[a.status]}. Eingang ${zeitHM(a.eingang)}${zt ? `, ${zt}` : ''}.${fz ? ` Fahrzeuge: ${fz}.` : ''}${a.ergebnis ? ` Ergebnis: ${a.ergebnis}` : ''}${ab ? ' (Nachtrag)' : ''} Auftragstagebuch folgt (${neu.length} Einträge).`,
    });
    if (!kopf) return;
    neu.forEach((x) => tbAdd(eid, {
      richtung: x.richtung, von: x.von, an: x.an, user: x.user, auftrag: a.nr, tOrig: x.t,
      auto: x.auto === 'status' ? 'status' : 'auftrag',
      text: `[Auftrag ${a.nr} · ${zeitHM(x.t)} · Nr. ${x.nr}] ${x.text}${x.korrigiert ? ` (Korrektur zu Nr. ${x.korrigiert})` : ''}`,
    }));
    a.ueberfuehrt = tb.length;
    a.ueberfuehrtAm = Date.now();
    a.tbNr = [...(a.tbNr || []), kopf.nr];
  }

  /* ---------- Objekte mit Plänen ---------- */
  const OBJ_ARTEN = ['Industrie / Gewerbe', 'Schule / Kita', 'Pflegeheim / Krankenhaus', 'Versammlungsstätte', 'Landwirtschaft', 'Gefahrstoffe', 'Wohnanlage', 'Sonstiges'];
  function objekte() { return Array.isArray(store[K.objekte]) ? store[K.objekte] : []; }
  function objektSpeichern(args, user) {
    const list = objekte().map((o) => ({ ...o }));
    const name = str(args.name, 120);
    if (!name) throw fehler('name_fehlt', 'Bitte einen Namen eintragen');
    const lat = Number(args.lat), lon = Number(args.lon);
    const hatKoord = args.lat != null && args.lon != null && Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && (lat || lon);
    const d = {
      name, art: str(args.art, 60), adresse: str(args.adresse, 200), lat: hatKoord ? +lat.toFixed(6) : null, lon: hatKoord ? +lon.toFixed(6) : null,
      hinweise: str(args.hinweise, 5000), kontakte: str(args.kontakte, 2000), stichworte: str(args.stichworte, 300), ortswehr: str(args.ortswehr, 80), merkmale: (Array.isArray(args.merkmale) ? args.merkmale : []).map((x) => str(x, 40)).filter(Boolean).slice(0, 20), geaendert: Date.now(), geaendertVon: user,
    };
    let o = args.id && list.find((x) => x.id === args.id);
    if (o) Object.assign(o, d);
    else { o = { id: rid('obj'), ...d, dateien: [] }; list.push(o); systemLog(user, `Objekt „${name}“ angelegt.`); }
    setKey(K.objekte, list);
    return o;
  }
  function objektDateiNeu(oid, meta, user) {
    const list = objekte().map((o) => ({ ...o }));
    const o = list.find((x) => x.id === oid); if (!o) throw fehler('objekt_fehlt', 'Objekt nicht gefunden');
    o.dateien = [...(o.dateien || []), meta];
    o.geaendert = Date.now(); o.geaendertVon = user || '';
    setKey(K.objekte, list); save();
    return meta;
  }
  function objektDateiLoeschen(args, user) {
    const list = objekte().map((o) => ({ ...o }));
    const o = list.find((x) => x.id === args.id); if (!o) throw fehler('objekt_fehlt', 'Objekt nicht gefunden');
    const d = (o.dateien || []).find((x) => x.id === args.fid); if (!d) throw fehler('datei_fehlt', 'Datei nicht gefunden');
    o.dateien = o.dateien.filter((x) => x.id !== args.fid);
    if (objektDir) { try { require('fs').unlinkSync(require('path').join(objektDir, o.id, d.datei)); } catch (err) { /* schon weg */ } }
    setKey(K.objekte, list);
    systemLog(user, `Objekt „${o.name}“: Datei „${d.name}“ gelöscht.`);
    return {};
  }
  function objektLoeschen(args, user) {
    const o = objekte().find((x) => x.id === args.id); if (!o) throw fehler('objekt_fehlt', 'Objekt nicht gefunden');
    if (objektDir && /^obj[a-z0-9]+$/.test(o.id)) { try { require('fs').rmSync(require('path').join(objektDir, o.id), { recursive: true, force: true }); } catch (err) { /* egal */ } }
    setKey(K.objekte, objekte().filter((x) => x.id !== o.id));
    systemLog(user, `Objekt „${o.name}“ mit ${(o.dateien || []).length} Datei(en) gelöscht.`);
    return {};
  }

  /* ---------- Stärke ---------- */
  function staerke(args, user, quelle) {
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    // ab 3.52 ohne Unterführer: ein mitgeschickter UF-Wert (ältere Apps) zählt zur Mannschaft
    const s = { f: int(args.f, 20), uf: 0, m: Math.min(200, int(args.m, 200) + int(args.uf, 50)), agt: int(args.agt, 200) };
    setKey(K.personnel, { ...(store[K.personnel] || {}), [vid]: s });
    const eid = fzEinsatz(vid);
    if (eid) tbAdd(eid, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Stärkemeldung ${s.f}/${s.m}/${s.f + s.m}, davon ${s.agt} AGT${quelle ? ` (${quelle})` : ''}`, user, auto: 'status' });
    return s;
  }

  /* ---------- Bereitstellungsräume (ab 3.50) ----------
     e.brs = [{id, name, adresse, lat, lon, t}] – der erste entspricht dem Bereitstellungsraum im Einsatzkopf (bereitstellung/brLat/brLon).
     Fahrzeuge im Raum: e.fahrzeuge[vid].br = brId, brSeit; Ein-/Ausgänge stehen im Einsatztagebuch. */
  function brListe(e) {
    if (!e) return [];
    if (Array.isArray(e.brs)) return e.brs;
    if (e.bereitstellung || e.brLat != null || e.gsl) return [{ id: 'br1', name: 'BR 1', adresse: e.bereitstellung || '', lat: e.brLat ?? null, lon: e.brLon ?? null, t: (e.eroeffnet || {}).t || Date.now() }];
    return [];
  }
  const brName = (b) => b.name || 'Bereitstellungsraum';
  function koord(la, lo) {
    const a = Number(la), b = Number(lo);
    return la != null && lo != null && la !== '' && lo !== '' && Number.isFinite(a) && Number.isFinite(b) && Math.abs(a) <= 90 && Math.abs(b) <= 180 && (a || b) ? [+a.toFixed(6), +b.toFixed(6)] : [null, null];
  }
  function brSpeichern(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const e = JSON.parse(JSON.stringify(e0)); e.brs = brListe(e0).map((b) => ({ ...b }));
    let b = args.id ? e.brs.find((x) => x.id === args.id) : null;
    if (args.id && !b) throw fehler('br_fehlt', 'Bereitstellungsraum nicht gefunden');
    const name = str(args.name, 40) || (b ? b.name : '') || `BR ${e.brs.length + 1}`;
    if (e.brs.some((x) => x !== b && x.name.toLowerCase() === name.toLowerCase())) throw fehler('br_doppelt', `„${name}“ gibt es schon.`);
    const [lat, lon] = args.lat !== undefined || args.lon !== undefined ? koord(args.lat, args.lon) : b ? [b.lat, b.lon] : [null, null];
    const neu = !b;
    if (!b) { let n = e.brs.length + 1; while (e.brs.some((x) => x.id === `br${n}`)) n++; b = { id: `br${n}`, t: Date.now() }; e.brs.push(b); }
    const alt = { name: b.name, adresse: b.adresse };
    Object.assign(b, { name, adresse: args.adresse !== undefined ? str(args.adresse, 200) : (b.adresse || ''), lat, lon });
    if (e.brs[0] === b) { e.bereitstellung = b.adresse; e.brLat = b.lat; e.brLon = b.lon; }
    putEinsatz(e);
    if (neu) tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Bereitstellungsraum „${name}“ eingerichtet${b.adresse ? `: ${b.adresse}` : ''}.`, user, auto: 'system' });
    else if (alt.name !== b.name || alt.adresse !== b.adresse) tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Bereitstellungsraum „${name}“${alt.name !== name ? ` (bisher „${alt.name}“)` : ''}: ${b.adresse || 'Adresse offen'}.`, user, auto: 'system' });
    return { ...b };
  }
  function brAufloesen(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const e = JSON.parse(JSON.stringify(e0)); e.brs = brListe(e0).map((b) => ({ ...b }));
    const i = e.brs.findIndex((x) => x.id === args.id); if (i < 0) throw fehler('br_fehlt', 'Bereitstellungsraum nicht gefunden');
    const b = e.brs[i]; e.brs.splice(i, 1);
    const drin = Object.keys(e.fahrzeuge || {}).filter((vid) => e.fahrzeuge[vid].br === b.id);
    drin.forEach((vid) => { e.fahrzeuge[vid].br = null; e.fahrzeuge[vid].brSeit = null; });
    if (i === 0) { const n = e.brs[0]; e.bereitstellung = n ? n.adresse : ''; e.brLat = n ? n.lat : null; e.brLon = n ? n.lon : null; }
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Bereitstellungsraum „${brName(b)}“ aufgelöst${drin.length ? ` (darin noch: ${drin.map(vehName).join(', ')})` : ''}.`, user, auto: 'system' });
    return { id: b.id };
  }
  // Fahrzeug betritt / verlässt einen Bereitstellungsraum
  function brFz(args, user, quelle) {
    const eid = String(args.einsatzId || ''); const e0 = einsaetze()[eid]; if (!e0) throw fehler('einsatz_fehlt', 'Einsatz läuft nicht (mehr).');
    const b = brListe(e0).find((x) => x.id === args.brId); if (!b) throw fehler('br_fehlt', 'Bereitstellungsraum nicht gefunden');
    const vid = String(args.vid || ''); if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    const von = quelle || user;
    if (args.aktion === 'ein') {
      const fe = fzEinsatz(vid);
      if (fe && fe !== eid) throw fehler('anderer_einsatz', `${vehName(vid)} ist in einem anderen Einsatz.`);
      if (!fe || stOf(vid) !== '4') fzStatus({ vid, st: '4', einsatzId: eid }, user, quelle);
      const e = JSON.parse(JSON.stringify(einsaetze()[eid])); if (!Array.isArray(e.brs)) e.brs = brListe(e);
      const f = e.fahrzeuge[vid]; const vorher = f.br && f.br !== b.id ? brListe(e).find((x) => x.id === f.br) : null;
      if (f.br === b.id) return { schonDa: true };
      f.br = b.id; f.brSeit = Date.now();
      (f.brLog = f.brLog || []).push({ br: b.id, ein: f.brSeit });
      putEinsatz(e);
      tbAdd(eid, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Im Bereitstellungsraum „${brName(b)}“ eingetroffen${vorher ? ` (vorher „${brName(vorher)}“)` : ''}.${quelle ? ` (${quelle})` : ''}`, user, auto: 'status' });
      return { ein: true };
    }
    if (args.aktion === 'aus') {
      const e = JSON.parse(JSON.stringify(e0)); if (!Array.isArray(e.brs)) e.brs = brListe(e);
      const f = (e.fahrzeuge || {})[vid];
      if (!f || f.br !== b.id) throw fehler('nicht_im_br', `${vehName(vid)} ist nicht im Bereitstellungsraum.`);
      const seit = f.brSeit; f.br = null; f.brSeit = null;
      const l = (f.brLog || []).slice(-1)[0]; if (l && !l.aus) l.aus = Date.now();
      putEinsatz(e);
      const ziel = { '3': 'zur Einsatzstelle / zum Auftrag (Status 3)', '1': 'zurück zum Standort (Status 1)' }[String(args.ziel || '')] || '';
      tbAdd(eid, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `Bereitstellungsraum „${brName(b)}“ verlassen${ziel ? ` – ${ziel}` : ''}${seit ? `, dort seit ${new Date(seit).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Berlin' })}` : ''}.${quelle ? ` (${quelle})` : ''}`, user, auto: 'status' });
      if (args.ziel === '3' || args.ziel === '1') { try { fzStatus({ vid, st: String(args.ziel), einsatzId: eid }, user, quelle); } catch (err) { /* Status bleibt */ } }
      return { aus: true };
    }
    throw fehler('aktion', 'Unbekannte Aktion');
  }

  /* ---------- Fahrzeug nachmelden (ab 3.49) ----------
     Fahrzeug an der Einsatzstelle erfassen: vorhandenes (vid) oder – wenn noch nicht in der Fahrzeugliste – neu anlegen
     (Funkrufname, Typ, Organisation; markiert als „nachgemeldet“). Danach Status 3/4 in diesem Einsatz, optional Stärke. */
  const nameNorm = (t) => String(t || '').toLowerCase().replace(/\s+/g, ' ').trim();
  function fzNachmelden(args, user, quelle) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    let vid = str(args.vid, 60), neu = false;
    if (!vid) {
      const name = str(args.funkrufname, 40).replace(/\s+/g, ' ');
      if (!name) throw fehler('name_fehlt', 'Bitte einen Funkrufnamen eintragen.');
      const sim = istSim(e0);
      const da = (sim ? vehiclesUeb() : vehiclesEcht()).find((v) => nameNorm(v.funkrufname) === nameNorm(name));
      if (da) vid = da.id;
      else {
        vid = `${sim ? 'ueb_' : ''}vn${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
        const v = { id: vid, funkrufname: name, fahrzeugtyp: str(args.typ, 40), filterType: str(args.typ, 40), ortswehr: str(args.organisation, 60), stadt: str(args.stadt, 60), kennzeichen: str(args.kennzeichen, 20), sondereinheit: '',
          einsatz: false, personnelDefault: { mannschaft: 0, paTraeger: 0 }, equipmentCategory: '', name: '', funktion: '', ausruestung: [],
          nachgemeldet: { t: Date.now(), von: str(user, 60), einsatz: e0.nummer || '' } };
        if (sim) { v.uebung = true; setKey(K_UEBFZ, [...vehiclesUeb(), v]); } else setKey(K.vehicles, [...vehiclesEcht(), v]);
        neu = true;
      }
    } else if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    trennungPruefen(e0, vid);
    const fe = fzEinsatz(vid);
    if (fe && fe !== e0.id) throw fehler('anderer_einsatz', `${vehName(vid)} ist in einem anderen Einsatz.`);
    if (neu) { const v = vehicles().find((x) => x.id === vid); tbAdd(e0.id, { richtung: 'Vermerk', von: quelle || user, text: `Fahrzeug nachgemeldet und neu angelegt (nicht in der Fahrzeugliste): ${[v.funkrufname, v.fahrzeugtyp, v.ortswehr].filter(Boolean).join(' · ')}.`, user, auto: 'status' }); }
    if (!fe) fzStatus({ vid, st: ['3', '4'].includes(String(args.st)) ? String(args.st) : '4', einsatzId: e0.id }, user, quelle);
    if (args.staerke && typeof args.staerke === 'object') staerke({ vid, ...args.staerke }, user, quelle);
    return { vid, neu, schonDa: fe === e0.id };
  }

  // mehrere Stärken auf einmal (Sammelerfassung per Handy, ab 3.36) – erst alles prüfen, dann setzen
  function staerkeMehrere(args, user) {
    const liste = Array.isArray(args.werte) ? args.werte.slice(0, 300) : [];
    if (!liste.length) throw fehler('leer', 'Keine Stärken übergeben');
    const ids = new Set(vehicles().map((v) => v.id));
    const falsch = liste.filter((w) => !w || !ids.has(String(w.vid)));
    if (falsch.length) throw fehler('fahrzeug_fehlt', `${falsch.length} Fahrzeug(e) nicht gefunden`);
    const quelle = String(args.quelle || 'Sammelerfassung per Handy').slice(0, 60);
    liste.forEach((w) => staerke({ vid: String(w.vid), f: w.f, uf: w.uf, m: w.m, agt: w.agt }, user, quelle));
    return { anzahl: liste.length };
  }

  /* ---------- Objektdaten für die Fahrzeug-App (ab 3.37) ----------
     Hat der Einsatz ein Objekt (zugeordnet oder gleiche Adresse/≤ 50 m), bekommt es nur EIN Fahrzeug:
     das erste alarmierte Fahrzeug aus der Ortsfeuerwehr des Einsatzortes, das in der Fahrzeug-App die
     Einsatzleitung übernimmt. Alle anderen sehen keine Objektdaten. Die Einsatzleitung (ELW) kann das zurücksetzen. */
  const normOrt = (t) => String(t || '').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').replace(/[^a-z0-9]+/g, ' ').trim();
  const gemeinde = () => String(((store['opta3.settings'] || {}).city) || 'Aerzen');
  function ortswehrenGemeinde() {
    const g = normOrt(gemeinde());
    return [...new Set(vehicles().filter((v) => normOrt(v.stadt) === g && String(v.ortswehr || '').trim()).map((v) => String(v.ortswehr).trim()))];
  }
  function ortAusText(text) {
    const t = ` ${normOrt(text)} `; if (!t.trim()) return null;
    const g = normOrt(gemeinde());
    const treffer = [];
    ortswehrenGemeinde().forEach((w) => {
      const teile = [w, ...String(w).split(/[-/]| und /)].map(normOrt).filter((x) => x.length >= 3);
      const l = Math.max(0, ...teile.filter((x) => t.includes(` ${x} `)).map((x) => x.length));
      if (l) treffer.push({ w, l, kern: normOrt(w) === g });
    });
    if (!treffer.length) return null;
    const spez = treffer.filter((x) => !x.kern);   // Ortsteil schlägt den Gemeindenamen (steht in jeder Anschrift)
    return (spez.length ? spez : treffer).sort((a, b) => b.l - a.l)[0].w;
  }
  function adrSchluessel(adr) {   // „Straße Hausnummer“ – der erste Teil der Anschrift, der so aussieht (davor kann ein Name stehen)
    for (const teil of String(adr || '').split(',')) {
      const n = normOrt(teil).replace(/\bstr\b/g, 'strasse');
      if (/^\d{5}\b/.test(n)) continue;   // PLZ und Ort
      const m = /([a-z][a-z ]{2,}?) ?(\d+ ?[a-z]?)$/.exec(n);
      if (m) return (m[1] + m[2]).replace(/\s+/g, '');
    }
    return '';
  }
  function abstandM(a, b) {
    const r = Math.PI / 180, dLat = (b.lat - a.lat) * r, dLon = (b.lon - a.lon) * r;
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLon / 2) ** 2;
    return 2 * 6371000 * Math.asin(Math.sqrt(h));
  }
  function einsatzObjekt(e) {
    if (!e) return null;
    const l = objekte();
    if (e.objektId) return l.find((o) => o.id === e.objektId) || null;
    const k = adrSchluessel(e.adresse);
    const hatKoord = (x) => x && x.lat != null && x.lon != null && Number.isFinite(+x.lat) && Number.isFinite(+x.lon);
    let best = null, bd = Infinity;
    for (const o of l) {
      if (k && adrSchluessel(o.adresse) === k) {
        const passt = hatKoord(e) && hatKoord(o) ? abstandM(e, o) <= 300 : normOrt(ortAusText(e.adresse)) === normOrt(ortAusText(o.adresse));
        if (passt) return o;
      }
      if (hatKoord(e) && hatKoord(o)) { const d = abstandM(e, o); if (d < bd) { bd = d; best = o; } }
    }
    return bd <= 50 ? best : null;
  }
  function einsatzOrtVon(e, o) { return (o && String(o.ortswehr || '').trim()) || ortAusText(o && o.adresse) || ortAusText(e && e.adresse) || null; }
  function objektRecht(vid) {
    const eid = fzEinsatz(vid); const e = eid && einsaetze()[eid];
    if (!e) return null;
    const o = einsatzObjekt(e); if (!o) return null;
    const v = vehicles().find((x) => x.id === vid) || {};
    const ort = einsatzOrtVon(e, o);
    const ok = !!ort && normOrt(v.ortswehr) === normOrt(ort) && normOrt(v.stadt) === normOrt(gemeinde());
    const z = e.objektZugriff && e.objektZugriff.oid === o.id ? e.objektZugriff : null;
    return { e, o, v, ort, ok, z };
  }
  // Was die Fahrzeug-App über das Objekt erfährt (null = nichts anzeigen)
  function objektStatusFuer(vid) {
    const r = objektRecht(vid);
    if (!r || !r.ok) return null;
    if (r.z && r.z.vid === vid) return { status: 'eigen', name: r.o.name, art: r.o.art || '', seit: r.z.t };
    if (r.z) return { status: 'vergeben', an: vehName(r.z.vid), seit: r.z.t };
    return { status: 'frei', name: r.o.name, art: r.o.art || '', dateien: (r.o.dateien || []).length, ort: r.ort };
  }
  function objektDatenFuer(vid) {
    const r = objektRecht(vid);
    if (!r || !r.ok || !r.z || r.z.vid !== vid) throw fehler('kein_recht', 'Keine Berechtigung für diese Objektdaten');
    const o = r.o;
    return { name: o.name, art: o.art || '', adresse: o.adresse || '', lat: o.lat, lon: o.lon, hinweise: o.hinweise || '', kontakte: o.kontakte || '', stichworte: o.stichworte || '',
      dateien: (o.dateien || []).map((d) => ({ id: d.id, name: d.name, typ: d.typ, groesse: d.groesse })), seit: r.z.t, einsatz: r.e.nummer };
  }
  function objektDateiFuer(vid, fid) {
    objektDatenFuer(vid);
    const r = objektRecht(vid);
    const d = (r.o.dateien || []).find((x) => x.id === String(fid));
    if (!d) throw fehler('datei_fehlt', 'Datei nicht gefunden');
    return { o: r.o, d };
  }
  function objektUebernehmen(args, user, quelle) {
    if (quelle !== 'Fahrzeug-App') throw fehler('nur_fahrzeug', 'Nur über die Fahrzeug-App möglich');
    const vid = String(args.vid || '');
    const r = objektRecht(vid);
    if (!r || !r.ok) throw fehler('kein_recht', 'Für dieses Fahrzeug sind keine Objektdaten freigegeben');
    if (r.z && r.z.vid !== vid) { const err = fehler('vergeben', `Die Objektdaten hat bereits ${vehName(r.z.vid)}`); err.an = vehName(r.z.vid); throw err; }
    if (r.z) return objektDatenFuer(vid);
    const e = JSON.parse(JSON.stringify(r.e));
    e.objektZugriff = { oid: r.o.id, vid, t: Date.now() };
    e.elVorOrt = { vid, t: Date.now(), quelle: 'Fahrzeug-App' };
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Eingang', von: vehName(vid), an: 'ELW', text: `${vehName(vid)} übernimmt die Einsatzleitung vor Ort und hat die Objektdaten „${r.o.name}“ in der Fahrzeug-App geöffnet (nur dieses Fahrzeug).`, user: 'Fahrzeug-App', auto: 'objekt' });
    return objektDatenFuer(vid);
  }
  function objektZugriffZuruecksetzen(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    if (!e0.objektZugriff) return {};
    const e = JSON.parse(JSON.stringify(e0));
    const alt = e.objektZugriff; delete e.objektZugriff;
    if (e.elVorOrt && e.elVorOrt.vid === alt.vid) delete e.elVorOrt;
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Objektdaten für ${vehName(alt.vid)} gesperrt – das nächste berechtigte Fahrzeug kann sie in der Fahrzeug-App übernehmen.`, user, auto: 'objekt' });
    return {};
  }

  /* ---------- Abschnitte ---------- */
  function abschnitt(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    if (args.loeschen) {
      const a = e.abschnitte.find((x) => x.id === args.id);
      if (!a || a.fixed) throw fehler('abschnitt_fest', 'Dieser Abschnitt kann nicht gelöscht werden');
      e.abschnitte = e.abschnitte.filter((x) => x.id !== args.id);
      // ab 3.89: Unterabschnitte eines aufgelösten Abschnitts werden zu eigenen Abschnitten; Fahrzeuge gehen an den übergeordneten Abschnitt bzw. nach „Frei“
      e.abschnitte.forEach((x) => { if (x.parent === args.id) delete x.parent; });
      Object.values(e.fahrzeuge).forEach((f) => { if (f.abschnitt === args.id) f.abschnitt = a.parent && e.abschnitte.some((x) => x.id === a.parent) ? a.parent : 'ea'; });
      putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Einsatzabschnitt „${a.name}" aufgelöst.`, user, auto: 'system' });
      return {};
    }
    let a = args.id && e.abschnitte.find((x) => x.id === args.id);
    // Fläche des Abschnitts auf der Lagekarte (Liste [lat, lon]) setzen oder entfernen
    if (a && args.nurFlaeche) {
      const pts = Array.isArray(args.flaeche) ? args.flaeche.slice(0, 400).map((q) => [Number(q && q[0]), Number(q && q[1])]).filter((q) => Number.isFinite(q[0]) && Number.isFinite(q[1]) && Math.abs(q[0]) <= 90 && Math.abs(q[1]) <= 180).map((q) => [+q[0].toFixed(6), +q[1].toFixed(6)]) : [];
      if (pts.length >= 3) a.flaeche = pts; else delete a.flaeche;
      putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Einsatzabschnitt „${a.name}": Bereich auf der Lagekarte ${a.flaeche ? 'eingezeichnet' : 'entfernt'}.`, user, auto: 'system' });
      return {};
    }
    // nur den Auftrag des Abschnitts ändern
    if (a && args.nurAuftrag) {
      const neu = str(args.auftrag, 300);
      if (neu === (a.auftrag || '')) return {};
      a.auftrag = neu;
      putEinsatz(e);
      if (neu) tbAdd(e.id, { richtung: 'Ausgang', von: 'ELW', an: a.leiter ? `${a.name} (${a.leiter})` : a.name, text: `Auftrag für Abschnitt „${a.name}": ${neu}`, user });
      return {};
    }
    const daten = { name: str(args.name, 80), leiter: str(args.leiter, 80), kanal: str(args.kanal, 40) };
    if (args.auftrag !== undefined) daten.auftrag = str(args.auftrag, 300);
    if (!daten.name && !(a && a.fixed)) throw fehler('name_fehlt', 'Bitte einen Namen eintragen');
    // ab 3.89: Unterabschnitt – eine Ebene unter einem Abschnitt (nicht unter „Frei“)
    let parent = undefined;
    if (args.parent !== undefined && !(a && a.fixed)) {
      const p = args.parent ? e.abschnitte.find((x) => x.id === String(args.parent)) : null;
      if (args.parent && (!p || p.fixed || p.parent || (a && p.id === a.id))) throw fehler('parent_ungueltig', 'Unterabschnitte nur unter einem Hauptabschnitt');
      if (p && a && e.abschnitte.some((x) => x.parent === a.id)) throw fehler('parent_ungueltig', 'Ein Abschnitt mit Unterabschnitten kann nicht selbst Unterabschnitt werden');
      parent = p ? p.id : null;
    }
    const pName = (id) => { const p = id && e.abschnitte.find((x) => x.id === id); return p ? p.name : ''; };
    if (a) {
      if (a.fixed) daten.name = a.name;
      const parentAlt = a.parent || null;
      Object.assign(a, daten);
      if (parent !== undefined) { if (parent) a.parent = parent; else delete a.parent; }
      if (parent !== undefined && (parent || null) !== parentAlt) tbAdd(e.id, { richtung: 'Vermerk', von: user, text: parent ? `„${a.name}" ist jetzt Unterabschnitt von „${pName(parent)}".` : `„${a.name}" ist jetzt ein eigener Abschnitt (kein Unterabschnitt mehr).`, user, auto: 'system' });
      tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Einsatzabschnitt „${a.name}": Leiter ${a.leiter || '–'}, Kanal ${a.kanal || '–'}${a.auftrag ? `, Auftrag: ${a.auftrag}` : ''}.`, user, auto: 'system' });
    } else {
      const FARBEN = ['#1F4E79', '#1D6B45', '#8E44AD', '#B86E00', '#117A65', '#A93226', '#5D6D7E', '#D4A800'];
      const belegt = e.abschnitte.map((x) => x.farbe);
      a = { id: rid('a'), ...daten, ...(parent ? { parent } : {}), farbe: FARBEN.find((f) => !belegt.includes(f)) || FARBEN[e.abschnitte.length % FARBEN.length] };
      e.abschnitte.push(a);
      tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `${parent ? `Unterabschnitt „${a.name}" zu „${pName(parent)}"` : `Einsatzabschnitt „${a.name}"`} gebildet${a.leiter ? `, Leiter ${a.leiter}` : ''}${a.kanal ? `, Kanal ${a.kanal}` : ''}${a.auftrag ? `, Auftrag: ${a.auftrag}` : ''}.`, user, auto: 'system' });
    }
    putEinsatz(e);
    return a;
  }

  /* ---------- Verkehrsunfall: Unfallfahrzeuge mit Antrieb, Personen und Maßnahmen ---------- */
  function vuName(f) { return `Unfallfahrzeug ${f.nr}${f.kennzeichen ? ` (${f.kennzeichen})` : ''}`; }
  function vuBeschreibung(f) {
    const teile = [[f.art, f.hersteller, f.modell].filter(Boolean).join(' '), f.farbe ? `Farbe ${f.farbe}` : '', f.antrieb ? `Antrieb ${f.antrieb}${HV_ANTRIEB.test(f.antrieb) ? ' – HOCHVOLT' : ''}` : '', f.lage || '',
      f.personen ? `${f.personen} Person${f.personen === 1 ? '' : 'en'}${f.eingeklemmt ? `, davon ${f.eingeklemmt} eingeklemmt` : ''}` : (f.eingeklemmt ? `${f.eingeklemmt} eingeklemmt` : ''), f.rettung || ''];
    return teile.filter(Boolean).join(', ');
  }
  function vuCrsText(c) {
    if (!c) return '';
    const p = c.punkte || {};
    return [...Object.keys(VU_CRS_PUNKTE).filter((k) => p[k]).map((k) => (k === 'batterie12' ? `12-V-Batterie: ${p[k]}` : VU_CRS_PUNKTE[k])), c.text].filter(Boolean).join('; ');
  }
  function vuFelder(args, alt) {
    const d = {};
    ['art', 'kennzeichen', 'hersteller', 'modell', 'baujahr', 'farbe', 'antrieb', 'lage', 'rettung'].forEach((k) => { if (args[k] !== undefined) d[k] = str(args[k], k === 'kennzeichen' ? 20 : k === 'baujahr' ? 10 : 60); });
    if (d.kennzeichen) d.kennzeichen = d.kennzeichen.toUpperCase();
    ['personen', 'eingeklemmt'].forEach((k) => { if (args[k] !== undefined) d[k] = int(args[k], 99); });
    if (args.notiz !== undefined) d.notiz = str(args.notiz, 500);
    const pers = d.personen !== undefined ? d.personen : (alt && alt.personen) || 0;
    const ekl = d.eingeklemmt !== undefined ? d.eingeklemmt : (alt && alt.eingeklemmt) || 0;
    if (ekl > pers && d.personen === undefined && d.eingeklemmt !== undefined) d.personen = ekl;   // eingeklemmte zählen als Personen
    return d;
  }
  function vu(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    e.vu = Array.isArray(e.vu) ? e.vu : [];
    const von = str(args.von, 80) || 'ELW';
    if (!args.id) {
      const nr = e.vu.reduce((m, x) => Math.max(m, x.nr || 0), 0) + 1;
      const f = { id: rid('u'), nr, massnahmen: {}, angelegt: Date.now(), ...vuFelder(args) };
      e.vu.push(f);
      putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von, text: `VU: ${vuName(f)} erfasst${vuBeschreibung(f) ? `: ${vuBeschreibung(f)}` : ''}.`, user, auto: 'system' });
      return f;
    }
    const f = e.vu.find((x) => x.id === args.id); if (!f) throw fehler('vu_fehlt', 'Unfallfahrzeug nicht gefunden');
    if (args.loeschen) {
      e.vu = e.vu.filter((x) => x.id !== f.id);
      putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von, text: `VU: ${vuName(f)} entfernt.`, user, auto: 'system' });
      return {};
    }
    if (args.crs !== undefined) {   // ab 3.80: Rettungsdaten aus dem Crash Recovery System (Bildschirmfotos + wichtigste Punkte)
      const c = args.crs && typeof args.crs === 'object' ? args.crs : {};
      const punkte = {};
      Object.keys(VU_CRS_PUNKTE).forEach((k) => { if (c.punkte && c.punkte[k]) punkte[k] = k === 'batterie12' ? str(c.punkte[k], 40) : true; });
      const neuC = { bilder: (Array.isArray(c.bilder) ? c.bilder : []).map(String).filter((b) => /^[0-9a-f]{24}$/.test(b)).slice(0, 3), punkte, text: str(c.text, 800), quelle: str(c.quelle, 40) || 'Crash Recovery System', land: str(c.land, 4), t: Date.now(), user };
      const leer = !neuC.bilder.length && !Object.keys(punkte).length && !neuC.text;
      if (leer) delete f.crs; else f.crs = neuC;
      putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von, text: leer ? `VU ${vuName(f)}: Rettungsdaten entfernt.` : `VU ${vuName(f)}: Rettungsdaten (${neuC.quelle}) erfasst${vuCrsText(neuC) ? ` – ${vuCrsText(neuC)}` : ''}${neuC.bilder.length ? ` [${neuC.bilder.length === 1 ? '1 Bild' : `${neuC.bilder.length} Bilder`}]` : ''}.`, user, auto: 'system' });
      return { ...f, berichtBilder: neuC.bilder };
    }
    if (args.massnahme) {
      const key = String(args.massnahme);
      if (!VU_MASSNAHMEN[key]) throw fehler('massnahme_ungueltig');
      f.massnahmen = f.massnahmen || {};
      const an = !!args.an;
      if (an === !!f.massnahmen[key]) return f;
      if (an) f.massnahmen[key] = { t: Date.now(), user }; else delete f.massnahmen[key];
      putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von, text: `VU ${vuName(f)}: ${VU_MASSNAHMEN[key]}${an ? '' : ' – zurückgenommen'}.`, user, auto: 'system' });
      return f;
    }
    const neu = vuFelder(args, f);
    const geaendert = Object.keys(neu).filter((k) => (neu[k] || '') !== (f[k] || ''));
    if (!geaendert.length) return f;
    Object.assign(f, neu);
    putEinsatz(e);
    const txt = geaendert.map((k) => `${VU_FELDER[k]} ${k === 'personen' || k === 'eingeklemmt' ? f[k] : (f[k] || '–')}${k === 'antrieb' && HV_ANTRIEB.test(f[k] || '') ? ' – HOCHVOLT' : ''}`).join(', ');
    tbAdd(e.id, { richtung: 'Vermerk', von, text: `VU ${vuName(f)}: ${txt}.`, user, auto: 'system' });
    return f;
  }

  /* ---------- Unwetterwarnung einmal je Einsatz im Tagebuch vermerken ---------- */
  function warnungVermerk(eid, w) {
    const e0 = einsaetze()[eid]; if (!e0 || !w || !w.id) return;
    if ((e0.warnungen || []).includes(w.id)) return;
    const e = JSON.parse(JSON.stringify(e0));
    e.warnungen = (e.warnungen || []).concat(w.id).slice(-100);
    putEinsatz(e);
    const zeit = (t) => new Date(t).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    tbAdd(eid, { richtung: 'Eingang', von: w.quelle || 'Warndienst', an: 'ELW', text: `WARNUNG: ${w.titel}${w.ende ? ` (gültig bis ${zeit(w.ende)})` : ''}.`, user: 'System', auto: 'system' });
    save();
  }

  /* ---------- Einsatz-Uhren: Notstromaggregat nachtanken, Erinnerung Lagemeldung ---------- */
  const uhrzeit = (t) => new Date(t).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  function uhr(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    e.uhren = e.uhren && typeof e.uhren === 'object' ? e.uhren : {};
    const jetzt = Date.now();
    const spaeterMin = Math.max(1, Math.min(720, int(args.spaeter, 720) || 10));
    const von = str(args.von, 80) || 'ELW';
    if (args.art === 'lage') {
      if (args.aktion !== 'spaeter') throw fehler('aktion_ungueltig');
      e.uhren.lage = { spaeter: jetzt + spaeterMin * 60000, gesetzt: jetzt, user };
      putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von, text: `Erinnerung Lagemeldung um ${spaeterMin} Minuten verschoben.`, user, auto: 'system' });
      return {};
    }
    if (args.art === 'besprechung') {
      const b = e.uhren.besprechung;
      if (args.aktion === 'spaeter') { e.uhren.besprechung = { faellig: jetzt + spaeterMin * 60000, gesetzt: jetzt, user }; putEinsatz(e); tbAdd(e.id, { richtung: 'Vermerk', von, text: `Lagebesprechung um ${spaeterMin} Minuten verschoben (${uhrzeit(jetzt + spaeterMin * 60000)}).`, user, auto: 'system' }); return {}; }
      if (args.aktion === 'aus') { if (!b) return {}; delete e.uhren.besprechung; putEinsatz(e); return {}; }
      throw fehler('aktion_ungueltig');
    }
    if (args.art === 'timer') {   // ab 3.88: eigene Timer mit Name, Zeit und Zweck
      const l = Array.isArray(e.uhren.timer) ? e.uhren.timer : [];
      let txt = '';
      if (args.aktion === 'neu') {
        const name = str(args.name, 60); if (!name) throw fehler('name_fehlt', 'Bitte einen Namen eintragen');
        const bis = Number(args.bis), min = int(args.min, 1440);
        const faellig = Number.isFinite(bis) && bis > jetzt && bis < jetzt + 48 * 3600000 ? bis : min > 0 ? jetzt + min * 60000 : 0;
        if (!faellig) throw fehler('zeit_fehlt', 'Bitte eine Dauer oder Uhrzeit angeben');
        const t = { id: rid('tm'), name, zweck: str(args.zweck, 200), basis: jetzt, faellig, user };
        l.push(t);
        txt = `Timer „${t.name}" gestellt auf ${uhrzeit(faellig)}${t.zweck ? ` – ${t.zweck}` : ''}.`;
      } else {
        const t = l.find((x) => x.id === args.id); if (!t) throw fehler('uhr_fehlt', 'Timer nicht gefunden');
        if (args.aktion === 'spaeter') { t.faellig = Math.max(t.faellig, jetzt) + spaeterMin * 60000; txt = `Timer „${t.name}" um ${spaeterMin} Minuten verlängert (${uhrzeit(t.faellig)}).`; }
        else if (args.aktion === 'erledigt') { t.erledigt = { t: jetzt, user }; txt = `Timer „${t.name}" erledigt${t.zweck ? ` (${t.zweck})` : ''}.`; }
        else if (args.aktion === 'loeschen') { l.splice(l.indexOf(t), 1); txt = `Timer „${t.name}" gelöscht.`; }
        else throw fehler('aktion_ungueltig');
      }
      e.uhren.timer = l.slice(-40);
      putEinsatz(e);
      if (txt) tbAdd(e.id, { richtung: 'Vermerk', von, text: txt, user, auto: 'system' });
      return {};
    }
    if (args.art !== 'aggregat') throw fehler('art_ungueltig');
    const intervall = Math.max(5, int(args.min, 1440) || 90);
    // Vorgabe-Aggregat ab Einsatzbeginn: wird beim ersten Eingriff fest angelegt
    let liste = Array.isArray(e.uhren.aggregate) ? e.uhren.aggregate : (args.std ? [{ id: 'std', name: 'Notstromaggregat', basis: e.alarmzeit }] : []);
    let txt = '';
    if (args.aktion === 'neu') {
      const a = { id: rid('g'), name: str(args.name, 60) || `Notstromaggregat ${liste.length + 1}`, basis: jetzt };
      liste.push(a);
      txt = `Notstromaggregat „${a.name}" in Betrieb – nachtanken um ${uhrzeit(jetzt + intervall * 60000)}.`;
    } else {
      const a = liste.find((x) => x.id === args.id); if (!a) throw fehler('uhr_fehlt', 'Uhr nicht gefunden');
      if (args.aktion === 'nachgetankt') { a.basis = jetzt; delete a.spaeter; a.aus = false; txt = `Notstromaggregat „${a.name}" nachgetankt – nächstes Nachtanken um ${uhrzeit(jetzt + intervall * 60000)}.`; }
      else if (args.aktion === 'spaeter') { a.spaeter = jetzt + spaeterMin * 60000; txt = `Notstromaggregat „${a.name}": Erinnerung Nachtanken um ${spaeterMin} Minuten verschoben.`; }
      else if (args.aktion === 'aus') { a.aus = true; txt = `Notstromaggregat „${a.name}" außer Betrieb – Tankuhr angehalten.`; }
      else if (args.aktion === 'an') { a.aus = false; a.basis = jetzt; delete a.spaeter; txt = `Notstromaggregat „${a.name}" wieder in Betrieb – nachtanken um ${uhrzeit(jetzt + intervall * 60000)}.`; }
      else if (args.aktion === 'name') { const n = str(args.name, 60); if (!n) throw fehler('name_fehlt'); a.name = n; }
      else throw fehler('aktion_ungueltig');
    }
    e.uhren.aggregate = liste;
    putEinsatz(e);
    if (txt) tbAdd(e.id, { richtung: 'Vermerk', von, text: txt, user, auto: 'system' });
    return {};
  }

  /* ---------- Nachrichten zwischen Einsatzleitung und Fahrzeug-App ----------
     opta3.nachrichten[vid]: Postfach je Fahrzeug (24 h) – Nachrichten an das Fahrzeug (richtung 'aus', Quittung „verstanden“)
     und vom Fahrzeug (richtung 'ein', „gelesen“ durch die Einsatzleitung).
     einsatz.nachrichten: Verlauf des Einsatzes {id, t, richtung, von, an, vids, text, bilder, quittiert{vid:t}, gelesen, bericht}
     – wird mit dem Einsatz archiviert; „bericht:true“ übernimmt die Nachricht in den Einsatzbericht. */
  const NLOG_MAX = 300;
  const bildIds = (l) => (Array.isArray(l) ? l : []).map(String).filter((b) => /^[0-9a-f]{24}$/.test(b)).slice(0, 3);
  function nachrichtenAlle() { return store[K.nachrichten] && typeof store[K.nachrichten] === 'object' ? store[K.nachrichten] : {}; }
  function nlogNeu(eid, eintrag) {
    const e = einsaetze()[eid]; if (!e) return;
    eintrag = { ...eintrag, von: fstTausch(eintrag.von, eid), an: fstTausch(eintrag.an, eid) };
    putEinsatz({ ...e, nachrichten: (Array.isArray(e.nachrichten) ? e.nachrichten : []).concat(eintrag).slice(-NLOG_MAX) });
  }
  function nlogAendern(eid, nid, fn) {
    const e = einsaetze()[eid]; if (!e || !nid || !Array.isArray(e.nachrichten)) return;
    const l = e.nachrichten.map((x) => (x.id === nid ? fn({ ...x }) : x));
    putEinsatz({ ...e, nachrichten: l });
  }
  function nachricht(args, user) {
    const bilder = bildIds(args.bilder);
    const text = str(args.text, 1000); if (!text && !bilder.length) throw fehler('text_fehlt', 'Bitte einen Text eintragen oder ein Bild anhängen');
    const vids = [...new Set((Array.isArray(args.vids) ? args.vids : [args.vid]).map(String))].filter((vid) => vehicles().some((v) => v.id === vid));
    if (!vids.length) throw fehler('fahrzeug_fehlt', 'Bitte mindestens ein Fahrzeug wählen');
    const alle = { ...nachrichtenAlle() };
    const jetzt = Date.now(), grenze = jetzt - 24 * 3600 * 1000;
    const von = str(args.von, 80) || 'ELW';
    const bericht = !!args.bericht;
    const proEinsatz = {};
    vids.forEach((vid) => { const eid = fzEinsatz(vid) || (einsaetze()[args.einsatzId] ? args.einsatzId : null); if (eid) { const p = proEinsatz[eid] = proEinsatz[eid] || { nid: rid('nl'), vids: [] }; p.vids.push(vid); } });
    vids.forEach((vid) => {
      const eid = Object.keys(proEinsatz).find((k) => proEinsatz[k].vids.includes(vid)) || null;
      const m = { id: rid('n'), t: jetzt, richtung: 'aus', text, von: eid && (von === 'ELW' || von === 'ÖEL') ? fstLabel(eid) : von, user, eid, ...(eid ? { nid: proEinsatz[eid].nid } : {}), ...(bilder.length ? { bilder } : {}) };
      alle[vid] = (alle[vid] || []).filter((x) => x.t >= grenze).concat(m).slice(-60);
    });
    setKey(K.nachrichten, alle);
    Object.entries(proEinsatz).forEach(([eid, p]) => {
      const namen = p.vids.map(vehName);
      nlogNeu(eid, { id: p.nid, t: jetzt, richtung: 'aus', von, an: namen.join(', ').slice(0, 200), vids: p.vids, text, bilder, quittiert: {}, bericht, user });
      tbAdd(eid, { richtung: 'Ausgang', von, an: namen.join(', ').slice(0, 80), text: `Nachricht an ${namen.join(', ')} (Fahrzeug-App): ${text || '(nur Bild)'}${bilder.length ? ` [${bilder.length === 1 ? 'mit Bild' : `mit ${bilder.length} Bildern`}]` : ''}`, user });
    });
    if (!Object.keys(proEinsatz).length) systemLog(user, `Nachricht an ${vids.map(vehName).join(', ')}: ${text || '(nur Bild)'}${bilder.length ? ' [mit Bild]' : ''}`);
    return { anzahl: vids.length, berichtBilder: bericht ? bilder : [] };
  }
  function nachrichtQuittung(args, user) {
    const vid = String(args.vid || '');
    const alle = { ...nachrichtenAlle() };
    const liste = (alle[vid] || []).map((x) => ({ ...x }));
    const m = liste.find((x) => x.id === args.id && x.richtung === 'aus'); if (!m) throw fehler('nachricht_fehlt');
    if (m.quittiert) return {};
    m.quittiert = Date.now();
    alle[vid] = liste;
    setKey(K.nachrichten, alle);
    if (m.fzfz) return {};   // Fahrzeug an Fahrzeug: keine Meldung an die Einsatzleitung
    const kurz = !m.text ? 'Bild' : m.text.length > 80 ? `${m.text.slice(0, 77)}…` : m.text;
    if (m.eid && einsaetze()[m.eid]) {
      nlogAendern(m.eid, m.nid, (x) => ({ ...x, quittiert: { ...(x.quittiert || {}), [vid]: m.quittiert } }));
      tbAdd(m.eid, { richtung: 'Eingang', von: vehName(vid), an: m.von || 'ELW', text: `Nachricht „${kurz}" verstanden (Fahrzeug-App).`, user: vehName(vid) });
    } else systemLog(vehName(vid), `Nachricht „${kurz}" verstanden.`);
    return {};
  }
  /* Nachricht (und Bilder) vom Fahrzeug an die Einsatzleitung – nur über den Meldeserver (Port 8081) */
  function nachrichtFz(args, user) {
    if (!String(user || '').startsWith('Fahrzeug-App')) throw fehler('keine_berechtigung', 'Nur aus der Fahrzeug-App');   // ab 5.191 auch „Fahrzeug-App (ohne Netz …)“
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    const bilder = bildIds(args.bilder);
    const text = str(args.text, 500); if (!text && !bilder.length) throw fehler('text_fehlt', 'Bitte einen Text eintragen oder ein Bild anhängen');
    const jetzt = Date.now(), eid = fzEinsatz(vid) || null, name = vehName(vid);
    const nid = eid ? rid('nl') : null;
    const alle = { ...nachrichtenAlle() };
    const m = { id: rid('n'), t: jetzt, richtung: 'ein', text, von: name, eid, ...(nid ? { nid } : {}), ...(bilder.length ? { bilder } : {}) };
    alle[vid] = (alle[vid] || []).filter((x) => x.t >= jetzt - 24 * 3600 * 1000).concat(m).slice(-60);
    setKey(K.nachrichten, alle);
    const mitBild = bilder.length ? ` [${bilder.length === 1 ? 'mit Bild' : `mit ${bilder.length} Bildern`}]` : '';
    if (eid && args.lage && text) {   // ab 5.27: Lagemeldung aus der Fahrzeug-App (z. B. gesprochen) → Einsatztagebuch
      const eintrag = tbAdd(eid, { richtung: 'Eingang', von: name, an: 'ELW', text: `LAGEMELDUNG: ${text}`, user: name, auto: 'fahrzeug' });
      const e3 = JSON.parse(JSON.stringify(einsaetze()[eid])); e3.lage = Array.isArray(e3.lage) ? e3.lage : []; e3.lage.push({ t: jetzt, text, user: name, von: name, an: 'ELW', nr: eintrag && eintrag.nr }); putEinsatz(e3);
    }
    if (eid) {
      // ab 5.28: Meldungen des Erkunders gehören sofort ins Tagebuch des erkundeten Auftrags
      let erkTb = null;
      try {
        const d0 = store[aufKey(eid)];
        if (d0 && Array.isArray(d0.liste) && d0.liste.some((x) => x.status === 'erkundung' && x.fahrzeuge && x.fahrzeuge[vid] && x.fahrzeuge[vid].aktiv)) {
          const doc = aufDoc(eid); const a = doc.liste.find((x) => x.status === 'erkundung' && x.fahrzeuge[vid] && x.fahrzeuge[vid].aktiv);
          const t0 = aufTb(a, { richtung: 'Eingang', von: name, an: 'ELW', text: `${args.lage ? 'Lagemeldung' : 'Nachricht'} (Erkunder, Fahrzeug-App): ${text || '(nur Bild)'}${mitBild}`, user: name, auto: 'nachricht' });
          if (bilder.length) a.bilder = [...new Set((a.bilder || []).concat(bilder))].slice(-30);
          setKey(aufKey(eid), doc); erkTb = t0 ? t0.nr : true;
        }
      } catch (err) { /* optional */ }
      nlogNeu(eid, { id: nid, t: jetzt, richtung: 'ein', von: name, an: 'ELW', vids: [vid], text: args.lage ? `🗣 Lagemeldung: ${text}` : text, bilder, gelesen: null, bericht: false, user: name, ...(aufVonFz(eid, vid) ? { auftrag: aufVonFz(eid, vid) } : {}), ...(erkTb ? { aufTb: erkTb } : {}) });
      if (bilder.length) {   // Fotos der Fahrzeuge gehören automatisch zur Fotodokumentation, Ort = letzte GPS-Position des Fahrzeugs
        const p = (store[K.pos] || {})[vid];
        const ort = p && Math.abs(jetzt - (p.t || 0)) < 15 * 60 * 1000 ? { lat: p.lat, lon: p.lon, ortQuelle: 'gps' } : {};
        const e2 = einsaetze()[eid];
        putEinsatz({ ...e2, fotos: (Array.isArray(e2.fotos) ? e2.fotos : []).concat(bilder.map((b) => ({ id: rid('fo'), t: jetzt, bild: b, von: name, vid, text, quelle: 'fahrzeug', ...ort, bericht: false }))).slice(-FOTO_MAX) });
      }
      tbAdd(eid, { richtung: 'Eingang', von: name, an: 'ELW', text: `Nachricht (Fahrzeug-App): ${text || '(nur Bild)'}${mitBild}`, user: name });
    } else systemLog(name, `Nachricht an die Einsatzleitung: ${text || '(nur Bild)'}${mitBild}`);
    return { id: m.id };
  }
  /* ab 3.83: Fahrzeug an Fahrzeug – nur zwischen Fahrzeugen desselben Einsatzes; erscheint in der Einsatzverwaltung
     im Nachrichtenverlauf (gekennzeichnet, ohne Meldung/ungelesen), nicht im Tagebuch */
  function kollegenVon(vid, mitPos) {
    const eid = fzEinsatz(vid); const e = eid && einsaetze()[eid];
    if (!e) return [];
    const P = store[K.pos] || {}, jetzt = Date.now();
    return Object.entries(e.fahrzeuge || {}).filter(([x, f]) => x !== vid && f.aktiv).map(([x]) => {
      const v = vehicles().find((y) => y.id === x) || {};
      const p = mitPos && P[x] && jetzt - (P[x].t || 0) < 60 * 60 * 1000 ? { lat: +Number(P[x].lat).toFixed(6), lon: +Number(P[x].lon).toFixed(6), t: P[x].t, acc: P[x].acc || null } : null;   // ab 3.85: Standort für die Karte der Fahrzeug-App
      return { vid: x, name: v.funkrufname || x, typ: v.fahrzeugtyp || v.funktion || '', st: stOf(x), ...(p ? { pos: p } : {}) }; })
      .sort((a, b) => String(a.name).localeCompare(String(b.name), 'de', { numeric: true }));
  }
  function nachrichtFzFz(args, user) {
    if (!String(user || '').startsWith('Fahrzeug-App')) throw fehler('keine_berechtigung', 'Nur aus der Fahrzeug-App');   // ab 5.191 auch „Fahrzeug-App (ohne Netz …)“
    const vid = String(args.vid || '');
    const eid = fzEinsatz(vid);
    if (!eid) throw fehler('kein_einsatz', 'Nachrichten an andere Fahrzeuge nur im Einsatz');
    const erlaubt = new Set(kollegenVon(vid).map((x) => x.vid));
    const an = [...new Set((Array.isArray(args.an) ? args.an : []).map(String))].filter((x) => erlaubt.has(x)).slice(0, 40);
    if (!an.length) throw fehler('fahrzeug_fehlt', 'Bitte ein Fahrzeug im selben Einsatz wählen');
    const bilder = bildIds(args.bilder);
    const text = str(args.text, 500); if (!text && !bilder.length) throw fehler('text_fehlt', 'Bitte einen Text eintragen oder ein Bild anhängen');
    const jetzt = Date.now(), grenze = jetzt - 24 * 3600 * 1000, name = vehName(vid), namen = an.map(vehName), nid = rid('nl');
    const alle = { ...nachrichtenAlle() };
    an.forEach((x) => { alle[x] = (alle[x] || []).filter((m) => m.t >= grenze).concat({ id: rid('n'), t: jetzt, richtung: 'aus', fzfz: true, text, von: name, vonVid: vid, eid, nid, ...(bilder.length ? { bilder } : {}) }).slice(-60); });
    alle[vid] = (alle[vid] || []).filter((m) => m.t >= grenze).concat({ id: rid('n'), t: jetzt, richtung: 'fzaus', text, an: namen.join(', ').slice(0, 200), anVids: an, eid, nid, ...(bilder.length ? { bilder } : {}) }).slice(-60);
    setKey(K.nachrichten, alle);
    nlogNeu(eid, { id: nid, t: jetzt, richtung: 'fz', von: name, an: namen.join(', ').slice(0, 200), vids: [vid, ...an], text, bilder, user: name });
    return { anzahl: an.length };
  }
  function nachrichtGelesen(args, user) {
    const vid = String(args.vid || '');
    const ids = Array.isArray(args.ids) ? args.ids.map(String) : args.id ? [String(args.id)] : [];
    const nids = Array.isArray(args.nids) ? args.nids.map(String) : [];
    const g = { t: Date.now(), user };
    const alle = { ...nachrichtenAlle() };
    const liste = (alle[vid] || []).map((x) => ({ ...x }));
    const treffer = liste.filter((x) => x.richtung === 'ein' && !x.gelesen && (ids.includes(x.id) || (x.nid && nids.includes(x.nid))));
    treffer.forEach((m) => { m.gelesen = g; if (m.nid && !nids.includes(m.nid) && m.eid) nids.push(m.nid); });
    if (treffer.length) { alle[vid] = liste; setKey(K.nachrichten, alle); }
    // Verlauf im Einsatz (auch wenn das Postfach nach 24 h schon geleert ist)
    const eids = new Set([String(args.einsatzId || ''), ...treffer.map((m) => m.eid)].filter((x) => x && einsaetze()[x]));
    let n = 0;
    eids.forEach((eid) => {
      const e = einsaetze()[eid]; let k = 0;
      const l = (e.nachrichten || []).map((x) => { if (x.richtung === 'ein' && !x.gelesen && nids.includes(x.id)) { k += 1; return { ...x, gelesen: g }; } return x; });
      if (k) { n += k; putEinsatz({ ...e, nachrichten: l }); }
    });
    return { anzahl: Math.max(treffer.length, n) };
  }
  /* Nachricht in den Einsatzbericht übernehmen (laufend und im Archiv) */
  function nachrichtBericht(args, user) {
    const id = String(args.einsatzId || '');
    const aktiv = einsaetze()[id];
    const rec = aktiv ? null : store[archKey(id)];
    if (!aktiv && !rec) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const e = aktiv || rec.einsatz;
    const nids = Array.isArray(args.ids) ? args.ids.map(String) : [String(args.id || '')];
    const an = !!args.an;
    const bilder = [];
    const l = (Array.isArray(e.nachrichten) ? e.nachrichten : []).map((x) => { if (!nids.includes(x.id) || !!x.bericht === an) return x; if (an) bilder.push(...(x.bilder || [])); return { ...x, bericht: an, berichtVon: { t: Date.now(), user } }; });
    // ab 3.88: Nachricht eines Fahrzeugs, das in einem Auftrag ist → mit „Bericht“ auch ins Tagebuch des Auftrags
    let l2 = l;
    if (aktiv && an && store[aufKey(id)]) {
      const doc = aufDoc(id); let geaendert = false;
      l2 = l.map((x) => {
        if (!nids.includes(x.id) || x.richtung !== 'ein' || x.aufTb) return x;
        const vid = (x.vids || [])[0];
        const nr = x.auftrag || aufVonFz(id, vid);
        const a = nr && doc.liste.find((y) => y.nr === nr); if (!a) return x;
        const tb = aufTb(a, { richtung: 'Eingang', von: x.von || vehName(vid), an: 'ELW', text: `Nachricht (Fahrzeug-App, ${new Date(x.t).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Berlin' })}): ${x.text || '(nur Bild)'}${(x.bilder || []).length ? ` [${x.bilder.length === 1 ? 'mit Bild' : `mit ${x.bilder.length} Bildern`}]` : ''}`, user, auto: 'nachricht' });
        geaendert = true;
        return { ...x, auftrag: a.nr, aufTb: tb ? tb.nr : true };
      });
      if (geaendert) setKey(aufKey(id), doc);
    }
    if (aktiv) putEinsatz({ ...aktiv, nachrichten: l2 });
    else { rec.einsatz = { ...rec.einsatz, nachrichten: l2 }; store[archKey(id)] = rec; save(); }
    return { berichtBilder: bilder };
  }
  function nachrichtenFuer(vid) { return (nachrichtenAlle()[vid] || []).filter((x) => x.richtung === 'aus' && x.t >= Date.now() - 24 * 3600 * 1000).slice(-40).map((x) => ({ id: x.id, t: x.t, text: x.text, von: x.von, ...(x.fzfz ? { fzfz: true, vonVid: x.vonVid } : {}), bilder: x.bilder || [], quittiert: x.quittiert || x.erledigt || null, ...(x.erledigt && !x.quittiert ? { erledigt: x.erledigt } : {}) })); }
  function gesendetVon(vid) { return (nachrichtenAlle()[vid] || []).filter((x) => (x.richtung === 'ein' || x.richtung === 'fzaus') && x.t >= Date.now() - 24 * 3600 * 1000).slice(-30).map((x) => ({ id: x.id, t: x.t, text: x.text, bilder: x.bilder || [], gelesen: x.gelesen ? x.gelesen.t : null, ...(x.richtung === 'fzaus' ? { an: x.an, fzfz: true } : {}) })); }

  /* ---------- Fotodokumentation je Einsatz ----------
     einsatz.fotos = [{id, t, bild, von, user, text, lat, lon, ortQuelle, quelle:'elw'|'fahrzeug', bericht}] */
  const FOTO_MAX = 400;
  function foto(args, user) {
    const id = String(args.einsatzId || '');
    const aktiv = einsaetze()[id];
    const rec = aktiv ? null : store[archKey(id)];
    if (!aktiv && !rec) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const e = aktiv || rec.einsatz;
    let l = Array.isArray(e.fotos) ? e.fotos.slice() : [];
    const a = args.aktion;
    const koord = (x) => { const lat = Number(x.lat), lon = Number(x.lon); return Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && !(lat === 0 && lon === 0) ? { lat: +lat.toFixed(6), lon: +lon.toFixed(6) } : null; };
    let bilder = [];
    if (a === 'neu') {
      if (!aktiv) throw fehler('einsatz_beendet', 'Der Einsatz ist beendet');
      const liste = (Array.isArray(args.fotos) ? args.fotos : [args]).slice(0, 20);
      liste.forEach((f) => {
        const b = String(f.bild || ''); if (!/^[0-9a-f]{24}$/.test(b)) return;
        const k = koord(f);
        const t = Number(f.aufgenommen); 
        l.push({ id: rid('fo'), t: Date.now(), ...(Number.isFinite(t) && t > Date.now() - 7 * 86400000 && t < Date.now() + 600000 ? { aufgenommen: t } : {}), bild: b, von: str(f.von, 60) || 'ELW', user, text: str(f.text, 300), ...(k ? { ...k, ortQuelle: ['gps', 'geraet', 'einsatzort', 'karte'].includes(f.ortQuelle) ? f.ortQuelle : 'geraet' } : {}), quelle: 'elw', bericht: !!f.bericht });
        bilder.push(b);
      });
      if (!bilder.length) throw fehler('bild_fehlt', 'Kein Bild');
      if (l.length > FOTO_MAX) throw fehler('zu_viele', `Höchstens ${FOTO_MAX} Fotos je Einsatz`);
    } else if (a === 'aendern') {
      l = l.map((x) => { if (x.id !== args.id) return x; const n = { ...x }; if (args.text != null) n.text = str(args.text, 300); if (args.lat !== undefined) { const k = koord(args); if (k) Object.assign(n, k, { ortQuelle: 'karte' }); else { delete n.lat; delete n.lon; delete n.ortQuelle; } } return n; });
    } else if (a === 'bericht') {
      const ids = Array.isArray(args.ids) ? args.ids.map(String) : [String(args.id || '')];
      l = l.map((x) => (ids.includes(x.id) ? { ...x, bericht: !!args.an } : x));
    } else if (a === 'loeschen') {
      l = l.filter((x) => x.id !== args.id);
    } else throw fehler('aktion_ungueltig');
    if (aktiv) putEinsatz({ ...aktiv, fotos: l });
    else { rec.einsatz = { ...rec.einsatz, fotos: l }; store[archKey(id)] = rec; save(); }
    return { berichtBilder: bilder };
  }
  /* Funkskizze: Kanäle zur Leitstelle und der Einsatzleitung (Abschnitts-Kanäle stehen am Abschnitt) */
  function funk(args, user) {
    const e = einsaetze()[String(args.einsatzId || '')]; if (!e) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const f = { ...(e.funk || {}) };
    ['leitstelle', 'leitstelleName', 'fuehrung', 'fuehrungName', 'bemerkung'].forEach((k) => { if (args[k] !== undefined) f[k] = str(args[k], k === 'bemerkung' ? 300 : 60); });
    // ab 5.144: weitere Funkbereiche und frei verschobene Kästen
    if (Array.isArray(args.zusatz)) f.zusatz = args.zusatz.slice(0, 20).map((z) => ({ id: str(z && z.id, 12) || rid('z'), name: str(z && z.name, 60), kanal: str(z && z.kanal, 40), leiter: str(z && z.leiter, 60), an: /^(lst|el|ab:[\w-]{1,40})$/.test(String(z && z.an || '')) ? String(z.an) : 'el', teilnehmer: str(z && z.teilnehmer, 400), farbe: /^#[0-9a-f]{6}$/i.test(String(z && z.farbe || '')) ? String(z.farbe) : '#117A65' }));
    if (args.pos && typeof args.pos === 'object') { const p = {}; Object.entries(args.pos).slice(0, 80).forEach(([k, v]) => { if (/^(lst|el|frei|ab:[\w-]{1,40}|z:[\w-]{1,12})$/.test(k) && v && Number.isFinite(+v.x) && Number.isFinite(+v.y)) p[k] = { x: Math.max(-3000, Math.min(6000, Math.round(+v.x))), y: Math.max(-3000, Math.min(6000, Math.round(+v.y))) }; }); f.pos = p; }
    if (args.bericht !== undefined) f.bericht = !!args.bericht;
    // ab 5.132: Rufgruppe an die Fahrzeuge senden (Fahrzeug-App), auch an später hinzukommende Fahrzeuge
    if (args.fzRufgruppe !== undefined) f.fzRufgruppe = str(args.fzRufgruppe, 40);
    if (args.fzAbschnitt !== undefined) f.fzAbschnitt = !!args.fzAbschnitt;
    if (args.fzSenden !== undefined) {
      const an = !!args.fzSenden;
      if (an && !f.fzRufgruppe && !f.fzAbschnitt) throw fehler('rufgruppe_fehlt', 'Bitte eine Rufgruppe eintragen');
      if (an !== !!f.fzSenden) tbAdd(e.id, { richtung: 'Vermerk', von: user, text: an ? `Rufgruppe an die Fahrzeuge: ${f.fzRufgruppe || '–'}${f.fzAbschnitt ? ' (Fahrzeuge in Abschnitten mit Kanal: Kanal des Abschnitts)' : ''} – wird an alle Fahrzeuge in der Fahrzeug-App gesendet.` : 'Senden der Rufgruppe an die Fahrzeuge beendet.', user, auto: 'system' });
      f.fzSenden = an; if (!an) f.fzGesendet = {};
    }
    if (args.gesendet && typeof args.gesendet === 'object') f.fzGesendet = { ...(f.fzGesendet || {}), ...args.gesendet };
    f.geaendert = { t: Date.now(), user };
    putEinsatz({ ...e, funk: f });
    return {};
  }
  /* ab 5.132: Rufgruppe, die ein Fahrzeug im Einsatz bekommen soll (null = keine) */
  function rufgruppeFuer(eid, vid) {
    const e = einsaetze()[eid]; const f = e && e.funk; if (!f || !f.fzSenden) return null;
    const fz = (e.fahrzeuge || {})[vid]; if (!fz || !fz.aktiv) return null;
    if (f.fzAbschnitt) { const ab = (e.abschnitte || []).find((a) => a.id === (fz.abschnitt || 'ea') && !a.fixed); if (ab && ab.kanal) return { rufgruppe: ab.kanal, abschnitt: ab.name }; }
    return f.fzRufgruppe ? { rufgruppe: f.fzRufgruppe, abschnitt: '' } : null;
  }
  /* Wetter an der Einsatzstelle (vom Server abgefragt, siehe server.js) */
  function wetterVermerk(eid, w, text) {
    const e = einsaetze()[eid]; if (!e) return;
    tbAdd(eid, { richtung: 'Vermerk', von: 'Wetterdienst', text, user: 'System', auto: 'wetter' });
    const e2 = einsaetze()[eid];
    putEinsatz({ ...e2, wetter: { erste: (e2.wetter && e2.wetter.erste) || w, letzte: w } });
    save();
  }

  /* ---------- Lagestände: Stand der Lage- oder Taktikkarte zu einem Zeitpunkt festhalten ----------
     opta3.lagestand.<eid> = [{id, t, name, user, modus, karte:{markers, shapes}, fz:{vid:{lat,lon,st,name}}, abschnitte, bericht}] */
  function lagestand(args, user) {
    const id = String(args.einsatzId || '');
    const aktiv = einsaetze()[id];
    const rec = aktiv ? null : store[archKey(id)];
    if (!aktiv && !rec) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    let l = aktiv ? (Array.isArray(store[lagestandKey(id)]) ? store[lagestandKey(id)].slice() : []) : (rec.lagestaende || []).slice();
    const a = args.aktion;
    if (a === 'neu') {
      if (!aktiv) throw fehler('einsatz_beendet', 'Der Einsatz ist beendet');
      const d = args.stand || {};
      const karte = { markers: Array.isArray(d.karte && d.karte.markers) ? d.karte.markers.slice(0, 2000) : [], shapes: Array.isArray(d.karte && d.karte.shapes) ? d.karte.shapes.slice(0, 1000) : [] };
      const fz = {};
      Object.entries(d.fz && typeof d.fz === 'object' ? d.fz : {}).slice(0, 200).forEach(([vid, p]) => { if (p && Number.isFinite(+p.lat) && Number.isFinite(+p.lon)) fz[String(vid).slice(0, 40)] = { lat: +p.lat, lon: +p.lon, st: str(p.st, 2), name: str(p.name, 40), typ: str(p.typ, 30) }; });
      const x = { id: rid('ls'), t: Date.now(), name: str(args.name, 60) || 'Lagestand', user, modus: args.modus === 'taktik' ? 'taktik' : 'lage', karte, fz, abschnitte: (aktiv.abschnitte || []).filter((ab) => !ab.fixed && Array.isArray(ab.flaeche)).map((ab) => ({ name: ab.name, farbe: ab.farbe, flaeche: ab.flaeche })), bericht: !!args.bericht };
      if (JSON.stringify(x).length > 600000) throw fehler('zu_gross', 'Die Karte ist zu groß für einen Lagestand');
      l.push(x);
      if (l.length > 40) throw fehler('zu_viele', 'Höchstens 40 Lagestände je Einsatz – bitte alte löschen');
      tbAdd(id, { richtung: 'Vermerk', von: user, text: `Lagestand „${x.name}“ (${x.modus === 'taktik' ? 'Einsatztaktik' : 'Lagekarte'}) gespeichert.`, user, auto: 'system' });
    } else if (a === 'loeschen') {
      l = l.filter((x) => x.id !== args.id);
    } else if (a === 'bericht') {
      l = l.map((x) => (x.id === args.id ? { ...x, bericht: !!args.an } : x));
    } else if (a === 'umbenennen') {
      const n = str(args.name, 60); if (!n) throw fehler('name_fehlt');
      l = l.map((x) => (x.id === args.id ? { ...x, name: n } : x));
    } else throw fehler('aktion_ungueltig');
    if (aktiv) setKey(lagestandKey(id), l);
    else { rec.lagestaende = l; store[archKey(id)] = rec; save(); }
    return {};
  }

  /* ---------- Nachbereitung je Fahrzeug: Material, Defekte, Atemschutzgeräte, Einsatzbereitschaft ----------
     Geht im laufenden Einsatz und nachträglich im Archiv. „_asue“ = Atemschutzgeräte des Einsatzes aus der ASÜ. */
  const NB_ART = ['Pressluftatmer', 'Lungenautomat', 'Atemschutzmaske', 'Atemluftflasche', 'CSA', 'Sonstiges'];
  function nbName(vid, e) { return vid === '_asue' ? 'Atemschutz (ASÜ)' : ((e.fahrzeugInfo || {})[vid] || vehName(vid)); }
  function nachbereitung(args, user) {
    const id = String(args.einsatzId || '');
    const aktiv = einsaetze()[id];
    const rec = aktiv ? null : store[archKey(id)];
    if (!aktiv && !rec) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const e = aktiv ? JSON.parse(JSON.stringify(aktiv)) : rec.einsatz;
    const vid = String(args.vid || '');
    if (vid !== '_asue' && !(e.fahrzeuge || {})[vid]) throw fehler('fahrzeug_fehlt', 'Fahrzeug war nicht in diesem Einsatz');
    if (!aktiv && rec.fahrzeuge && rec.fahrzeuge[vid]) e.fahrzeugInfo = { ...(e.fahrzeugInfo || {}), [vid]: rec.fahrzeuge[vid].funkrufname };
    e.nachbereitung = e.nachbereitung || {};
    const nb = e.nachbereitung[vid] = e.nachbereitung[vid] || { material: [], defekte: [], atemschutz: [] };
    ['material', 'defekte', 'atemschutz'].forEach((k) => { nb[k] = Array.isArray(nb[k]) ? nb[k] : []; });
    const feld = ['material', 'defekte', 'atemschutz'].includes(args.feld) ? args.feld : null;
    let tb = '';
    const name = nbName(vid, e);
    if (args.aktion === 'neu') {
      if (!feld) throw fehler('feld_ungueltig');
      const it = args.item || {};
      let x;
      if (feld === 'material') { x = { was: str(it.was, 80), menge: str(it.menge, 20) }; if (!x.was) throw fehler('was_fehlt', 'Bitte eintragen, was verbraucht wurde'); tb = `Verbrauch ${x.menge ? `${x.menge} ` : ''}${x.was}`; }
      if (feld === 'defekte') { x = { was: str(it.was, 80), problem: str(it.problem, 200) }; if (!x.was) throw fehler('was_fehlt', 'Bitte das Gerät eintragen'); tb = `Defekt: ${x.was}${x.problem ? ` – ${x.problem}` : ''}`; }
      if (feld === 'atemschutz') { x = { art: NB_ART.includes(it.art) ? it.art : 'Pressluftatmer', geraet: str(it.geraet, 40), grund: str(it.grund, 120) || 'nach Einsatz: Reinigung und Prüfung' }; tb = `${x.art} ${x.geraet || ''} zur Atemschutzwerkstatt`.replace(/\s+/g, ' ').trim(); }
      nb[feld].push({ id: rid('m'), ...x, t: Date.now(), user });
    } else if (args.aktion === 'loeschen') {
      if (!feld) throw fehler('feld_ungueltig');
      nb[feld] = nb[feld].filter((x) => x.id !== args.itemId);
    } else if (args.aktion === 'erledigt') {
      if (!feld) throw fehler('feld_ungueltig');
      const x = nb[feld].find((y) => y.id === args.itemId); if (!x) throw fehler('eintrag_fehlt');
      if (args.an) x.erledigt = { t: Date.now(), user }; else delete x.erledigt;
    } else if (args.aktion === 'status') {
      if (args.bereit !== undefined) { nb.bereit = ['ja', 'eingeschraenkt', 'nein'].includes(args.bereit) ? args.bereit : ''; tb = `Einsatzbereitschaft: ${{ ja: 'einsatzbereit', eingeschraenkt: 'eingeschränkt einsatzbereit', nein: 'NICHT einsatzbereit' }[nb.bereit] || 'offen'}`; }
      if (args.bemerkung !== undefined) nb.bemerkung = str(args.bemerkung, 500);
    } else if (args.aktion === 'fertig') {
      if (args.an) nb.fertig = { t: Date.now(), user }; else delete nb.fertig;
      tb = args.an ? 'Nachbereitung abgeschlossen' : '';
    } else if (args.aktion === 'asue') {
      // alle Geräte aus den zugeordneten Überwachungen übernehmen (laufend: ASÜ-Daten, Archiv: gesicherte Daten)
      const quellen = aktiv
        ? Object.values(store['asue.einsaetze'] || {}).filter((x) => x && x.einsatz && x.einsatz.data && x.einsatz.data.evId === id).map((x) => Object.values(x.trupps || {}).filter((t) => t && t.data && !t.vorschlag && !t.data._gone).map((t) => t.data))
        : (rec.asueDetail || []).map((x) => x.trupps || []);
      const vorhanden = new Set(nb.atemschutz.map((x) => `${x.art}|${x.geraet}`));
      let n = 0;
      quellen.flat().filter((t) => t.ev && t.ev.beginn).forEach((t) => (t.mitglieder || []).forEach((m) => {
        [['Pressluftatmer', m.geraetNr], ['Lungenautomat', m.laNr], ['Atemschutzmaske', m.maskeNr], ['Atemluftflasche', m.flascheNr]].forEach(([art, nr]) => {
          const g = str(nr, 40); if (!g || vorhanden.has(`${art}|${g}`)) return;
          vorhanden.add(`${art}|${g}`); n += 1;
          nb.atemschutz.push({ id: rid('m'), art, geraet: g, grund: 'nach Einsatz: Reinigung und Prüfung', t: Date.now(), user, asue: true });
        });
      }));
      tb = n ? `${n} Atemschutzgeräte/-teile aus der ASÜ zur Atemschutzwerkstatt übernommen` : '';
      if (!n) { if (aktiv) putEinsatz(e); else { store[archKey(id)] = rec; } save(); return { anzahl: 0 }; }
    } else throw fehler('aktion_ungueltig');
    nb.geaendert = { t: Date.now(), user };
    if (aktiv) {
      delete e.fahrzeugInfo;
      putEinsatz(e);
      if (tb) tbAdd(id, { richtung: 'Vermerk', von: user, text: `Nachbereitung ${name}: ${tb}.`, user, auto: 'system' });
    } else {
      delete e.fahrzeugInfo;
      store[archKey(id)] = rec;
      if (tb) { rec.tagebuch = rec.tagebuch || []; const nr = rec.tagebuch.length ? rec.tagebuch[rec.tagebuch.length - 1].nr + 1 : 1; const nachX = { nr, t: Date.now(), richtung: 'Vermerk', von: user, an: '', text: `Nachbereitung ${name}: ${tb}. (nach Einsatzende)`, user, auto: 'system', nachtrag: false }; tbKetteAnhaengen(id, rec.tagebuch, nachX); rec.tagebuch.push(nachX); }
    }
    setKey('opta3.nbStand', Date.now());
    return { ok: true };
  }
  /* offene Punkte für den Gerätewart (laufende Einsätze und Archiv der letzten Tage) */
  function nachbereitungOffen(tage) {
    const grenze = Date.now() - (tage || 180) * 24 * 3600 * 1000;
    const out = [];
    const nimm = (e, archiv, fzNamen) => Object.entries(e.nachbereitung || {}).forEach(([vid, nb]) => {
      const fz = vid === '_asue' ? 'Atemschutz (ASÜ)' : ((fzNamen || {})[vid] || vehName(vid));
      const basis = { einsatzId: e.id, nummer: e.nummer, stichwort: e.stichwort, meldebild: e.meldebild, datum: e.alarmzeit, archiv, vid, fahrzeug: fz, bereit: nb.bereit || '', fertig: !!nb.fertig };
      ['material', 'defekte', 'atemschutz'].forEach((feld) => (nb[feld] || []).forEach((x) => out.push({ ...basis, feld, item: x })));
      if (nb.bereit && nb.bereit !== 'ja') out.push({ ...basis, feld: 'bereit', item: { id: `bereit-${vid}`, was: nb.bereit, bemerkung: nb.bemerkung || '' } });
    });
    Object.values(einsaetze()).forEach((e) => nimm(e, false));
    (store[K.archIndex] || []).filter((x) => (x.ende || x.alarmzeit) >= grenze).forEach((z) => { const rec = store[archKey(z.id)]; if (rec) nimm(rec.einsatz, true, Object.fromEntries(Object.entries(rec.fahrzeuge || {}).map(([k, v]) => [k, v.funkrufname]))); });
    return out;
  }

  /* ---------- Ansprechpartner: Datenbank und Zuordnung zum Einsatz ---------- */
  function kontakte() { return Array.isArray(store[K.kontakte]) ? store[K.kontakte] : []; }
  function kontaktFelder(args) {
    const k = { funktion: str(args.funktion, 80), name: str(args.name, 80), telefon: str(args.telefon, 40), telefon2: str(args.telefon2, 40), email: str(args.email, 120), bemerkung: str(args.bemerkung, 300), kategorie: ['person', 'dienst', 'geraet', 'behoerde'].includes(args.kategorie) ? args.kategorie : '', stichworte: str(args.stichworte, 300), ort: str(args.ort, 80), rund: !!args.rund };
    if (!k.name && !k.funktion) throw fehler('name_fehlt', 'Bitte Name oder Funktion eintragen');
    if (k.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(k.email)) throw fehler('email_ungueltig', 'Die E-Mail-Adresse ist ungültig');
    return k;
  }
  function kontaktSpeichern(args, user) {
    const liste = kontakte().slice();
    const k = kontaktFelder(args);
    let x = args.id ? liste.find((y) => y.id === args.id) : null;
    if (args.id && !x) throw fehler('kontakt_fehlt', 'Ansprechpartner nicht gefunden');
    if (x) Object.assign(x, k, { geaendert: Date.now(), user });
    else { x = { id: rid('k'), ...k, angelegt: Date.now(), user }; liste.push(x); }
    setKey(K.kontakte, liste);
    return x;
  }
  function kontaktLoeschen(args, user) {
    const x = kontakte().find((y) => y.id === args.id); if (!x) throw fehler('kontakt_fehlt');
    setKey(K.kontakte, kontakte().filter((y) => y.id !== args.id));
    systemLog(user, `Ansprechpartner „${[x.funktion, x.name].filter(Boolean).join(' ')}“ aus der Datenbank gelöscht.`);
    return {};
  }
  function kontaktImport(args, user) {   // Liste aus CSV: gleiche Namen+Funktion werden aktualisiert
    const liste = kontakte().slice();
    let neu = 0, akt = 0;
    (Array.isArray(args.liste) ? args.liste : []).slice(0, 2000).forEach((z) => {
      let k; try { k = kontaktFelder(z || {}); } catch (e) { return; }
      const x = liste.find((y) => (y.name || '').toLowerCase() === k.name.toLowerCase() && (y.funktion || '').toLowerCase() === k.funktion.toLowerCase());
      if (x) { Object.assign(x, k, { geaendert: Date.now(), user }); akt += 1; } else { liste.push({ id: rid('k'), ...k, angelegt: Date.now(), user }); neu += 1; }
    });
    setKey(K.kontakte, liste);
    systemLog(user, `Ansprechpartner importiert: ${neu} neu, ${akt} aktualisiert.`);
    return { neu, akt };
  }
  function einsatzKontakt(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    e.kontakte = Array.isArray(e.kontakte) ? e.kontakte : [];
    const txt = (k) => `${[k.funktion, k.name].filter(Boolean).join(' ')}${k.telefon ? `, Tel. ${k.telefon}` : ''}`;
    if (args.entfernen) {
      const k = e.kontakte.find((x) => x.id === args.id); if (!k) throw fehler('kontakt_fehlt');
      e.kontakte = e.kontakte.filter((x) => x.id !== args.id);
      putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Ansprechpartner entfernt: ${txt(k)}.`, user, auto: 'system' });
      return {};
    }
    let k;
    if (args.kontaktId) { const x = kontakte().find((y) => y.id === args.kontaktId); if (!x) throw fehler('kontakt_fehlt', 'Ansprechpartner nicht gefunden'); k = { kategorie: x.kategorie || '', stichworte: x.stichworte || '', ort: x.ort || '', rund: !!x.rund, funktion: x.funktion, name: x.name, telefon: x.telefon, telefon2: x.telefon2, email: x.email, bemerkung: x.bemerkung, kontaktId: x.id }; }
    else { k = kontaktFelder(args); if (args.speichern) k.kontaktId = kontaktSpeichern(args, user).id; }
    if (k.kontaktId && e.kontakte.some((x) => x.kontaktId === k.kontaktId)) return {};
    const neu = { id: rid('p'), ...k, rolle: str(args.rolle, 80), t: Date.now(), user };
    e.kontakte.push(neu);
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Ansprechpartner hinzugefügt: ${txt(neu)}${neu.rolle ? ` (${neu.rolle})` : ''}.`, user, auto: 'system' });
    return neu;
  }

  /* ---------- Lagekarte/Einsatztaktik: Änderungen einzelner Elemente zusammenführen ----------
     Mehrere Geräte können gleichzeitig zeichnen: es werden nur die geänderten Marker/Zeichnungen/
     Fahrzeugpositionen übernommen, nicht die ganze Karte überschrieben. */
  const KARTE_FELDER = ['mScale', 'vScale', 'bild', 'view'];
  function karteAendern(args, user) {
    const key = String(args.key || '');
    const m = /^opta3\.(karte|taktik)\.([A-Za-z0-9_-]+)$/.exec(key);
    if (!m || !einsaetze()[m[2]]) throw fehler('karte_ungueltig', 'Karte nicht gefunden (Einsatz beendet?)');
    const k = store[key] && typeof store[key] === 'object' ? JSON.parse(JSON.stringify(store[key])) : { v: 2, markers: [], vehPos: {}, shapes: [], mScale: 1, vScale: 1, bild: null };
    k.v = 2;
    k.markers = Array.isArray(k.markers) ? k.markers : [];
    k.shapes = Array.isArray(k.shapes) ? k.shapes : [];
    k.vehPos = k.vehPos && typeof k.vehPos === 'object' ? k.vehPos : {};
    (Array.isArray(args.aenderungen) ? args.aenderungen : []).slice(0, 1000).forEach((a) => {
      if (!a || typeof a.id !== 'string' || a.id.length > 60) return;
      if (a.liste === 'markers' || a.liste === 'shapes') {
        const l = k[a.liste], i = l.findIndex((x) => x && x.id === a.id);
        if (a.wert == null) { if (i >= 0) l.splice(i, 1); } else if (typeof a.wert === 'object') { const w = { ...a.wert, id: a.id }; if (i >= 0) l[i] = w; else l.push(w); }
      } else if (a.liste === 'vehPos') {
        if (a.wert == null) delete k.vehPos[a.id]; else if (typeof a.wert === 'object') k.vehPos[a.id] = a.wert;
      }
    });
    Object.entries(args.felder || {}).forEach(([f, w]) => { if (KARTE_FELDER.includes(f)) { if (w == null) delete k[f]; else k[f] = w; } });
    k.geaendert = { t: Date.now(), user };
    setKey(key, k);
    return { geaendert: k.geaendert };
  }

  /* ---------- Checklisten nach Stichwort: abgehakte Punkte mit Zeit ---------- */
  function check(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const liste = str(args.liste, 60); if (!liste) throw fehler('liste_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    e.checks = e.checks && typeof e.checks === 'object' ? e.checks : {};
    if (args.hinzufuegen !== undefined) {   // weitere Checkliste zum Einsatz nehmen / wieder abwählen
      e.checkListen = Array.isArray(e.checkListen) ? e.checkListen.filter((x) => x !== liste) : [];
      if (args.hinzufuegen) e.checkListen.push(liste);
      putEinsatz(e);
      return {};
    }
    const punkt = str(args.punkt, 200); if (!punkt) throw fehler('punkt_fehlt');
    const l = { ...(e.checks[liste] || {}) };
    const an = !!args.an;
    if (an === !!l[punkt]) return {};
    if (an) l[punkt] = { t: Date.now(), user }; else delete l[punkt];
    e.checks[liste] = l;
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: str(args.von, 80) || 'ELW', text: `Checkliste „${liste}": ${an ? '✓ ' : ''}${punkt}${an ? '' : ' – zurückgenommen'}.`, user, auto: 'system' });
    return {};
  }


  /* ---------- Ablaufplan ELW/ÖEL (ab 5.53): Plätze besetzen, Schritte abhaken, betreute Feuerwehren, Hilfsmittel ---------- */
  function ablauf(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    const a = e.ablauf && typeof e.ablauf === 'object' ? e.ablauf : {};
    a.plaetze = a.plaetze && typeof a.plaetze === 'object' ? a.plaetze : {}; a.hilfe = a.hilfe && typeof a.hilfe === 'object' ? a.hilfe : {};
    const plan = str(args.plan, 10) || 'ELW', von = str(args.von, 80) || plan;
    const pid = str(args.platz, 40), key = `${plan}:${pid}`, ptitel = str(args.titel, 80) || pid;
    const P = () => { a.plaetze[key] = a.plaetze[key] || { person: '', wehren: [], erledigt: {} }; return a.plaetze[key]; };
    let tb = '';
    if (args.aktion === 'person') { const x = P(); const n = str(args.person, 80); if (n === x.person) return {}; const alt = x.person; x.person = n; tb = args.uebergabe && alt && n ? `${plan} ${ptitel}: übergeben von ${alt} an ${n} (Ablöse).` : n ? `${plan} ${ptitel}: besetzt durch ${n}.` : `${plan} ${ptitel}: nicht mehr besetzt.`; }
    else if (args.aktion === 'schritt') { const x = P(); const s = str(args.schritt, 300); if (!s) throw fehler('punkt_fehlt'); const an = !!args.an; if (an === !!x.erledigt[s]) return {}; if (an) x.erledigt[s] = { t: Date.now(), user }; else delete x.erledigt[s]; tb = `${plan} ${ptitel}: ${an ? '✓ ' : ''}${s}${an ? '' : ' – zurückgenommen'}.`; }
    else if (args.aktion === 'wehren') { const x = P(); x.wehren = (Array.isArray(args.wehren) ? args.wehren : []).map((w) => str(w, 80)).filter(Boolean).slice(0, 60); tb = `${plan} ${ptitel}: betreut ${x.wehren.length ? x.wehren.join(', ') : 'alle Feuerwehren'}.`; }
    else if (args.aktion === 'hilfe') { const f = str(args.feld, 40); if (!f) throw fehler('feld_fehlt'); const w = String(args.text == null ? '' : args.text).slice(0, 4000); if (args.anhaengen) { if (!w.trim()) return {}; a.hilfe[f] = (a.hilfe[f] ? a.hilfe[f] + '\n' : '') + w; } else a.hilfe[f] = w; if (args.anhaengen) tb = `Nachforderung (${ptitel}): ${w}`; }
    else throw fehler('aktion_fehlt');
    e.ablauf = a; putEinsatz(e);
    if (tb) tbAdd(e.id, { richtung: 'Vermerk', von, text: tb, user, auto: 'system' });
    return {};
  }

  /* ---------- Kräfteanforderung ---------- */
  function anforderung(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    if (args.id) {
      const a = e.anforderungen.find((x) => x.id === args.id);
      if (!a) throw fehler('anforderung_fehlt');
      if (!ANF_STATUS.includes(args.status)) throw fehler('status_ungueltig');
      a.status = args.status; a.zeiten = { ...(a.zeiten || {}), [args.status]: Date.now() };
      putEinsatz(e);
      tbAdd(e.id, { richtung: args.status === 'storniert' ? 'Ausgang' : 'Vermerk', von: user, an: args.status === 'storniert' ? 'Leitstelle' : '', text: `Anforderung ${a.anzahl > 1 ? `${a.anzahl}× ` : ''}${a.was}: ${args.status}.`, user, auto: 'system' });
      return a;
    }
    const was = str(args.was, 120); if (!was) throw fehler('was_fehlt', 'Bitte eintragen, was angefordert wird');
    const vid = args.vid && vehicles().some((v) => v.id === args.vid) ? String(args.vid) : null;
    const a = { id: rid('r'), was, vid, anzahl: Math.max(1, int(args.anzahl, 99)), grund: str(args.grund, 200), ziel: str(args.ziel, 120) || e.bereitstellung || '', status: 'angefordert', zeiten: { angefordert: Date.now() }, user };
    e.anforderungen.push(a);
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Ausgang', von: str(args.von, 80) || user, an: str(args.an, 80) || 'Leitstelle', text: `Anforderung: ${a.anzahl > 1 ? `${a.anzahl}× ` : ''}${a.was}${a.grund ? ` – ${a.grund}` : ''}${a.ziel ? `; Anfahrt ${a.ziel}` : ''}.`, user, auto: 'system' });
    return a;
  }

  /* ---------- Lagemeldung ---------- */
  function lage(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const text = str(args.text, 2000); if (!text) throw fehler('text_fehlt', 'Bitte die Lage beschreiben');
    const e = JSON.parse(JSON.stringify(e0));
    const von = str(args.von, 80) || user;
    const eintrag = tbAdd(e.id, { richtung: args.an ? 'Ausgang' : 'Vermerk', von, an: str(args.an, 80), text: `LAGEMELDUNG: ${text}`, user });
    e.lage.push({ t: Date.now(), text, user, von, an: str(args.an, 80), nr: eintrag && eintrag.nr });
    putEinsatz(e);
    return {};
  }

  /* ---------- Gefahrstoffe am Einsatz (3.43) ---------- */
  function gefahrstoff(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const e = JSON.parse(JSON.stringify(e0));
    const l = Array.isArray(e.gefahrstoffe) ? e.gefahrstoffe : [];
    if (args.aktion === 'loeschen') {
      const x = l.find((g) => g.id === args.id); if (!x) return {};
      e.gefahrstoffe = l.filter((g) => g.id !== args.id); putEinsatz(e);
      tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Gefahrstoff entfernt: UN ${x.un} ${x.name}.`, user, auto: 'system' });
      return {};
    }
    const un = String(args.un || '').replace(/\D/g, '').padStart(4, '0');
    if (!/^\d{4}$/.test(un) || +un < 4 || +un > 3600) throw fehler('un_falsch', 'UN-Nummer hat 4 Ziffern (0004–3600)');
    if (l.some((g) => g.un === un)) return { id: l.find((g) => g.un === un).id, doppelt: true };
    const x = { id: rid('gs'), un, name: str(args.name, 120) || `UN ${un}`, gn: str(args.gn, 4).toUpperCase().replace(/[^X0-9]/g, ''), kl: str(args.kl, 6), quelle: str(args.quelle, 60) || 'von Hand', fund: str(args.fund, 80), t: Date.now(), user };
    e.gefahrstoffe = l.concat(x).slice(0, 20); putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: user, text: `Gefahrstoff ${x.quelle === 'von Hand' ? 'eingetragen' : `erkannt (${x.quelle}${x.fund ? `: ${x.fund}` : ''}) – bitte prüfen`}: UN ${un} ${x.name}${x.gn ? `, Gefahrnummer ${x.gn}` : ''}${x.kl ? `, Klasse ${x.kl}` : ''}.`, user, auto: 'system' });
    return { id: x.id };
  }

  /* ---------- Lagebesprechung (3.27) ---------- */
  function besprechung(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const text = str(args.text, 3000), rollt = str(args.rollt, 1000), benoetigt = str(args.benoetigt, 1000);   // ab 5.144: Anforderungen
    if (!text && !rollt && !benoetigt) throw fehler('text_fehlt', 'Bitte Ergebnis / Maßnahmen eintragen');
    const e = JSON.parse(JSON.stringify(e0));
    const jetzt = Date.now();
    const min = Math.max(0, Math.min(240, int(args.naechste, 240) || 0));
    const teilnehmer = str(args.teilnehmer, 400);
    e.besprechungen = Array.isArray(e.besprechungen) ? e.besprechungen : [];
    e.besprechungen.push({ t: jetzt, user, text, teilnehmer, ...(rollt ? { rollt } : {}), ...(benoetigt ? { benoetigt } : {}), naechste: min ? jetzt + min * 60000 : null });
    if (e.besprechungen.length > 100) e.besprechungen = e.besprechungen.slice(-100);
    e.uhren = e.uhren && typeof e.uhren === 'object' ? e.uhren : {};
    if (min) e.uhren.besprechung = { faellig: jetzt + min * 60000, gesetzt: jetzt, user }; else delete e.uhren.besprechung;
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: str(args.von, 80) || 'Einsatzleitung', text: `LAGEBESPRECHUNG${teilnehmer ? ` (${teilnehmer})` : ''}: ${text || '–'}${rollt ? ` · Rollt bereits: ${rollt}` : ''}${benoetigt ? ` · Noch benötigt / wer kümmert sich: ${benoetigt}` : ''}${min ? ` – nächste Besprechung um ${uhrzeit(jetzt + min * 60000)}` : ''}`, user });
    return { naechste: min ? jetzt + min * 60000 : null };
  }
  /* ---------- Übergabe der Einsatzleitung (3.27) ---------- */
  function uebergabe(args, user) {
    const e0 = einsaetze()[args.einsatzId]; if (!e0) throw fehler('einsatz_fehlt');
    const an = str(args.an, 80); if (!an) throw fehler('name_fehlt', 'Bitte den neuen Einsatzleiter eintragen');
    const e = JSON.parse(JSON.stringify(e0));
    const von = e.einsatzleiter || '';
    if (von && von === an) throw fehler('gleich', 'Das ist bereits der Einsatzleiter');
    const punkte = (Array.isArray(args.punkte) ? args.punkte : []).map((x) => str(x, 120)).filter(Boolean).slice(0, 20);
    const bemerkung = str(args.bemerkung, 1000);
    const t = Date.now();
    e.einsatzleiter = an;
    e.elWechsel = Array.isArray(e.elWechsel) ? e.elWechsel : [];
    e.elWechsel.push({ t, von, an, punkte, bemerkung, user });
    putEinsatz(e);
    tbAdd(e.id, { richtung: 'Vermerk', von: 'Einsatzleitung', text: `ÜBERGABE DER EINSATZLEITUNG${von ? ` von ${von}` : ''} an ${an}.${punkte.length ? ` Übergeben: ${punkte.join(', ')}.` : ''}${bemerkung ? ` Bemerkung: ${bemerkung}` : ''}`, user });
    return {};
  }

  /* ---------- Einsatz beenden → Archiv ---------- */
  function einsatzEnde(args, user) {
    const e0 = einsaetze()[args.id]; if (!e0) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
    const now = Date.now();
    // noch aktive Fahrzeuge freimelden (Status 2)
    Object.entries(e0.fahrzeuge).filter(([, f]) => f.aktiv).forEach(([vid]) => {
      // ab 5.69: Fahrzeuge mit Status von außen, die noch auf „A“ stehen, gehen auf den zuletzt gelesenen Status zurück
      const ex = (store[K.extStatus] || {})[vid];
      const st = stOf(vid) === 'A' && ex && FMS[ex.st] && !AKTIV.includes(ex.st) ? ex.st : '2';
      try { fzStatus({ vid, st, entlassen: true }, user, st === '2' ? 'Einsatzende' : 'Einsatzende – gelesener Status'); } catch (err) { /* Fahrzeug gelöscht */ }
    });
    // ab 5.201: nicht bestätigte Nachrichten dieses Einsatzes an die Fahrzeuge gelten als erledigt (keine Anzeige mehr in der Fahrzeug-App)
    { const alleN = { ...nachrichtenAlle() }; let nN = 0;
      Object.keys(alleN).forEach((vid) => { if (!Array.isArray(alleN[vid])) return; alleN[vid] = alleN[vid].map((x) => { if (x.richtung === 'aus' && x.eid === e0.id && !x.quittiert && !x.erledigt) { nN += 1; return { ...x, erledigt: now }; } return x; }); });
      if (nN) setKey(K.nachrichten, alleN); }
    // Aufträge: alles, was noch nicht im Einsatztagebuch steht, übernehmen
    let auftraege = null;
    if (store[aufKey(e0.id)]) {
      const doc = aufDoc(e0.id);
      doc.liste.forEach((a) => aufUeberfuehren(e0.id, a, user, AUF_ZU.includes(a.status) ? null : `bei Einsatzende noch ${AUF_LABEL[a.status]}`));
      auftraege = doc;
    }
    tbAdd(e0.id, { richtung: 'Vermerk', von: user, text: `Einsatz ${e0.nummer} beendet.${auftraege ? ` ${auftraege.liste.length} Aufträge, davon ${auftraege.liste.filter((a) => a.status === 'erledigt').length} erledigt.` : ''}`, user, auto: 'system' });
    const e = einsaetze()[args.id];
    const fzInfo = {};
    Object.keys(e.fahrzeuge).forEach((vid) => {
      const v = vehicles().find((x) => x.id === vid) || {};
      fzInfo[vid] = { funkrufname: v.funkrufname || vid, fahrzeugtyp: v.fahrzeugtyp || v.funktion || '', ortswehr: v.ortswehr || '', stadt: v.stadt || '', staerke: (!e.fahrzeuge[vid].aktiv && e.fahrzeuge[vid].staerke) || (store[K.personnel] || {})[vid] || null };
    });
    const asue = Object.values(store[K.asueStatus] || {}).filter((a) => a.evId === e.id);
    const karte = store[karteKey(e.id)] || null;
    const taktik = store[`opta3.taktik.${e.id}`] || null;
    const pos = {};
    Object.keys(e.fahrzeuge).forEach((vid) => { const p = (store[K.pos] || {})[vid]; if (p) pos[vid] = p; });
    // vollständige Daten der zugeordneten Atemschutzüberwachungen (Trupps, Namen, Zeiten, Drücke) für den Einsatzbericht
    const asueDetail = Object.entries(store['asue.einsaetze'] || {}).filter(([, x]) => x && x.einsatz && x.einsatz.data && x.einsatz.data.evId === e.id)
      .map(([code, x]) => ({ code, einsatz: x.einsatz.data, trupps: Object.values(x.trupps || {}).filter((t) => t && t.data && !t.vorschlag && !t.data._gone).map((t) => t.data) }));
    const lagestaende = Array.isArray(store[lagestandKey(e.id)]) ? store[lagestandKey(e.id)] : [];
    const tbEnde = store[tbKey(e.id)] || []; const tbP = tbPruefen(e.id, tbEnde);
    const rec = { version: 3, tbSiegel: { t: now, n: tbP.n, kopf: tbP.kopf, ok: tbP.ok }, einsatz: { ...e, ende: now, beendet: { t: now, user } }, tagebuch: tbEnde, fahrzeuge: fzInfo, asue, karte, taktik, positionen: pos, spuren: store[spurKey(e.id)] || {}, auftraege, asueDetail, lagestaende };
    if (e.objektId) { const o = objekte().find((x) => x.id === e.objektId); if (o) rec.objekt = { id: o.id, name: o.name, art: o.art, adresse: o.adresse }; }
    delete store[spurKey(e.id)];
    store[archKey(e.id)] = rec;
    const index = Array.isArray(store[K.archIndex]) ? store[K.archIndex] : [];
    index.push(archivZeile(rec));
    store[K.archIndex] = index;
    // aufräumen
    const all = { ...einsaetze() }; delete all[e.id]; setKey(K.einsaetze, all);
    delKey(tbKey(e.id)); delKey(karteKey(e.id)); delKey(karteBgKey(e.id)); delKey(aufKey(e.id)); delKey(`opta3.taktik.${e.id}`); delKey(`opta3.taktikBg.${e.id}`); delKey(lagestandKey(e.id));
    const st = { ...(store[K.asueStatus] || {}) };
    Object.keys(st).forEach((k) => { if (st[k].evId === e.id) delete st[k]; });
    setKey(K.asueStatus, st);
    systemLog(user, `Einsatz ${e.nummer} beendet und archiviert.`);
    return { id: e.id };
  }
  function archivZeile(rec) {
    const e = rec.einsatz;
    const fz = Object.values(rec.fahrzeuge || {});
    const s = fz.reduce((a, f) => { const x = f.staerke || {}; a.f += x.f || 0; a.uf += x.uf || 0; a.m += x.m || 0; a.agt += x.agt || 0; return a; }, { f: 0, uf: 0, m: 0, agt: 0 });
    const au = rec.auftraege && Array.isArray(rec.auftraege.liste) ? rec.auftraege.liste : null;
    const nb = rec.nachbesprechung || null;
    return { id: e.id, nummer: e.nummer, stichwort: e.stichwort, meldebild: e.meldebild, adresse: e.adresse, alarmzeit: e.alarmzeit, ende: e.ende, fahrzeuge: fz.length, staerke: s, einsatzleiter: rec.geschwaerzt ? '' : e.einsatzleiter, wehren: [...new Set(fz.map((f) => f.ortswehr).filter(Boolean))], nb: !!nb, ergebnis: (nb && nb.ergebnis) || '', objekt: rec.objekt ? rec.objekt.name : '', bma: /\bBMA\b|brandmelde/i.test([e.stichwort, e.meldebild].join(' ')), ...(rec.geschwaerzt ? { geschwaerzt: true } : {}), ...(au ? { auftraege: au.length, erledigt: au.filter((a) => a.status === 'erledigt').length } : {}), ...(e.uebung ? { uebung: true } : {}), ...(e.demo ? { demo: true } : {}) };
  }
  function archivEinfuegen(rec) {   // fertigen Datensatz ins Archiv (Demo-Einsätze)
    store[archKey(rec.einsatz.id)] = rec;
    const index = Array.isArray(store[K.archIndex]) ? store[K.archIndex] : [];
    index.push(archivZeile(rec));
    store[K.archIndex] = index;
    save();
    return rec.einsatz.id;
  }
  function archivLoeschen(args, user) {
    const id = String(args.id || '');
    if (!store[archKey(id)]) throw fehler('archiv_fehlt');
    const nr = store[archKey(id)].einsatz.nummer;
    delete store[archKey(id)];
    store[K.archIndex] = (store[K.archIndex] || []).filter((x) => x.id !== id);
    systemLog(user, `Archivierter Einsatz ${nr} gelöscht.`);
    return {};
  }

  /* ---------- Systemprotokoll ---------- */
  function logNeu(args, user) {
    const text = str(args.text, 1000); if (!text) throw fehler('text_fehlt');
    systemLog(user, text); return {};
  }

  /* ---------- Operationen (vom WebSocket oder Meldeserver) ---------- */
  /* ---------- Standort aus der Fahrzeug-App ---------- */
  function fzPos(args, user, quelle) {
    const vid = String(args.vid || '');
    if (!vehicles().some((v) => v.id === vid)) throw fehler('fahrzeug_fehlt', 'Fahrzeug nicht gefunden');
    const lat = Number(args.lat), lon = Number(args.lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180 || (lat === 0 && lon === 0)) throw fehler('position_ungueltig', 'Ungültige Position');
    const now = Date.now();
    let t = Number(args.t) || now;
    if (Math.abs(t - now) > 10 * 60 * 1000) t = now; // falsch gehende Uhr am Handy
    const p = { lat: +lat.toFixed(6), lon: +lon.toFixed(6), t, empfangen: now };
    const acc = args.acc == null ? NaN : Number(args.acc); if (Number.isFinite(acc) && acc >= 0) p.acc = Math.round(Math.min(acc, 99999));
    const sp = args.speed == null ? NaN : Number(args.speed); if (Number.isFinite(sp) && sp >= 0) p.speed = +Math.min(sp, 120).toFixed(1);   // m/s
    const hd = args.heading == null ? NaN : Number(args.heading); if (Number.isFinite(hd) && hd >= 0) p.heading = Math.round(hd) % 360;
    if (quelle) p.quelle = quelle;
    setKey(K.pos, { ...(store[K.pos] || {}), [vid]: p });
    const eid = fzEinsatz(vid);
    if (eid) {
      const sp2 = store[spurKey(eid)] && typeof store[spurKey(eid)] === 'object' ? store[spurKey(eid)] : {};
      const arr = Array.isArray(sp2[vid]) ? sp2[vid] : [];
      arr.push([t, p.lat, p.lon]);
      sp2[vid] = arr.slice(-SPUR_MAX);
      store[spurKey(eid)] = sp2;
    }
    return { t };
  }
  /* ---------- Lagekarte: altes Kartenformat umrechnen ---------- */
  function pointToCoord(x, y, center, scale) { // altes Kartenformat: x 0..100, y 0..75 (Kartenbreite = scale Meter)
    const mpu = scale / 100;
    return { lat: center.lat + ((37.5 - y) * mpu) / 111320, lon: center.lon + ((x - 50) * mpu) / (111320 * Math.cos((center.lat * Math.PI) / 180)) };
  }
  /* Lagekarte im alten Bild-Format (Prozent-Koordinaten) → Geokoordinaten (Version 2) */
  const HEIMAT = { lat: 52.0497, lon: 9.2660 }; // Aerzen
  function karteV2(k, e) {
    if (!k || typeof k !== 'object') return { k: { v: 2, markers: [], vehPos: {}, shapes: [], mScale: 1, vScale: 1, bild: null }, bgVerwerfen: false };
    if (k.v === 2) return { k, bgVerwerfen: false };
    const geo = !!(k.center && k.scale);
    const c = geo ? k.center : (e && e.lat != null ? { lat: e.lat, lon: e.lon } : HEIMAT);
    const s = geo ? k.scale : 400;
    const r6 = (v) => +Number(v).toFixed(6);
    const pc = (x, yu) => { const p = pointToCoord(Number(x) || 0, Number(yu) || 0, c, s); return { lat: r6(p.lat), lon: r6(p.lon) }; };
    const markers = (Array.isArray(k.markers) ? k.markers : []).map((m) => {
      const p = m.coord && geo ? { lat: r6(m.coord.lat), lon: r6(m.coord.lon) } : pc(m.x, (Number(m.y) || 0) * 0.75);
      return { id: m.id, type: m.type, ...p, ...(m.label ? { text: m.label } : {}) };
    });
    const vehPos = {};
    Object.entries(k.vehPos || {}).forEach(([vid, p]) => { if (p) vehPos[vid] = pc(p.x, (Number(p.y) || 0) * 0.75); });
    const shapes = (Array.isArray(k.shapes) ? k.shapes : []).map((sh) => {
      if (sh.type === 'circle') { const p = pc(sh.cx, sh.cy); return { id: sh.id, type: 'circle', ...p, r: Math.max(1, Math.round((Number(sh.r) || 0) * s / 100)) }; }
      if (Array.isArray(sh.points)) return { id: sh.id, type: sh.type, pts: sh.points.map((q) => { const p = pc(q.x, q.y); return [p.lat, p.lon]; }) };
      return null;
    }).filter(Boolean);
    const out = { v: 2, markers, vehPos, shapes, mScale: k.mScale || 1, vScale: k.vScale || 1, bild: null, view: { lat: c.lat, lon: c.lon, z: k.osm && k.osm.zoom ? k.osm.zoom : 16 } };
    if (!k.osm) out.bild = { lat: c.lat, lon: c.lon, breite: s, deckkraft: 1, karteAus: !geo };
    return { k: out, bgVerwerfen: !!k.osm };
  }

  const OPS = {
    'einsatz.neu': (a, u) => einsatzNeu(a, u),
    'einsatz.aendern': (a, u) => einsatzAendern(a, u),
    'einsatz.ende': (a, u) => einsatzEnde(a, u),
    'fz.status': (a, u, q) => fzStatus(a, u, q),
    'fz.ruf': (a, u, q) => fzRuf(a, u, q),
    'fz.umsetzen': (a, u) => fzUmsetzen(a, u),
    'fz.bereit': (a, u, q) => fzBereit(a, u, q),
    'fz.zuordnen': (a, u) => fzZuordnen(a, u),
    'fz.abschnitt': (a, u) => fzAbschnitt(a, u),
    'staerke': (a, u, q) => staerke(a, u, q),
    'staerke.mehrere': (a, u) => staerkeMehrere(a, u),
    'objekt.uebernehmen': (a, u, q) => objektUebernehmen(a, u, q),
    'objekt.zugriffZuruecksetzen': (a, u) => objektZugriffZuruecksetzen(a, u),
    'abschnitt': (a, u) => abschnitt(a, u),
    'vu': (a, u) => vu(a, u),
    'uhr': (a, u) => uhr(a, u),
    'karte.aendern': (a, u) => karteAendern(a, u),
    'kontakt.speichern': (a, u) => kontaktSpeichern(a, u),
    'kontakt.loeschen': (a, u) => kontaktLoeschen(a, u),
    'kontakt.import': (a, u) => kontaktImport(a, u),
    'einsatz.kontakt': (a, u) => einsatzKontakt(a, u),
    'nachbereitung': (a, u) => nachbereitung(a, u),
    // ab 5.133: Verpflegung der Einsatzkräfte (ohne Kosten)
    'verpflegung': (a, u) => {
      const e = einsaetze()[String(a.einsatzId || '')]; if (!e) throw fehler('einsatz_fehlt', 'Einsatz nicht gefunden');
      const vp = { bestellungen: [], ...(e.verpflegung || {}) }; vp.bestellungen = (vp.bestellungen || []).slice();
      const ST = { bestellt: 'bestellt', geliefert: 'geliefert', ausgegeben: 'ausgegeben', storniert: 'storniert' };
      let tb = '';
      if (a.aktion === 'neu') {
        const was = str(a.was, 80); if (!was) throw fehler('was_fehlt', 'Bitte eintragen, was bestellt wird');
        const anz = Math.max(1, Math.min(9999, Math.round(Number(a.anzahl) || 0))); if (!anz) throw fehler('anzahl_fehlt', 'Bitte die Anzahl eintragen');
        const x = { id: rid('vp'), t: Date.now(), was, anzahl: anz, lieferant: str(a.lieferant, 80), ort: str(a.ort, 120), bis: str(a.bis, 5), bem: str(a.bem, 200), status: 'bestellt', user: u };
        vp.bestellungen.push(x); tb = `Verpflegung bestellt: ${anz}× ${was}${x.lieferant ? ` bei ${x.lieferant}` : ''}${x.ort ? `, Lieferung an ${x.ort}` : ''}${x.bis ? ` bis ${x.bis} Uhr` : ''}.`;
      } else if (a.aktion === 'status') {
        const x = vp.bestellungen.find((y) => y.id === a.id); if (!x) throw fehler('eintrag_fehlt');
        if (!ST[a.status]) throw fehler('status_ungueltig');
        const i = vp.bestellungen.indexOf(x); vp.bestellungen[i] = { ...x, status: a.status, [`t_${a.status}`]: Date.now() };
        tb = `Verpflegung ${x.anzahl}× ${x.was}: ${ST[a.status]}.`;
      } else if (a.aktion === 'extra') {
        vp.extra = Math.max(0, Math.min(9999, Math.round(Number(a.extra) || 0)));
      } else if (a.aktion === 'hinweis') {
        vp.hinweisStd = Math.max(0, Math.min(24, Number(a.std) || 0));
      } else throw fehler('aktion_ungueltig');
      putEinsatz({ ...einsaetze()[e.id], verpflegung: vp });
      if (tb) tbAdd(e.id, { richtung: 'Vermerk', von: u, text: tb, user: u, auto: 'system' });
      return { ok: true };
    },
    'nachricht': (a, u) => nachricht(a, u),
    'nachricht.quittung': (a, u) => nachrichtQuittung(a, u),
    'nachricht.fz': (a, u) => nachrichtFz(a, u),
    'nachricht.fzfz': (a, u) => nachrichtFzFz(a, u),
    'nachricht.gelesen': (a, u) => nachrichtGelesen(a, u),
    'nachricht.bericht': (a, u) => nachrichtBericht(a, u),
    'lagestand': (a, u) => lagestand(a, u),
    'foto': (a, u) => foto(a, u),
    'funk': (a, u) => funk(a, u),
    'check': (a, u) => check(a, u),
    'ablauf': (a, u) => ablauf(a, u),
    'anforderung': (a, u) => anforderung(a, u),
    'lage': (a, u) => lage(a, u),
    'gefahrstoff': (a, u) => gefahrstoff(a, u),
    'besprechung': (a, u) => besprechung(a, u),
    'einsatz.uebergabe': (a, u) => uebergabe(a, u),
    'tb.neu': (a, u) => {
      if (!einsaetze()[a.einsatzId]) throw fehler('einsatz_fehlt');
      if (!str(a.text)) throw fehler('text_fehlt', 'Bitte einen Text eintragen');
      let nachtragZeit;
      if (a.zeit != null && a.zeit !== '') {
        const z = Number(a.zeit), jetzt = Date.now(), ez = einsaetze()[a.einsatzId];
        if (!Number.isFinite(z) || z > jetzt) throw fehler('zeit_ungueltig', 'Der Zeitpunkt des Nachtrags darf nicht in der Zukunft liegen');
        if (z < (ez.alarmzeit || jetzt) - 12 * 60 * 60 * 1000) throw fehler('zeit_ungueltig', 'Der Zeitpunkt liegt mehr als 12 Stunden vor der Alarmierung');
        if (jetzt - z > 60 * 1000) nachtragZeit = z;
      }
      return tbAdd(a.einsatzId, { einsatzId: a.einsatzId, richtung: a.richtung, von: a.von, an: a.an, text: a.text, korrigiert: a.korrigiert, nachtragZeit, user: u });
    },
    'archiv.loeschen': (a, u) => archivLoeschen(a, u),
    // ab 3.62: veraltete Truppstatus-Meldung einer ASÜ von Hand entfernen (z. B. Test oder vergessenes Gerät)
    'asue.entfernen': (a, u) => {
      const st = { ...(store[K.asueStatus] || {}) }, key = String(a.key || '');
      const x = st[key]; if (!x) return { ok: true };
      delete st[key]; setKey(K.asueStatus, st);
      const fw = (x.feuerwehr && x.feuerwehr.name) || 'ASÜ';
      const text = `Meldung der Atemschutzüberwachung „${fw}“ entfernt (letzte Meldung ${new Date(x.empfangen).toLocaleString('de-DE', { timeZone: 'Europe/Berlin' })}, ${(x.status && x.status.imEinsatz && x.status.imEinsatz.trupps) || 0} Trupp(s) im Einsatz).`;
      if (x.evId && einsaetze()[x.evId]) tbAdd(x.evId, { richtung: 'Vermerk', von: u, text, user: u, auto: 'system' }); else systemLog(u, text);
      return { ok: true };
    },
    'log.neu': (a, u) => logNeu(a, u),
    'fz.pos': (a, u, q) => fzPos(a, u, q),
    'fz.entlassen': (a, u) => fzEntlassen(a, u),
    'fz.entfernen': (a, u) => fzEntfernen(a, u),
    'fz.nachmelden': (a, u, q) => fzNachmelden(a, u, q),
    'br.speichern': (a, u) => brSpeichern(a, u),
    'br.aufloesen': (a, u) => brAufloesen(a, u),
    'br.fz': (a, u, q) => brFz(a, u, q),
    'auftrag.neu': (a, u) => auftragNeu(a, u),
    'auftrag.aendern': (a, u) => auftragAendern(a, u),
    'auftrag.status': (a, u) => auftragStatus(a, u),
    'auftrag.fz': (a, u) => auftragFz(a, u),
    'auftrag.erkunden': (a, u) => auftragErkunden(a, u),
    'auftrag.erkundet': (a, u) => auftragErkundet(a, u),
    'auftrag.tb': (a, u) => auftragTbNeu(a, u),
    'objekt.speichern': (a, u) => objektSpeichern(a, u),
    'objekt.loeschen': (a, u) => objektLoeschen(a, u),
    'objekt.dateiLoeschen': (a, u) => objektDateiLoeschen(a, u),
  };
  let protokollHook = null;   // Änderungsprotokoll (server.js)
  function handleOp(op, args, user, quelle) {
    const fn = OPS[op];
    if (!fn) throw fehler('unbekannt', 'Unbekannte Aktion');
    const vorher = protokollHook ? protokollVorher(op, args || {}) : null;
    const r = fn(args || {}, str(user, 60) || 'System', quelle);
    save();
    if (protokollHook) { try { protokollHook(op, args || {}, str(user, 60) || 'System', quelle, r, vorher); } catch (e) { /* Protokoll darf nie stören */ } }
    return r;
  }
  function protokollVorher(op, a) {
    try {
      if (op === 'fz.status' || op === 'fz.entlassen') return { st: stOf(String(a.vid || '')) };
      if (op === 'einsatz.aendern') { const e = einsaetze()[a.id]; return e ? { nummer: e.nummer } : null; }
      if (op === 'einsatz.ende') { const e = einsaetze()[a.id]; return e ? { nummer: e.nummer } : null; }
    } catch (e) { /* egal */ }
    return null;
  }

  /* ---------- Übernahme alter Daten (Fahrzeugverwaltung ≤ 2.0) ---------- */
  function migrate() {
    let changed = false;
    // Status: frei/alarmiert/einsatz → FMS
    const st = store[K.status];
    if (st && Object.values(st).some((v) => ['frei', 'alarmiert', 'einsatz'].includes(v))) {
      const neu = {};
      Object.entries(st).forEach(([vid, v]) => { if (v === 'alarmiert') neu[vid] = 'A'; else if (v === 'einsatz') neu[vid] = '3'; else if (FMS[v] && v !== '2') neu[vid] = v; });
      store[K.status] = neu; changed = true;
    }
    // Stärke: {mannschaft, paTraeger} → {f, uf, m, agt}
    const p = store[K.personnel];
    if (p && Object.values(p).some((x) => x && x.mannschaft !== undefined)) {
      const neu = {};
      Object.entries(p).forEach(([vid, x]) => { neu[vid] = x && x.mannschaft !== undefined ? { f: 0, uf: 0, m: int(x.mannschaft, 200), agt: int(x.paTraeger, 200) } : x; });
      store[K.personnel] = neu; changed = true;
    }
    // ab 3.52: Unterführer zählt zur Mannschaft
    const p2 = store[K.personnel];
    if (p2 && Object.values(p2).some((x) => x && Number(x.uf) > 0)) {
      const neu = {};
      Object.entries(p2).forEach(([vid, x]) => { neu[vid] = x && Number(x.uf) > 0 ? { ...x, m: (Number(x.m) || 0) + Number(x.uf), uf: 0 } : x; });
      store[K.personnel] = neu; changed = true;
    }
    // laufender Einsatz aus der alten Einsatzansicht → eigener Einsatz
    const aktiv = Object.entries(store[K.status] || {}).filter(([, v]) => AKTIV.includes(v)).map(([vid]) => vid);
    const altKeys = ['opta3.sections', 'opta3.assignments', 'opta3.mapMarkers', 'opta3.mapVehiclePos', 'opta3.mapShapes', 'opta3.mapScale', 'opta3.mapCenterCoord', 'opta3.mapMarkerScale', 'opta3.mapVehicleScale', 'opta3.mapBg', 'opta3.einsatzort', 'opta3.einsatzStart'];
    const hatAlt = altKeys.some((k) => k in store);
    if (hatAlt) {
      if (aktiv.length && !Object.keys(einsaetze()).length) {
        const ort = store['opta3.einsatzort'];
        const e = einsatzNeu({ stichwort: '', meldebild: 'Übernommen aus der bisherigen Fahrzeugverwaltung', alarmzeit: store['opta3.einsatzStart'] || Date.now(), lat: ort && ort.lat, lon: ort && ort.lon }, 'System');
        const secs = Array.isArray(store['opta3.sections']) ? store['opta3.sections'].filter((s) => !s.fixed) : [];
        e.abschnitte.push(...secs.map((s) => ({ id: s.id, name: s.name, leiter: '', kanal: '' })));
        const asg = store['opta3.assignments'] || {};
        aktiv.forEach((vid) => { e.fahrzeuge[vid] = { seit: e.alarmzeit, abschnitt: e.abschnitte.some((a) => a.id === asg[vid]) ? asg[vid] : 'ea', zeiten: [{ st: store[K.status][vid], t: e.alarmzeit }], aktiv: true }; });
        store[K.einsaetze] = { [e.id]: e };
        store[karteKey(e.id)] = {
          markers: store['opta3.mapMarkers'] || [], vehPos: store['opta3.mapVehiclePos'] || {}, shapes: store['opta3.mapShapes'] || [],
          scale: store['opta3.mapScale'] || null, center: store['opta3.mapCenterCoord'] || null,
          mScale: store['opta3.mapMarkerScale'] || 1, vScale: store['opta3.mapVehicleScale'] || 1,
        };
        if (store['opta3.mapBg']) store[karteBgKey(e.id)] = store['opta3.mapBg'];
        console.log(`Laufenden Einsatz übernommen als ${e.nummer} (${aktiv.length} Fahrzeuge).`);
      }
      altKeys.forEach((k) => delete store[k]);
      changed = true;
    }
    // Lagekarten im alten Bildformat auf Geokoordinaten umstellen (Version 3.2)
    Object.keys(store).filter((k) => k.startsWith(K.karte) && !k.startsWith('opta3.karteBg.')).forEach((k) => {
      const v = store[k];
      if (!v || v.v === 2) return;
      const eid = k.slice(K.karte.length);
      const r = karteV2(v, einsaetze()[eid]);
      if (!store[karteBgKey(eid)]) r.k.bild = null;
      if (r.bgVerwerfen) delete store[karteBgKey(eid)];
      store[k] = r.k; changed = true;
      console.log(`Lagekarte von Einsatz ${(einsaetze()[eid] || {}).nummer || eid} auf Geokoordinaten umgestellt.`);
    });
    if (changed) save();
  }

  /* ---------- Abfragen für REST ---------- */
  function aktiveListe() {
    return Object.values(einsaetze()).sort((a, b) => a.alarmzeit - b.alarmzeit)
      .map((e) => ({ id: e.id, nummer: e.nummer, stichwort: e.stichwort, meldebild: e.meldebild, adresse: e.adresse, alarmzeit: e.alarmzeit, einsatzleiter: e.einsatzleiter }));
  }
  function archivListe() { return (store[K.archIndex] || []).slice().sort((a, b) => b.alarmzeit - a.alarmzeit); }
  function archivHole(id) { return store[archKey(String(id))] || null; }
  function archivAendern(id, fn) {   // ab 5.27: Nachbesprechung, Datenschutz
    const k = archKey(String(id)); const rec = store[k]; if (!rec) throw fehler('archiv_fehlt', 'Einsatz nicht im Archiv');
    const neu = fn(rec); store[k] = neu;
    store[K.archIndex] = (store[K.archIndex] || []).map((z) => (z.id === String(id) ? archivZeile(neu) : z));
    save(); return neu;
  }

  function setProtokoll(fn) { protokollHook = fn; }
  function einsatzMarkieren(eid, felder) { const e = einsaetze()[eid]; if (e) putEinsatz({ ...e, ...felder }); }
  return { rufgruppeFuer, archivAendern, ortswehrenGemeinde, istSim, istUebFz, kollegenVon, brListe, einsatzMarkieren, auftragFuer, objektStatusFuer, objektDatenFuer, objektDateiFuer, einsatzObjekt, einsatzOrtVon, ortAusText, handleOp, archivEinfuegen, setProtokoll, wetterVermerk, warnungVermerk, nachrichtenFuer, gesendetVon, nachbereitungOffen, migrate, aktiveListe, archivListe, archivHole, tbAdd, tbPruefen, fzEinsatz, einsaetze, objekte, objektDateiNeu, OBJ_ARTEN, FMS, AKTIV, RUF };
};
module.exports.FMS = FMS;
module.exports.tbPruefen = tbPruefen;
module.exports.AKTIV = AKTIV;
module.exports.RUF = RUF;
