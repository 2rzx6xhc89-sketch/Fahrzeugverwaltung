#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Einsatzverwaltung mit Atemschutzüberwachung und Fahrzeug-App
# Installation und Update auf einem Raspberry Pi (Raspberry Pi OS / Debian)
#
# Aufruf im entpackten Ordner (als normaler Benutzer, NICHT als root):
#     bash install.sh
#
# Das Skript
#   - installiert Node.js (LTS), falls es fehlt oder älter als Version 18 ist
#   - kopiert die Programmdateien nach ~/einsatzverwaltung
#     (vorhandene data.json, backups/, tiles/ und asue/benutzer.js bleiben erhalten)
#   - übernimmt die Daten einer alten Installation aus ~/fahrzeugverwaltung
#   - installiert die Pakete (express, ws)
#   - richtet den Dienst „einsatzverwaltung“ ein, der beim Hochfahren startet
# Es kann für Updates beliebig oft erneut ausgeführt werden.
# ---------------------------------------------------------------------------
set -euo pipefail

ZIEL="${ZIEL:-$HOME/einsatzverwaltung}"
PORT="${PORT:-8080}"
QUELLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BENUTZER="$(id -un)"
DIENST="${DIENST:-/etc/systemd/system/einsatzverwaltung.service}"

rot()   { printf '\033[1;31m%s\033[0m\n' "$*"; }
gruen() { printf '\033[1;32m%s\033[0m\n' "$*"; }
info()  { printf '\n\033[1m== %s\033[0m\n' "$*"; }

if [ "$(id -u)" -eq 0 ]; then
  rot "Bitte nicht als root bzw. mit sudo starten, sondern als normaler Benutzer:  bash install.sh"
  exit 1
fi
for f in server.js einsatz.js mail.js demo.js demo-modus.js package.json public/index.html asue/index.html melde/index.html; do
  if [ ! -f "$QUELLE/$f" ]; then rot "Datei fehlt: $f – bitte das ZIP vollständig entpacken und install.sh im Ordner einsatzverwaltung starten."; exit 1; fi
done

info "1/6 Node.js prüfen"
NODE_OK=0
if command -v node >/dev/null 2>&1; then
  V="$(node -v | sed 's/^v//; s/\..*//')"
  if [ "${V:-0}" -ge 18 ]; then NODE_OK=1; fi
fi
if [ "$NODE_OK" -eq 0 ]; then
  echo "Node.js fehlt oder ist zu alt – installiere die aktuelle LTS-Version (dauert einige Minuten) …"
  sudo apt-get update
  sudo apt-get install -y ca-certificates curl
  curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi
echo "Node.js $(node -v), npm $(npm -v)"
# Chromium für den Einsatzbericht als PDF per E-Mail (ab 3.41) – optional, Fehler sind nicht schlimm
if ! command -v chromium >/dev/null 2>&1 && ! command -v chromium-browser >/dev/null 2>&1; then
  echo "Chromium (für den Einsatzbericht als PDF per E-Mail) wird installiert …"
  sudo apt-get install -y chromium >/dev/null 2>&1 || sudo apt-get install -y chromium-browser >/dev/null 2>&1 || echo "Hinweis: Chromium nicht installiert – Berichte gehen dann als HTML-Datei per E-Mail."
fi

info "2/6 Alte Installation (Fahrzeugverwaltung) übernehmen, falls vorhanden"
ALT="$HOME/fahrzeugverwaltung"
if systemctl list-unit-files 2>/dev/null | grep -q '^fahrzeugverwaltung\.service'; then
  echo "Alter Dienst „fahrzeugverwaltung“ gefunden – wird angehalten und abgeschaltet."
  sudo systemctl stop fahrzeugverwaltung || true
  sudo systemctl disable fahrzeugverwaltung || true
  sudo rm -f /etc/systemd/system/fahrzeugverwaltung.service
  sudo systemctl daemon-reload
fi
mkdir -p "$ZIEL"
if [ -d "$ALT" ] && [ ! -f "$ZIEL/data.json" ] && [ -f "$ALT/data.json" ]; then
  echo "Übernehme data.json und backups/ aus $ALT"
  cp -a "$ALT/data.json" "$ZIEL/data.json"
  [ -d "$ALT/backups" ] && cp -a "$ALT/backups" "$ZIEL/" || true
fi
[ -d "$ALT" ] || echo "Keine alte Installation gefunden."

info "3/6 Programmdateien nach $ZIEL kopieren"
if [ -f "$ZIEL/data.json" ]; then
  cp -a "$ZIEL/data.json" "$ZIEL/data.json.vor-update-$(date +%Y%m%d-%H%M%S)"
  echo "Sicherung der Daten: $(ls -t "$ZIEL"/data.json.vor-update-* | head -1)"
fi
BEN_SICHER=""
if [ -f "$ZIEL/asue/benutzer.js" ] && [ "$QUELLE" != "$ZIEL" ]; then
  BEN_SICHER="$(mktemp)"; cp -a "$ZIEL/asue/benutzer.js" "$BEN_SICHER"
fi
if [ "$QUELLE" != "$ZIEL" ]; then
  for f in server.js einsatz.js mail.js demo.js demo-modus.js package.json install.sh ANLEITUNG.md sicherung-entschluesseln.js; do [ -f "$QUELLE/$f" ] && cp -a "$QUELLE/$f" "$ZIEL/"; done
  for d in public asue melde docs; do
    rm -rf "$ZIEL/$d.neu"; cp -a "$QUELLE/$d" "$ZIEL/$d.neu"
    rm -rf "$ZIEL/$d"; mv "$ZIEL/$d.neu" "$ZIEL/$d"
  done
fi
if [ -n "$BEN_SICHER" ]; then
  cp -a "$BEN_SICHER" "$ZIEL/asue/benutzer.js"; rm -f "$BEN_SICHER"
  echo "Eure Zugänge (asue/benutzer.js) wurden beibehalten."
fi

info "4/6 Pakete installieren (express, ws)"
cd "$ZIEL"
npm install --omit=dev --no-audit --no-fund

info "5/6 Dienst „einsatzverwaltung“ einrichten"
if [ -f "$DIENST" ]; then
  echo "Dienstdatei vorhanden – eigene Einstellungen (Environment=…) bleiben erhalten."
else
  sudo tee "$DIENST" >/dev/null <<EOF
[Unit]
Description=Einsatzverwaltung, Atemschutzueberwachung und Fahrzeug-App
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$BENUTZER
WorkingDirectory=$ZIEL
ExecStart=$(command -v node) server.js
Restart=always
RestartSec=5
Environment=PORT=$PORT
# Optional (Raute entfernen, dann: sudo systemctl daemon-reload && sudo systemctl restart einsatzverwaltung)
# Environment=ASUE_KEY=langer-geheimer-schluessel
# Environment=ASUE_ORIGIN=https://NAME.github.io
# Environment=W3W_KEY=what3words-api-schluessel
# Environment=WARN_ARS=032520000000   (Regionalschlüssel für Unwetterwarnungen, Vorgabe Landkreis Hameln-Pyrmont; aus = abschalten)
# Environment=BACKUP_ZIEL=/mnt/fwbackup   (USB-Stick/Netzlaufwerk für die automatische Sicherung, siehe ANLEITUNG Schritt 15)
# Environment=ASUE_AUFBEWAHRUNG_TAGE=90
# Environment=BACKUP_RETENTION_DAYS=30
# Environment=OBJEKT_MAX_MB=40
# Environment=TLS_CERT=/pfad/fullchain.pem
# Environment=TLS_KEY=/pfad/privkey.pem
# Environment=MELDE_TLS_CERT=/pfad/fullchain.pem
# Environment=MELDE_TLS_KEY=/pfad/privkey.pem

[Install]
WantedBy=multi-user.target
EOF
fi
# ab 3.75: Verbindungsprüfung darf Tailscale/Funnel neu einrichten und den Pi neu starten (nur diese Befehle)
if [ ! -f /etc/sudoers.d/einsatzverwaltung ]; then
  echo "$BENUTZER ALL=(root) NOPASSWD: /usr/bin/systemctl restart tailscaled, /usr/bin/tailscale, /usr/sbin/reboot" | sudo tee /etc/sudoers.d/einsatzverwaltung >/dev/null
  sudo chmod 440 /etc/sudoers.d/einsatzverwaltung
  sudo visudo -cf /etc/sudoers.d/einsatzverwaltung >/dev/null || sudo rm -f /etc/sudoers.d/einsatzverwaltung
fi
sudo systemctl daemon-reload
sudo systemctl enable einsatzverwaltung >/dev/null
sudo systemctl restart einsatzverwaltung

info "6/6 Prüfen"
OK=0
for i in $(seq 1 20); do
  if curl -fsS "http://localhost:$((PORT+2))/api/health" >/dev/null 2>&1 || curl -fsSk "https://localhost:$((PORT+2))/api/health" >/dev/null 2>&1; then OK=1; break; fi
  sleep 1
done
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [ "$OK" -eq 1 ]; then
  gruen "Fertig – der Dienst läuft."
else
  rot "Der Dienst antwortet noch nicht. Protokoll ansehen mit:  journalctl -u einsatzverwaltung -n 50"
fi
cat <<EOF

  Einsatzverwaltung:      http://$IP:$PORT          (Benutzer admin, PIN 1234 – sofort ändern!)
  Atemschutzüberwachung:  http://$IP:$((PORT+2))
  Fahrzeug-App:           Port $((PORT+1)) – für den Standort https einrichten
                          (ANLEITUNG.md, Schritt 8: sudo tailscale funnel --bg $((PORT+1)))

  Nützlich:
    sudo systemctl status einsatzverwaltung     Zustand
    sudo systemctl restart einsatzverwaltung    Neustart
    journalctl -u einsatzverwaltung -f          Live-Protokoll
EOF
