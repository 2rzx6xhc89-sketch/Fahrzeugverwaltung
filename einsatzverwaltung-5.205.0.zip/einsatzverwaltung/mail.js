/*
 * E-Mail für die Einsatzverwaltung (ab 3.41) – ohne zusätzliche Bibliotheken.
 *  - senden(cfg, msg):   SMTP mit SSL/TLS (Port 465), STARTTLS (587) oder unverschlüsselt (nur Tests/LAN), AUTH PLAIN/LOGIN
 *  - abrufen(cfg, fn):   IMAP (993 SSL / 143 STARTTLS), ungelesene Mails im Posteingang holen, nach Verarbeitung als gelesen markieren
 *  - zerlegen(raw):      MIME-Nachricht → {von, an, betreff, datum, messageId, auth, text, html, anhaenge}
 *  - leitstelleLesen():  Felder aus Alarm-/Auftragsmails der Leitstelle („Schlüssel: Wert“)
 * cfg = { smtp:{host, port, sicher}, imap:{host, port, sicher}, user, pass, absender, tlsPruefen }
 */
const net = require('net');
const tls = require('tls');
const os = require('os');
const crypto = require('crypto');

const ZEIT = 30000;

/* ---------- Hilfen ---------- */
function adresseAus(s) {
  const t = String(s || '').trim();
  const m = /<([^<>@\s]+@[^<>\s]+)>/.exec(t) || /([^\s<>"',;]+@[^\s<>"',;]+)/.exec(t);
  const adresse = m ? m[1].toLowerCase() : '';
  let name = m && m[0].startsWith('<') ? t.slice(0, t.indexOf('<')).trim().replace(/^"|"$/g, '') : '';
  name = name.replace(/\\"/g, '"');
  return { name, adresse };
}
function adressenAus(s) {
  const out = []; let cur = '', q = false, w = 0;
  for (const ch of String(s || '')) {
    if (ch === '"') q = !q; if (!q && ch === '<') w++; if (!q && ch === '>') w--;
    if (ch === ',' && !q && w <= 0) { out.push(cur); cur = ''; } else cur += ch;
  }
  if (cur.trim()) out.push(cur);
  return out.map(adresseAus).filter((x) => x.adresse);
}
const istAdresse = (a) => /^[^\s@<>()",;]+@[^\s@<>()",;]+\.[a-z]{2,}$/i.test(String(a || ''));
function wortKodieren(t) { return /^[\x20-\x7e]*$/.test(t) ? t : `=?UTF-8?B?${Buffer.from(t, 'utf8').toString('base64')}?=`; }
function nameAdresse(s) { const x = adresseAus(s); return x.name ? `${wortKodieren(x.name.replace(/"/g, ''))} <${x.adresse}>` : `<${x.adresse}>`; }
function b64Zeilen(buf) { return buf.toString('base64').replace(/.{1,76}/g, '$&\r\n'); }
function datumRfc(d) {
  const t = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const p = (n) => String(n).padStart(2, '0'); const o = -d.getTimezoneOffset();
  return `${t[d.getDay()]}, ${p(d.getDate())} ${m[d.getMonth()]} ${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())} ${o >= 0 ? '+' : '-'}${p(Math.floor(Math.abs(o) / 60))}${p(Math.abs(o) % 60)}`;
}
function dateiParam(n) {
  const name = String(n || 'datei').replace(/[\r\n"\\]/g, '_');
  return /^[\x20-\x7e]*$/.test(name) ? `filename="${name}"` : `filename*=UTF-8''${encodeURIComponent(name)}`;
}

/* ---------- Nachricht bauen ---------- */
function mimeBauen(cfg, msg) {
  const von = adresseAus(cfg.absender || cfg.user);
  const grenze = (p) => `=_${p}_${crypto.randomBytes(9).toString('hex')}`;
  const kopf = [
    `From: ${nameAdresse(cfg.absender || cfg.user)}`,
    `To: ${msg.an.map((a) => nameAdresse(a)).join(', ')}`,
    ...(msg.cc && msg.cc.length ? [`Cc: ${msg.cc.map((a) => nameAdresse(a)).join(', ')}`] : []),
    ...(msg.antwortAn ? [`Reply-To: ${nameAdresse(msg.antwortAn)}`] : []),
    `Subject: ${wortKodieren(String(msg.betreff || '').replace(/[\r\n]+/g, ' ').slice(0, 200))}`,
    `Date: ${datumRfc(new Date())}`,
    `Message-ID: <${Date.now().toString(36)}.${crypto.randomBytes(8).toString('hex')}@${(von.adresse.split('@')[1] || 'einsatzverwaltung.local')}>`,
    'MIME-Version: 1.0',
    'X-Mailer: Einsatzverwaltung',
  ];
  const textTeil = (typ, inhalt) => `Content-Type: ${typ}; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${b64Zeilen(Buffer.from(String(inhalt || ''), 'utf8'))}`;
  let rumpf = msg.html
    ? (() => { const g = grenze('alt'); return `Content-Type: multipart/alternative; boundary="${g}"\r\n\r\n--${g}\r\n${textTeil('text/plain', msg.text)}\r\n--${g}\r\n${textTeil('text/html', msg.html)}\r\n--${g}--\r\n`; })()
    : textTeil('text/plain', msg.text);
  const alle = Array.isArray(msg.anhaenge) ? msg.anhaenge : [];
  // ab 5.192: Bilder mit cid erscheinen im HTML-Teil (<img src="cid:…">) – multipart/related
  const inline = msg.html ? alle.filter((a) => a && a.cid) : [];
  const anh = alle.filter((a) => !inline.includes(a));
  if (inline.length) {
    const g = grenze('rel');
    rumpf = `Content-Type: multipart/related; boundary="${g}"\r\n\r\n--${g}\r\n${rumpf}\r\n` + inline.map((a) =>
      `--${g}\r\nContent-Type: ${a.typ || 'application/octet-stream'}; name="${wortKodieren(String(a.name || 'bild').replace(/[\r\n"\\]/g, '_'))}"\r\nContent-Transfer-Encoding: base64\r\nContent-ID: <${String(a.cid).replace(/[<>\r\n]/g, '')}>\r\nContent-Disposition: inline; ${dateiParam(a.name)}\r\n\r\n${b64Zeilen(a.daten)}`).join('\r\n') + `\r\n--${g}--\r\n`;
  }
  if (anh.length) {
    const g = grenze('mix');
    rumpf = `Content-Type: multipart/mixed; boundary="${g}"\r\n\r\n--${g}\r\n${rumpf}\r\n` + anh.map((a) =>
      `--${g}\r\nContent-Type: ${a.typ || 'application/octet-stream'}; name="${wortKodieren(String(a.name || 'datei').replace(/[\r\n"\\]/g, '_'))}"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; ${dateiParam(a.name)}\r\n\r\n${b64Zeilen(a.daten)}`).join('\r\n') + `\r\n--${g}--\r\n`;
  }
  return `${kopf.join('\r\n')}\r\n${rumpf}`;
}

/* ---------- Verbindung mit zeilenweisem Lesen ---------- */
function verbinden(host, port, ssl, tlsPruefen) {
  return new Promise((ok, fail) => {
    const opt = { host, port, servername: host, rejectUnauthorized: tlsPruefen !== false, timeout: ZEIT };
    const s = ssl ? tls.connect(opt, () => ok(s)) : net.connect(opt, () => ok(s));
    s.setTimeout(ZEIT, () => s.destroy(new Error('Zeitüberschreitung')));
    s.once('error', fail);
  });
}
function tlsUpgrade(sock, host, tlsPruefen) {
  return new Promise((ok, fail) => {
    const s = tls.connect({ socket: sock, servername: host, rejectUnauthorized: tlsPruefen !== false }, () => ok(s));
    s.once('error', fail);
  });
}
class Leser {
  constructor(sock) { this.wechsel(sock); }
  wechsel(sock) {
    this.sock = sock; this.puffer = Buffer.alloc(0); this.warte = null; this.fehler = null;
    sock.on('data', (d) => { this.puffer = Buffer.concat([this.puffer, d]); this.pruefen(); });
    sock.on('error', (e) => { this.fehler = e; this.pruefen(); });
    sock.on('close', () => { if (!this.fehler) this.fehler = new Error('Verbindung beendet'); this.pruefen(); });
  }
  pruefen() { if (this.warte) { const w = this.warte; this.warte = null; w(); } }
  async zeile() {   // eine Zeile ohne CRLF
    for (;;) {
      const i = this.puffer.indexOf('\r\n');
      if (i >= 0) { const z = this.puffer.slice(0, i).toString('utf8'); this.puffer = this.puffer.slice(i + 2); return z; }
      if (this.fehler) throw this.fehler;
      await new Promise((r) => { this.warte = r; });
    }
  }
  async bytes(n) {
    for (;;) {
      if (this.puffer.length >= n) { const b = this.puffer.slice(0, n); this.puffer = this.puffer.slice(n); return b; }
      if (this.fehler) throw this.fehler;
      await new Promise((r) => { this.warte = r; });
    }
  }
  schreiben(t) { this.sock.write(t); }
}

/* ---------- SMTP ---------- */
async function smtpAntwort(l) {
  const zeilen = [];
  for (;;) { const z = await l.zeile(); zeilen.push(z); if (/^\d{3} /.test(z) || /^\d{3}$/.test(z)) break; if (!/^\d{3}-/.test(z)) break; }
  const code = Number(zeilen[zeilen.length - 1].slice(0, 3));
  return { code, text: zeilen.map((z) => z.slice(4)).join(' '), zeilen };
}
async function smtpBefehl(l, cmd, erwartet, anzeige) {
  if (cmd != null) l.schreiben(`${cmd}\r\n`);
  const a = await smtpAntwort(l);
  if (!erwartet.includes(a.code)) { const e = new Error(`SMTP ${anzeige || String(cmd).split(' ')[0]}: ${a.code} ${a.text}`.slice(0, 300)); e.smtp = a.code; throw e; }
  return a;
}
async function senden(cfg, msg) {
  const s = cfg.smtp || {};
  if (!s.host) throw new Error('Kein SMTP-Server eingetragen');
  const an = [...(msg.an || []), ...(msg.cc || [])].map((x) => adresseAus(x).adresse).filter(istAdresse);
  if (!an.length) throw new Error('Kein gültiger Empfänger');
  const von = adresseAus(cfg.absender || cfg.user).adresse;
  if (!istAdresse(von)) throw new Error('Absenderadresse fehlt oder ist ungültig');
  const sicher = s.sicher || 'ssl';
  let sock = await verbinden(s.host, Number(s.port) || (sicher === 'ssl' ? 465 : 587), sicher === 'ssl', cfg.tlsPruefen);
  const l = new Leser(sock);
  try {
    await smtpBefehl(l, null, [220], 'Begrüßung');
    const helo = `EHLO ${(os.hostname() || 'einsatzverwaltung').replace(/[^a-z0-9.-]/gi, '') || 'localhost'}`;
    let eh = await smtpBefehl(l, helo, [250]);
    if (sicher === 'starttls') {
      if (!eh.zeilen.some((z) => /STARTTLS/i.test(z))) throw new Error('Server bietet kein STARTTLS an');
      await smtpBefehl(l, 'STARTTLS', [220]);
      sock.removeAllListeners('data'); sock.removeAllListeners('close'); sock.removeAllListeners('error');
      sock = await tlsUpgrade(sock, s.host, cfg.tlsPruefen); l.wechsel(sock);
      eh = await smtpBefehl(l, helo, [250]);
    }
    if (cfg.user) {
      const auth = eh.zeilen.find((z) => /AUTH/i.test(z)) || '';
      if (/PLAIN/i.test(auth) || !/LOGIN/i.test(auth)) {
        await smtpBefehl(l, `AUTH PLAIN ${Buffer.from(`\0${cfg.user}\0${cfg.pass || ''}`, 'utf8').toString('base64')}`, [235], 'Anmeldung');
      } else {
        await smtpBefehl(l, 'AUTH LOGIN', [334], 'Anmeldung');
        await smtpBefehl(l, Buffer.from(cfg.user, 'utf8').toString('base64'), [334], 'Anmeldung');
        await smtpBefehl(l, Buffer.from(cfg.pass || '', 'utf8').toString('base64'), [235], 'Anmeldung');
      }
    }
    await smtpBefehl(l, `MAIL FROM:<${von}>`, [250]);
    let angenommen = 0; const abgelehnt = [];
    for (const a of an) { try { await smtpBefehl(l, `RCPT TO:<${a}>`, [250, 251]); angenommen++; } catch (e) { abgelehnt.push(a); } }
    if (!angenommen) throw new Error(`Kein Empfänger angenommen (${abgelehnt.join(', ')})`);
    await smtpBefehl(l, 'DATA', [354]);
    const roh = mimeBauen(cfg, msg).replace(/\r?\n/g, '\r\n').replace(/^\./gm, '..');
    l.schreiben(`${roh}${roh.endsWith('\r\n') ? '' : '\r\n'}.\r\n`);
    await smtpBefehl(l, null, [250], 'Senden');
    try { l.schreiben('QUIT\r\n'); } catch (e) { /* egal */ }
    return { ok: true, empfaenger: angenommen, abgelehnt };
  } finally { setTimeout(() => { try { sock.destroy(); } catch (e) { /* egal */ } }, 200); }
}

/* ---------- IMAP ---------- */
const imapText = (t) => `"${String(t).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
class Imap {
  constructor(l) { this.l = l; this.n = 0; }
  async antwortLesen(tag) {   // liefert {status, text, zeilen:[{text, literale:[Buffer]}]}
    const zeilen = [];
    for (;;) {
      let z = await this.l.zeile(); const literale = [];
      let m;
      while ((m = /\{(\d+)\}$/.exec(z))) { literale.push(await this.l.bytes(Number(m[1]))); z = `${z.slice(0, m.index)}\u0000LIT${literale.length - 1}\u0000${await this.l.zeile()}`; }
      if (tag && z.startsWith(`${tag} `)) { const r = z.slice(tag.length + 1); return { status: r.split(' ')[0], text: r, zeilen }; }
      zeilen.push({ text: z, literale });
      if (!tag) return { status: 'OK', text: z, zeilen };
    }
  }
  async befehl(cmd) {
    const tag = `E${++this.n}`;
    this.l.schreiben(`${tag} ${cmd}\r\n`);
    const a = await this.antwortLesen(tag);
    if (a.status !== 'OK') { const e = new Error(`IMAP ${cmd.split(' ')[0] === 'LOGIN' ? 'Anmeldung' : cmd.split(' ').slice(0, 2).join(' ')}: ${a.text}`.slice(0, 300)); throw e; }
    return a;
  }
}
async function abrufen(cfg, verarbeiten, opt = {}) {
  const s = cfg.imap || {};
  if (!s.host) throw new Error('Kein IMAP-Server eingetragen');
  const sicher = s.sicher || 'ssl';
  let sock = await verbinden(s.host, Number(s.port) || (sicher === 'ssl' ? 993 : 143), sicher === 'ssl', cfg.tlsPruefen);
  const l = new Leser(sock); const im = new Imap(l);
  const ergebnis = { gelesen: 0, verarbeitet: 0 };
  try {
    const gruss = await im.antwortLesen(null);
    if (!/^\* (OK|PREAUTH)/i.test(gruss.text)) throw new Error(`IMAP-Begrüßung: ${gruss.text}`);
    if (sicher === 'starttls') {
      await im.befehl('STARTTLS');
      sock.removeAllListeners('data'); sock.removeAllListeners('close'); sock.removeAllListeners('error');
      sock = await tlsUpgrade(sock, s.host, cfg.tlsPruefen); l.wechsel(sock);
    }
    await im.befehl(`LOGIN ${imapText(cfg.user || '')} ${imapText(cfg.pass || '')}`);
    const sel = await im.befehl(`SELECT ${imapText(opt.ordner || 'INBOX')}`);
    const uidLesen = (r) => r.zeilen.filter((z) => /^\* SEARCH/i.test(z.text)).flatMap((z) => z.text.replace(/^\* SEARCH/i, '').trim().split(/\s+/)).filter((x) => /^\d+$/.test(x)).map(Number);
    const ungelesen = uidLesen(await im.befehl('UID SEARCH UNSEEN'));
    /* ab 5.203: nicht nur ungelesene Mails – wer das Postfach z. B. auf dem Handy mitliest, markiert Alarm-Mails als gelesen, bevor der Pi abruft.
       Darum zusätzlich alle Mails der letzten 2 Tage, deren UID noch nicht verarbeitet ist (opt.stand = {v: UIDVALIDITY, uids: [...]}). */
    let uids = ungelesen;
    if (opt.stand) {
      const vz = sel.zeilen.map((z) => /UIDVALIDITY\s+(\d+)/i.exec(z.text)).find(Boolean); const v = vz ? vz[1] : '';
      const d = new Date(Date.now() - 2 * 86400000); const seit = `${d.getUTCDate()}-${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getUTCMonth()]}-${d.getUTCFullYear()}`;
      let neuere = []; try { neuere = uidLesen(await im.befehl(`UID SEARCH SINCE ${seit}`)); } catch (e) { neuere = []; }
      const bekannt = new Set(opt.stand.v === v && Array.isArray(opt.stand.uids) ? opt.stand.uids : []);
      if (opt.stand.v !== v || !Array.isArray(opt.stand.uids)) { ergebnis.erstmals = true; neuere.forEach((u) => { if (!ungelesen.includes(u)) bekannt.add(u); }); }   // erster Abruf: schon gelesene alte Mails nicht nachholen
      uids = [...new Set(ungelesen.concat(neuere.filter((u) => !bekannt.has(u))))].sort((x, y) => x - y);
      ergebnis.nachgeholt = uids.filter((u) => !ungelesen.includes(u)).length;
      ergebnis.stand = { v, uids: [...bekannt] };
      ergebnis.merke = (u) => { bekannt.add(u); ergebnis.stand.uids = [...bekannt].sort((x, y) => x - y).slice(-800); };
    }
    for (const uid of uids.slice(0, opt.max || 20)) {
      const f = await im.befehl(`UID FETCH ${uid} (BODY.PEEK[])`);
      const z = f.zeilen.find((x) => x.literale.length);
      if (!z) continue;
      ergebnis.gelesen++;
      let markieren = true;
      try { markieren = (await verarbeiten(z.literale[0], uid)) !== false; } catch (e) { markieren = true; }
      if (markieren) { await im.befehl(`UID STORE ${uid} +FLAGS (\\Seen)`); ergebnis.verarbeitet++; if (ergebnis.merke) ergebnis.merke(uid); }
    }
    try { await im.befehl('LOGOUT'); } catch (e) { /* egal */ }
    if (ergebnis.stand) { ergebnis.stand.uids = ergebnis.stand.uids.sort((x, y) => x - y).slice(-800); delete ergebnis.merke; }
    return ergebnis;
  } finally { setTimeout(() => { try { sock.destroy(); } catch (e) { /* egal */ } }, 200); }
}

/* ---------- MIME lesen ---------- */
function zeichensatz(buf, cs) {
  const c = String(cs || 'utf-8').toLowerCase().replace(/^"|"$/g, '');
  try { return new TextDecoder(c === 'us-ascii' ? 'utf-8' : c).decode(buf); } catch (e) { return buf.toString('latin1'); }
}
function woerterDekodieren(s) {
  return String(s || '').replace(/(=\?[^?]+\?[bqBQ]\?[^?]*\?=)\s+(?==\?)/g, '$1').replace(/=\?([^?]+)\?([bqBQ])\?([^?]*)\?=/g, (m, cs, art, t) => {
    try {
      const buf = art.toUpperCase() === 'B' ? Buffer.from(t, 'base64') : Buffer.from(t.replace(/_/g, ' ').replace(/=([0-9a-f]{2})/gi, (x, h) => String.fromCharCode(parseInt(h, 16))), 'latin1');
      return zeichensatz(buf, cs.split('*')[0]);
    } catch (e) { return m; }
  });
}
function kopfLesen(t) {
  const h = {};
  t.replace(/\r?\n[ \t]+/g, ' ').split(/\r?\n/).forEach((z) => { const i = z.indexOf(':'); if (i > 0) { const k = z.slice(0, i).trim().toLowerCase(); (h[k] = h[k] || []).push(z.slice(i + 1).trim()); } });
  return h;
}
function paramLesen(wert) {
  const teile = []; let cur = '', q = false;
  for (const ch of String(wert || '')) { if (ch === '"') q = !q; if (ch === ';' && !q) { teile.push(cur); cur = ''; } else cur += ch; }
  teile.push(cur);
  const p = { wert: teile.shift().trim().toLowerCase() };
  teile.forEach((x) => {
    const i = x.indexOf('='); if (i < 0) return;
    let k = x.slice(0, i).trim().toLowerCase(), v = x.slice(i + 1).trim().replace(/^"|"$/g, '');
    if (k.endsWith('*')) { k = k.slice(0, -1); const m = /^([^']*)'[^']*'(.*)$/.exec(v); if (m) { try { v = zeichensatz(Buffer.from(m[2].replace(/%([0-9a-f]{2})/gi, (x, h) => String.fromCharCode(parseInt(h, 16))), 'latin1'), m[1] || 'utf-8'); } catch (e) { v = m[2]; } } }
    p[k] = woerterDekodieren(v);
  });
  return p;
}
function qpDekodieren(t) {
  const s = t.replace(/=\r?\n/g, '');
  const out = []; for (let i = 0; i < s.length; i++) { if (s[i] === '=' && /^[0-9a-f]{2}$/i.test(s.slice(i + 1, i + 3))) { out.push(parseInt(s.slice(i + 1, i + 3), 16)); i += 2; } else out.push(s.charCodeAt(i) & 0xff); }
  return Buffer.from(out);
}
function teilLesen(buf, tiefe, out) {
  const roh = buf.toString('latin1');
  const t = roh.search(/\r?\n\r?\n/); const kopfT = t >= 0 ? roh.slice(0, t) : roh;
  const rumpfStart = t >= 0 ? t + (roh.slice(t, t + 4) === '\r\n\r\n' ? 4 : 2) : roh.length;
  let kopfText = kopfT;
  try { kopfText = new TextDecoder('utf-8', { fatal: true }).decode(buf.slice(0, kopfT.length)); } catch (e) { /* kein UTF-8: latin1 lassen */ }
  const h = kopfLesen(kopfText);
  const ct = paramLesen((h['content-type'] || ['text/plain'])[0]);
  const enc = String((h['content-transfer-encoding'] || ['7bit'])[0]).toLowerCase();
  const rumpf = buf.slice(rumpfStart);
  if (ct.wert.startsWith('multipart/') && ct.boundary && tiefe < 8) {
    const b = `--${ct.boundary}`; const r = rumpf.toString('latin1');
    const stuecke = r.split(new RegExp(`\\r?\\n?${b.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?:--)?[ \\t]*\\r?\\n?`));
    stuecke.slice(1).forEach((st) => { if (st.trim()) teilLesen(Buffer.from(st, 'latin1'), tiefe + 1, out); });
    return h;
  }
  let daten = rumpf;
  if (enc === 'base64') daten = Buffer.from(rumpf.toString('latin1').replace(/[^A-Za-z0-9+/=]/g, ''), 'base64');
  else if (enc === 'quoted-printable') daten = qpDekodieren(rumpf.toString('latin1'));
  const disp = paramLesen((h['content-disposition'] || [''])[0]);
  const name = disp.filename || ct.name || '';
  if ((ct.wert === 'text/plain' || ct.wert === 'text/html') && disp.wert !== 'attachment') {
    let text = zeichensatz(daten, ct.charset);
    if (ct.wert === 'text/plain' && /^flowed$/i.test(ct.format || '')) text = flowedEntfalten(text, /^yes$/i.test(ct.delsp || ''));
    if (ct.wert === 'text/plain' && out.text == null) out.text = text;
    if (ct.wert === 'text/html' && out.html == null) out.html = text;
  } else if (ct.wert === 'message/rfc822') {
    teilLesen(daten, tiefe + 1, out);
  } else if (!ct.wert.startsWith('multipart/')) {
    out.anhaenge.push({ name: name || 'anhang', typ: ct.wert, daten });
  }
  return h;
}
function htmlZuText(h) {
  return String(h || '').replace(/<(script|style)[\s\S]*?<\/\1>/gi, '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|tr|li|h\d)>/gi, '\n').replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#(\d+);/g, (m, n) => String.fromCharCode(Number(n))).replace(/\n{3,}/g, '\n\n').trim();
}
// RFC 3676 (format=flowed, z. B. web.de/GMX): Zeilen mit Leerzeichen am Ende werden mit der nächsten verbunden
function flowedEntfalten(text, delsp) {
  const z = String(text).split(/\r?\n/); const out = []; let akt = null;
  for (let l of z) {
    if (l.startsWith(' ')) l = l.slice(1);
    const weich = l.endsWith(' ') && l !== '-- ';
    const teil = weich && delsp ? l.slice(0, -1) : l;
    akt = akt == null ? teil : akt + teil;
    if (!weich) { out.push(akt); akt = null; }
  }
  if (akt != null) out.push(akt);
  return out.join('\n');
}
function zerlegen(raw) {
  const buf = Buffer.isBuffer(raw) ? raw : Buffer.from(String(raw), 'utf8');
  const out = { text: null, html: null, anhaenge: [] };
  const h = teilLesen(buf, 0, out);
  const k = (n) => woerterDekodieren((h[n] || [''])[0]);
  const text = out.text != null ? out.text : htmlZuText(out.html);
  return {
    von: adresseAus(k('from')), an: adressenAus(k('to')), betreff: k('subject'), datum: Date.parse(k('date')) || null,
    messageId: k('message-id').replace(/[<>\s]/g, '').slice(0, 200), antwortAn: adresseAus(k('reply-to')),
    auth: (h['authentication-results'] || []).join(' ; ').toLowerCase(),
    text: String(text || '').replace(/\r\n/g, '\n').trim(), html: out.html, anhaenge: out.anhaenge,
  };
}
// Echtheit des Absenders nach den Prüfergebnissen des eigenen Mailservers (falls vorhanden)
function echtheit(auth) {
  const a = String(auth || '');
  if (!a) return { geprueft: false, ok: true, text: 'keine Prüfergebnisse im Kopf' };
  const dkimPass = /dkim=pass/.test(a), spfPass = /spf=pass/.test(a), dmarcFail = /dmarc=fail/.test(a), spfFail = /spf=(fail|softfail)/.test(a), dkimFail = /dkim=fail/.test(a);
  if (dmarcFail || ((spfFail || dkimFail) && !dkimPass && !spfPass)) return { geprueft: true, ok: false, text: 'SPF/DKIM/DMARC fehlgeschlagen' };
  return { geprueft: true, ok: true, text: dkimPass || spfPass ? 'SPF/DKIM bestanden' : 'ohne eindeutiges Ergebnis' };
}

/* ---------- Leitstellen-Mails („Schlüssel: Wert“) ---------- */
const LS_FELDER = [
  ['stichwort', /^(einsatz)?stichwort|^alarmstichwort|^stichw|^alarmierungsstichwort|^einsatzart|^aao/],
  ['eroeffnung', /^er(ö|oe)ffnung|^alarmzeit|^alarmierungszeit|^einsatzbeginn/],
  ['meldebild', /^meldebild|^sachverhalt|^einsatzgrund|^lage|^schlagwort|^bemerkung|^zusatz|^info|^hinweis|^freitext/],
  ['einsatzort', /^einsatzort|^ort der|^einsatzstelle/],
  ['strasse', /^stra(ss|ß)e|^str\b|^anschrift|^einsatzadresse|^adresse/],
  ['hausnummer', /^haus(nummer|nr)|^hnr|^nr\b/],
  ['ortsteil', /^ortsteil|^ot\b/],
  ['ort', /^ort\b|^gemeinde|^stadt|^plz.?ort/],
  ['plz', /^plz\b|^postleitzahl/],
  ['objekt', /^objekt|^einrichtung|^firma/],
  ['meldender', /^meldende|^mitteiler|^anrufer|^anrufende|^melder/],
  ['telefon', /^telefon|^tel\b|^rufnummer|^r(ü|ue)ckruf/],
  ['nummer', /^einsatz.?(nr|nummer)|^ereignis.?(nr|nummer)|^ls.?nr|^vorgang|^auftrags?.?nr/],
  ['kraefte', /^(alarmierte )?kr(ä|ae)fte|^(alarmierte )?einheiten|^alarmierte (feuerwehren|wehren|organisationen)/],
  ['fahrzeuge', /^(alarmierte )?einsatzmittel|^fahrzeuge|^alarmierte|^alarmiert|^rufnamen/],
  ['koordinate', /^koordinate|^gps|^position|^lat.?lon|^wgs/],
  ['lat', /^(breite|lat|latitude)\b/],
  ['lon', /^(l(ä|ae)nge|lon|long|lng|longitude)\b/],
  ['prio', /^prio/],
];
const STICHWORT_ZEILE = /^\s*([A-ZÄÖÜ]{1,5}\s?\d{1,2}[A-ZÄÖÜ]{0,4}(?:\s[A-ZÄÖÜ0-9]{1,6}){0,3})\s*:\s*(.+)$/;   // ab 3.68 auch „H1 VU Y“, „B2 LKW AY“, „H0 TÜR“
const gleich = (a, b) => String(a || '').toLowerCase() === String(b || '').toLowerCase();
/* „Objekt Gemeinde Ortsteil Straße Nr“ (z. B. „Hallenbad Aerzen Aerzen Aerzen Hopfenweg 16“) zerlegen.
   orte = {gemeinden:[], ortsteile:[]} aus der Fahrzeugliste/den Einstellungen. */
function ortZerlegen(text, orte) {
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  if (!t || /,/.test(t)) return null;
  const T = t.split(' ');
  const gem = (orte && orte.gemeinden || []).filter(Boolean), ot = (orte && orte.ortsteile || []).filter(Boolean).sort((a, b) => b.split(' ').length - a.split(' ').length);
  const otAb = (j) => { for (const o of ot) { const n = o.split(' ').length; if (j + n <= T.length && gleich(T.slice(j, j + n).join(' '), o)) return n; } return 0; };
  const ergebnis = (i, n) => ({ objekt: T.slice(0, i).join(' '), ort: T[i], ortsteil: T.slice(i + 1, i + 1 + n).join(' '), strasse: T.slice(i + 1 + n).join(' ') });
  for (let i = T.length - 2; i >= 0; i--) {   // von hinten: Gemeinde + bekannter Ortsteil + Straße
    if (!gem.some((g) => gleich(g, T[i]))) continue;
    const n = otAb(i + 1);
    if (n && i + 1 + n < T.length) return ergebnis(i, n);
  }
  for (let i = T.length - 3; i >= 0; i--) {   // Ortsteil unbekannt: ein Wort, danach Straße mit Hausnummer
    if (gem.some((g) => gleich(g, T[i])) && /\d/.test(T[T.length - 1])) return ergebnis(i, 1);
  }
  return null;
}
function leitstelleLesen(text, betreff, orte) {
  const d = { rest: [] };
  const norm = (s) => s.toLowerCase().replace(/[^a-zäöüß0-9 .]/g, ' ').replace(/\s+/g, ' ').trim();
  let offen = null, swZeile = false;
  String(text || '').split(/\r?\n/).forEach((z) => {
    if (offen) { if (!z.trim()) return; d[offen] = z.trim(); offen = null; return; }   // „EINSATZORT:“ – Wert in der nächsten Zeile
    const sw = !d.stichwort && STICHWORT_ZEILE.exec(z);
    if (sw && !/^\s*(tel|nr|plz|ot)\b/i.test(z)) { d.stichwort = sw[1].trim(); if (!d.meldebild) d.meldebild = sw[2].trim(); swZeile = true; return; }
    const m = /^\s*([A-Za-zÄÖÜäöüß][A-Za-zÄÖÜäöüß .\/-]{0,30}?)\s*[:=]\s*(.*)$/.exec(z);
    if (m) {
      const k = norm(m[1]); const f = LS_FELDER.find(([, re]) => re.test(k));
      if (f && m[2].trim()) { d[f[0]] = d[f[0]] ? `${d[f[0]]}, ${m[2].trim()}` : m[2].trim(); return; }
      if (f && !m[2].trim()) { offen = f[0]; return; }
    }
    if (z.trim()) d.rest.push(z.trim());
  });
  // Koordinaten auch als „[lat=52.05][long=9.26]“ oder „lat 52.05 lon 9.26“
  const kk = /\blat(?:itude)?\s*[=:]?\s*(-?\d{1,2}[.,]\d+)\]?\s*[,;\s]*\[?\s*(?:long|lon|lng|longitude)\s*[=:]?\s*(-?\d{1,3}[.,]\d+)/i.exec(text || '');
  if (kk && (d.lat == null || d.lon == null)) { d.lat = kk[1]; d.lon = kk[2]; }
  d.rest = d.rest.filter((z) => !/^\[?\s*lat\s*[=:]/i.test(z) && !/^alarm-?mail\b/i.test(z));
  if (swZeile && d.rest.length && d.meldebild && !d.rest[0].includes(':')) d.meldebild = `${d.meldebild} – ${d.rest.shift()}`;   // Zeile unter dem Stichwort = Meldebild
  if (!d.stichwort && betreff) {
    const m = /(?:^|[^A-Za-zÄÖÜäöü])((?:B|TH|ABC|CBRN|RD|H|F|THL|VU|G)\s?\d?(?:\s?(?:ABST|BAHN|BEL|BMA|DLK|EIN|FLUG|LKW|SRHT|TÜR|VEG|VU|ERK|BSW|[WXAÜY]{1,4})(?![A-Za-zÄÖÜäöü])){0,3})(?![A-Za-zÄÖÜäöü0-9])/.exec(betreff);
    if (m && m[1].trim()) d.stichwort = m[1].trim();
  }
  if (d.einsatzort && !d.strasse) {
    const z = ortZerlegen(d.einsatzort, orte);
    if (z) { d.strasse = z.strasse; if (!d.ortsteil && !gleich(z.ortsteil, z.ort)) d.ortsteil = z.ortsteil; if (!d.ort) d.ort = z.ort; if (z.objekt && !d.objekt) d.objekt = z.objekt; }
    else d.strasse = d.einsatzort;
  }
  let adresse = '';
  if (d.strasse) adresse = `${d.strasse}${d.hausnummer && !/\d/.test(d.strasse) ? ` ${d.hausnummer}` : ''}`;
  const ortTeile = [d.ortsteil, [d.plz, d.ort].filter(Boolean).join(' ')].filter((x) => x && !(adresse && adresse.includes(',') && adresse.toLowerCase().includes(x.toLowerCase())));
  if (ortTeile.length) adresse = [adresse, ...ortTeile].filter(Boolean).join(', ');
  d.adresse = adresse;
  if (d.koordinate && (d.lat == null || d.lon == null)) { const m = /(-?\d{1,2}[.,]\d+)\s*[,; ]\s*(-?\d{1,3}[.,]\d+)/.exec(d.koordinate); if (m) { d.lat = m[1]; d.lon = m[2]; } }
  const lat = Number(String(d.lat || '').replace(',', '.')), lon = Number(String(d.lon || '').replace(',', '.'));
  d.lat = Number.isFinite(lat) && Math.abs(lat) <= 90 && lat ? lat : null; d.lon = Number.isFinite(lon) && Math.abs(lon) <= 180 && lon ? lon : null;
  const liste = (x) => String(x || '').split(/[,;\n]| und /).map((y) => y.trim()).filter(Boolean);
  d.fahrzeugListe = liste(d.fahrzeuge);
  d.kraefteListe = liste(d.kraefte);
  const ez = /(\d{1,2})\.(\d{1,2})\.(\d{4})\D+(\d{1,2}):(\d{2})/.exec(d.eroeffnung || '');
  d.eroeffnungT = ez ? new Date(+ez[3], +ez[2] - 1, +ez[1], +ez[4], +ez[5]).getTime() : null;
  return d;
}
// Freitext (Erkunder): „Adresse: …“ oder erste Zeile mit Hausnummer
function freitextLesen(text) {
  const z = String(text || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  let adresse = '';
  const az = z.find((x) => /^(adresse|ort|einsatzort|anschrift|wo)\s*[:=]/i.test(x));
  if (az) adresse = az.replace(/^[^:=]+[:=]\s*/, '');
  else { const s = z.find((x) => /[A-Za-zÄÖÜäöüß]{3,}(stra(ss|ß)e|str\.|weg|platz|allee|ring|gasse|damm|feld|hof)\s+\d+/i.test(x)); if (s) adresse = (/[A-Za-zÄÖÜäöüß .-]{3,}\s+\d+\s?[a-z]?(\s*,\s*[^\n]+)?/i.exec(s) || [s])[0].trim(); }
  let lat = null, lon = null;
  const k = /(-?\d{1,2}[.,]\d{3,})\s*[,; ]\s*(-?\d{1,3}[.,]\d{3,})/.exec(text || '');
  if (k) { lat = Number(k[1].replace(',', '.')); lon = Number(k[2].replace(',', '.')); }
  return { adresse, lat, lon };
}

/* Gefahrstoffe in einer Alarmmail erkennen (3.43): „UN 1017“, Warntafel „265/1017“ oder Stoffname („Chlorgaswarnanlage“ → Chlor) */
function gefahrstoffeFinden(text, tabelle) {
  const t = String(text || ''), liste = (tabelle && tabelle.stoffe) || [], funde = new Map();
  const nachUn = (un) => liste.find((x) => x.un === un);
  const dazu = (un, gn, fund) => { if (funde.has(un)) return; const s = nachUn(un); funde.set(un, { un, name: s ? (s.kurz || s.name) : `UN ${un}`, gn: gn || (s ? s.gn : ''), kl: s ? (s.kl_adr || s.kl) : '', fund, bekannt: !!s, giftig: !!(s && (s.giftig || s.tih)) }); };
  let m; const reUn = /\bUN[\s.-]*(?:nr\.?|nummer)?[\s:.-]*(\d{4})\b/gi;
  while ((m = reUn.exec(t))) { const n = +m[1]; if (n >= 4 && n <= 3600) dazu(m[1], '', `UN ${m[1]}`); }
  const reTafel = /\b(X?\d{2,3})\s*\/\s*(\d{4})\b/g;
  // ab 3.96: Gefahrnummern beginnen mit 2–9 (oder X) – „12/2025“ o. ä. ist ein Datum, keine Tafel
  while ((m = reTafel.exec(t))) { if (/^X?[2-9]\d{1,2}$/.test(m[1]) && !/^\s*\/\s*\d/.test(t.slice(reTafel.lastIndex)) && nachUn(m[2])) dazu(m[2], m[1], `Warntafel ${m[1]}/${m[2]}`); }
  const woerter = t.toLowerCase().match(/[a-zäöüß0-9]+(?:-[a-zäöüß0-9]+)*/g) || [];
  const namen = []; liste.filter((x) => x.suche !== false).forEach((x) => (x.namen || []).forEach((n) => namen.push({ n, x })));
  namen.sort((a, b) => b.n.length - a.n.length);
  woerter.forEach((w) => {
    const h = namen.find(({ n, x }) => (n.length < 5 ? w === n : w.startsWith(n)) && !(x.nicht || []).some((y) => w.startsWith(y)));
    if (h) dazu(h.x.un, '', `Stichwort „${w}“`);
  });
  return [...funde.values()].slice(0, 10);
}
module.exports = { senden, abrufen, zerlegen, mimeBauen, adresseAus, adressenAus, istAdresse, echtheit, leitstelleLesen, ortZerlegen, freitextLesen, gefahrstoffeFinden, htmlZuText };
