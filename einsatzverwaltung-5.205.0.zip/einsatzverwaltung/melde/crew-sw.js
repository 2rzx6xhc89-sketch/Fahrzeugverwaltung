// Service Worker der Besatzungs-App: App-Hülle offline, Rückmeldungen nie aus dem Cache
const CACHE = 'crew-v8';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== CACHE && x.startsWith('crew-')).map((x) => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const req = e.request; if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === location.origin && !url.pathname.startsWith('/crew/')) return;   // /api immer live
  if (url.origin !== location.origin) return;
  e.respondWith(fetch(req).then((res) => { if (res && res.ok) { const cp = res.clone(); caches.open(CACHE).then((c) => c.put(req, cp)); } return res; }).catch(() => caches.match(req).then((hit) => hit || Response.error())));
});
