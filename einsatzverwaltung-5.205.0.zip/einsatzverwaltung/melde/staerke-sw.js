// Service Worker der Sammelseite für Stärken: Seite auch ohne Netz verfügbar (Daten liegen nur im Teil hinter #)
const CACHE = 'staerke-v4';
self.addEventListener('install', (e) => { self.skipWaiting(); e.waitUntil(caches.open(CACHE).then((c) => c.add('/staerke/')).catch(() => {})); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== CACHE && x.startsWith('staerke-')).map((x) => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname !== '/staerke/') return;
  e.respondWith(fetch(e.request).then((res) => { if (res && res.ok) { const cp = res.clone(); caches.open(CACHE).then((c) => c.put('/staerke/', cp)); } return res; }).catch(() => caches.match('/staerke/').then((h) => h || Response.error())));
});
