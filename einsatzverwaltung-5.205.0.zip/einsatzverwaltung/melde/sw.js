// Service Worker der Fahrzeug-App: App-Hülle offline verfügbar, Meldungen nie aus dem Cache; ab 3.65 Benachrichtigungen (Web-Push)
const CACHE = 'fzapp-v66';
const KARTE = 'fzapp-karte';   // ab 5.190: Kartenkacheln, die schon einmal angezeigt wurden – für die Hydrantenprüfung im Funkloch
self.addEventListener('install', (e) => { self.skipWaiting(); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== CACHE && x !== 'fzapp-push' && x !== KARTE && x.startsWith('fzapp-')).map((x) => caches.delete(x)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === location.origin && url.pathname.startsWith('/api/kachel/')) { e.respondWith(kachel(req)); return; }
  if (url.origin === location.origin && url.pathname.startsWith('/melden/') && req.mode === 'navigate') { e.respondWith(seite(req)); return; }
  if (url.origin === location.origin && !url.pathname.startsWith('/melden/')) return; // /api, /lage: immer live
  const cacheable = url.origin === location.origin || url.hostname.endsWith('googleapis.com') || url.hostname.endsWith('gstatic.com');
  if (!cacheable) return;
  e.respondWith(fetch(req).then((res) => {
    if (res && (res.ok || res.type === 'opaque')) { const cp = res.clone(); caches.open(CACHE).then((c) => c.put(req, cp)); }
    return res;
  }).catch(() => caches.match(req).then((hit) => hit || Response.error())));
});

/* ab 5.190: Kacheln aus dem Netz, ohne Netz aus dem Speicher (höchstens rund 4000 Kacheln, die ältesten fliegen raus) */
async function kachel(req) {
  const c = await caches.open(KARTE);
  try {
    const res = await fetch(req, { signal: AbortSignal.timeout ? AbortSignal.timeout(12000) : undefined });
    if (res && res.ok) { c.put(req, res.clone()).then(async () => { const k = await c.keys(); if (k.length > 4000) for (const x of k.slice(0, 500)) await c.delete(x); }).catch(() => {}); return res; }
    const hit = await c.match(req); return hit || res;
  } catch (e) { const hit = await c.match(req); return hit || Response.error(); }
}
/* ab 5.190: App-Seite im Funkloch: nach 6 Sekunden ohne Antwort die gespeicherte Seite nehmen */
async function seite(req) {
  const hit = await caches.match(req);
  const netz = fetch(req).then((res) => { if (res && res.ok) { const cp = res.clone(); caches.open(CACHE).then((c) => c.put(req, cp)); } return res; });
  if (!hit) return netz.catch(() => Response.error());
  return Promise.race([netz.catch(() => hit), new Promise((r) => setTimeout(() => r(hit), 6000))]);
}

/* ---------- Benachrichtigungen (ab 3.65) ---------- */
const PUSH_CACHE = 'fzapp-push';   // merkt sich den Link (Token) für ein erneuertes Abo
self.addEventListener('message', (e) => {
  if (e.data && e.data.typ === 'token' && /^[0-9a-f]{40}$/.test(e.data.token || '')) {
    caches.open(PUSH_CACHE).then((c) => c.put('/melden/_token', new Response(e.data.token))).catch(() => {});
  }
});
self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { d = { titel: 'Fahrzeug-App', text: e.data ? e.data.text() : '' }; }
  e.waitUntil((async () => {
    try { (await self.clients.matchAll({ type: 'window', includeUncontrolled: true })).forEach((c) => c.postMessage({ typ: 'push', art: d.art })); } catch (x) { /* egal */ }
    await self.registration.showNotification(d.titel || 'Fahrzeug-App', {
      body: d.text || '', tag: d.tag || d.art || 'fzapp', renotify: true, lang: 'de',
      icon: '/melden/icon-192.png', badge: '/melden/icon-192.png', vibrate: [300, 150, 300, 150, 300],
      requireInteraction: d.art === 'auftrag' || d.art === 'nachricht', timestamp: d.t || Date.now(),
      data: { url: d.url || '/melden/' },
    });
  })());
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const ziel = new URL((e.notification.data && e.notification.data.url) || '/melden/', self.location.origin).href;
  e.waitUntil((async () => {
    const liste = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const c = liste.find((x) => x.url.split('?')[0] === ziel) || liste.find((x) => x.url.startsWith(self.location.origin + '/melden/'));
    if (c) { try { if (c.url.split('?')[0] !== ziel && c.navigate) await c.navigate(ziel); } catch (x) { /* egal */ } return c.focus(); }
    return self.clients.openWindow(ziel);
  })());
});
self.addEventListener('pushsubscriptionchange', (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(PUSH_CACHE); const r = await c.match('/melden/_token'); if (!r) return;
    const token = await r.text();
    const opt = (e.oldSubscription && e.oldSubscription.options) || null;
    let key = opt && opt.applicationServerKey;
    if (!key) { const k = await (await fetch('/api/push/schluessel/' + token, { cache: 'no-store' })).json(); if (!k.key) return; const p = '='.repeat((4 - k.key.length % 4) % 4); key = Uint8Array.from(atob((k.key + p).replace(/-/g, '+').replace(/_/g, '/')), (x) => x.charCodeAt(0)); }
    const neu = e.newSubscription || await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
    await fetch('/api/push/abo/' + token, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ abo: neu.toJSON(), geraet: 'erneuert' }) });
  })().catch(() => {}));
});
