/*
 * QR-Code-Leser ohne externe Bibliothek (ab 3.36) – für Bilder von Kamera oder Foto.
 * Liest QR-Codes mit Fehlerkorrektur L und M (so erzeugt sie die Einsatzverwaltung und die
 * Sammel-Seite für Stärken). Ablauf: Graustufen → örtlicher Schwellwert → Suchmuster (Finder)
 * → Ausrichtungsmuster → perspektivische Entzerrung → Format/Version → Reed-Solomon → Text.
 *   QRLESEN.lesen(canvas | ImageData) → Text oder null
 */
(function (global) {
  'use strict';
  /* ---------- Tabellen (identisch zum Erzeuger QRGEN) ---------- */
  const ECC = {
    L: [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    M: [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
  };
  const BLK = {
    L: [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
    M: [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
  };
  const ECL_BITS = { 1: 'L', 0: 'M', 3: 'Q', 2: 'H' };
  const rawMods = (v) => { let r = (16 * v + 128) * v + 64; if (v >= 2) { const n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; } return r; };
  const alignPos = (v, size) => { if (v === 1) return []; const n = Math.floor(v / 7) + 2; const step = (v === 32) ? 26 : Math.ceil((v * 4 + 4) / (n * 2 - 2)) * 2; const r = [6]; for (let p = size - 7; r.length < n; p -= step) r.splice(1, 0, p); return r; };
  const MASK = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x, y) => x % 3 === 0, (x, y) => (x + y) % 3 === 0, (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => x * y % 2 + x * y % 3 === 0, (x, y) => (x * y % 2 + x * y % 3) % 2 === 0, (x, y) => ((x + y) % 2 + x * y % 3) % 2 === 0];
  const FORMATE = []; for (let d = 0; d < 32; d++) { let r = d; for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537); FORMATE.push({ d, w: ((d << 10) | r) ^ 0x5412 }); }
  const VERSIONEN = []; for (let v = 7; v <= 40; v++) { let r = v; for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1F25); VERSIONEN.push({ v, w: (v << 12) | r }); }
  const bitsAnders = (a, b) => { let x = a ^ b, n = 0; while (x) { n += x & 1; x >>>= 1; } return n; };

  /* ---------- GF(256) und Reed-Solomon ---------- */
  const EXP = new Uint8Array(512), LOG = new Uint8Array(256);
  for (let i = 0, x = 1; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11D; }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  const mul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);
  const inv = (a) => EXP[255 - LOG[a]];
  const polyAt = (p, x) => { let y = 0; for (let i = p.length - 1; i >= 0; i--) y = mul(y, x) ^ p[i]; return y; };   // p[i] = Koeffizient von x^i
  function rsKorrigieren(cw, nsym) {
    const n = cw.length;
    const S = new Array(nsym);
    let fehler = false;
    for (let i = 0; i < nsym; i++) { let s = 0; const a = EXP[i]; for (let k = 0; k < n; k++) s = mul(s, a) ^ cw[k]; S[i] = s; if (s) fehler = true; }
    if (!fehler) return 0;
    // Berlekamp-Massey
    let C = [1], B = [1], L = 0, m = 1, b = 1;
    for (let i = 0; i < nsym; i++) {
      let d = S[i]; for (let j = 1; j <= L; j++) d ^= mul(C[j] || 0, S[i - j]);
      if (d === 0) { m++; continue; }
      const T = C.slice(); const f = mul(d, inv(b));
      const neu = C.slice(); for (let j = 0; j < B.length; j++) { neu[j + m] = (neu[j + m] || 0) ^ mul(f, B[j]); }
      for (let j = 0; j < neu.length; j++) if (neu[j] === undefined) neu[j] = 0;
      C = neu;
      if (2 * L <= i) { L = i + 1 - L; B = T; b = d; m = 1; } else m++;
    }
    if (2 * L > nsym) return -1;
    // Chien-Suche: Fehler an Index k ↔ X = α^(n-1-k)
    const pos = [];
    for (let k = 0; k < n; k++) { const p = n - 1 - k; if (polyAt(C, EXP[(255 - p) % 255]) === 0) pos.push(k); }
    if (pos.length !== L) return -1;
    // Forney (erste Nullstelle α^0): e = X · Ω(X⁻¹) / Λ'(X⁻¹)
    const Om = new Array(nsym).fill(0);
    for (let i = 0; i < nsym; i++) for (let j = 0; j < C.length && j <= i; j++) Om[i] ^= mul(S[i - j], C[j]);
    const Cd = []; for (let j = 1; j < C.length; j += 2) { Cd[j - 1] = C[j]; } for (let j = 0; j < Cd.length; j++) if (Cd[j] === undefined) Cd[j] = 0;
    for (const k of pos) {
      const X = EXP[(n - 1 - k) % 255], Xi = inv(X);
      const nenner = polyAt(Cd, Xi); if (!nenner) return -1;
      cw[k] ^= mul(mul(X, polyAt(Om, Xi)), inv(nenner));
    }
    for (let i = 0; i < nsym; i++) { let s = 0; const a = EXP[i]; for (let k = 0; k < n; k++) s = mul(s, a) ^ cw[k]; if (s) return -1; }
    return pos.length;
  }

  /* ---------- Bild → Schwarz/Weiß ---------- */
  function graustufen(img) {
    const { width: w, height: h, data: d } = img;
    const g = new Uint8Array(w * h);
    for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = (d[i] * 77 + d[i + 1] * 150 + d[i + 2] * 29) >> 8;
    return { w, h, g };
  }
  function binaer({ w, h, g }) {
    const B = 8, bw = Math.ceil(w / B), bh = Math.ceil(h / B);
    const avg = new Float32Array(bw * bh);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      let s = 0, mn = 255, mx = 0, n = 0;
      for (let y = by * B; y < Math.min(h, by * B + B); y++) for (let x = bx * B; x < Math.min(w, bx * B + B); x++) { const v = g[y * w + x]; s += v; n++; if (v < mn) mn = v; if (v > mx) mx = v; }
      let a = s / n;
      if (mx - mn <= 24) {   // kaum Kontrast: eher Fläche – an Nachbarn anlehnen
        a = mn / 2;
        if (by > 0 && bx > 0) { const nb = (avg[(by - 1) * bw + bx] + 2 * avg[by * bw + bx - 1] + avg[(by - 1) * bw + bx - 1]) / 4; if (mn < nb) a = nb; }
      }
      avg[by * bw + bx] = a;
    }
    const bits = new Uint8Array(w * h);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      const cx = Math.min(Math.max(bx, 2), bw - 3), cy = Math.min(Math.max(by, 2), bh - 3);
      let s = 0, n = 0;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { const yy = cy + dy, xx = cx + dx; if (yy >= 0 && yy < bh && xx >= 0 && xx < bw) { s += avg[yy * bw + xx]; n++; } }
      const t = s / n;
      for (let y = by * B; y < Math.min(h, by * B + B); y++) for (let x = bx * B; x < Math.min(w, bx * B + B); x++) bits[y * w + x] = g[y * w + x] <= t ? 1 : 0;
    }
    return { w, h, bits, get: (x, y) => (x >= 0 && y >= 0 && x < w && y < h ? bits[y * w + x] : 0) };
  }

  /* ---------- Suchmuster (1:1:3:1:1) ---------- */
  function musterPasst(c) {
    const t = c[0] + c[1] + c[2] + c[3] + c[4]; if (t < 7) return false;
    const m = t / 7, v = m / 1.5;
    return Math.abs(m - c[0]) < v && Math.abs(m - c[1]) < v && Math.abs(3 * m - c[2]) < 3 * v && Math.abs(m - c[3]) < v && Math.abs(m - c[4]) < v;
  }
  // entlang einer Richtung (dx,dy) vom Punkt aus die fünf Läufe messen; liefert Mitte und Modulgröße
  function querPruefen(B, x0, y0, dx, dy, maxLauf) {
    const c = [0, 0, 0, 0, 0];
    let x = x0, y = y0;
    while (B.get(x, y) && c[2] <= maxLauf) { c[2]++; x -= dx; y -= dy; }
    if (!inBild(B, x, y)) return null;
    while (inBild(B, x, y) && !B.get(x, y) && c[1] <= maxLauf) { c[1]++; x -= dx; y -= dy; }
    if (!inBild(B, x, y) || c[1] > maxLauf) return null;
    while (inBild(B, x, y) && B.get(x, y) && c[0] <= maxLauf) { c[0]++; x -= dx; y -= dy; }
    if (c[0] > maxLauf) return null;
    x = x0 + dx; y = y0 + dy;
    while (B.get(x, y) && c[2] <= maxLauf * 3) { c[2]++; x += dx; y += dy; }
    if (!inBild(B, x, y)) return null;
    while (inBild(B, x, y) && !B.get(x, y) && c[3] <= maxLauf) { c[3]++; x += dx; y += dy; }
    if (!inBild(B, x, y) || c[3] > maxLauf) return null;
    while (inBild(B, x, y) && B.get(x, y) && c[4] <= maxLauf) { c[4]++; x += dx; y += dy; }
    if (c[4] > maxLauf || !musterPasst(c)) return null;
    // Mitte: Ende des 4. Laufs minus halbe Breite von Lauf 3..5
    const ende = c[3] + c[4]; const vonMitte = (c[2] + 1) / 2;
    void ende;
    // Lage der Mitte relativ zum Startpunkt: Start liegt im Mittelfeld; linker Rand des Mittelfelds bei -(links), rechter bei +(rechts)
    return { c, modul: (c[0] + c[1] + c[2] + c[3] + c[4]) / 7, vonMitte };
  }
  const inBild = (B, x, y) => x >= 0 && y >= 0 && x < B.w && y < B.h;
  function mitteEntlang(B, x0, y0, dx, dy, maxLauf) {
    // genaue Mitte des schwarzen Mittelfelds entlang der Richtung
    let a = 0; while (B.get(x0 - dx * (a + 1), y0 - dy * (a + 1)) && a < maxLauf * 3) a++;
    let b = 0; while (B.get(x0 + dx * (b + 1), y0 + dy * (b + 1)) && b < maxLauf * 3) b++;
    const r = querPruefen(B, x0, y0, dx, dy, maxLauf);
    if (!r) return null;
    return { x: x0 + dx * (b - a) / 2, y: y0 + dy * (b - a) / 2, modul: r.modul };
  }
  function finderSuchen(B) {
    const kand = [];
    const maxLauf = Math.ceil(Math.max(B.w, B.h) / 14);
    const schritt = Math.max(1, Math.floor(B.h / 300));
    for (let y = 0; y < B.h; y += schritt) {
      const c = [0, 0, 0, 0, 0]; let st = 0;
      for (let x = 0; x <= B.w; x++) {
        const dunkel = x < B.w ? B.bits[y * B.w + x] : 0;
        if (dunkel) { if (st & 1) st++; c[st]++; }
        else if (!(st & 1)) {
          if (st === 4) {
            if (musterPasst(c)) {
              const cx = Math.round(x - c[4] - c[3] - c[2] / 2);
              const v = mitteEntlang(B, cx, y, 0, 1, maxLauf);
              if (v) {
                const hz = mitteEntlang(B, Math.round(v.x), Math.round(v.y), 1, 0, maxLauf);
                if (hz) {
                  const d1 = querPruefen(B, Math.round(hz.x), Math.round(v.y), 1, 1, maxLauf);
                  const d2 = querPruefen(B, Math.round(hz.x), Math.round(v.y), 1, -1, maxLauf);
                  if (d1 || d2) kandAdd(kand, hz.x, v.y, (v.modul + hz.modul) / 2);
                }
              }
            }
            c[0] = c[2]; c[1] = c[3]; c[2] = c[4]; c[3] = 1; c[4] = 0; st = 3;
          } else { st++; c[st]++; }
        } else c[st]++;
      }
    }
    return kand;
  }
  function kandAdd(kand, x, y, m) {
    for (const k of kand) {
      if (Math.abs(k.x - x) <= k.m * 1.5 && Math.abs(k.y - y) <= k.m * 1.5 && Math.abs(k.m - m) <= Math.max(1, k.m * 0.5)) {
        const n = k.n + 1; k.x = (k.x * k.n + x) / n; k.y = (k.y * k.n + y) / n; k.m = (k.m * k.n + m) / n; k.n = n; return;
      }
    }
    kand.push({ x, y, m, n: 1 });
  }
  function dreierWaehlen(kand) {
    const l = kand.slice().sort((a, b) => b.n - a.n).slice(0, 12);
    const out = [];
    for (let i = 0; i < l.length; i++) for (let j = i + 1; j < l.length; j++) for (let k = j + 1; k < l.length; k++) {
      const p = [l[i], l[j], l[k]];
      const ms = (p[0].m + p[1].m + p[2].m) / 3;
      if (p.some((q) => Math.abs(q.m - ms) > ms * 0.5)) continue;
      const d = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
      const s = [[d(p[1], p[2]), 0], [d(p[0], p[2]), 1], [d(p[0], p[1]), 2]].sort((a, b) => b[0] - a[0]);
      const hyp = s[0][0], l1 = s[1][0], l2 = s[2][0];
      if (l1 < ms * 14) continue;
      const fehler = Math.abs(l1 - l2) / l1 + Math.abs(hyp - Math.hypot(l1, l2)) / hyp + Math.abs(p[0].m - p[1].m) / ms * 0.1;
      if (fehler > 0.5) continue;
      const tl = p[s[0][1]], rest = p.filter((q) => q !== tl);
      out.push({ fehler: fehler - (l[i].n + l[j].n + l[k].n) * 0.002, tl, a: rest[0], b: rest[1], modul: ms });
    }
    return out.sort((x, y) => x.fehler - y.fehler).slice(0, 4);
  }

  /* ---------- Perspektive ---------- */
  function homographie(src, dst) {   // src/dst: je 4 Punkte [x,y]; liefert f(x,y) → [x', y']
    const A = [], b = [];
    for (let i = 0; i < 4; i++) {
      const [x, y] = src[i], [u, v] = dst[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
    }
    for (let c = 0; c < 8; c++) {   // Gauß mit Pivot
      let p = c; for (let r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
      [A[c], A[p]] = [A[p], A[c]]; [b[c], b[p]] = [b[p], b[c]];
      if (Math.abs(A[c][c]) < 1e-12) return null;
      for (let r = 0; r < 8; r++) if (r !== c) { const f = A[r][c] / A[c][c]; for (let k = c; k < 8; k++) A[r][k] -= f * A[c][k]; b[r] -= f * b[c]; }
    }
    const h = b.map((v, i) => v / A[i][i]);
    return (x, y) => { const z = h[6] * x + h[7] * y + 1; return [(h[0] * x + h[1] * y + h[2]) / z, (h[3] * x + h[4] * y + h[5]) / z]; };
  }
  function homographieLS(src, dst) {   // Ausgleichsrechnung für ≥ 4 Punktpaare
    if (src.length === 4) return homographie(src, dst);
    const AtA = [...Array(8)].map(() => new Array(8).fill(0)), Atb = new Array(8).fill(0);
    const zeile = (r, v) => { for (let i = 0; i < 8; i++) { Atb[i] += r[i] * v; for (let j = 0; j < 8; j++) AtA[i][j] += r[i] * r[j]; } };
    for (let i = 0; i < src.length; i++) {
      const [x, y] = src[i], [u, v] = dst[i];
      zeile([x, y, 1, 0, 0, 0, -u * x, -u * y], u); zeile([0, 0, 0, x, y, 1, -v * x, -v * y], v);
    }
    const A = AtA, b = Atb;
    for (let c = 0; c < 8; c++) {
      let p = c; for (let r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
      [A[c], A[p]] = [A[p], A[c]]; [b[c], b[p]] = [b[p], b[c]];
      if (Math.abs(A[c][c]) < 1e-12) return null;
      for (let r = 0; r < 8; r++) if (r !== c) { const f = A[r][c] / A[c][c]; for (let k = c; k < 8; k++) A[r][k] -= f * A[c][k]; b[r] -= f * b[c]; }
    }
    const h = b.map((v, i) => v / A[i][i]);
    return (x, y) => { const z = h[6] * x + h[7] * y + 1; return [(h[0] * x + h[1] * y + h[2]) / z, (h[3] * x + h[4] * y + h[5]) / z]; };
  }
  // Ausrichtungsmuster nacheinander (vom Suchmuster oben links aus) suchen und die Entzerrung jedes Mal verbessern
  function entzerren(B, src, dst, dim) {
    let f = homographie(src, dst); if (!f) return null;
    const v = (dim - 17) / 4; if (v < 2) return { f, gefunden: 0 };
    const ap = alignPos(v, dim), na = ap.length, liste = [];
    for (let i = 0; i < na; i++) for (let j = 0; j < na; j++) { if ((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0)) continue; liste.push([ap[i], ap[j]]); }
    liste.sort((a, b) => (a[0] + a[1]) - (b[0] + b[1]));
    const S = src.slice(0, 3), D = dst.slice(0, 3);
    let gefunden = 0;
    for (const [mx, my] of liste) {
      const p = f(mx + 0.5, my + 0.5), px = f(mx + 1.5, my + 0.5), py = f(mx + 0.5, my + 1.5);
      const ex = [px[0] - p[0], px[1] - p[1]], ey = [py[0] - p[0], py[1] - p[1]];
      const modul = Math.hypot(...ex);
      if (!(modul >= 1 && modul <= 60) || !(p[0] > -modul * 3 && p[1] > -modul * 3 && p[0] < B.w + modul * 3 && p[1] < B.h + modul * 3)) continue;
      const r = Math.min(120, Math.ceil(modul * (gefunden ? 2.5 : 5)));
      let best = null, bs = -1e9;
      for (let yy = Math.round(p[1] - r); yy <= p[1] + r; yy++) for (let xx = Math.round(p[0] - r); xx <= p[0] + r; xx++) {
        let sc = 0;
        for (let j = -2; j <= 2; j++) for (let i = -2; i <= 2; i++) {
          const qx = Math.floor(xx + ex[0] * i + ey[0] * j), qy = Math.floor(yy + ex[1] * i + ey[1] * j);
          if ((B.get(qx, qy) === 1) === (Math.max(Math.abs(i), Math.abs(j)) !== 1)) sc++;
        }
        const wert = sc - Math.hypot(xx - p[0], yy - p[1]) / modul * 0.6;
        if (sc >= 21 && wert > bs) { bs = wert; best = [xx, yy]; }
      }
      if (best) {
        S.push([mx + 0.5, my + 0.5]); D.push(best); gefunden++;
        if (S.length >= 4) { const g = S.length === 4 ? homographie(S, D) : homographieLS(S, D); if (g) f = g; }
      }
    }
    return { f, gefunden };
  }
  function abtasten(B, f, dim) {
    const M = [];
    for (let y = 0; y < dim; y++) {
      const z = new Uint8Array(dim);
      for (let x = 0; x < dim; x++) { const [px, py] = f(x + 0.5, y + 0.5); z[x] = B.get(Math.round(px - 0.5), Math.round(py - 0.5)); }
      M.push(z);
    }
    return M;
  }

  /* ---------- Bitmatrix → Text ---------- */
  function formatLesen(M) {
    const size = M.length; let a = 0, b = 0;
    const g1 = (i) => (i <= 5 ? M[i][8] : i === 6 ? M[7][8] : i === 7 ? M[8][8] : i === 8 ? M[8][7] : M[8][14 - i]);
    const g2 = (i) => (i < 8 ? M[8][size - 1 - i] : M[size - 15 + i][8]);
    for (let i = 0; i < 15; i++) { if (g1(i)) a |= 1 << i; if (g2(i)) b |= 1 << i; }
    let best = null, bd = 99;
    for (const f of FORMATE) { const d = Math.min(bitsAnders(f.w, a), bitsAnders(f.w, b)); if (d < bd) { bd = d; best = f; } }
    return bd <= 3 ? { ecl: ECL_BITS[best.d >> 3], maske: best.d & 7 } : null;
  }
  function versionLesen(M) {
    const size = M.length; let a = 0, b = 0;
    for (let i = 0; i < 18; i++) { const x = size - 11 + i % 3, y = Math.floor(i / 3); if (M[y][x]) a |= 1 << i; if (M[x][y]) b |= 1 << i; }
    let best = null, bd = 99;
    for (const v of VERSIONEN) { const d = Math.min(bitsAnders(v.w, a), bitsAnders(v.w, b)); if (d < bd) { bd = d; best = v; } }
    return bd <= 3 ? best.v : null;
  }
  function funktionsFelder(v) {
    const size = v * 4 + 17, F = [...Array(size)].map(() => new Uint8Array(size));
    const set = (x, y) => { if (x >= 0 && y >= 0 && x < size && y < size) F[y][x] = 1; };
    for (let i = 0; i < size; i++) { set(6, i); set(i, 6); }
    for (const [cx, cy] of [[3, 3], [size - 4, 3], [3, size - 4]]) for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) set(cx + dx, cy + dy);
    const ap = alignPos(v, size), na = ap.length;
    for (let i = 0; i < na; i++) for (let j = 0; j < na; j++) { if ((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0)) continue; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(ap[i] + dx, ap[j] + dy); }
    for (let i = 0; i <= 8; i++) { set(8, i); set(i, 8); }
    for (let i = 0; i < 8; i++) { set(size - 1 - i, 8); set(8, size - 1 - i); }
    if (v >= 7) for (let i = 0; i < 18; i++) { const a = size - 11 + i % 3, c = Math.floor(i / 3); set(a, c); set(c, a); }
    return F;
  }
  function matrixLesen(M) {
    const size = M.length; if ((size - 17) % 4 !== 0) return null;
    let v = (size - 17) / 4; if (v < 1 || v > 40) return null;
    if (v >= 7) { const vv = versionLesen(M); if (vv && vv !== v) return { andereVersion: vv }; }
    const fmt = formatLesen(M); if (!fmt || !ECC[fmt.ecl]) return null;
    const F = funktionsFelder(v), mf = MASK[fmt.maske];
    const raw = Math.floor(rawMods(v) / 8), cw = new Uint8Array(raw);
    let i = 0;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (let vert = 0; vert < size; vert++) for (let j = 0; j < 2; j++) {
        const x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - vert : vert;
        if (!F[y][x] && i < raw * 8) { const bit = M[y][x] ^ (mf(x, y) ? 1 : 0); if (bit) cw[i >>> 3] |= 0x80 >>> (i & 7); i++; }
      }
    }
    const nb = BLK[fmt.ecl][v], el = ECC[fmt.ecl][v], nShort = nb - raw % nb, shortLen = Math.floor(raw / nb);
    const bl = [...Array(nb)].map(() => new Array(shortLen + 1).fill(0));
    let k = 0;
    for (let p = 0; p < shortLen + 1; p++) for (let j = 0; j < nb; j++) { if (p !== shortLen - el || j >= nShort) bl[j][p] = cw[k++]; }
    const daten = [];
    for (let j = 0; j < nb; j++) {
      const b = j < nShort ? bl[j].slice(0, shortLen - el).concat(bl[j].slice(shortLen - el + 1)) : bl[j];
      if (rsKorrigieren(b, el) < 0) return null;
      for (let q = 0; q < b.length - el; q++) daten.push(b[q]);
    }
    return { text: segmente(daten, v), version: v, ecl: fmt.ecl };
  }
  function segmente(daten, v) {
    let pos = 0; const n = daten.length * 8;
    const lies = (k) => { let r = 0; for (let i = 0; i < k; i++) { r = (r << 1) | ((daten[pos >>> 3] >>> (7 - (pos & 7))) & 1); pos++; } return r; };
    const bytes = []; let text = '';
    const flush = () => { if (bytes.length) { try { text += new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(bytes)); } catch (e) { text += String.fromCharCode(...bytes); } bytes.length = 0; } };
    const AN = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';
    while (pos + 4 <= n) {
      const mode = lies(4);
      if (mode === 0) break;
      if (mode === 4) { const c = lies(v < 10 ? 8 : 16); for (let i = 0; i < c && pos + 8 <= n; i++) bytes.push(lies(8)); }
      else if (mode === 1) { flush(); let c = lies(v < 10 ? 10 : v < 27 ? 12 : 14); while (c >= 3) { text += String(lies(10)).padStart(3, '0'); c -= 3; } if (c === 2) text += String(lies(7)).padStart(2, '0'); else if (c === 1) text += String(lies(4)); }
      else if (mode === 2) { flush(); let c = lies(v < 10 ? 9 : v < 27 ? 11 : 13); while (c >= 2) { const x = lies(11); text += AN[Math.floor(x / 45)] + AN[x % 45]; c -= 2; } if (c === 1) text += AN[lies(6)]; }
      else if (mode === 7) { const a = lies(8); if ((a & 0x80) === 0x80) lies(8); if ((a & 0xC0) === 0xC0) lies(8); }
      else break;
    }
    flush();
    return text;
  }

  /* ---------- Gesamtablauf ---------- */
  function ausBinaer(B) {
    const kand = finderSuchen(B);
    if (kand.length < 3) return null;
    for (const t of dreierWaehlen(kand)) {
      for (const tausch of [false, true]) {
        let tr = t.a, bl = t.b;
        const kreuz = (tr.x - t.tl.x) * (bl.y - t.tl.y) - (tr.y - t.tl.y) * (bl.x - t.tl.x);
        if ((kreuz < 0) !== tausch) [tr, bl] = [bl, tr];
        const dTR = Math.hypot(tr.x - t.tl.x, tr.y - t.tl.y), dBL = Math.hypot(bl.x - t.tl.x, bl.y - t.tl.y);
        // Lauflängen wurden waagerecht/senkrecht gemessen – bei gedrehtem Code sind sie um 1/cos(Winkel) zu lang
        let w = Math.atan2(tr.y - t.tl.y, tr.x - t.tl.x); w = ((w % (Math.PI / 2)) + Math.PI / 2) % (Math.PI / 2); if (w > Math.PI / 4) w = Math.PI / 2 - w;
        const modul = t.modul * Math.cos(w);
        const schaetz = Math.round(Math.max(dTR, dBL) / modul) + 7;   // Verkürzung durch Schräglage macht Abstände nur kleiner
        const dims = [];
        const basis = Math.round((schaetz - 17) / 4);
        for (const dv of [0, -1, 1, -2, 2, -3, 3, -4]) { const v = basis + dv; if (v >= 1 && v <= 40) dims.push(v * 4 + 17); }
        const versucht = new Set();
        while (dims.length) {
          const dim = dims.shift(); if (versucht.has(dim)) continue; versucht.add(dim);
          const v = (dim - 17) / 4;
          const src = [[3.5, 3.5], [dim - 3.5, 3.5], [3.5, dim - 3.5], [dim - 3.5, dim - 3.5]];
          const dst = [[t.tl.x + 0.5, t.tl.y + 0.5], [tr.x + 0.5, tr.y + 0.5], [bl.x + 0.5, bl.y + 0.5], [tr.x + bl.x - t.tl.x + 0.5, tr.y + bl.y - t.tl.y + 0.5]];
          const ez = entzerren(B, src, dst, dim);
          if (global.QRLESEN && global.QRLESEN.debug) global.QRLESEN.debug.push({ dim, tausch, ap: ez && ez.gefunden });
          for (const f of ez ? [ez.f] : []) {
            const M = abtasten(B, f, dim);
            const r = matrixLesen(M);
            if (global.QRLESEN && global.QRLESEN.debug) global.QRLESEN.debug.push({ fmt: formatLesen(M), r: r ? (r.andereVersion || 'ok') : null });
            if (r && r.andereVersion) { dims.unshift(r.andereVersion * 4 + 17); break; }
            if (r && r.text != null) return r.text;
          }
        }
      }
    }
    return null;
  }
  function lesen(quelle) {
    let img = quelle;
    if (quelle && quelle.getContext) img = quelle.getContext('2d').getImageData(0, 0, quelle.width, quelle.height);
    if (!img || !img.data) return null;
    const groessen = [];
    const L = Math.max(img.width, img.height);
    [1000, 1600, 700, 2200].forEach((z) => { if (z < L * 1.05) groessen.push(z); });
    if (!groessen.length || L <= 2200) groessen.unshift(L);
    const gesehen = new Set();
    for (const z of groessen) {
      if (gesehen.has(z)) continue; gesehen.add(z);
      const g = z === L ? graustufen(img) : graustufen(skalieren(img, z / L));
      const t = ausBinaer(binaer(g));
      if (t != null) return t;
    }
    return null;
  }
  function skalieren(img, f) {
    const w = Math.max(1, Math.round(img.width * f)), h = Math.max(1, Math.round(img.height * f));
    if (typeof document !== 'undefined') {
      const c1 = document.createElement('canvas'); c1.width = img.width; c1.height = img.height; c1.getContext('2d').putImageData(img, 0, 0);
      const c2 = document.createElement('canvas'); c2.width = w; c2.height = h; const x = c2.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(c1, 0, 0, w, h);
      return x.getImageData(0, 0, w, h);
    }
    const d = new Uint8ClampedArray(w * h * 4);   // ohne DOM (Tests): nächster Nachbar
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const sx = Math.min(img.width - 1, Math.floor(x / f)), sy = Math.min(img.height - 1, Math.floor(y / f)); const s = (sy * img.width + sx) * 4, t = (y * w + x) * 4; d[t] = img.data[s]; d[t + 1] = img.data[s + 1]; d[t + 2] = img.data[s + 2]; d[t + 3] = 255; }
    return { width: w, height: h, data: d };
  }
  global.QRLESEN = { lesen, _intern: { rsKorrigieren, matrixLesen } };
})(typeof window !== 'undefined' ? window : globalThis);
