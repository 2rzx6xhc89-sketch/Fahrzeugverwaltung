const CACHE_NAME = 'einsatzverwaltung-v270';
const SHELL_FILES = [
  '/',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/qrlesen.js',
  '/gemeinsam.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      // nur eigene Caches aufräumen
      Promise.all(names.filter((n) => n !== CACHE_NAME && (n.startsWith('einsatzverwaltung-') || n.startsWith('fahrzeugverwaltung-'))).map((n) => caches.delete(n)))
    )
  );
  self.clients.claim();
});

// Nur die App-Huelle (HTML/Manifest/Icons) aus dem Cache bedienen, wenn offline -
// alle Live-Daten laufen ueber WebSocket und werden hier nicht angefasst.
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // fremde Dienste (Satellitenbild, Wetter) nie cachen
  if (url.pathname.startsWith('/ws')) return;
  if (url.pathname === '/config' || url.pathname.startsWith('/api/')) return; // Live-Daten nie aus dem Cache
  if (url.pathname.startsWith('/tiles/')) return; // Kartenkacheln speichert der Pi und der Browser-Cache
  if (url.pathname.startsWith('/monitor')) return; // Alarmmonitor: immer live

  event.respondWith(
    fetch(req)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {});
        return res;
      })
      .catch(() => caches.match(req).then((cached) => cached || (req.mode === 'navigate' && !url.pathname.startsWith('/uebung') ? caches.match('/') : Response.error())))
  );
});
