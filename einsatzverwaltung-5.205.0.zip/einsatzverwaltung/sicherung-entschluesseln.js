#!/usr/bin/env node
/* Entschlüsselt eine verschlüsselte Datensicherung der Einsatzverwaltung (ab 3.29).
   Aufruf:  node sicherung-entschluesseln.js <Sicherungsordner oder Datei.enc> <Zielordner>
   Passwort: wird abgefragt (unsichtbar) oder aus der Umgebungsvariable SICHERUNG_PASSWORT gelesen.
   Format je Datei: „EVSICH01“ | Salz (16) | IV (12) | Daten (AES-256-GCM) | Prüfwert (16), Schlüssel = scrypt(Passwort, Salz). */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MAGIC = Buffer.from('EVSICH01');
const keyCache = new Map();
function schluessel(pw, salt) {
  const k = salt.toString('hex');
  if (!keyCache.has(k)) keyCache.set(k, crypto.scryptSync(pw, salt, 32, { N: 32768, r: 8, p: 1, maxmem: 96 * 1024 * 1024 }));
  return keyCache.get(k);
}
function entschluesseln(buf, pw) {
  if (buf.length < 52 || !buf.subarray(0, 8).equals(MAGIC)) throw new Error('keine verschlüsselte Sicherungsdatei');
  const salt = buf.subarray(8, 24), iv = buf.subarray(24, 36), tag = buf.subarray(buf.length - 16);
  const d = crypto.createDecipheriv('aes-256-gcm', schluessel(pw, salt), iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(buf.subarray(36, buf.length - 16)), d.final()]);
}

function passwortFragen() {
  if (process.env.SICHERUNG_PASSWORT) return Promise.resolve(process.env.SICHERUNG_PASSWORT);
  return new Promise((resolve) => {
    const ein = process.stdin;
    process.stdout.write('Sicherungs-Passwort: ');
    if (!ein.isTTY) {   // Passwort per Pipe
      let s = '';
      ein.setEncoding('utf8');
      ein.on('data', (c) => { s += c; });
      ein.on('end', () => { process.stdout.write('\n'); resolve(s.replace(/\r?\n$/, '')); });
      return;
    }
    let s = '';
    ein.setRawMode(true); ein.resume(); ein.setEncoding('utf8');
    const weiter = (c) => {
      for (const z of c) {
        if (z === '\r' || z === '\n' || z === '\u0004') { ein.setRawMode(false); ein.pause(); ein.removeListener('data', weiter); process.stdout.write('\n'); resolve(s); return; }
        if (z === '\u0003') { process.stdout.write('\n'); process.exit(130); }
        if (z === '\u007f' || z === '\b') s = s.slice(0, -1); else s += z;
      }
    };
    ein.on('data', weiter);
  });
}

function dateienSammeln(p, basis, liste) {
  const st = fs.statSync(p);
  if (st.isFile()) { liste.push({ quelle: p, rel: path.basename(p) }); return liste; }
  fs.readdirSync(p, { withFileTypes: true }).forEach((d) => {
    const q = path.join(p, d.name);
    if (d.isDirectory()) dateienSammeln(q, basis, liste);
    else if (d.isFile()) liste.push({ quelle: q, rel: path.relative(basis, q) });
  });
  return liste;
}

(async () => {
  const [quelle, ziel] = process.argv.slice(2);
  if (!quelle || !ziel) {
    console.log('Aufruf: node sicherung-entschluesseln.js <Sicherungsordner oder Datei.enc> <Zielordner>');
    process.exit(1);
  }
  if (!fs.existsSync(quelle)) { console.error(`Nicht gefunden: ${quelle}`); process.exit(1); }
  const basis = fs.statSync(quelle).isDirectory() ? quelle : path.dirname(quelle);
  const dateien = dateienSammeln(quelle, basis, []).filter((d) => d.rel.endsWith('.enc') && path.basename(d.rel) !== 'passwort-pruefung.enc');
  if (!dateien.length) { console.error('Keine verschlüsselten Dateien (.enc) gefunden.'); process.exit(1); }
  const pw = await passwortFragen();
  if (!pw) { console.error('Kein Passwort eingegeben.'); process.exit(1); }

  const pruef = path.join(basis, 'passwort-pruefung.enc');
  if (fs.existsSync(pruef)) {
    let passt = false;
    try { passt = entschluesseln(fs.readFileSync(pruef), pw).toString() === 'EV-SICHERUNG'; } catch (e) { passt = false; }
    if (!passt) console.log('Hinweis: Das Passwort passt nicht zum aktuellen Sicherungs-Passwort. Ältere Tagesstände werden trotzdem versucht.');
  }

  let ok = 0; const fehler = [];
  dateien.forEach((d) => {
    try {
      const klar = entschluesseln(fs.readFileSync(d.quelle), pw);
      const z = path.join(ziel, d.rel.replace(/\.enc$/, ''));
      fs.mkdirSync(path.dirname(z), { recursive: true });
      fs.writeFileSync(z, klar, { mode: 0o600 });
      ok += 1;
    } catch (e) {
      fehler.push(`${d.rel}: ${/auth|unable|Unsupported state/i.test(e.message) ? 'falsches Passwort oder Datei beschädigt' : e.message}`);
    }
  });
  console.log(`${ok} von ${dateien.length} Dateien entschlüsselt nach ${path.resolve(ziel)}`);
  if (fehler.length) {
    console.log(`${fehler.length} Dateien nicht entschlüsselt:`);
    fehler.slice(0, 20).forEach((f) => console.log(`  ${f}`));
    if (fehler.length > 20) console.log(`  … und ${fehler.length - 20} weitere`);
  }
  process.exit(ok ? 0 : 2);
})();
